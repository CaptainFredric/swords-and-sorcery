#include <math.h>
#include <stdint.h>

static inline float clampf(float x, float a, float b) {
    return x < a ? a : (x > b ? b : x);
}

void rasterize_and_shade(
    int n_tris,
    const int32_t* valid,
    const int32_t* xmin, const int32_t* xmax,
    const int32_t* ymin, const int32_t* ymax,
    const float* denom,
    const float* x0, const float* y0, const float* z0,
    const float* x1, const float* y1, const float* z1,
    const float* x2, const float* y2, const float* z2,
    const int32_t* t0, const int32_t* t1, const int32_t* t2,
    const float* inv_z,
    const float* pos,
    const float* norm,
    const float* v_color,
    const float* v_mr,
    const float* v_emit,
    const float* cam_pos,
    int is_ortho, int img_w, int img_h,
    uint8_t bg_r, uint8_t bg_g, uint8_t bg_b,
    float* zbuf,
    int32_t* tri_id_buf,
    float* bary_u_buf,
    float* bary_v_buf,
    uint8_t* out_img
) {
    int total_pix = img_w * img_h;
    #pragma omp parallel for schedule(static)
    for (int i = 0; i < total_pix; ++i) {
        zbuf[i] = 1e30f;
        tri_id_buf[i] = -1;
        out_img[i * 3 + 0] = bg_r;
        out_img[i * 3 + 1] = bg_g;
        out_img[i * 3 + 2] = bg_b;
    }

    for (int ti = 0; ti < n_tris; ++ti) {
        if (!valid[ti]) continue;
        int xa = xmin[ti], xb = xmax[ti];
        int ya = ymin[ti], yb = ymax[ti];
        float d_inv = 1.0f / denom[ti];
        float X0 = x0[ti], Y0 = y0[ti], Z0 = z0[ti];
        float X1 = x1[ti], Y1 = y1[ti], Z1 = z1[ti];
        float X2 = x2[ti], Y2 = y2[ti], Z2 = z2[ti];
        float iz0 = inv_z[t0[ti]], iz1 = inv_z[t1[ti]], iz2 = inv_z[t2[ti]];

        for (int py_i = ya; py_i <= yb; ++py_i) {
            float py = (float)py_i + 0.5f;
            int row_off = py_i * img_w;
            for (int px_i = xa; px_i <= xb; ++px_i) {
                float px = (float)px_i + 0.5f;
                float w0 = ((Y1 - Y2) * (px - X2) + (X2 - X1) * (py - Y2)) * d_inv;
                float w1 = ((Y2 - Y0) * (px - X2) + (X0 - X2) * (py - Y2)) * d_inv;
                float w2 = 1.0f - w0 - w1;
                if (w0 >= -1e-4f && w1 >= -1e-4f && w2 >= -1e-4f) {
                    float z_pix;
                    if (is_ortho) {
                        z_pix = w0 * Z0 + w1 * Z1 + w2 * Z2;
                    } else {
                        float iz = w0 * iz0 + w1 * iz1 + w2 * iz2;
                        z_pix = 1.0f / (iz > 1e-6f ? iz : 1e-6f);
                    }
                    int idx = row_off + px_i;
                    if (z_pix < zbuf[idx]) {
                        zbuf[idx] = z_pix;
                        tri_id_buf[idx] = ti;
                        bary_u_buf[idx] = w0;
                        bary_v_buf[idx] = w1;
                    }
                }
            }
        }
    }

    const float l1x = 0.4535f, l1y = 0.7256f, l1z = 0.5173f;
    const float l2x = -0.6804f, l2y = 0.3969f, l2z = 0.6160f;
    const float l3x = 0.0f,    l3y = 0.2673f, l3z = -0.9636f;

    #pragma omp parallel for schedule(static)
    for (int idx = 0; idx < total_pix; ++idx) {
        int ti = tri_id_buf[idx];
        if (ti < 0) continue;
        int i0 = t0[ti], i1 = t1[ti], i2 = t2[ti];
        float w0 = bary_u_buf[idx];
        float w1 = bary_v_buf[idx];
        float w2 = 1.0f - w0 - w1;

        if (!is_ortho) {
            float c0 = w0 * inv_z[i0];
            float c1 = w1 * inv_z[i1];
            float c2 = w2 * inv_z[i2];
            float csum = c0 + c1 + c2;
            if (csum > 1e-8f) {
                float inv_s = 1.0f / csum;
                w0 = c0 * inv_s;
                w1 = c1 * inv_s;
                w2 = c2 * inv_s;
            }
        }

        float nx = w0 * norm[i0*3+0] + w1 * norm[i1*3+0] + w2 * norm[i2*3+0];
        float ny = w0 * norm[i0*3+1] + w1 * norm[i1*3+1] + w2 * norm[i2*3+1];
        float nz = w0 * norm[i0*3+2] + w1 * norm[i1*3+2] + w2 * norm[i2*3+2];
        float nl = sqrtf(nx*nx + ny*ny + nz*nz);
        if (nl > 1e-8f) { nx /= nl; ny /= nl; nz /= nl; }

        float px = w0 * pos[i0*3+0] + w1 * pos[i1*3+0] + w2 * pos[i2*3+0];
        float py = w0 * pos[i0*3+1] + w1 * pos[i1*3+1] + w2 * pos[i2*3+1];
        float pz = w0 * pos[i0*3+2] + w1 * pos[i1*3+2] + w2 * pos[i2*3+2];

        float vx = cam_pos[0] - px;
        float vy = cam_pos[1] - py;
        float vz = cam_pos[2] - pz;
        float vl = sqrtf(vx*vx + vy*vy + vz*vz);
        if (vl > 1e-8f) { vx /= vl; vy /= vl; vz /= vl; }

        if (nx*vx + ny*vy + nz*vz < 0.0f) {
            nx = -nx; ny = -ny; nz = -nz;
        }

        float nd1 = clampf(nx*l1x + ny*l1y + nz*l1z, 0.0f, 1.0f);
        float nd2 = clampf(nx*l2x + ny*l2y + nz*l2z, 0.0f, 1.0f);
        float nd3 = clampf(nx*l3x + ny*l3y + nz*l3z, 0.0f, 1.0f);

        float hx = l1x + vx, hy = l1y + vy, hz = l1z + vz;
        float hl = sqrtf(hx*hx + hy*hy + hz*hz);
        if (hl > 1e-8f) { hx /= hl; hy /= hl; hz /= hl; }
        float ndh = clampf(nx*hx + ny*hy + nz*hz, 0.0f, 1.0f);

        float br = w0 * v_color[i0*3+0] + w1 * v_color[i1*3+0] + w2 * v_color[i2*3+0];
        float bg = w0 * v_color[i0*3+1] + w1 * v_color[i1*3+1] + w2 * v_color[i2*3+1];
        float bb = w0 * v_color[i0*3+2] + w1 * v_color[i1*3+2] + w2 * v_color[i2*3+2];

        float rough = clampf(w0 * v_mr[i0*3+1] + w1 * v_mr[i1*3+1] + w2 * v_mr[i2*3+1], 0.14f, 1.0f);
        float metal = clampf(w0 * v_mr[i0*3+2] + w1 * v_mr[i1*3+2] + w2 * v_mr[i2*3+2], 0.0f, 1.0f);

        float er = w0 * v_emit[i0*3+0] + w1 * v_emit[i1*3+0] + w2 * v_emit[i2*3+0];
        float eg = w0 * v_emit[i0*3+1] + w1 * v_emit[i1*3+1] + w2 * v_emit[i2*3+1];
        float eb = w0 * v_emit[i0*3+2] + w1 * v_emit[i1*3+2] + w2 * v_emit[i2*3+2];

        float shin = clampf(2.0f / (rough*rough + 0.04f), 4.0f, 48.0f);
        float sp_pow = powf(ndh, shin) * 0.55f * (1.1f - 0.6f * rough);
        float diff = 0.50f + 0.52f * nd1 + 0.22f * nd2 + 0.14f * nd3;
        float m_atten = 1.0f - 0.20f * metal;

        float cr = br * m_atten * diff + sp_pow * (0.04f * (1.0f - metal) + br * metal) + er * 1.25f;
        float cg = bg * m_atten * diff + sp_pow * (0.04f * (1.0f - metal) + bg * metal) + eg * 1.25f;
        float cb = bb * m_atten * diff + sp_pow * (0.04f * (1.0f - metal) + bb * metal) + eb * 1.25f;

        out_img[idx*3+0] = (uint8_t)clampf(cr * 255.0f, 0.0f, 255.0f);
        out_img[idx*3+1] = (uint8_t)clampf(cg * 255.0f, 0.0f, 255.0f);
        out_img[idx*3+2] = (uint8_t)clampf(cb * 255.0f, 0.0f, 255.0f);
    }
}
