#!/usr/bin/env python3
"""
SO-FIST-ICATION v2.4 — Crisp Faceted Armored Fist & Wheels + Rearward Axle Relocation (`Z = -0.820 m`)
======================================================================================================
Preserves the existing v2.2 files (`so-fist-ication-refined.glb`, `SoFist-crafted-refined.blend`,
`soFistGeometry.mjs`) untouched for rollback, and produces the v2.4 review candidate:
  - `so-fist-ication-v24-review.glb`
  - `SoFist-v24-runtime-source.blend`
  - `soFistGeometry_v24.mjs`
"""
import sys, os, io, json, math, struct, ctypes, hashlib
from pathlib import Path
from collections import defaultdict
import numpy as np
from PIL import Image

OUT_DIR = Path("/working_dir/c_63a1f8c151a6582d/artifacts/file_generation/ttl=63d/output")
WORK_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT_DIR))
sys.path.insert(0, str(WORK_DIR))

import blend_io
from build_sofist_v2_1_candidate import (
    CleanMeshBuilder,
    read_raw_mesh_gltf,
    RETIMED_FRAMES_26,
    update_blend_mesh_from_gltf_arrays,
)
from build_sofist_v2_2_salvaged import (
    SALVAGED_LOCATORS_1X,
    retime_1x_fcurves_only,
    smooth_1x_piston_or_collar,
)
from export_sofist_v2_1_glb import clean_prefix

SO_FIST_SCALE = 2.85
REAR_AXLE_Z_OLD = -0.420
REAR_AXLE_Z_NEW = -0.820 # Moved 0.400m rearward (-1.140m world at 2.85x) so wheelbase is 1.145m local / 3.2633m world!
FRONT_AXLE_Z    = +0.325

# Clean PBR Material Definitions:
# Removes the old AI-baked normalTexture (index 2) from solid metal/walnut/wheel materials so old normal-map
# noise never smears across our newly constructed faceted gauntlet, wheels, and carriage beams!
MATERIAL_DEFS_V24 = [
    ("MARam candidate chains.003",       {"baseColorFactor": [0.055, 0.064, 0.075, 1.0], "metallicFactor": 0.78, "roughnessFactor": 0.52}),
    ("MARam candidate cloth.003",        {"baseColorTexture": 0, "metallicRoughnessTexture": 1, "normalTexture": 2, "doubleSided": True}),
    ("MARam candidate collar.003",       {"baseColorFactor": [0.320, 0.205, 0.082, 1.0], "metallicFactor": 0.76, "roughnessFactor": 0.38, "emissiveTexture": 3, "emissiveFactor": [1.0, 1.0, 1.0]}),
    ("MARam candidate mechanism.003",    {"baseColorFactor": [0.115, 0.140, 0.170, 1.0], "metallicFactor": 0.78, "roughnessFactor": 0.44}),
    ("MARam candidate timber.003",       {"baseColorTexture": 0, "metallicRoughnessTexture": 1}),
    ("MARam control grip leather.001",   {"baseColorFactor": [0.055, 0.028, 0.015, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.88}),
    ("MARam forged frame walnut.003",    {"baseColorFactor": [0.135, 0.068, 0.030, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.82}),
    ("MARam region brass.003",           {"baseColorFactor": [0.380, 0.245, 0.090, 1.0], "metallicFactor": 0.78, "roughnessFactor": 0.36}),
    ("MARam region iron.003",            {"baseColorFactor": [0.052, 0.060, 0.072, 1.0], "metallicFactor": 0.68, "roughnessFactor": 0.54}),
    ("MARam region steel.003",           {"baseColorFactor": [0.275, 0.305, 0.340, 1.0], "metallicFactor": 0.72, "roughnessFactor": 0.38}),
    ("MARam region timber.003",          {"baseColorFactor": [0.165, 0.082, 0.036, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.84}),
    ("MARam region timberLight.003",     {"baseColorFactor": [0.240, 0.125, 0.055, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.82}),
    ("MARam wheel bronze.003",           {"baseColorFactor": [0.350, 0.220, 0.080, 1.0], "metallicFactor": 0.76, "roughnessFactor": 0.38}),
    ("MARam wheel iron.003",             {"baseColorFactor": [0.068, 0.080, 0.095, 1.0], "metallicFactor": 0.72, "roughnessFactor": 0.48}),
    ("MARam wheel timber detail.003",    {"baseColorFactor": [0.165, 0.085, 0.038, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.80}),
]

# =============================================================================
# 1. PART B1: ARCHITECTURAL LOW-POLY ARMORED FIST (`MEArmored_Fist_Mesh.003`)
# =============================================================================
# Material slots on `MEArmored_Fist_Mesh.003`:
#   0: `MARam region steel.003` (Honed faceted steel gauntlet, knuckles, phalanx plates, thumb armor)
#   1: `MARam region iron.003`  (Dark forged-iron recessed armor seam channels, palm anvil cavity, wrist clevis)
#   2: `MARam region brass.003` (Burnished brass wrist collar ring, knuckle-guard strap, dorsal crest, hex rivets)

def build_crisp_armored_fist_mesh():
    """
    Constructs `MEArmored_Fist_Mesh.003` as an unmistakably readable, solid, fabricated Castleward
    low-poly armored gauntlet inside the exact authoritative impact envelope:
      `X ∈ [-0.252, +0.242] m`, `Y ∈ [-0.205, +0.208] m`, `Z ∈ [+0.005, +0.4310] m`
      (preserving `Z_tip = +0.9510 m` rest / `+1.3960 m` extended with 0.000 m difference!).
    Features:
      - 12-faceted forged-iron & burnished-brass wrist clevis collar (`Z = +0.005..+0.095m`)
      - Multi-plane sloped dorsal gauntlet carapace with 3 overlapping steel lames, raised central ridge,
        recessed dark-iron armor seams, and a heavy riveted brass gauntlet bridge (`Z = +0.085..+0.265m`)
      - 4 distinct pyramidal/faceted knuckle crowns (`X = -0.165, -0.055, +0.055, +0.165m`) with brass trim
      - 4 distinct curled, multi-segment armored fingers (each with a sloped proximal phalanx lame, a vertical
        blunt-impact middle phalanx lame at `Z = +0.4310m`, a curled distal phalanx tucked into the palm anvil,
        and a raised dorsal finger ridge so each finger reads as forged plate armor rather than a flat box!)
      - A prominent articulated armored thumb wrapping from the lower `-X` cheek across the curled fingers.
    """
    mb = CleanMeshBuilder()
    MAT_STEEL = 0
    MAT_IRON  = 1
    MAT_BRASS = 2

    # 1. Rear 12-Faceted Wrist Clevis Socket & Riveted Brass Collar (`Z = +0.005..+0.098m`)
    mb.add_cylinder([0.0, 0.0, +0.005], [0.0, 0.0, +0.098], 0.168, mat_idx=MAT_IRON, segs=12)
    mb.add_cylinder([0.0, 0.0, +0.020], [0.0, 0.0, +0.074], 0.178, mat_idx=MAT_BRASS, segs=12)
    for k in range(8):
        ang = k * (math.pi / 4.0) + (math.pi / 8.0)
        ca, sa = math.cos(ang), math.sin(ang)
        mb.add_chamfered_beam([0.166*ca, 0.166*sa, +0.014], [0.166*ca, 0.166*sa, +0.092], 0.040, 0.034, mat_idx=MAT_BRASS if k % 2 == 0 else MAT_IRON, chamfer=0.005)

    # 2. Recessed Dark-Iron Core Block & Palm Anvil Cavity (`Z = +0.088..+0.340m`)
    #    Creates deep, high-contrast dark-iron channels between the 4 fingers and between dorsal armor lames!
    mb.add_box(-0.205, +0.205, -0.145, +0.145, +0.088, +0.340, mat_idx=MAT_IRON, chamfer=0.015)
    mb.add_box(-0.188, +0.188, -0.195, -0.075, +0.105, +0.265, mat_idx=MAT_IRON, chamfer=0.012)
    mb.add_box(-0.160, +0.160, -0.202, -0.148, +0.125, +0.240, mat_idx=MAT_BRASS, chamfer=0.006)

    # 3. Sloped Multi-Plane Dorsal Hand Carapace (2 Overlapping Steel Lames + Side Cheek Plates, `Z = +0.088..+0.265m`)
    #    - Rear dorsal lame (`Z = +0.088..+0.175m`)
    mb.add_chamfered_beam([0.000, +0.156, +0.088], [0.000, +0.174, +0.176], 0.125, 0.052, mat_idx=MAT_STEEL, chamfer=0.010)
    #    - Forward dorsal lame (`Z = +0.185..+0.268m`)
    mb.add_chamfered_beam([0.000, +0.168, +0.184], [0.000, +0.184, +0.268], 0.135, 0.054, mat_idx=MAT_STEEL, chamfer=0.010)
    #    - Raised central gothic dorsal spine ridge (`X ∈ [-0.024, +0.024]`)
    mb.add_chamfered_beam([0.000, +0.178, +0.092], [0.000, +0.198, +0.265], 0.046, 0.036, mat_idx=MAT_BRASS, chamfer=0.006)

    for sx in (-1.0, +1.0):
        # Sloped left/right dorsal metacarpal plates (`|X| = 0.065..0.175m`, `Y` slopes down outward!)
        mb.add_chamfered_beam([sx*0.122, +0.142, +0.090], [sx*0.128, +0.158, +0.176], 0.105, 0.050, mat_idx=MAT_STEEL, chamfer=0.009)
        mb.add_chamfered_beam([sx*0.126, +0.152, +0.184], [sx*0.132, +0.168, +0.268], 0.108, 0.052, mat_idx=MAT_STEEL, chamfer=0.009)
        # Angled side gauntlet cuff & cheek plates (`|X| = 0.175..0.238m`)
        mb.add_chamfered_beam([sx*0.198, +0.055, +0.092], [sx*0.212, +0.072, +0.270], 0.064, 0.155, mat_idx=MAT_STEEL, chamfer=0.010)
        mb.add_chamfered_beam([sx*0.200, -0.072, +0.095], [sx*0.208, -0.082, +0.255], 0.060, 0.110, mat_idx=MAT_STEEL, chamfer=0.009)

    # Transverse Burnished-Brass Dorsal Strap & Side Buckles (`Z = +0.162..+0.198m`)
    mb.add_box(-0.226, +0.226, +0.118, +0.188, +0.162, +0.198, mat_idx=MAT_BRASS, chamfer=0.007)
    for sx in (-1.0, +1.0):
        mb.add_box(sx*0.220 - 0.016, sx*0.220 + 0.016, -0.115, +0.155, +0.162, +0.198, mat_idx=MAT_BRASS, chamfer=0.005)

    # 4. Four Distinct, Articulated Armored Fingers & Prominent Faceted Knuckle Crowns
    #    Notice the 18mm clear separation between adjacent finger widths (`fw = 0.092m` on `0.110m` pitch)
    #    so dark-iron recessed channels (`MAT_IRON`) clearly separate Index, Middle, Ring, and Little fingers!
    finger_specs = [
        # (fx, fw, y_knuck, z_knuck, z_front, y_mid_top, y_bot)
        (-0.165, 0.090, +0.196, +0.295, +0.426, +0.088, -0.125), # Index finger (`-X`)
        (-0.055, 0.094, +0.208, +0.305, +0.431, +0.096, -0.130), # Middle finger (peak `Z = +0.4310m`)
        (+0.055, 0.094, +0.202, +0.300, +0.429, +0.092, -0.128), # Ring finger
        (+0.165, 0.088, +0.188, +0.288, +0.420, +0.080, -0.118), # Little finger (`+X`)
    ]
    # Recessed dark-iron & brass knuckle-valley bar across `Z = +0.255..+0.325m`
    mb.add_box(-0.218, +0.218, +0.075, +0.158, +0.258, +0.325, mat_idx=MAT_IRON, chamfer=0.008)

    for f_idx, (fx, fw, y_knuck, z_knuck, z_front, y_mid_top, y_bot) in enumerate(finger_specs):
        hw = fw * 0.5
        # A. Prominent Pyramidal/Beveled Knuckle Crown (`Z = +0.252..+0.342m`, `Y = +0.115..y_knuck`)
        mb.add_box(fx - hw, fx + hw, +0.115, y_knuck, z_knuck - 0.045, z_knuck + 0.040, mat_idx=MAT_STEEL, chamfer=0.012)
        mb.add_box(fx - hw*0.68, fx + hw*0.68, y_knuck - 0.022, y_knuck + 0.008, z_knuck - 0.028, z_knuck + 0.028, mat_idx=MAT_BRASS, chamfer=0.006)

        # B. Sloped Proximal Phalanx Lame (`(fx, y_knuck-0.015, z_knuck+0.015)` -> `(fx, y_mid_top, z_front-0.012)`)
        #    Slopes forward and downward at ~32 degrees like a true clenched gauntlet finger!
        mb.add_chamfered_beam([fx, y_knuck - 0.018, z_knuck + 0.010], [fx, y_mid_top, z_front - 0.014], fw, 0.068, mat_idx=MAT_STEEL, chamfer=0.010)
        #    Raised central gothic finger-knuckle ridge along the proximal phalanx
        mb.add_chamfered_beam([fx, y_knuck - 0.008, z_knuck + 0.015], [fx, y_mid_top + 0.010, z_front - 0.010], fw * 0.44, 0.052, mat_idx=MAT_STEEL, chamfer=0.006)

        # C. Forward Proximal-Middle Interphalangeal Knuckle Band (`Y = y_mid_top - 0.035 .. y_mid_top + 0.018`, `Z = z_front - 0.065 .. z_front`)
        mb.add_box(fx - hw, fx + hw, y_mid_top - 0.035, y_mid_top + 0.016, z_front - 0.068, z_front, mat_idx=MAT_STEEL, chamfer=0.010)
        mb.add_box(fx - hw*0.88, fx + hw*0.88, y_mid_top - 0.042, y_mid_top - 0.022, z_front - 0.072, z_front + 0.001, mat_idx=MAT_BRASS, chamfer=0.004)

        # D. Vertical Blunt-Impact Middle Phalanx Lame (`Y = y_bot .. y_mid_top - 0.040`, `Z = z_front - 0.078 .. z_front`)
        #    Forms the main vertical planar battering surface of the clenched fist, with a recessed dark-iron joint at mid-height!
        y_joint = 0.5 * (y_bot + (y_mid_top - 0.040))
        mb.add_box(fx - hw, fx + hw, y_joint + 0.006, y_mid_top - 0.038, z_front - 0.075, z_front, mat_idx=MAT_STEEL, chamfer=0.009)
        mb.add_box(fx - hw*0.92, fx + hw*0.92, y_joint - 0.008, y_joint + 0.008, z_front - 0.080, z_front - 0.005, mat_idx=MAT_IRON, chamfer=0.003)
        mb.add_box(fx - hw, fx + hw, y_bot, y_joint - 0.006, z_front - 0.082, z_front - 0.004, mat_idx=MAT_STEEL, chamfer=0.009)
        # Raised central vertical ridge on the middle phalanx impact plate
        mb.add_box(fx - hw*0.38, fx + hw*0.38, y_bot + 0.012, y_mid_top - 0.045, z_front - 0.040, z_front + 0.001, mat_idx=MAT_STEEL, chamfer=0.005)

        # E. Curled Distal Phalanx Finger-Tip Plate (`(fx, y_bot+0.015, z_front-0.035)` -> `(fx, -0.188, +0.215)`)
        mb.add_chamfered_beam([fx, y_bot + 0.015, z_front - 0.038], [fx, -0.185, +0.220], fw * 0.94, 0.062, mat_idx=MAT_STEEL, chamfer=0.008)
        mb.add_box(fx - hw*0.82, fx + hw*0.82, -0.198, -0.148, +0.202, +0.258, mat_idx=MAT_BRASS, chamfer=0.005)

    # 5. Articulated Locked Armored Thumb Assembly (`X ∈ [-0.252, -0.065] m`, `Y ∈ [-0.190, +0.045] m`, `Z ∈ [+0.125, +0.382] m`)
    #    - Thumb Base Plate emerging from lower-left (`-X`) cheek
    mb.add_chamfered_beam([-0.212, +0.010, +0.130], [-0.232, -0.055, +0.268], 0.072, 0.102, mat_idx=MAT_STEEL, chamfer=0.010)
    mb.add_box(-0.252, -0.182, -0.082, +0.022, +0.238, +0.302, mat_idx=MAT_BRASS, chamfer=0.007)
    #    - Thumb Proximal Segment angling across Index finger base
    mb.add_chamfered_beam([-0.230, -0.105, +0.275], [-0.145, -0.145, +0.352], 0.076, 0.082, mat_idx=MAT_STEEL, chamfer=0.010)
    #    - Thumb Distal Segment & Brass Nail-Guard locking across Middle finger base
    mb.add_chamfered_beam([-0.152, -0.145, +0.348], [-0.065, -0.148, +0.342], 0.072, 0.076, mat_idx=MAT_STEEL, chamfer=0.009)
    mb.add_box(-0.162, -0.122, -0.188, -0.102, +0.305, +0.382, mat_idx=MAT_BRASS, chamfer=0.006)

    verts = np.array(mb.verts, dtype=np.float32)
    poly_offsets = [0]
    corner_verts, uv_map = [], []
    for pv, puv in zip(mb.poly_verts, mb.poly_uvs):
        corner_verts.extend(pv); uv_map.extend(puv); poly_offsets.append(len(corner_verts))
    return (
        verts,
        np.array(poly_offsets, dtype=np.int32),
        np.array(corner_verts, dtype=np.int32),
        np.array(uv_map, dtype=np.float32),
        np.array(mb.poly_mats, dtype=np.int32),
    )

# =============================================================================
# 2. PART B2: CRISP FACETED LOW-POLY SIEGE WHEELS (`MEWheel_FL/FR/RL/RR_Mesh.004`)
# =============================================================================
# Material slots on `MEWheel_*_Mesh.004`:
#   0: `MARam wheel timber detail.003` (Oak felloe ring & 8 mortised oak spokes)
#   1: `MARam wheel iron.003`          (24-segment circular iron tire tread, bevels, spoke collars, linchpin)
#   2: `MARam wheel bronze.003`        (12-sided cast-bronze nave hub & inner felloe stiffening ring)

def build_crisp_siege_wheel_mesh(side_sign: float):
    """
    Constructs a clean, deliberately faceted Castleward low-poly siege wheel at exact `1.0x` scale:
      - Outer radius `R = 0.1650 m` local (`0.47025 m` world at `2.85x`), width `0.116 m` (`X ∈ [-0.058, +0.058] m`).
      - 24-segment circular forged-iron tire tread (`R = 0.148..0.1650 m`, `mat = 1`) with crisp `6 mm` side bevels
        and 12 riveted iron strake plates on the outer sidewalls.
      - 24-segment faceted oak felloe ring (`R = 0.110..0.148 m`, `X ∈ [-0.048, +0.048] m`, `mat = 0`) with an
        inner bronze stiffening band (`R = 0.103..0.110 m`, `mat = 2`).
      - 8 distinct mortised octagonal oak spokes (`R = 0.048..0.106 m`, `mat = 0`) with forged-iron spoke collars (`mat = 1`).
      - 12-faceted cast-bronze nave hub (`R = 0.056 m`, `X ∈ [-0.062, +0.062] m`, `mat = 2`) and iron linchpin cap (`mat = 1`).
    """
    mb = CleanMeshBuilder()
    MAT_TIMBER = 0
    MAT_IRON   = 1
    MAT_BRONZE = 2

    n_seg = 24
    angs = [2.0 * math.pi * i / n_seg for i in range(n_seg)]

    def add_annular_ring(r_in, r_out, x_in, x_out, mat_idx):
        """Builds a 24-segment concentric ring with front (-X), back (+X), inner, and outer quad faces."""
        for i in range(n_seg):
            a0, a1 = angs[i], angs[(i + 1) % n_seg]
            c0, s0 = math.cos(a0), math.sin(a0)
            c1, s1 = math.cos(a1), math.sin(a1)
            # 4 vertices on -x_in..+x_in (inner radius) and 4 on -x_out..+x_out (outer radius)
            p_in_l0  = [-x_in,  r_in * c0,  r_in * s0]
            p_in_l1  = [-x_in,  r_in * c1,  r_in * s1]
            p_in_r0  = [+x_in,  r_in * c0,  r_in * s0]
            p_in_r1  = [+x_in,  r_in * c1,  r_in * s1]
            p_out_l0 = [-x_out, r_out * c0, r_out * s0]
            p_out_l1 = [-x_out, r_out * c1, r_out * s1]
            p_out_r0 = [+x_out, r_out * c0, r_out * s0]
            p_out_r1 = [+x_out, r_out * c1, r_out * s1]
            # Outer circumferential face (+r)
            mb.add_quad(p_out_l0, p_out_r0, p_out_r1, p_out_l1, mat_idx)
            # Inner circumferential face (-r)
            mb.add_quad(p_in_r0, p_in_l0, p_in_l1, p_in_r1, mat_idx)
            # Left sidewall (-X)
            mb.add_quad(p_in_l0, p_out_l0, p_out_l1, p_in_l1, mat_idx)
            # Right sidewall (+X)
            mb.add_quad(p_out_r0, p_in_r0, p_in_r1, p_out_r1, mat_idx)

    # 1. Outer Forged-Iron Tire Band (`R = 0.148..0.1650 m`, `X = ±0.054 m` stepping to `±0.048 m` at tread bevel)
    add_annular_ring(0.148, 0.160, 0.054, 0.054, MAT_IRON)
    add_annular_ring(0.160, 0.1650, 0.054, 0.046, MAT_IRON)

    # 2. Seasoned Oak Felloe Ring (`R = 0.110..0.148 m`, `X = ±0.046 m` — crisp 8mm step inside the iron tire!)
    add_annular_ring(0.110, 0.148, 0.046, 0.046, MAT_TIMBER)

    # 3. Inner Cast-Bronze Felloe Stiffening Ring (`R = 0.102..0.110 m`, `X = ±0.049 m`)
    add_annular_ring(0.102, 0.110, 0.049, 0.049, MAT_BRONZE)

    # 4. 12 Forged-Iron Rim Strake Clamp Plates & Brass/Bronze Rivet Heads around the Felloe-to-Tire Joint
    for k in range(12):
        ang = k * (2.0 * math.pi / 12.0)
        ca, sa = math.cos(ang), math.sin(ang)
        p_in  = [0.0, 0.132 * ca, 0.132 * sa]
        p_out = [0.0, 0.158 * ca, 0.158 * sa]
        mb.add_chamfered_beam(p_in, p_out, 0.114, 0.020, mat_idx=MAT_IRON, chamfer=0.003)

    # 5. 8 Distinct Mortised Octagonal Oak Spokes (`R = 0.048..0.104 m`) with Iron Base & Rim Collars
    for k in range(8):
        ang = k * (math.pi / 4.0)
        ca, sa = math.cos(ang), math.sin(ang)
        mb.add_chamfered_beam([0.0, 0.046 * ca, 0.046 * sa], [0.0, 0.105 * ca, 0.105 * sa], 0.036, 0.028, mat_idx=MAT_TIMBER, chamfer=0.005)
        # Spoke root iron collar (`R = 0.052..0.065 m`)
        mb.add_chamfered_beam([0.0, 0.052 * ca, 0.052 * sa], [0.0, 0.065 * ca, 0.065 * sa], 0.044, 0.034, mat_idx=MAT_IRON, chamfer=0.004)
        # Spoke rim mortise iron collar (`R = 0.091..0.103 m`)
        mb.add_chamfered_beam([0.0, 0.091 * ca, 0.091 * sa], [0.0, 0.103 * ca, 0.103 * sa], 0.042, 0.032, mat_idx=MAT_IRON, chamfer=0.004)

    # 6. 12-Faceted Cast-Bronze Nave Hub (`R = 0.056 m`) & Forged-Iron Axle Linchpin Cap
    s = float(side_sign) # +1.0 for Left (+X outer), -1.0 for Right (-X outer)
    mb.add_cylinder([-0.058, 0.0, 0.0], [+0.058, 0.0, 0.0], 0.055, mat_idx=MAT_BRONZE, segs=12)
    mb.add_cylinder([-0.042, 0.0, 0.0], [+0.042, 0.0, 0.0], 0.062, mat_idx=MAT_IRON,   segs=12)
    # Outer protruding bronze hub breast & iron linchpin cap on the outward (`s`) face
    mb.add_cylinder([0.0, 0.0, 0.0], [s * 0.064, 0.0, 0.0], 0.042, mat_idx=MAT_BRONZE, segs=12)
    mb.add_cylinder([s * 0.054, 0.0, 0.0], [s * 0.067, 0.0, 0.0], 0.028, mat_idx=MAT_IRON, segs=8)
    mb.add_box(s * 0.058 - 0.006, s * 0.058 + 0.006, -0.038, +0.038, -0.008, +0.008, mat_idx=MAT_BRONZE, chamfer=0.002)

    verts = np.array(mb.verts, dtype=np.float32)
    poly_offsets = [0]
    corner_verts, uv_map = [], []
    for pv, puv in zip(mb.poly_verts, mb.poly_uvs):
        corner_verts.extend(pv); uv_map.extend(puv); poly_offsets.append(len(corner_verts))
    return (
        verts,
        np.array(poly_offsets, dtype=np.int32),
        np.array(corner_verts, dtype=np.int32),
        np.array(uv_map, dtype=np.float32),
        np.array(mb.poly_mats, dtype=np.int32),
    )

# =============================================================================
# 3. PART C: CARRIAGE MESH WITH RELOCATED REAR AXLE (`Z = -0.820 m`)
# =============================================================================

def build_v24_relocated_axle_carriage_mesh():
    """
    Builds `MECarriage_Main_Mesh.003` at `1.0x` scale with:
      - Front axle at `Z = +0.325 m` (`X = ±0.430 m`, `Y = 0.165 m`)
      - Rear axle structurally relocated from `Z = -0.420 m` to `Z = -0.820 m` (`X = ±0.370 m`, `Y = 0.165 m`),
        increasing native wheelbase from `0.745 m` (`2.1233 m` world) to `1.145 m` (`3.2633 m` world at `2.85x`)!
      - Stepped lower longitudinal sill extended with an arched rear wheel-well over `Z ∈ [-0.955, -0.685] m`
        centered at `Z = -0.820 m`, heavy forged-iron & walnut rear axle tree and pillow blocks at `Z = -0.820 m`,
        and reinforced diagonal undercarriage bracing supporting the rear winch tower and rider platform.
    """
    mb = CleanMeshBuilder()
    B = 1.065

    for side in (-1.0, +1.0):
        x_low = side * 0.205
        x_up  = side * 0.285
        x_mid = side * 0.245

        # --- A. Stepped Lower Sill with Arched Wheel-Well Clearance at Z = +0.325m AND Rearward Z = -0.820m ---
        # 1. Front nose & front wheel arch over Z = +0.325m
        mb.add_chamfered_beam([x_low, 0.205, +0.475], [x_low, 0.235, +0.365], 0.095*B, 0.082*B, mat_idx=1, chamfer=0.008)
        mb.add_chamfered_beam([x_low, 0.242, +0.375], [x_low, 0.242, +0.235], 0.095*B, 0.076*B, mat_idx=1, chamfer=0.008)
        mb.add_chamfered_beam([x_low, 0.240, +0.245], [x_low, 0.165, +0.155], 0.095*B, 0.082*B, mat_idx=1, chamfer=0.008)
        # 2. Long dropped mid-carriage belly sill (`Z = +0.165m` to `-0.655m`, `Y = 0.165m`)
        mb.add_chamfered_beam([x_low, 0.165, +0.165], [x_low, 0.165, -0.655], 0.098*B, 0.088*B, mat_idx=1, chamfer=0.009)
        # 3. Rear wheel arch bridge over relocated Wheel_RL/RR (`Z = -0.655m` to `-0.985m`, centered at `Z = -0.820m`!)
        mb.add_chamfered_beam([x_low, 0.165, -0.645], [x_low, 0.242, -0.715], 0.095*B, 0.082*B, mat_idx=1, chamfer=0.008)
        mb.add_chamfered_beam([x_low, 0.244, -0.705], [x_low, 0.244, -0.935], 0.096*B, 0.080*B, mat_idx=1, chamfer=0.008)
        mb.add_chamfered_beam([x_low, 0.242, -0.925], [x_low, 0.205, -1.130], 0.095*B, 0.082*B, mat_idx=1, chamfer=0.008)

        # --- B. Sculpted Tapered Upper Compression Chord ---
        mb.add_chamfered_beam([x_up, 0.488, +0.462], [x_up, 0.595, +0.145], 0.096*B, 0.092*B, mat_idx=1, chamfer=0.009)
        mb.add_chamfered_beam([x_up, 0.598, +0.155], [x_up, 0.598, -0.245], 0.100*B, 0.095*B, mat_idx=0, chamfer=0.009)
        mb.add_chamfered_beam([x_up, 0.595, -0.235], [x_up, 0.525, -0.715], 0.096*B, 0.090*B, mat_idx=1, chamfer=0.009)

        # --- C. Truss Posts & Diagonal Braces ---
        mb.add_chamfered_beam([x_low, 0.205, +0.440], [x_up, 0.495, +0.440], 0.078*B, 0.078*B, mat_idx=0, chamfer=0.007)
        mb.add_chamfered_beam([x_low, 0.165, +0.135], [x_up, 0.598, +0.135], 0.076*B, 0.076*B, mat_idx=0, chamfer=0.007)
        mb.add_chamfered_beam([x_low, 0.165, -0.245], [x_up, 0.598, -0.245], 0.076*B, 0.076*B, mat_idx=0, chamfer=0.007)
        mb.add_chamfered_beam([x_low, 0.185, -0.655], [x_up, 0.535, -0.655], 0.082*B, 0.082*B, mat_idx=0, chamfer=0.007)
        # Rear Axle Kingpost directly above `Z = -0.820m` linking Rear Wheel Arch (`Y=0.244`) to Rider Hip Rail (`Y=0.545`)!
        mb.add_chamfered_beam([x_low, 0.240, -0.820], [side*0.268, 0.545, -0.820], 0.074*B, 0.074*B, mat_idx=0, chamfer=0.007)

        mb.add_chamfered_beam([x_mid, 0.195, +0.145], [x_mid, 0.468, +0.430], 0.062*B, 0.062*B, mat_idx=0, chamfer=0.006)
        mb.add_chamfered_beam([x_mid, 0.185, -0.235], [x_mid, 0.305, +0.125], 0.058*B, 0.058*B, mat_idx=0, chamfer=0.006)
        mb.add_chamfered_beam([x_mid, 0.195, -0.255], [x_mid, 0.495, -0.645], 0.062*B, 0.062*B, mat_idx=0, chamfer=0.006)
        # Diagonal rear-axle load-transfer strut from `Z = -0.820m` wheel arch forward-up to `Z = -0.655m` winch tower
        mb.add_chamfered_beam([x_low, 0.244, -0.820], [x_mid, 0.465, -0.660], 0.058*B, 0.058*B, mat_idx=2, chamfer=0.005)
        # Diagonal rear-axle brace from `Z = -0.820m` wheel arch aft-up to `Z = -1.035m` rear stanchion
        mb.add_chamfered_beam([x_low, 0.244, -0.820], [side*0.265, 0.485, -1.025], 0.056*B, 0.056*B, mat_idx=2, chamfer=0.005)

        # --- D. Forged-Iron Node Gussets & Brass Rivet Caps ---
        mb.add_iron_strap_with_rivets(x_up,  0.490, +0.440, 0.112*B, 0.110*B, 0.085*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_up,  0.598, +0.135, 0.116*B, 0.112*B, 0.090*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_up,  0.598, -0.245, 0.116*B, 0.112*B, 0.090*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_up,  0.525, -0.655, 0.112*B, 0.110*B, 0.085*B, rivet_axis='x')

        mb.add_iron_strap_with_rivets(x_low, 0.215, +0.440, 0.110*B, 0.098*B, 0.082*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_low, 0.165, +0.135, 0.112*B, 0.102*B, 0.086*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_low, 0.165, -0.245, 0.112*B, 0.102*B, 0.086*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_low, 0.195, -0.655, 0.110*B, 0.098*B, 0.082*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_low, 0.244, -0.820, 0.114*B, 0.104*B, 0.096*B, rivet_axis='x')

        # --- E. Physical Banner Hangers at exact [±0.258, 0.520, +0.115] and [±0.272, 0.685, -0.760] ---
        mb.add_box(side*0.235 if side>0 else -0.348, side*0.348 if side>0 else -0.235,
                   0.512, 0.532, +0.055, +0.175, mat_idx=2, chamfer=0.003)
        mb.add_cylinder([side*0.258, 0.520, +0.045], [side*0.258, 0.520, +0.185], 0.011, mat_idx=3, segs=10)

        mb.add_chamfered_beam([side*0.272, 0.220, -0.715], [side*0.272, 0.735, -0.715], 0.052*B, 0.052*B, mat_idx=1, chamfer=0.005)
        mb.add_iron_strap_with_rivets(side*0.272, 0.610, -0.715, 0.068, 0.055, 0.068, rivet_axis='x')
        mb.add_chamfered_beam([side*0.272, 0.724, -0.695], [side*0.272, 0.724, -0.805], 0.032, 0.028, mat_idx=2, chamfer=0.003)
        mb.add_box(side*0.272 - 0.028, side*0.272 + 0.028, 0.732, 0.752, -0.740, -0.690, mat_idx=3, chamfer=0.004)

    # 2. Forward Stator Yoke & Open Sightline Piston Cradle (`Y = 0.365 m`)
    mb.add_chamfered_beam([-0.245, 0.205, +0.445], [+0.245, 0.205, +0.445], 0.078*B, 0.072*B, mat_idx=2, chamfer=0.006)
    for side in (-1.0, +1.0):
        mb.add_chamfered_beam([side*0.225, 0.215, +0.455], [side*0.185, 0.365, +0.465], 0.058*B, 0.058*B, mat_idx=2, chamfer=0.005)
        mb.add_chamfered_beam([side*0.265, 0.485, +0.445], [side*0.175, 0.435, +0.460], 0.054*B, 0.054*B, mat_idx=2, chamfer=0.005)

    for z_tie in (+0.135, -0.245):
        for sx in (-1.0, +1.0):
            mb.add_chamfered_beam([sx*0.285, 0.565, z_tie], [sx*0.215, 0.485, z_tie], 0.052*B, 0.052*B, mat_idx=2, chamfer=0.004)
        mb.add_chamfered_beam([-0.235, 0.175, z_tie], [+0.235, 0.175, z_tie], 0.085*B, 0.072*B, mat_idx=1, chamfer=0.007)
        mb.add_chamfered_beam([-0.195, 0.185, z_tie], [-0.115, 0.265, z_tie], 0.052*B, 0.052*B, mat_idx=2, chamfer=0.004)
        mb.add_chamfered_beam([+0.195, 0.185, z_tie], [+0.115, 0.265, z_tie], 0.052*B, 0.052*B, mat_idx=2, chamfer=0.004)

    # 3. Four-Wheel Steering Axle Trees:
    #    - Front Axle Tree at `Z = +0.325 m` (`X = ±0.430 m`, `Y = 0.165 m`)
    mb.add_chamfered_beam([-0.430, 0.165, +0.325], [+0.430, 0.165, +0.325], 0.058*B, 0.058*B, mat_idx=2, chamfer=0.005)
    mb.add_chamfered_beam([-0.335, 0.195, +0.325], [+0.335, 0.195, +0.325], 0.082*B, 0.062*B, mat_idx=1, chamfer=0.006)
    #    - Relocated Rear Axle Tree at `Z = -0.820 m` (`X = ±0.370 m`, `Y = 0.165 m`) + Heavy Undercarriage Pillow Blocks!
    mb.add_chamfered_beam([-0.370, 0.165, REAR_AXLE_Z_NEW], [+0.370, 0.165, REAR_AXLE_Z_NEW], 0.062*B, 0.062*B, mat_idx=2, chamfer=0.005)
    mb.add_chamfered_beam([-0.310, 0.198, REAR_AXLE_Z_NEW], [+0.310, 0.198, REAR_AXLE_Z_NEW], 0.086*B, 0.066*B, mat_idx=1, chamfer=0.006)
    for sx in (-1.0, +1.0):
        # Forged-iron axle hanger brackets connecting Rear Axle (`Y=0.165`) up to Lower Sill Arch (`Y=0.244`) at `Z = -0.820 m`
        mb.add_box(sx*0.285 - 0.032, sx*0.285 + 0.032, 0.145, 0.245, REAR_AXLE_Z_NEW - 0.045, REAR_AXLE_Z_NEW + 0.045, mat_idx=2, chamfer=0.004)
        mb.add_box(sx*0.285 - 0.036, sx*0.285 + 0.036, 0.155, 0.185, REAR_AXLE_Z_NEW - 0.050, REAR_AXLE_Z_NEW + 0.050, mat_idx=3, chamfer=0.003)

    for zp in np.linspace(+0.39, -0.63, 10):
        mb.add_box(-0.205, +0.205, 0.115, 0.148, zp - 0.038, zp + 0.038, mat_idx=0, chamfer=0.004)

    # 4. Integrated Rear Driving Station (`Z = -0.710..-1.180 m`, `|X| <= 0.265 m` so inner wheel faces at `|X| = 0.312 m` have +47mm per-side clearance!)
    for side in (-1.0, +1.0):
        mb.add_chamfered_beam([side*0.235, 0.195, -0.660], [side*0.235, 0.205, -1.130], 0.068*B, 0.068*B, mat_idx=1, chamfer=0.006)
        mb.add_chamfered_beam([side*0.265, 0.565, -0.715], [side*0.265, 0.520, -1.035], 0.054*B, 0.050*B, mat_idx=1, chamfer=0.006)
        mb.add_chamfered_beam([side*0.265, 0.220, -1.080], [side*0.265, 0.525, -1.020], 0.052*B, 0.052*B, mat_idx=2, chamfer=0.005)
        mb.add_box(side*0.265 - 0.030, side*0.265 + 0.030, 0.512, 0.542, -1.055, -0.995, mat_idx=3, chamfer=0.004)

        fx = side * 0.115
        mb.add_box(fx - 0.058, fx + 0.058, 0.224, 0.254, -0.795, -0.765, mat_idx=2, chamfer=0.003)
        mb.add_box(fx - 0.058, fx - 0.038, 0.224, 0.246, -0.935, -0.775, mat_idx=2, chamfer=0.003)
        mb.add_box(fx + 0.038, fx + 0.058, 0.224, 0.246, -0.935, -0.775, mat_idx=2, chamfer=0.003)
        mb.add_box(fx - 0.048, fx + 0.048, 0.224, 0.235, -0.925, -0.785, mat_idx=3, chamfer=0.002)

    # Raised Slatted Oak Riding Platform Deck (`|X| <= 0.255 m`, `Y = +0.226 m`)
    for zp in (-0.755, -0.835, -0.915, -0.995, -1.075):
        mb.add_box(-0.255, +0.255, 0.192, 0.226, zp - 0.034, zp + 0.034, mat_idx=0, chamfer=0.004)

    mb.add_chamfered_beam([-0.265, 0.520, -1.025], [+0.265, 0.520, -1.025], 0.052, 0.052, mat_idx=1, chamfer=0.005)
    mb.add_box(-0.140, +0.140, 0.495, 0.550, -1.045, -0.985, mat_idx=4, chamfer=0.008)
    mb.add_chamfered_beam([0.0, 0.226, -0.955], [0.0, 0.465, -0.925], 0.062, 0.062, mat_idx=2, chamfer=0.005)
    mb.add_box(-0.080, +0.080, 0.455, 0.495, -0.975, -0.855, mat_idx=4, chamfer=0.008)

    mb.add_chamfered_beam([-0.265, 0.205, -1.130], [+0.265, 0.205, -1.130], 0.062, 0.055, mat_idx=2, chamfer=0.005)
    mb.add_box(-0.220, +0.220, 0.135, 0.168, -1.180, -1.120, mat_idx=2, chamfer=0.004)

    mb.add_chamfered_beam([-0.275, 0.572, -0.710], [+0.275, 0.572, -0.710], 0.058, 0.052, mat_idx=1, chamfer=0.006)
    mb.add_cylinder([+0.115, 0.195, -0.665], [+0.115, 0.600, -0.710], 0.019, mat_idx=2, segs=10)
    mb.add_cylinder([+0.055, 0.600, -0.705], [+0.185, 0.600, -0.730], 0.021, mat_idx=4, segs=10)
    mb.add_cylinder([-0.055, 0.600, -0.705], [-0.185, 0.600, -0.730], 0.021, mat_idx=4, segs=10)
    mb.add_box(+0.045, +0.075, 0.565, 0.608, -0.725, -0.695, mat_idx=2, chamfer=0.003)
    mb.add_box(-0.075, -0.045, 0.565, 0.608, -0.725, -0.695, mat_idx=2, chamfer=0.003)
    mb.add_cylinder([+0.185, 0.600, -0.730], [+0.202, 0.600, -0.734], 0.025, mat_idx=3, segs=10)
    mb.add_cylinder([-0.185, 0.600, -0.730], [-0.202, 0.600, -0.734], 0.025, mat_idx=3, segs=10)

    mb.add_box(-0.068, +0.068, 0.490, 0.585, -0.715, -0.515, mat_idx=2, chamfer=0.005)
    mb.add_box(-0.048, +0.048, 0.580, 0.598, -0.695, -0.535, mat_idx=3, chamfer=0.003)

    verts = np.array(mb.verts, dtype=np.float32)
    poly_offsets = [0]
    corner_verts, uv_map = [], []
    for pv, puv in zip(mb.poly_verts, mb.poly_uvs):
        corner_verts.extend(pv); uv_map.extend(puv); poly_offsets.append(len(corner_verts))
    return (
        verts,
        np.array(poly_offsets, dtype=np.int32),
        np.array(corner_verts, dtype=np.int32),
        np.array(uv_map, dtype=np.float32),
        np.array(mb.poly_mats, dtype=np.int32),
    )

# =============================================================================
# 4. EXPORT `SoFist-v24-runtime-source.blend` AND `so-fist-ication-v24-review.glb`
# =============================================================================

def build_and_export_sofist_v24():
    bf = blend_io.BlendFile(str(Path(__file__).resolve().parent) + "/SoFist-crafted-uncompressed.blend")
    ob_layout = bf.get_layout("Object")

    # 1. Update Carriage Main with relocated rear axle structure (`Z = -0.820 m`)
    c_pos, c_poff, c_cv, c_uv, c_midx = build_v24_relocated_axle_carriage_mesh()
    update_blend_mesh_from_gltf_arrays(bf, "MECarriage_Main_Mesh.003", c_pos, c_poff, c_cv, c_uv, c_midx)

    # 2. Update Armored Fist with crisp, deliberately faceted low-poly gauntlet geometry
    f_pos, f_poff, f_cv, f_uv, f_midx = build_crisp_armored_fist_mesh()
    update_blend_mesh_from_gltf_arrays(bf, "MEArmored_Fist_Mesh.003", f_pos, f_poff, f_cv, f_uv, f_midx)

    # 3. Update all 4 Wheels with crisp, deliberately constructed low-poly wheel geometry
    w_l_tup = build_crisp_siege_wheel_mesh(+1.0)
    w_r_tup = build_crisp_siege_wheel_mesh(-1.0)
    update_blend_mesh_from_gltf_arrays(bf, "MEWheel_FL_Mesh.004", *w_l_tup)
    update_blend_mesh_from_gltf_arrays(bf, "MEWheel_RL_Mesh.004", *w_l_tup)
    update_blend_mesh_from_gltf_arrays(bf, "MEWheel_FR_Mesh.004", *w_r_tup)
    update_blend_mesh_from_gltf_arrays(bf, "MEWheel_RR_Mesh.004", *w_r_tup)

    # 4. Relocate `OBWheel_RL.004` and `OBWheel_RR.004` in the Blender Object blocks from Z_gltf = -0.420m (`Y_blend = +0.420m`)
    #    to `Z_gltf = -0.820m` (`Y_blend = +0.820m`)!
    for b in bf.blocks:
        if b["code"] == "OB":
            ob_id = bf.get_id_name(b)
            if ob_id == "OBWheel_RL.004":
                struct.pack_into("<3f", b["payload"], ob_layout["loc"][0], +0.370, float(-REAR_AXLE_Z_NEW), +0.165)
            elif ob_id == "OBWheel_RR.004":
                struct.pack_into("<3f", b["payload"], ob_layout["loc"][0], -0.370, float(-REAR_AXLE_Z_NEW), +0.165)

    # 5. Smooth cylindrical running surfaces on Piston & Collars at 1.0x scale
    for mname in ["MERam_Shaft_Piston_Mesh.003", "MEArcane_Stator_Collar_Mesh.003", "MEWrist_Resonator_Ring_Mesh.003"]:
        m_pos, m_poff, m_cv, m_uv, m_midx = smooth_1x_piston_or_collar(bf, mname)
        update_blend_mesh_from_gltf_arrays(bf, mname, m_pos, m_poff, m_cv, m_uv, m_midx)

    # 6. Retime FCurves to 0.68s release / 0.88s peak extension over the 4.00s cycle
    retime_1x_fcurves_only(bf)

    uncomp_path = WORK_DIR / "SoFist-v24-runtime-source-uncompressed.blend"
    bf.save(str(uncomp_path))

    libzstd = ctypes.CDLL("libzstd.so.1")
    libzstd.ZSTD_compressBound.argtypes = [ctypes.c_size_t]
    libzstd.ZSTD_compressBound.restype = ctypes.c_size_t
    libzstd.ZSTD_compress.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
    libzstd.ZSTD_compress.restype = ctypes.c_size_t

    raw_b = uncomp_path.read_bytes()
    bound = libzstd.ZSTD_compressBound(len(raw_b))
    dst = ctypes.create_string_buffer(bound)
    c_size = libzstd.ZSTD_compress(dst, bound, raw_b, len(raw_b), 3)
    out_blend = OUT_DIR / "SoFist-v24-runtime-source.blend"
    out_blend.write_bytes(dst.raw[:c_size])
    blend_sha = hashlib.sha256(out_blend.read_bytes()).hexdigest()
    print(f"[OK] Exported {out_blend.name}: {c_size:,} bytes ({c_size/1048576:.2f} MB), SHA256={blend_sha}")

    # 7. Export `so-fist-ication-v24-review.glb` with crisp pairwise face-normal welding:
    #    - On `Armored_Fist_Mesh` and `Carriage_Main_Mesh`: strict `18 deg` crease threshold so every single
    #      bevel, knuckle, finger plate, and timber beam facet is 100% crisp flat-shaded!
    #    - On `Wheel_*_Mesh`: smooth circumferential normals ONLY on the outer iron running tread (`r_yz >= 0.158m`
    #      and `|fn_x| < 0.25`), while keeping all wheel sidewalls, bevels, felloes, spokes, and hubs 100% crisp flat-shaded!
    ptr_to_name = {b["old"]: bf.get_id_name(b) for b in bf.blocks}
    me_layout = bf.get_layout("Mesh")
    cd_layout = bf.get_layout("CustomData")
    cdl_layout = bf.get_layout("CustomDataLayer")

    bin_chunks = bytearray()
    buffer_views, accessors = [], []

    def add_bv(raw_bytes: bytes, target=None):
        pad = (4 - (len(bin_chunks) % 4)) % 4
        if pad: bin_chunks.extend(b"\x00" * pad)
        off = len(bin_chunks)
        bin_chunks.extend(raw_bytes)
        bv = {"buffer": 0, "byteOffset": off, "byteLength": len(raw_bytes)}
        if target is not None: bv["target"] = target
        idx = len(buffer_views)
        buffer_views.append(bv)
        return idx

    def add_acc(bv_idx: int, comp_type: int, count: int, acc_type: str, vmin=None, vmax=None):
        acc = {"bufferView": bv_idx, "componentType": comp_type, "count": count, "type": acc_type}
        if vmin is not None: acc["min"] = [float(x) if comp_type == 5126 else int(x) for x in vmin]
        if vmax is not None: acc["max"] = [float(x) if comp_type == 5126 else int(x) for x in vmax]
        idx = len(accessors)
        accessors.append(acc)
        return idx

    tex_files = [
        ("texture_diffuse", str(Path(__file__).resolve().parent) + "/IMtexture_diffuse.006.png"),
        ("texture_metallic-texture_roughness", str(Path(__file__).resolve().parent) + "/IMtexture_metallic-texture_roughness.006.png"),
        ("texture_normal", str(Path(__file__).resolve().parent) + "/IMtexture_normal.006.png"),
        ("texture_emissive", str(Path(__file__).resolve().parent) + "/IMtexture_emissive.003.png"),
    ]
    images, textures = [], []
    samplers = [{"magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497}]
    for tname, tpath in tex_files:
        im = Image.open(tpath)
        buf = io.BytesIO()
        im.save(buf, format="PNG", optimize=True, compress_level=9)
        bv_i = add_bv(buf.getvalue())
        img_i = len(images)
        images.append({"name": tname, "mimeType": "image/png", "bufferView": bv_i})
        textures.append({"sampler": 0, "source": img_i, "name": tname})

    mat_id_to_idx = {}
    gltf_materials = []
    for idx, (ma_id, spec) in enumerate(MATERIAL_DEFS_V24):
        mat_id_to_idx[ma_id] = idx
        pbr = {}
        for k in ("baseColorFactor", "metallicFactor", "roughnessFactor"):
            if k in spec: pbr[k] = spec[k]
        if "baseColorTexture" in spec: pbr["baseColorTexture"] = {"index": spec["baseColorTexture"]}
        if "metallicRoughnessTexture" in spec: pbr["metallicRoughnessTexture"] = {"index": spec["metallicRoughnessTexture"]}
        m_obj = {"name": clean_prefix(ma_id, "MA"), "pbrMetallicRoughness": pbr, "doubleSided": spec.get("doubleSided", False)}
        if "normalTexture" in spec: m_obj["normalTexture"] = {"index": spec["normalTexture"]}
        if "emissiveTexture" in spec:
            m_obj["emissiveTexture"] = {"index": spec["emissiveTexture"]}
            m_obj["emissiveFactor"] = spec.get("emissiveFactor", [1.0, 1.0, 1.0])
        gltf_materials.append(m_obj)

    me_id_to_idx = {}
    gltf_meshes = []
    total_welded_verts = 0
    total_tris = 0

    for b in bf.blocks:
        if b["code"] == "ME":
            me_id = bf.get_id_name(b)
            me_buf = b["payload"]
            totvert, totedge, totpoly, totloop = struct.unpack_from("<4i", me_buf, me_layout["totvert"][0])
            totcol = struct.unpack_from("<h", me_buf, me_layout["totcol"][0])[0]
            mat_ptr = struct.unpack_from("<Q", me_buf, me_layout["mat"][0])[0]
            mat_names = [ptr_to_name.get(p, "MARam candidate timber.003") for p in struct.unpack_from(f"<{totcol}Q", bf.ptr_map[mat_ptr]["payload"], 0)] if (mat_ptr in bf.ptr_map and totcol > 0) else ["MARam candidate timber.003"]
            poly_off_ptr = struct.unpack_from("<Q", me_buf, me_layout["poly_offset_indices"][0])[0]
            poly_offsets = np.frombuffer(bf.ptr_map[poly_off_ptr]["payload"], dtype=np.int32, count=totpoly+1).copy()

            pos, corner_verts, uv_map, mat_idx = None, None, None, np.zeros(totpoly, dtype=np.int32)
            for cname, cnt in [("vdata", totvert), ("pdata", totpoly), ("ldata", totloop)]:
                coff = me_layout[cname][0]
                lptr = struct.unpack_from("<Q", me_buf, coff + cd_layout["layers"][0])[0]
                tlay = struct.unpack_from("<i", me_buf, coff + cd_layout["totlayer"][0])[0]
                if not lptr or tlay == 0: continue
                lb = bf.ptr_map[lptr]
                for li in range(tlay):
                    loff = li * 120
                    lname = bytes(lb["payload"][loff+cdl_layout["name"][0]:loff+cdl_layout["name"][0]+68]).split(b"\x00")[0].decode("utf-8", "replace")
                    dptr = struct.unpack_from("<Q", lb["payload"], loff + cdl_layout["data"][0])[0]
                    if dptr not in bf.ptr_map: continue
                    db = bf.ptr_map[dptr]
                    if cname == "vdata" and lname == "position":
                        pos = np.frombuffer(db["payload"], dtype=np.float32, count=totvert*3).reshape(totvert, 3).copy()
                    elif cname == "pdata" and lname == "material_index":
                        mat_idx = np.frombuffer(db["payload"], dtype=np.int32, count=totpoly).copy()
                    elif cname == "ldata" and lname == ".corner_vert":
                        corner_verts = np.frombuffer(db["payload"], dtype=np.int32, count=totloop).copy()
                    elif cname == "ldata" and lname == "UVMap":
                        uv_map = np.frombuffer(db["payload"], dtype=np.float32, count=totloop*2).reshape(totloop, 2).copy()

            pos_gltf = np.column_stack([pos[:, 0], pos[:, 2], -pos[:, 1]]).astype(np.float32)

            face_norms = np.zeros((totpoly, 3), dtype=np.float32)
            vert_faces = defaultdict(list)
            for pi in range(totpoly):
                s, e = int(poly_offsets[pi]), int(poly_offsets[pi+1])
                if e - s < 3: continue
                vs = corner_verts[s:e]
                fn = np.cross(pos_gltf[vs[1]] - pos_gltf[vs[0]], pos_gltf[vs[2]] - pos_gltf[vs[0]])
                fl = float(np.linalg.norm(fn))
                if fl > 1e-10:
                    fn /= fl
                    face_norms[pi] = fn
                    for v in vs:
                        vert_faces[int(v)].append(pi)

            # Pairwise face-normal crease clustering:
            # - For Armored_Fist_Mesh and Carriage_Main_Mesh: strict 18 deg crease angle (cos = 0.951) so every single
            #   bevel, knuckle, finger plate, and timber beam facet is 100% crisp flat-shaded!
            # - For Wheel_*_Mesh: smooth ONLY circumferential tread faces (`r_yz > 0.158` and `|fn_x| < 0.25`, cos = 0.92),
            #   while keeping all sidewalls, felloes, spokes, and hub steps 100% crisp flat-shaded (cos = 0.96)!
            is_fist_or_carriage = me_id in ("MEArmored_Fist_Mesh.003", "MECarriage_Main_Mesh.003")
            is_wheel = "Wheel" in me_id

            prims_by_mat = {}
            for pi in range(totpoly):
                s, e = int(poly_offsets[pi]), int(poly_offsets[pi+1])
                if e - s < 3: continue
                fn = face_norms[pi]
                if np.linalg.norm(fn) < 1e-9: continue
                mi = int(mat_idx[pi]) if int(mat_idx[pi]) < len(mat_names) else 0
                g_mat_idx = mat_id_to_idx.get(mat_names[mi], 0)
                if g_mat_idx not in prims_by_mat:
                    prims_by_mat[g_mat_idx] = ({}, [], [], [], [])
                v_map, p_list, n_list, uv_list, idx_list = prims_by_mat[g_mat_idx]

                c_verts = corner_verts[s:e]
                c_uvs = uv_map[s:e] if uv_map is not None else np.zeros((e-s, 2), dtype=np.float32)

                corner_out_idxs = []
                for k in range(e - s):
                    vi = int(c_verts[k])
                    uv_k = c_uvs[k]
                    u_f, v_f = float(uv_k[0]), float(1.0 - uv_k[1])

                    if is_fist_or_carriage:
                        cos_thr = 0.955 # 17 deg: strictly flat-shaded facets & bevels!
                    elif is_wheel:
                        r_yz = math.hypot(pos_gltf[vi, 1], pos_gltf[vi, 2])
                        cos_thr = 0.920 if (r_yz > 0.158 and abs(float(fn[0])) < 0.25) else 0.965
                    else:
                        cos_thr = 0.780 # 38 deg on cylindrical piston/winch/springs/chains/banners

                    nsum = np.zeros(3, dtype=np.float64)
                    for pj in vert_faces[vi]:
                        if float(np.dot(fn, face_norms[pj])) >= cos_thr:
                            nsum += face_norms[pj]
                    ln = float(np.linalg.norm(nsum))
                    use_n = (nsum / ln).astype(np.float32) if ln > 1e-10 else fn

                    n_key = (int(round(use_n[0]*200)), int(round(use_n[1]*200)), int(round(use_n[2]*200)))
                    uses_tex = g_mat_idx in (1, 2, 4)
                    uv_key = (round(u_f, 3), round(v_f, 3)) if uses_tex else (0, 0)
                    key = (vi, n_key, uv_key)
                    out_i = v_map.get(key)
                    if out_i is None:
                        out_i = len(p_list)
                        v_map[key] = out_i
                        p_list.append(pos_gltf[vi])
                        n_list.append(use_n)
                        uv_list.append([u_f, v_f])
                    corner_out_idxs.append(out_i)

                for k in range(1, (e - s) - 1):
                    idx_list.extend([corner_out_idxs[0], corner_out_idxs[k], corner_out_idxs[k + 1]])

            primitives = []
            for g_mat_idx, (_, p_list, n_list, uv_list, idx_list) in sorted(prims_by_mat.items()):
                if not idx_list: continue
                p_arr = np.array(p_list, dtype=np.float32)
                n_arr = np.array(n_list, dtype=np.float32)
                uv_arr = np.array(uv_list, dtype=np.float32)
                idx_arr = np.array(idx_list, dtype=np.uint16 if len(p_arr) < 65535 else np.uint32)
                total_welded_verts += len(p_arr)
                total_tris += len(idx_arr) // 3

                bv_p = add_bv(p_arr.tobytes(), 34962)
                bv_n = add_bv(n_arr.tobytes(), 34962)
                bv_u = add_bv(uv_arr.tobytes(), 34962)
                bv_i = add_bv(idx_arr.tobytes(), 34963)

                acc_p = add_acc(bv_p, 5126, len(p_arr), "VEC3", p_arr.min(axis=0), p_arr.max(axis=0))
                acc_n = add_acc(bv_n, 5126, len(n_arr), "VEC3")
                acc_u = add_acc(bv_u, 5126, len(uv_arr), "VEC2")
                acc_i = add_acc(bv_i, 5123 if len(p_arr) < 65535 else 5125, len(idx_arr), "SCALAR", [int(idx_arr.min())], [int(idx_arr.max())])

                primitives.append({
                    "attributes": {"POSITION": acc_p, "NORMAL": acc_n, "TEXCOORD_0": acc_u},
                    "indices": acc_i,
                    "material": g_mat_idx,
                    "mode": 4,
                })

            me_idx = len(gltf_meshes)
            me_id_to_idx[me_id] = me_idx
            gltf_meshes.append({"name": clean_prefix(me_id, "ME"), "primitives": primitives})

    # Build 20 core nodes + 13 operator/entry/dismount locator nodes
    ob_info = {}
    for b in bf.blocks:
        if b["code"] == "OB":
            ob_id = bf.get_id_name(b)
            loc = struct.unpack_from("<3f", b["payload"], ob_layout["loc"][0])
            p_ptr = struct.unpack_from("<Q", b["payload"], ob_layout["parent"][0])[0]
            d_ptr = struct.unpack_from("<Q", b["payload"], ob_layout["data"][0])[0]
            loc_gltf = [round(float(loc[0]), 6), round(float(loc[2]), 6), round(float(-loc[1]), 6)]
            if ob_id == "OBRam_Assembly.003":
                loc_gltf = [0.0, 0.365, 0.520]
            elif ob_id == "OBRetraction_Chains_Aft.003":
                loc_gltf = [0.0, 0.385, -0.455]
            elif ob_id == "OBWheel_RL.004":
                loc_gltf = [+0.370, +0.165, REAR_AXLE_Z_NEW]
            elif ob_id == "OBWheel_RR.004":
                loc_gltf = [-0.370, +0.165, REAR_AXLE_Z_NEW]
            ob_info[ob_id] = {"parent": ptr_to_name.get(p_ptr), "data": ptr_to_name.get(d_ptr), "translation": loc_gltf, "children": []}

    for ob_id, info in ob_info.items():
        p = info["parent"]
        if p and p in ob_info:
            ob_info[p]["children"].append(ob_id)

    ordered_ob_ids = ["OBBattleRam_Root.003"] + [k for k in sorted(ob_info.keys()) if k != "OBBattleRam_Root.003"]
    ob_id_to_node_idx = {ob_id: i for i, ob_id in enumerate(ordered_ob_ids)}
    slot_name_to_node_idx = {}
    for ob_id, nidx in ob_id_to_node_idx.items():
        slot_name_to_node_idx[ob_id] = nidx
        base_ob = ob_id.split(".")[0]
        slot_name_to_node_idx[base_ob] = nidx
        slot_name_to_node_idx[base_ob + ".001"] = nidx

    gltf_nodes = []
    for ob_id in ordered_ob_ids:
        info = ob_info[ob_id]
        nd = {"name": clean_prefix(ob_id, "OB")}
        if any(abs(v) > 1e-6 for v in info["translation"]):
            nd["translation"] = info["translation"]
        if info["data"] and info["data"] in me_id_to_idx:
            nd["mesh"] = me_id_to_idx[info["data"]]
        if info["children"]:
            nd["children"] = [ob_id_to_node_idx[ch] for ch in sorted(info["children"])]
        gltf_nodes.append(nd)

    carriage_node_idx = ob_id_to_node_idx["OBCarriage_Main.003"]
    if "children" not in gltf_nodes[carriage_node_idx]:
        gltf_nodes[carriage_node_idx]["children"] = []
    for lname, ltr in SALVAGED_LOCATORS_1X:
        l_idx = len(gltf_nodes)
        gltf_nodes.append({"name": lname, "translation": ltr})
        gltf_nodes[carriage_node_idx]["children"].append(l_idx)

    # Extract all 4 Slotted Actions
    ac_layout = bf.get_layout("bAction")
    slot_layout = bf.get_layout("ActionSlot")
    kd_layout = bf.get_layout("ActionStripKeyframeData")
    cb_layout = bf.get_layout("ActionChannelBag")
    fc_layout = bf.get_layout("FCurve")
    bz_layout = bf.get_layout("BezTriple")

    gltf_animations = []
    for b in bf.blocks:
        if b["code"] != "AC": continue
        ac_id = bf.get_id_name(b)
        anim_name = clean_prefix(ac_id, "AC")
        slot_arr_ptr = struct.unpack_from("<Q", b["payload"], ac_layout["slot_array"][0])[0]
        slot_num = struct.unpack_from("<i", b["payload"], ac_layout["slot_array_num"][0])[0]
        slots = {}
        if slot_arr_ptr in bf.ptr_map and slot_num > 0:
            sb = bf.ptr_map[slot_arr_ptr]
            for sp in struct.unpack_from(f"<{slot_num}Q", sb["payload"], 0):
                if sp in bf.ptr_map:
                    slb = bf.ptr_map[sp]
                    sname = bytes(slb["payload"][slot_layout["name"][0]:slot_layout["name"][0]+64]).split(b"\x00")[0].decode()
                    shandle = struct.unpack_from("<i", slb["payload"], slot_layout["handle"][0])[0]
                    slots[shandle] = sname

        kd_arr_ptr = struct.unpack_from("<Q", b["payload"], ac_layout["strip_keyframe_data_array"][0])[0]
        kd_num = struct.unpack_from("<i", b["payload"], ac_layout["strip_keyframe_data_array_num"][0])[0]
        if kd_arr_ptr not in bf.ptr_map or kd_num == 0: continue

        samplers_list, channels_list = [], []
        kdb = bf.ptr_map[kd_arr_ptr]
        for kp in struct.unpack_from(f"<{kd_num}Q", kdb["payload"], 0):
            if kp not in bf.ptr_map: continue
            kb = bf.ptr_map[kp]
            cb_arr_ptr = struct.unpack_from("<Q", kb["payload"], kd_layout["channelbag_array"][0])[0]
            cb_num = struct.unpack_from("<i", kb["payload"], kd_layout["channelbag_array_num"][0])[0]
            if cb_arr_ptr not in bf.ptr_map or cb_num == 0: continue
            cbb = bf.ptr_map[cb_arr_ptr]
            for cbp in struct.unpack_from(f"<{cb_num}Q", cbb["payload"], 0):
                if cbp not in bf.ptr_map: continue
                bag = bf.ptr_map[cbp]
                sh = struct.unpack_from("<i", bag["payload"], cb_layout["slot_handle"][0])[0]
                fnum = struct.unpack_from("<i", bag["payload"], cb_layout["fcurve_array_num"][0])[0]
                farr = struct.unpack_from("<Q", bag["payload"], cb_layout["fcurve_array"][0])[0]
                target_node = slot_name_to_node_idx.get(slots.get(sh, ""))
                if target_node is None or farr not in bf.ptr_map or fnum == 0: continue

                fcurves_by_prop = {}
                fab = bf.ptr_map[farr]
                for fp in struct.unpack_from(f"<{fnum}Q", fab["payload"], 0):
                    if fp not in bf.ptr_map: continue
                    fb = bf.ptr_map[fp]
                    rptr = struct.unpack_from("<Q", fb["payload"], fc_layout["rna_path"][0])[0]
                    rpath = bytes(bf.ptr_map[rptr]["payload"]).split(b"\x00")[0].decode() if rptr in bf.ptr_map else ""
                    aidx = struct.unpack_from("<i", fb["payload"], fc_layout["array_index"][0])[0]
                    totv = struct.unpack_from("<i", fb["payload"], fc_layout["totvert"][0])[0]
                    bptr = struct.unpack_from("<Q", fb["payload"], fc_layout["bezt"][0])[0]
                    pts = {}
                    if bptr in bf.ptr_map and totv > 0:
                        bb = bf.ptr_map[bptr]
                        sz = bb["size"] // totv
                        for k in range(totv):
                            vec = struct.unpack_from("<9f", bb["payload"], k * sz + bz_layout["vec"][0])
                            pts[round(float(vec[3]), 4)] = float(vec[4])
                    fcurves_by_prop.setdefault(rpath, {})[aidx] = pts

                for rpath, idx_map in fcurves_by_prop.items():
                    frames = sorted(set().union(*(d.keys() for d in idx_map.values())))
                    if not frames: continue
                    times_sec = np.array([f / 24.0 for f in frames], dtype=np.float32)
                    bv_t = add_bv(times_sec.tobytes())
                    acc_t = add_acc(bv_t, 5126, len(times_sec), "SCALAR", [float(times_sec.min())], [float(times_sec.max())])

                    if rpath == "location":
                        vals = [[idx_map.get(0, {}).get(f, 0.0), idx_map.get(2, {}).get(f, 0.0), -idx_map.get(1, {}).get(f, 0.0)] for f in frames]
                        v_arr = np.array(vals, dtype=np.float32)
                        bv_v = add_bv(v_arr.tobytes())
                        acc_v = add_acc(bv_v, 5126, len(v_arr), "VEC3", v_arr.min(axis=0), v_arr.max(axis=0))
                        s_idx = len(samplers_list)
                        samplers_list.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
                        channels_list.append({"sampler": s_idx, "target": {"node": target_node, "path": "translation"}})
                    elif rpath == "rotation_quaternion":
                        vals = []
                        for f in frames:
                            wb, xb, yb, zb = idx_map.get(0, {}).get(f, 1.0), idx_map.get(1, {}).get(f, 0.0), idx_map.get(2, {}).get(f, 0.0), idx_map.get(3, {}).get(f, 0.0)
                            q = np.array([xb, zb, -yb, wb], dtype=np.float64)
                            n = np.linalg.norm(q)
                            if n > 1e-9: q /= n
                            vals.append(q)
                        v_arr = np.array(vals, dtype=np.float32)
                        bv_v = add_bv(v_arr.tobytes())
                        acc_v = add_acc(bv_v, 5126, len(v_arr), "VEC4", v_arr.min(axis=0), v_arr.max(axis=0))
                        s_idx = len(samplers_list)
                        samplers_list.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
                        channels_list.append({"sampler": s_idx, "target": {"node": target_node, "path": "rotation"}})
                    elif rpath == "scale":
                        vals = [[idx_map.get(0, {}).get(f, 1.0), idx_map.get(2, {}).get(f, 1.0), idx_map.get(1, {}).get(f, 1.0)] for f in frames]
                        v_arr = np.array(vals, dtype=np.float32)
                        bv_v = add_bv(v_arr.tobytes())
                        acc_v = add_acc(bv_v, 5126, len(v_arr), "VEC3", v_arr.min(axis=0), v_arr.max(axis=0))
                        s_idx = len(samplers_list)
                        samplers_list.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
                        channels_list.append({"sampler": s_idx, "target": {"node": target_node, "path": "scale"}})

        gltf_animations.append({"name": anim_name, "samplers": samplers_list, "channels": channels_list})

    pad_bin = (4 - (len(bin_chunks) % 4)) % 4
    if pad_bin: bin_chunks.extend(b"\x00" * pad_bin)

    gltf_dict = {
        "asset": {"version": "2.0", "generator": "Castleward SO-FIST-ICATION v2.4 Exporter (Crisp Fist/Wheels + Rear Axle Z=-0.820m)"},
        "scene": 0,
        "scenes": [{"name": "Scene", "nodes": [0]}],
        "nodes": gltf_nodes,
        "meshes": gltf_meshes,
        "materials": gltf_materials,
        "textures": textures,
        "images": images,
        "samplers": samplers,
        "animations": gltf_animations,
        "accessors": accessors,
        "bufferViews": buffer_views,
        "buffers": [{"byteLength": len(bin_chunks)}],
        "extras": {
            "assetId": "so-fist-ication",
            "version": "2.4.0",
            "runtimeScale": 2.85,
            "frontAxleZLocal": +0.325,
            "rearAxleZLocalOld": -0.420,
            "rearAxleZLocalNew": -0.820,
            "wheelbaseLocalOld": 0.745,
            "wheelbaseLocalNew": 1.145,
            "wheelbaseWorldOld": 2.1233,
            "wheelbaseWorldNew": 3.2633,
            "wheelRadiusLocal": 0.165,
            "wheelRadiusWorld": 0.47025,
            "totalWeldedVertices": total_welded_verts,
            "totalTriangles": total_tris,
        }
    }

    json_bytes = json.dumps(gltf_dict, separators=(",", ":")).encode("utf-8")
    pad_json = (4 - (len(json_bytes) % 4)) % 4
    if pad_json: json_bytes += b" " * pad_json

    total_len = 12 + 8 + len(json_bytes) + 8 + len(bin_chunks)
    glb_out = bytearray()
    glb_out.extend(struct.pack("<4sII", b"glTF", 2, total_len))
    glb_out.extend(struct.pack("<I4s", len(json_bytes), b"JSON"))
    glb_out.extend(json_bytes)
    glb_out.extend(struct.pack("<I4s", len(bin_chunks), b"BIN\x00"))
    glb_out.extend(bin_chunks)

    out_glb_v24 = OUT_DIR / "so-fist-ication-v24-review.glb"
    out_glb_v24.write_bytes(glb_out)
    sha = hashlib.sha256(glb_out).hexdigest()
    print(f"[OK] Exported {out_glb_v24.name}: {len(glb_out):,} bytes ({len(glb_out)/1048576:.2f} MB), welded_verts={total_welded_verts:,}, tris={total_tris:,}, SHA256={sha}")
    return gltf_dict, sha, blend_sha

if __name__ == "__main__":
    build_and_export_sofist_v24()
