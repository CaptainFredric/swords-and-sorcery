#!/usr/bin/env python3
"""
SO-FIST-ICATION v2.5 — Substantive Design Improvement:
  1. Synthesized Closed-Fist Siege Gauntlet (`MEArmored_Fist_Mesh.003`):
     - Combines v2.2's unmistakable closed-fist silhouette (arched dorsal metacarpal crown, index/middle
       knuckle prominence, sloping ring/little knuckle sweep, inward-curling multi-phalanx fingers tucked
       into the palm cavity, and a massive diagonal thumb locking across the curled fingers) with v2.4's
       crisp, deliberately constructed low-poly armor facets (`18.0 deg` crease threshold).
     - Eliminates the v2.4 "four vertical rectangular slabs" appearance from the front silhouette.
     - Sculpted 3-stage Piston -> Octagonal Clevis Yoke -> Flared Gauntlet Wrist Cuff -> Palm Heel Anvil
       transition (`Z = -0.015 .. +0.220 m`).
     - Preserves the exact authoritative strike envelope (`Z_tip = +0.9510 m` rest / `+1.3960 m` peak strike).
  2. Cohesive Heavy Siege Wheels (`MEWheel_FL/FR/RL/RR_Mesh.004`):
     - Crowned forged-iron tire (`R = 0.1650 m`), 12 wrap-around iron strake shoes with through-bolts,
       scarf-jointed oak felloe ring with 8 iron dowel plates, inner bronze compression ring, 8 tapered
       octagonal oak spokes seated into flanged iron mortise shoes, and banded bronze nave hubs with
       inboard journal sleeves and outboard linchpin caps.
  3. Integrated Rear Undercarriage & Axle Subframe at `Z = -0.820 m` (`MECarriage_Main_Mesh.003`):
     - Continuous full-length twin underslung keel stringers (`Z = +0.420 .. -1.040 m`), triangulated
       fore-and-aft diagonal axle hound-struts (`reach braces`), forged-iron U-bolt saddle bolsters, and
       continuous under-deck belly planking so the `Z = -0.820 m` rear axle is structurally woven into
       the carriage from underneath, side, and 3/4 angles.
"""
import sys, os, io, json, math, struct, ctypes, hashlib
from pathlib import Path
from collections import defaultdict
import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
INTER_DIR = HERE
OUT_DIR   = Path(os.environ.get("CASTLEWARD_OUT_DIR", str(HERE)))
WORK_DIR  = HERE
sys.path.insert(0, str(WORK_DIR))
sys.path.insert(0, str(INTER_DIR))
sys.path.insert(0, str(OUT_DIR))

import blend_io
from build_sofist_v2_1_candidate import (
    CleanMeshBuilder,
    read_raw_mesh_gltf,
    RETIMED_FRAMES_26,
    update_blend_mesh_from_gltf_arrays,
)
from build_sofist_v2_2_salvaged import (
    SALVAGED_LOCATORS_1X,
    retime_1x_fcurves_only,
    smooth_1x_piston_or_collar,
)
from export_sofist_v2_1_glb import clean_prefix

SO_FIST_SCALE   = 2.85
REAR_AXLE_Z_OLD = -0.420
REAR_AXLE_Z_NEW = -0.820  # Preserved v2.4 rear axle relocation (1.145m local / 3.2633m world wheelbase)
FRONT_AXLE_Z    = +0.325

MATERIAL_DEFS_V25 = [
    ("MARam candidate chains.003",       {"baseColorFactor": [0.055, 0.064, 0.075, 1.0], "metallicFactor": 0.78, "roughnessFactor": 0.52}),
    ("MARam candidate cloth.003",        {"baseColorTexture": 0, "metallicRoughnessTexture": 1, "normalTexture": 2, "doubleSided": True}),
    ("MARam candidate collar.003",       {"baseColorFactor": [0.320, 0.205, 0.082, 1.0], "metallicFactor": 0.76, "roughnessFactor": 0.38, "emissiveTexture": 3, "emissiveFactor": [1.0, 1.0, 1.0]}),
    ("MARam candidate mechanism.003",    {"baseColorFactor": [0.115, 0.140, 0.170, 1.0], "metallicFactor": 0.78, "roughnessFactor": 0.44}),
    ("MARam candidate timber.003",       {"baseColorTexture": 0, "metallicRoughnessTexture": 1}),
    ("MARam control grip leather.001",   {"baseColorFactor": [0.055, 0.028, 0.015, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.88}),
    ("MARam forged frame walnut.003",    {"baseColorFactor": [0.135, 0.068, 0.030, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.82}),
    ("MARam region brass.003",           {"baseColorFactor": [0.405, 0.265, 0.095, 1.0], "metallicFactor": 0.80, "roughnessFactor": 0.34}),
    ("MARam region iron.003",            {"baseColorFactor": [0.050, 0.058, 0.070, 1.0], "metallicFactor": 0.70, "roughnessFactor": 0.52}),
    ("MARam region steel.003",           {"baseColorFactor": [0.295, 0.328, 0.365, 1.0], "metallicFactor": 0.75, "roughnessFactor": 0.36}),
    ("MARam region timber.003",          {"baseColorFactor": [0.165, 0.082, 0.036, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.84}),
    ("MARam region timberLight.003",     {"baseColorFactor": [0.240, 0.125, 0.055, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.82}),
    ("MARam wheel bronze.003",           {"baseColorFactor": [0.365, 0.232, 0.085, 1.0], "metallicFactor": 0.78, "roughnessFactor": 0.36}),
    ("MARam wheel iron.003",             {"baseColorFactor": [0.065, 0.076, 0.090, 1.0], "metallicFactor": 0.74, "roughnessFactor": 0.46}),
    ("MARam wheel timber detail.003",    {"baseColorFactor": [0.160, 0.082, 0.036, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.80}),
]


def add_lofted_tube(mb: CleanMeshBuilder, stations_rings, mat_rings, cap_start=True, cap_end=True):
    """
    Lofts a multi-station polygonal tube where each station in `stations_rings` is a list of `N` 3D `[x,y,z]` points
    in counter-clockwise order when viewed from `+axis` (from station 0 toward station K-1).
    `mat_rings` can be an int (single material) or a list of material indices per longitudinal segment `(i, k)`.
    """
    n_st = len(stations_rings)
    n_ring = len(stations_rings[0])
    ring_indices = []
    for st in stations_rings:
        base = len(mb.verts)
        for pt in st:
            mb.verts.append([float(pt[0]), float(pt[1]), float(pt[2])])
        ring_indices.append([base + k for k in range(n_ring)])

    for i in range(n_st - 1):
        r0 = ring_indices[i]
        r1 = ring_indices[i + 1]
        for k in range(n_ring):
            kn = (k + 1) % n_ring
            m_idx = mat_rings[i][k] if isinstance(mat_rings, list) else int(mat_rings)
            mb.poly_verts.append([r0[k], r0[kn], r1[kn], r1[k]])
            mb.poly_uvs.append([[0.1, 0.1], [0.9, 0.1], [0.9, 0.9], [0.1, 0.9]])
            mb.poly_mats.append(m_idx)

    if cap_start:
        r0 = ring_indices[0]
        c0 = np.mean(np.array(stations_rings[0], dtype=np.float64), axis=0)
        c0_idx = len(mb.verts)
        mb.verts.append([float(c0[0]), float(c0[1]), float(c0[2])])
        m_cap0 = mat_rings[0][0] if isinstance(mat_rings, list) else int(mat_rings)
        for k in range(n_ring):
            kn = (k + 1) % n_ring
            mb.poly_verts.append([c0_idx, r0[kn], r0[k]])
            mb.poly_uvs.append([[0.5, 0.5], [0.9, 0.1], [0.1, 0.1]])
            mb.poly_mats.append(m_cap0)

    if cap_end:
        rL = ring_indices[-1]
        cL = np.mean(np.array(stations_rings[-1], dtype=np.float64), axis=0)
        cL_idx = len(mb.verts)
        mb.verts.append([float(cL[0]), float(cL[1]), float(cL[2])])
        m_capL = mat_rings[-1][0] if isinstance(mat_rings, list) else int(mat_rings)
        for k in range(n_ring):
            kn = (k + 1) % n_ring
            mb.poly_verts.append([cL_idx, rL[k], rL[kn]])
            mb.poly_uvs.append([[0.5, 0.5], [0.1, 0.9], [0.9, 0.9]])
            mb.poly_mats.append(m_capL)


def make_8pt_section(cx, cy, cz, rx, ry, rot_x_deg=0.0, rot_y_deg=0.0, rot_z_deg=0.0, crown_top=1.0, crown_bot=1.0):
    """
    Generates an 8-point chamfered/octagonal cross-section centered at `(cx, cy, cz)`
    oriented initially in the XY plane (normal along `+Z`), then rotated by `(rot_x_deg, rot_y_deg, rot_z_deg)`.
    Vertices are ordered CCW when looking from `-Z` toward `+Z` (so outward normals point radially outward).
    """
    c = 0.74
    pts_2d = [
        (-rx * c, -ry * crown_bot),
        (+rx * c, -ry * crown_bot),
        (+rx,     -ry * 0.52 * crown_bot),
        (+rx,     +ry * 0.56 * crown_top),
        (+rx * c, +ry * crown_top),
        (-rx * c, +ry * crown_top),
        (-rx,     +ry * 0.56 * crown_top),
        (-rx,     -ry * 0.52 * crown_bot),
    ]
    rx_r = math.radians(rot_x_deg)
    ry_r = math.radians(rot_y_deg)
    rz_r = math.radians(rot_z_deg)
    cx_r, sx_r = math.cos(rx_r), math.sin(rx_r)
    cy_r, sy_r = math.cos(ry_r), math.sin(ry_r)
    cz_r, sz_r = math.cos(rz_r), math.sin(rz_r)

    Rx = np.array([[1.0, 0.0, 0.0], [0.0, cx_r, -sx_r], [0.0, sx_r, cx_r]])
    Ry = np.array([[cy_r, 0.0, sy_r], [0.0, 1.0, 0.0], [-sy_r, 0.0, cy_r]])
    Rz = np.array([[cz_r, -sz_r, 0.0], [sz_r, cz_r, 0.0], [0.0, 0.0, 1.0]])
    R = Rz @ Ry @ Rx
    center = np.array([cx, cy, cz], dtype=np.float64)
    out = []
    for px, py in pts_2d:
        v = R @ np.array([px, py, 0.0], dtype=np.float64) + center
        out.append(v.tolist())
    return out


# =============================================================================
# 1. PART B1: SUBSTANTIVE v2.5 ARMORED FIST (`MEArmored_Fist_Mesh.003`)
# =============================================================================
# Material slots on `MEArmored_Fist_Mesh.003`:
#   0: `MARam region steel.003` (Honed faceted steel gauntlet carapace, arched knuckle bridge, curled finger lames, thumb)
#   1: `MARam region iron.003`  (Dark forged-iron piston-socket clevis, recessed inter-lame channels, palm anvil cavity)
#   2: `MARam region brass.003` (Burnished brass wrist collar, gothic dorsal crest, knuckle-guard band, shear pins, rivets)

def build_v25_synthesized_armored_fist_mesh():
    """
    Synthesizes the unmistakable closed-fist silhouette of v2.2 with the crisp faceted plate-armor
    construction of v2.4:
      - Asymmetric anatomical knuckle-crown arch: Middle (`Y=+0.218m, Z_pip=+0.4310m`) and Index (`Y=+0.202m`)
        sit high and proud, while Ring (`Y=+0.178m`) and Little (`Y=+0.136m`) sweep progressively downward
        (`-82 mm` drop!) and rearward along the sloped ulnar cheek, completely eliminating the rectangular
        front silhouette of v2.4.
      - Unified transverse arched knuckle-bridge (`Gadling Crown`) with 4 distinct faceted knuckle bosses
        rising out of one shared steel-and-brass dorsal hand carapace.
      - 4 visibly curled, interlocking multi-segment armored fingers separated by deep 14mm dark-iron clefts,
        each built from 3 overlapping, steeply chamfered plate-armor lames (sloped proximal lame -> crowned
        PIP blunt-impact knuckle lame at `Z_max = +0.4310m` -> inward-curled middle & distal phalanx lames
        that roll rearward by `-110 mm` in Z and tuck into the palm anvil cavity).
      - Massive, muscular armored thumb (`0.105m` thick) emerging from the radial (`-X = -0.254m`) thenar
        palm swell and locking diagonally upward across the curled Index and Middle fingers (`X = -0.245 -> +0.015m`).
      - 3-stage Piston -> Shear-Pin Clevis Socket -> Flared Gauntlet Wrist Cuff -> Palm Heel Anvil transition.
    """
    mb = CleanMeshBuilder()
    MAT_STEEL = 0
    MAT_IRON  = 1
    MAT_BRASS = 2

    # 1. Stage 1 (`Z = -0.012..+0.082m`): 12-Faceted Forged-Iron Piston Socket Yoke & Shear-Pin Clevis
    mb.add_cylinder([0.0, 0.0, -0.012], [0.0, 0.0, +0.082], 0.166, mat_idx=MAT_IRON, segs=12)
    mb.add_cylinder([0.0, 0.0, +0.014], [0.0, 0.0, +0.060], 0.178, mat_idx=MAT_BRASS, segs=12)
    mb.add_cylinder([-0.206, 0.0, +0.038], [+0.206, 0.0, +0.038], 0.034, mat_idx=MAT_BRASS, segs=10)
    mb.add_cylinder([-0.215, 0.0, +0.038], [+0.215, 0.0, +0.038], 0.022, mat_idx=MAT_IRON, segs=8)
    for sx in (-1.0, +1.0):
        mb.add_chamfered_beam([sx * 0.156, 0.0, -0.006], [sx * 0.184, 0.0, +0.088], 0.052, 0.094, mat_idx=MAT_IRON, chamfer=0.008)
        mb.add_chamfered_beam([sx * 0.166, 0.0, +0.008], [sx * 0.192, 0.0, +0.072], 0.044, 0.066, mat_idx=MAT_BRASS, chamfer=0.006)
    for ang_deg in (35.0, 90.0, 145.0, 215.0, 270.0, 325.0):
        ar = math.radians(ang_deg)
        ca, sa = math.cos(ar), math.sin(ar)
        mb.add_chamfered_beam(
            [0.160 * ca, 0.156 * sa, +0.006],
            [0.186 * ca, 0.170 * sa, +0.122],
            0.038, 0.034, mat_idx=MAT_BRASS if ang_deg in (90.0, 270.0) else MAT_IRON, chamfer=0.005
        )

    # 2. Stage 2 & 3 (`Z = +0.068..+0.315m`): Flared Gauntlet Wrist Cuff, Recessed Dark-Iron Core & Palm Heel Anvil
    #    Keep the dark-iron core (`MAT_IRON`) recessed at `Z <= +0.325m` so deep dark-iron shadow clefts
    #    separate the 4 curled fingers without any flat grey wall behind them!
    def make_hand_carapace_ring(z_val, x_left, x_right, y_bot_heel, y_top_idx, y_top_mid, y_top_ring, y_top_pinky, y_thumb_swell):
        return [
            [x_left * 0.62,  y_bot_heel * 0.92, z_val],
            [-0.020,         y_bot_heel,        z_val],
            [x_right * 0.58, y_bot_heel * 0.84, z_val],
            [x_right * 0.90, y_bot_heel * 0.35, z_val],
            [x_right * 0.98, y_top_pinky * 0.55, z_val],
            [x_right * 0.72, y_top_pinky,       z_val],
            [x_right * 0.26, y_top_ring,        z_val],
            [x_left * 0.18,  y_top_mid,         z_val],
            [x_left * 0.64,  y_top_idx,         z_val],
            [x_left * 0.92,  y_top_idx * 0.68,  z_val],
            [x_left * 1.04,  y_thumb_swell,     z_val],
            [x_left * 0.88,  y_bot_heel * 0.58, z_val],
        ]

    hand_rings = [
        make_hand_carapace_ring(+0.065, -0.168, +0.168, -0.158, +0.155, +0.164, +0.152, +0.132, +0.005),
        make_hand_carapace_ring(+0.118, -0.198, +0.192, -0.188, +0.172, +0.184, +0.166, +0.136, -0.012),
        make_hand_carapace_ring(+0.188, -0.228, +0.214, -0.212, +0.186, +0.200, +0.176, +0.138, -0.025),
        make_hand_carapace_ring(+0.258, -0.225, +0.210, -0.192, +0.192, +0.208, +0.178, +0.135, -0.035),
        make_hand_carapace_ring(+0.312, -0.202, +0.192, -0.145, +0.178, +0.192, +0.165, +0.122, -0.042),
    ]
    hand_mats = []
    for st_i in range(len(hand_rings) - 1):
        row_m = []
        for k in range(12):
            if st_i == 3:
                row_m.append(MAT_IRON) # Front core face is dark iron so inter-finger clefts are dark iron!
            elif k in (0, 1, 2, 11):
                row_m.append(MAT_BRASS if st_i == 1 else MAT_IRON)
            else:
                row_m.append(MAT_BRASS if st_i == 1 and k in (5, 6, 7, 8) else MAT_STEEL)
        hand_mats.append(row_m)
    add_lofted_tube(mb, hand_rings, hand_mats, cap_start=True, cap_end=True)

    # Riveted Burnished-Brass Gauntlet Cuff Ring (`Z = +0.095..+0.134m`) & Dorsal V-Chevron Armor Trim
    wrist_band_rings = [
        make_hand_carapace_ring(+0.094, -0.202, +0.195, -0.188, +0.172, +0.184, +0.166, +0.138, -0.008),
        make_hand_carapace_ring(+0.132, -0.215, +0.206, -0.198, +0.180, +0.192, +0.174, +0.142, -0.016),
    ]
    add_lofted_tube(mb, wrist_band_rings, MAT_BRASS, cap_start=True, cap_end=True)

    # Central Dorsal Spine Crest & Swept Metacarpal Lames (`Z = +0.085..+0.285m`)
    mb.add_chamfered_beam([-0.042, +0.176, +0.085], [-0.042, +0.214, +0.282], 0.052, 0.036, mat_idx=MAT_BRASS, chamfer=0.006)
    mb.add_chamfered_beam([-0.042, +0.192, +0.185], [-0.215, +0.158, +0.150], 0.044, 0.040, mat_idx=MAT_BRASS, chamfer=0.006)
    mb.add_chamfered_beam([-0.042, +0.192, +0.185], [+0.202, +0.128, +0.150], 0.044, 0.040, mat_idx=MAT_BRASS, chamfer=0.006)
    # Lower Palm Heel Anvil Reinforce Plates (`Y = -0.214..-0.145m, Z = +0.135..+0.255m`)
    mb.add_chamfered_beam([-0.085, -0.196, +0.132], [-0.075, -0.172, +0.252], 0.112, 0.050, mat_idx=MAT_STEEL, chamfer=0.009)
    mb.add_chamfered_beam([+0.075, -0.188, +0.132], [+0.068, -0.164, +0.248], 0.104, 0.048, mat_idx=MAT_STEEL, chamfer=0.009)

    # 3. Unified Arched Transverse Knuckle-Bridge (`Gadling Crown`, `Z = +0.255..+0.335m`)
    #    Notice the dramatic anatomical slope from Middle (`Y=+0.212m`) down to Little (`Y=+0.134m`) and Ulnar Cheek (`Y=+0.085m`)!
    knuckle_bow_pts = [
        [-0.228, +0.148, +0.268],
        [-0.154, +0.198, +0.308],
        [-0.048, +0.214, +0.322],
        [+0.058, +0.180, +0.306],
        [+0.156, +0.136, +0.282],
        [+0.212, +0.082, +0.252],
    ]
    for i in range(len(knuckle_bow_pts) - 1):
        mb.add_chamfered_beam(knuckle_bow_pts[i], knuckle_bow_pts[i + 1], 0.064, 0.058, mat_idx=MAT_BRASS, chamfer=0.008)

    # 4. Four Visibly Curled, Interlocking Multi-Segment Finger Gauntlets (`Z_max = +0.4310 m` EXACT)
    #    Each finger is built from 4 distinct, articulated, steeply chamfered plate-armor lames separated by
    #    recessed dark-iron articulation joints (`MAT_IRON`) and brass knuckle bands (`MAT_BRASS`), with a
    #    13 mm dark-iron cleft between adjacent fingers so every finger is individually readable while
    #    forming one unmistakable closed fist!
    finger_specs = [
        # (x_mcp, x_pip, x_dip, x_tip, fw, y_mcp, z_mcp, y_pip, z_pip, y_mid_low, z_mid_low, y_dip, z_dip, y_tip, z_tip)
        (-0.156, -0.148, -0.135, -0.120, 0.090, +0.198, +0.312, +0.072, +0.4250, -0.042, +0.4080, -0.122, +0.332, -0.088, +0.218), # Index
        (-0.048, -0.046, -0.042, -0.038, 0.094, +0.216, +0.326, +0.084, +0.4310, -0.038, +0.4140, -0.130, +0.338, -0.092, +0.218), # Middle (Peak +0.4310m)
        (+0.058, +0.054, +0.046, +0.038, 0.092, +0.180, +0.310, +0.054, +0.4220, -0.056, +0.4020, -0.128, +0.328, -0.088, +0.218), # Ring
        (+0.156, +0.146, +0.130, +0.112, 0.084, +0.136, +0.286, +0.016, +0.4020, -0.078, +0.3800, -0.118, +0.312, -0.078, +0.212), # Little (Sloped & Tucked!)
    ]

    for (x_mcp, x_pip, x_dip, x_tip, fw, y_mcp, z_mcp, y_pip, z_pip, y_mid_low, z_mid_low, y_dip, z_dip, y_tip, z_tip) in finger_specs:
        # A. Prominent Pyramidal MCP Knuckle Gadling Boss (`Z = z_mcp - 0.038 .. z_mcp + 0.032`)
        mb.add_chamfered_beam(
            [x_mcp, y_mcp - 0.024, z_mcp - 0.038],
            [x_mcp, y_mcp + 0.016, z_mcp + 0.028],
            fw * 1.04, 0.068, mat_idx=MAT_STEEL, chamfer=0.014
        )
        mb.add_chamfered_beam(
            [x_mcp, y_mcp + 0.002, z_mcp - 0.022],
            [x_mcp, y_mcp + 0.022, z_mcp + 0.018],
            fw * 0.62, 0.038, mat_idx=MAT_BRASS, chamfer=0.006
        )

        # B. Lame 1 — Sloped Proximal Phalanx Plate (`MCP -> PIP`, sloping forward & downward at ~48 deg)
        #    Use a deep `chamfer = 0.016` so each finger has bold 45-degree side bevel facets!
        mb.add_chamfered_beam(
            [x_mcp, y_mcp - 0.012, z_mcp + 0.006],
            [x_pip, y_pip + 0.012, z_pip - 0.028],
            fw, 0.064, mat_idx=MAT_STEEL, chamfer=0.015
        )
        # Raised central gothic finger-flute ridge along the proximal phalanx
        mb.add_chamfered_beam(
            [x_mcp, y_mcp + 0.004, z_mcp + 0.014],
            [x_pip, y_pip + 0.024, z_pip - 0.020],
            fw * 0.44, 0.038, mat_idx=MAT_STEEL, chamfer=0.007
        )

        # C. Recessed Dark-Iron & Burnished-Brass PIP Knuckle Articulation Band (`y_pip`, `z_pip`)
        mb.add_chamfered_beam(
            [x_pip, y_pip + 0.018, z_pip - 0.042],
            [x_pip, y_pip - 0.014, z_pip - 0.030],
            fw * 1.02, 0.062, mat_idx=MAT_BRASS, chamfer=0.010
        )
        mb.add_chamfered_beam(
            [x_pip, y_pip - 0.008, z_pip - 0.045],
            [x_pip, y_pip - 0.028, z_pip - 0.036],
            fw * 0.94, 0.056, mat_idx=MAT_IRON, chamfer=0.006
        )

        # D. Lame 2 — Upper Middle-Phalanx Blunt Striking Knuckle Plate (`y_pip -> y_mid_low`, outer face at exact `z_pip`!)
        #    Notice it angles slightly inward (`z_pip -> z_mid_low`) and has a raised central knuckle boss!
        r_thick = 0.034
        mb.add_chamfered_beam(
            [x_pip, y_pip - 0.012, z_pip - r_thick],
            [0.5*(x_pip+x_dip), y_mid_low + 0.008, z_mid_low - r_thick],
            fw, r_thick * 2.0, mat_idx=MAT_STEEL, chamfer=0.015
        )
        mb.add_chamfered_beam(
            [x_pip, y_pip - 0.016, z_pip - r_thick + 0.006],
            [0.5*(x_pip+x_dip), y_mid_low + 0.012, z_mid_low - r_thick + 0.006],
            fw * 0.46, r_thick * 1.9, mat_idx=MAT_STEEL, chamfer=0.007
        )

        # E. Recessed Dark-Iron & Brass Mid-Finger Articulation Slot (`y_mid_low`)
        mb.add_chamfered_beam(
            [0.5*(x_pip+x_dip), y_mid_low + 0.006, z_mid_low - 0.040],
            [0.5*(x_pip+x_dip), y_mid_low - 0.016, z_mid_low - 0.052],
            fw * 0.94, 0.054, mat_idx=MAT_IRON, chamfer=0.006
        )
        mb.add_chamfered_beam(
            [0.5*(x_pip+x_dip), y_mid_low - 0.004, z_mid_low - 0.034],
            [0.5*(x_pip+x_dip), y_mid_low - 0.020, z_mid_low - 0.046],
            fw * 0.98, 0.054, mat_idx=MAT_BRASS, chamfer=0.007
        )

        # F. Lame 3 — Inward-Curling Lower Middle Phalanx (`y_mid_low -> y_dip`, curling sharply rearward to `z_dip`!)
        mb.add_chamfered_beam(
            [0.5*(x_pip+x_dip), y_mid_low - 0.014, z_mid_low - 0.032],
            [x_dip, y_dip + 0.006, z_dip],
            fw * 0.96, 0.060, mat_idx=MAT_STEEL, chamfer=0.014
        )
        mb.add_chamfered_beam(
            [0.5*(x_pip+x_dip), y_mid_low - 0.016, z_mid_low - 0.024],
            [x_dip, y_dip + 0.008, z_dip + 0.006],
            fw * 0.44, 0.054, mat_idx=MAT_STEEL, chamfer=0.006
        )

        # G. Lame 4 — Curled Distal Phalanx Fingertip tucked upward & rearward into the Palm Anvil (`y_dip -> y_tip, z_dip -> z_tip`)
        mb.add_chamfered_beam(
            [x_dip, y_dip + 0.004, z_dip - 0.008],
            [x_tip, y_tip, z_tip],
            fw * 0.88, 0.052, mat_idx=MAT_STEEL, chamfer=0.012
        )
        mb.add_chamfered_beam(
            [0.5*(x_dip+x_tip), 0.5*(y_dip+y_tip), 0.5*(z_dip+z_tip)],
            [x_tip, y_tip + 0.008, z_tip - 0.012],
            fw * 0.82, 0.046, mat_idx=MAT_BRASS, chamfer=0.008
        )

    # 5. Massive, Muscular Clenched Siege Thumb (`-X` Thenar Swell -> Diagonally Locked Across Index & Middle Fingers!)
    #    - Segment A: Flared Thenar / Thumb Metacarpal Cheek emerging from the radial (`-X`) side of the gauntlet
    mb.add_chamfered_beam(
        [-0.208, +0.035, +0.135],
        [-0.246, -0.045, +0.268],
        0.096, 0.118, mat_idx=MAT_STEEL, chamfer=0.016
    )
    mb.add_chamfered_beam(
        [-0.222, +0.018, +0.165],
        [-0.254, -0.048, +0.262],
        0.068, 0.076, mat_idx=MAT_BRASS, chamfer=0.010
    )
    #    - Segment B: Prominent Thumb MCP/IP Knuckle Boss at the lower-left corner of the fist (`X=-0.238, Y=-0.105, Z=+0.342`)
    mb.add_chamfered_beam(
        [-0.244, -0.052, +0.258],
        [-0.215, -0.118, +0.362],
        0.098, 0.102, mat_idx=MAT_STEEL, chamfer=0.016
    )
    mb.add_chamfered_beam(
        [-0.252, -0.075, +0.295],
        [-0.218, -0.118, +0.368],
        0.072, 0.068, mat_idx=MAT_BRASS, chamfer=0.010
    )
    #    - Segment C: Diagonal Proximal & Distal Thumb Lames sweeping UPWARD and ACROSS the curled Index & Middle fingers!
    #      Notice `Y = -0.122 -> -0.068m` and `Z = +0.365 -> +0.398m` so the thumb presses directly against the curled fingers!
    mb.add_chamfered_beam(
        [-0.218, -0.122, +0.358],
        [-0.092, -0.088, +0.392],
        0.092, 0.096, mat_idx=MAT_STEEL, chamfer=0.015
    )
    # Recessed dark-iron & brass thumb IP joint strap (`X = -0.115..-0.085m`)
    mb.add_chamfered_beam(
        [-0.122, -0.096, +0.382],
        [-0.082, -0.084, +0.394],
        0.098, 0.100, mat_idx=MAT_BRASS, chamfer=0.010
    )
    # Thumb Distal Phalanx & Beveled Brass Nail-Guard locking across Middle Finger (`X = -0.092 -> +0.012m`)
    mb.add_chamfered_beam(
        [-0.092, -0.088, +0.388],
        [+0.012, -0.068, +0.378],
        0.084, 0.088, mat_idx=MAT_STEEL, chamfer=0.014
    )
    mb.add_chamfered_beam(
        [-0.042, -0.076, +0.386],
        [+0.018, -0.065, +0.376],
        0.068, 0.072, mat_idx=MAT_BRASS, chamfer=0.010
    )
    # Raised dorsal thumb ridge running continuously along the diagonal thumb sweep
    mb.add_chamfered_beam(
        [-0.215, -0.118, +0.368],
        [-0.005, -0.068, +0.392],
        0.042, 0.044, mat_idx=MAT_STEEL, chamfer=0.007
    )

    # Guarantee exact authoritative `Z_max = +0.4310 m` on the primary striking face (`0.0000 m` delta vs v2.2 & v2.4!)
    verts = np.array(mb.verts, dtype=np.float32)
    z_max_cur = float(verts[:, 2].max())
    if abs(z_max_cur - 0.4310) > 1e-5:
        mask_f = verts[:, 2] > 0.340
        verts[mask_f, 2] = 0.340 + (verts[mask_f, 2] - 0.340) * ((0.4310 - 0.340) / (z_max_cur - 0.340))

    poly_offsets = [0]
    corner_verts, uv_map = [], []
    for pv, puv in zip(mb.poly_verts, mb.poly_uvs):
        corner_verts.extend(pv); uv_map.extend(puv); poly_offsets.append(len(corner_verts))
    return (
        verts,
        np.array(poly_offsets, dtype=np.int32),
        np.array(corner_verts, dtype=np.int32),
        np.array(uv_map, dtype=np.float32),
        np.array(mb.poly_mats, dtype=np.int32),
    )


# =============================================================================
# 2. PART B2: COHESIVE HEAVY SIEGE WHEELS (`MEWheel_FL/FR/RL/RR_Mesh.004`)
# =============================================================================
# Material slots on `MEWheel_*_Mesh.004`:
#   0: `MARam wheel timber detail.003` (Chamfered oak felloe segments & 8 tapered octagonal oak spokes)
#   1: `MARam wheel iron.003`          (Crowned forged-iron tire tread, 12 wrap-around strake shoes, 8 felloe joint plates, spoke mortise shoes, linchpin)
#   2: `MARam wheel bronze.003`        (12-faceted cast-bronze nave hub, inboard axle-journal bearing sleeve, inner felloe compression ring)

def build_v25_cohesive_siege_wheel_mesh(side_sign: float):
    """
    Upgrades `MEWheel_*_Mesh.004` so the iron rim, wooden felloes, tapered spokes, central nave hub,
    and inboard axle journal attachment interlock as a cohesive, load-bearing siege wheel:
      - Outer radius `R = 0.1650 m` local (`0.47025 m` world at `2.85x`), width `0.118 m`.
      - 24-segment crowned forged-iron tire (`R = 0.146..0.1650 m`) with beveled outer shoulders and
        12 wrap-around iron strake clamp shoes with countersunk bronze/iron bolt heads.
      - Deep chamfered seasoned-oak felloe ring (`R = 0.104..0.146 m`) with 8 forged-iron scarf-joint
        dowel plates on both sidewalls and an inner cast-bronze compression ring (`R = 0.095..0.104 m`).
      - 8 tapered octagonal oak spokes (`R = 0.046..0.098 m`, flaring from `32x26 mm` at the felloe to
        `46x38 mm` at the nave root) seated into individual forged-iron rim mortise shoes and hub flanges.
      - Banded 12-faceted cast-bronze nave hub (`R = 0.058 m`) with an extended inboard axle-journal bearing
        collar (`X_inboard = -s*0.072 m`) that mates directly with the carriage axle tree, plus an outboard
        forged-iron linchpin cap & transverse keeper pin.
    """
    mb = CleanMeshBuilder()
    MAT_TIMBER = 0
    MAT_IRON   = 1
    MAT_BRONZE = 2

    n_seg = 24
    angs = [2.0 * math.pi * i / n_seg for i in range(n_seg)]

    def add_annular_ring(r_in, r_out, x_in, x_out, mat_idx):
        for i in range(n_seg):
            a0, a1 = angs[i], angs[(i + 1) % n_seg]
            c0, s0 = math.cos(a0), math.sin(a0)
            c1, s1 = math.cos(a1), math.sin(a1)
            p_in_l0  = [-x_in,  r_in * c0,  r_in * s0]
            p_in_l1  = [-x_in,  r_in * c1,  r_in * s1]
            p_in_r0  = [+x_in,  r_in * c0,  r_in * s0]
            p_in_r1  = [+x_in,  r_in * c1,  r_in * s1]
            p_out_l0 = [-x_out, r_out * c0, r_out * s0]
            p_out_l1 = [-x_out, r_out * c1, r_out * s1]
            p_out_r0 = [+x_out, r_out * c0, r_out * s0]
            p_out_r1 = [+x_out, r_out * c1, r_out * s1]
            mb.add_quad(p_out_l0, p_out_r0, p_out_r1, p_out_l1, mat_idx)
            mb.add_quad(p_in_r0, p_in_l0, p_in_l1, p_in_r1, mat_idx)
            mb.add_quad(p_in_l0, p_out_l0, p_out_l1, p_in_l1, mat_idx)
            mb.add_quad(p_out_r0, p_in_r0, p_in_r1, p_out_r1, mat_idx)

    # 1. Crowned Forged-Iron Tire Band (`R = 0.146..0.1650 m`) with stepped sidewall lip (`X = ±0.055 -> ±0.046 m`)
    add_annular_ring(0.146, 0.159, 0.055, 0.055, MAT_IRON)
    add_annular_ring(0.159, 0.1650, 0.055, 0.045, MAT_IRON)

    # 2. Chamfered Seasoned-Oak Felloe Ring (`R = 0.104..0.146 m`, `X = ±0.047 m`)
    add_annular_ring(0.104, 0.146, 0.047, 0.047, MAT_TIMBER)

    # 3. Inner Cast-Bronze Felloe Compression Band (`R = 0.095..0.104 m`, `X = ±0.050 m`)
    add_annular_ring(0.095, 0.104, 0.050, 0.050, MAT_BRONZE)

    # 4. 12 Wrap-Around Iron Tire Strake Clamps & Bronze Bolt Bosses
    for k in range(12):
        ang = k * (2.0 * math.pi / 12.0)
        ca, sa = math.cos(ang), math.sin(ang)
        mb.add_chamfered_beam([0.0, 0.130 * ca, 0.130 * sa], [0.0, 0.161 * ca, 0.161 * sa], 0.116, 0.022, mat_idx=MAT_IRON, chamfer=0.003)
        mb.add_chamfered_beam([0.0, 0.133 * ca, 0.133 * sa], [0.0, 0.143 * ca, 0.143 * sa], 0.122, 0.014, mat_idx=MAT_BRONZE, chamfer=0.002)

    # 5. 8 Tapered Octagonal Oak Spokes (`R = 0.046..0.098 m`) + Flanged Hub & Felloe Mortise Shoes + Felloe Scarf-Joint Plates
    for k in range(8):
        ang = k * (math.pi / 4.0)
        ca, sa = math.cos(ang), math.sin(ang)
        # Lower-half spoke (wider root `0.046 x 0.038 m`)
        mb.add_chamfered_beam([0.0, 0.048 * ca, 0.048 * sa], [0.0, 0.076 * ca, 0.076 * sa], 0.046, 0.036, mat_idx=MAT_TIMBER, chamfer=0.006)
        # Upper-half spoke (tapered neck `0.036 x 0.028 m`)
        mb.add_chamfered_beam([0.0, 0.072 * ca, 0.072 * sa], [0.0, 0.099 * ca, 0.099 * sa], 0.036, 0.028, mat_idx=MAT_TIMBER, chamfer=0.005)
        # Flanged iron spoke-root collar (`R = 0.052..0.064 m`)
        mb.add_chamfered_beam([0.0, 0.052 * ca, 0.052 * sa], [0.0, 0.064 * ca, 0.064 * sa], 0.054, 0.042, mat_idx=MAT_IRON, chamfer=0.004)
        # Flanged iron felloe-mortise shoe (`R = 0.086..0.097 m`)
        mb.add_chamfered_beam([0.0, 0.086 * ca, 0.086 * sa], [0.0, 0.097 * ca, 0.097 * sa], 0.050, 0.038, mat_idx=MAT_IRON, chamfer=0.004)

        # Mid-felloe scarf-joint iron splice plate (`ang + pi/8`)
        ang_j = ang + (math.pi / 8.0)
        cj, sj = math.cos(ang_j), math.sin(ang_j)
        mb.add_chamfered_beam([0.0, 0.112 * cj, 0.112 * sj], [0.0, 0.138 * cj, 0.138 * sj], 0.100, 0.028, mat_idx=MAT_IRON, chamfer=0.003)

    # 6. 12-Faceted Cast-Bronze Nave Hub, Inboard Axle-Bearing Sleeve & Outboard Iron Linchpin Keeper
    s = float(side_sign) # +1.0 for Left (+X outer), -1.0 for Right (-X outer)
    # Inboard extended axle-journal collar (`-s*0.074 .. +s*0.060 m`) so the hub visibly sleeves onto the carriage axle!
    mb.add_cylinder([-s * 0.074, 0.0, 0.0], [+s * 0.060, 0.0, 0.0], 0.046, mat_idx=MAT_IRON, segs=12)
    mb.add_cylinder([-0.058, 0.0, 0.0], [+0.058, 0.0, 0.0], 0.058, mat_idx=MAT_BRONZE, segs=12)
    mb.add_cylinder([-0.044, 0.0, 0.0], [+0.044, 0.0, 0.0], 0.065, mat_idx=MAT_IRON,   segs=12)
    mb.add_cylinder([-0.018, 0.0, 0.0], [+0.018, 0.0, 0.0], 0.069, mat_idx=MAT_BRONZE, segs=12)
    # Outboard bronze hub nose & forged-iron linchpin keeper pin
    mb.add_cylinder([0.0, 0.0, 0.0], [s * 0.066, 0.0, 0.0], 0.044, mat_idx=MAT_BRONZE, segs=12)
    mb.add_cylinder([s * 0.054, 0.0, 0.0], [s * 0.070, 0.0, 0.0], 0.030, mat_idx=MAT_IRON, segs=8)
    mb.add_box(s * 0.060 - 0.007, s * 0.060 + 0.007, -0.044, +0.044, -0.010, +0.010, mat_idx=MAT_BRONZE, chamfer=0.002)

    verts = np.array(mb.verts, dtype=np.float32)
    poly_offsets = [0]
    corner_verts, uv_map = [], []
    for pv, puv in zip(mb.poly_verts, mb.poly_uvs):
        corner_verts.extend(pv); uv_map.extend(puv); poly_offsets.append(len(corner_verts))
    return (
        verts,
        np.array(poly_offsets, dtype=np.int32),
        np.array(corner_verts, dtype=np.int32),
        np.array(uv_map, dtype=np.float32),
        np.array(mb.poly_mats, dtype=np.int32),
    )


# =============================================================================
# 3. PART C: INTEGRATED UNDERCARRIAGE & REAR AXLE SUBFRAME (`Z = -0.820 m`)
# =============================================================================

def build_v25_integrated_axle_carriage_mesh():
    """
    Builds `MECarriage_Main_Mesh.003` at `1.0x` scale with:
      - Preserved v2.4 rear axle relocation at `Z = -0.820 m` (`1.145 m` local / `3.2633 m` world wheelbase).
      - Fully integrated Underbody Structural Subframe (`Y = 0.125..0.245 m`, `Z = +0.440..-1.100 m`):
        1. Twin continuous longitudinal under-chassis keel stringers (`X = ±0.118 m`) running from the front
           axle bolster (`Z = +0.325 m`) all the way back through the mid-chassis cross-ties into the rear
           axle bolster (`Z = -0.820 m`) and rear boarding frame (`Z = -1.100 m`).
        2. Triangulated Fore-and-Aft Diagonal Axle Hound-Struts (`Reach Braces`) on BOTH the Front Axle
           (`Z = +0.325 m`) and Relocated Rear Axle (`Z = -0.820 m`), connecting the outboard axle journals
           (`X = ±0.310..0.345 m, Y = 0.165 m`) diagonally into the lower sills and keel stringers!
        3. Arched Walnut & Forged-Iron Axle Saddle Bolsters, U-Bolt Clamps, and Wheel-Well Cheek Plates
           at `Z = -0.820 m` so the rear axle is structurally woven into the carriage from underneath, side, and 3/4 views.
    """
    mb = CleanMeshBuilder()
    B = 1.065

    for side in (-1.0, +1.0):
        x_low = side * 0.205
        x_up  = side * 0.285
        x_mid = side * 0.245

        # --- A. Stepped Lower Sill with Sculpted Wheel-Well Arches at Z = +0.325m AND Z = -0.820m ---
        mb.add_chamfered_beam([x_low, 0.205, +0.475], [x_low, 0.238, +0.365], 0.096*B, 0.084*B, mat_idx=1, chamfer=0.008)
        mb.add_chamfered_beam([x_low, 0.244, +0.375], [x_low, 0.244, +0.235], 0.098*B, 0.078*B, mat_idx=1, chamfer=0.008)
        mb.add_chamfered_beam([x_low, 0.242, +0.245], [x_low, 0.165, +0.155], 0.096*B, 0.084*B, mat_idx=1, chamfer=0.008)
        # Dropped mid-carriage belly sill (`Z = +0.165m` to `-0.645m`, `Y = 0.165m`)
        mb.add_chamfered_beam([x_low, 0.165, +0.165], [x_low, 0.165, -0.645], 0.100*B, 0.090*B, mat_idx=1, chamfer=0.009)
        # Integrated Rear Wheel-Well Arch over `Z = -0.820m` (`Z = -0.645m .. -0.995m`)
        mb.add_chamfered_beam([x_low, 0.165, -0.635], [x_low, 0.246, -0.710], 0.098*B, 0.086*B, mat_idx=1, chamfer=0.008)
        mb.add_chamfered_beam([x_low, 0.248, -0.700], [x_low, 0.248, -0.940], 0.100*B, 0.084*B, mat_idx=1, chamfer=0.008)
        mb.add_chamfered_beam([x_low, 0.246, -0.930], [x_low, 0.198, -1.130], 0.098*B, 0.084*B, mat_idx=1, chamfer=0.008)
        # Forged-iron arch liner strap under the rear wheel well (`Z = -0.655 .. -0.985 m`)
        mb.add_chamfered_beam([x_low, 0.205, -0.705], [x_low, 0.205, -0.935], 0.106*B, 0.032*B, mat_idx=2, chamfer=0.004)

        # --- B. Sculpted Tapered Upper Compression Chord ---
        mb.add_chamfered_beam([x_up, 0.488, +0.462], [x_up, 0.595, +0.145], 0.096*B, 0.092*B, mat_idx=1, chamfer=0.009)
        mb.add_chamfered_beam([x_up, 0.598, +0.155], [x_up, 0.598, -0.245], 0.100*B, 0.095*B, mat_idx=0, chamfer=0.009)
        mb.add_chamfered_beam([x_up, 0.595, -0.235], [x_up, 0.525, -0.715], 0.096*B, 0.090*B, mat_idx=1, chamfer=0.009)

        # --- C. Truss Posts & Diagonal Braces ---
        mb.add_chamfered_beam([x_low, 0.205, +0.440], [x_up, 0.495, +0.440], 0.078*B, 0.078*B, mat_idx=0, chamfer=0.007)
        mb.add_chamfered_beam([x_low, 0.165, +0.135], [x_up, 0.598, +0.135], 0.076*B, 0.076*B, mat_idx=0, chamfer=0.007)
        mb.add_chamfered_beam([x_low, 0.165, -0.245], [x_up, 0.598, -0.245], 0.076*B, 0.076*B, mat_idx=0, chamfer=0.007)
        mb.add_chamfered_beam([x_low, 0.185, -0.655], [x_up, 0.535, -0.655], 0.082*B, 0.082*B, mat_idx=0, chamfer=0.007)
        # Rear Axle Kingpost directly above `Z = -0.820m` linking Rear Wheel Arch (`Y=0.244`) to Rider Hip Rail (`Y=0.545`)
        mb.add_chamfered_beam([x_low, 0.240, -0.820], [side*0.268, 0.545, -0.820], 0.078*B, 0.078*B, mat_idx=0, chamfer=0.007)

        mb.add_chamfered_beam([x_mid, 0.195, +0.145], [x_mid, 0.468, +0.430], 0.062*B, 0.062*B, mat_idx=0, chamfer=0.006)
        mb.add_chamfered_beam([x_mid, 0.185, -0.235], [x_mid, 0.305, +0.125], 0.058*B, 0.058*B, mat_idx=0, chamfer=0.006)
        mb.add_chamfered_beam([x_mid, 0.195, -0.255], [x_mid, 0.495, -0.645], 0.062*B, 0.062*B, mat_idx=0, chamfer=0.006)
        # Diagonal rear-axle load-transfer struts from `Z = -0.820m` wheel arch forward-up to `Z = -0.655m` and aft-up to `Z = -1.025m`
        mb.add_chamfered_beam([x_low, 0.244, -0.820], [x_mid, 0.465, -0.660], 0.060*B, 0.060*B, mat_idx=2, chamfer=0.005)
        mb.add_chamfered_beam([x_low, 0.244, -0.820], [side*0.265, 0.485, -1.025], 0.058*B, 0.058*B, mat_idx=2, chamfer=0.005)

        # --- D. Forged-Iron Node Gussets & Brass Rivet Caps ---
        mb.add_iron_strap_with_rivets(x_up,  0.490, +0.440, 0.112*B, 0.110*B, 0.085*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_up,  0.598, +0.135, 0.116*B, 0.112*B, 0.090*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_up,  0.598, -0.245, 0.116*B, 0.112*B, 0.090*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_up,  0.525, -0.655, 0.112*B, 0.110*B, 0.085*B, rivet_axis='x')

        mb.add_iron_strap_with_rivets(x_low, 0.215, +0.440, 0.110*B, 0.098*B, 0.082*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_low, 0.165, +0.135, 0.112*B, 0.102*B, 0.086*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_low, 0.165, -0.245, 0.112*B, 0.102*B, 0.086*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_low, 0.195, -0.655, 0.110*B, 0.098*B, 0.082*B, rivet_axis='x')
        mb.add_iron_strap_with_rivets(x_low, 0.244, -0.820, 0.116*B, 0.108*B, 0.102*B, rivet_axis='x')

        # --- E. Physical Banner Hangers ---
        mb.add_box(side*0.235 if side>0 else -0.348, side*0.348 if side>0 else -0.235,
                   0.512, 0.532, +0.055, +0.175, mat_idx=2, chamfer=0.003)
        mb.add_cylinder([side*0.258, 0.520, +0.045], [side*0.258, 0.520, +0.185], 0.011, mat_idx=3, segs=10)

        mb.add_chamfered_beam([side*0.272, 0.220, -0.715], [side*0.272, 0.735, -0.715], 0.052*B, 0.052*B, mat_idx=1, chamfer=0.005)
        mb.add_iron_strap_with_rivets(side*0.272, 0.610, -0.715, 0.068, 0.055, 0.068, rivet_axis='x')
        mb.add_chamfered_beam([side*0.272, 0.724, -0.695], [side*0.272, 0.724, -0.805], 0.032, 0.028, mat_idx=2, chamfer=0.003)
        mb.add_box(side*0.272 - 0.028, side*0.272 + 0.028, 0.732, 0.752, -0.740, -0.690, mat_idx=3, chamfer=0.004)

    # 2. Forward Stator Yoke & Open Sightline Piston Cradle (`Y = 0.365 m`)
    mb.add_chamfered_beam([-0.245, 0.205, +0.445], [+0.245, 0.205, +0.445], 0.078*B, 0.072*B, mat_idx=2, chamfer=0.006)
    for side in (-1.0, +1.0):
        mb.add_chamfered_beam([side*0.225, 0.215, +0.455], [side*0.185, 0.365, +0.465], 0.058*B, 0.058*B, mat_idx=2, chamfer=0.005)
        mb.add_chamfered_beam([side*0.265, 0.485, +0.445], [side*0.175, 0.435, +0.460], 0.054*B, 0.054*B, mat_idx=2, chamfer=0.005)

    for z_tie in (+0.135, -0.245, -0.580):
        for sx in (-1.0, +1.0):
            if z_tie > -0.40:
                mb.add_chamfered_beam([sx*0.285, 0.565, z_tie], [sx*0.215, 0.485, z_tie], 0.052*B, 0.052*B, mat_idx=2, chamfer=0.004)
        mb.add_chamfered_beam([-0.235, 0.172, z_tie], [+0.235, 0.172, z_tie], 0.088*B, 0.074*B, mat_idx=1, chamfer=0.007)
        mb.add_chamfered_beam([-0.195, 0.182, z_tie], [-0.115, 0.262, z_tie], 0.052*B, 0.052*B, mat_idx=2, chamfer=0.004)
        mb.add_chamfered_beam([+0.195, 0.182, z_tie], [+0.115, 0.262, z_tie], 0.052*B, 0.052*B, mat_idx=2, chamfer=0.004)

    # -------------------------------------------------------------------------
    # 3. SUBSTANTIVE v2.5 INTEGRATED UNDERBODY SUBFRAME & AXLE HOUND-TRUSSES (`Z = +0.325m` & `Z = -0.820m`)
    # -------------------------------------------------------------------------
    # A. Twin Continuous Longitudinal Under-Chassis Keel Stringers (`X = ±0.115 m, Y = 0.158 m, Z = +0.440..-1.080 m`)
    for sx in (-1.0, +1.0):
        mb.add_chamfered_beam([sx * 0.115, 0.158, +0.440], [sx * 0.115, 0.158, -1.080], 0.068*B, 0.064*B, mat_idx=1, chamfer=0.006)
        # Diagonal under-belly X-bracing between keel stringers and outer lower sills
        mb.add_chamfered_beam([sx * 0.115, 0.158, +0.135], [sx * 0.205, 0.165, -0.245], 0.048*B, 0.044*B, mat_idx=2, chamfer=0.004)
        mb.add_chamfered_beam([sx * 0.205, 0.165, +0.135], [sx * 0.115, 0.158, -0.245], 0.048*B, 0.044*B, mat_idx=2, chamfer=0.004)
        mb.add_chamfered_beam([sx * 0.115, 0.158, -0.245], [sx * 0.205, 0.165, -0.580], 0.048*B, 0.044*B, mat_idx=2, chamfer=0.004)

    # B. Front Steerable Axle Subframe at `Z = +0.325 m` (`X = ±0.430 m`, `Y = 0.165 m`)
    mb.add_chamfered_beam([-0.430, 0.165, +0.325], [+0.430, 0.165, +0.325], 0.062*B, 0.062*B, mat_idx=2, chamfer=0.005)
    mb.add_chamfered_beam([-0.345, 0.198, +0.325], [+0.345, 0.198, +0.325], 0.088*B, 0.068*B, mat_idx=1, chamfer=0.006)
    mb.add_cylinder([0.0, 0.142, +0.325], [0.0, 0.218, +0.325], 0.085, mat_idx=2, segs=12) # Front bolster swivel ring
    for sx in (-1.0, +1.0):
        # Front axle diagonal hound-struts (fore & aft triangulated reach bars)
        mb.add_chamfered_beam([sx * 0.325, 0.168, +0.325], [sx * 0.205, 0.195, +0.445], 0.050*B, 0.048*B, mat_idx=2, chamfer=0.004)
        mb.add_chamfered_beam([sx * 0.325, 0.168, +0.325], [sx * 0.205, 0.165, +0.145], 0.054*B, 0.050*B, mat_idx=2, chamfer=0.004)
        mb.add_chamfered_beam([sx * 0.310, 0.168, +0.325], [sx * 0.205, 0.244, +0.325], 0.064*B, 0.062*B, mat_idx=1, chamfer=0.005)
        mb.add_iron_strap_with_rivets(sx * 0.305, 0.185, +0.325, 0.068, 0.082, 0.076, rivet_axis='x')

    # C. Relocated Rear Axle Structural Subframe at `Z = -0.820 m` (`X = ±0.370 m`, `Y = 0.165 m`)
    #    Woven directly into the lower sills, keel stringers, and rear riding platform!
    mb.add_chamfered_beam([-0.370, 0.165, REAR_AXLE_Z_NEW], [+0.370, 0.165, REAR_AXLE_Z_NEW], 0.066*B, 0.066*B, mat_idx=2, chamfer=0.005)
    # Sculpted walnut axle-bed bolster beam spanning across the lower chassis and keel stringers
    mb.add_chamfered_beam([-0.315, 0.198, REAR_AXLE_Z_NEW], [+0.315, 0.198, REAR_AXLE_Z_NEW], 0.094*B, 0.072*B, mat_idx=1, chamfer=0.007)
    # Central cast-iron & brass bolster turntable ring & kingpin boss at `[0.0, 0.142..0.220, -0.820]`
    mb.add_cylinder([0.0, 0.142, REAR_AXLE_Z_NEW], [0.0, 0.222, REAR_AXLE_Z_NEW], 0.092, mat_idx=2, segs=12)
    mb.add_cylinder([0.0, 0.135, REAR_AXLE_Z_NEW], [0.0, 0.155, REAR_AXLE_Z_NEW], 0.056, mat_idx=3, segs=10)
    for sx in (-1.0, +1.0):
        # Arched walnut & iron axle-tree cheeks rising from the Rear Axle (`X=±0.285, Y=0.165`) into the Wheel-Arch Bridge (`X=±0.205, Y=0.248`)
        mb.add_chamfered_beam([sx * 0.295, 0.165, REAR_AXLE_Z_NEW], [sx * 0.205, 0.246, REAR_AXLE_Z_NEW], 0.074*B, 0.074*B, mat_idx=1, chamfer=0.006)
        # Forward diagonal axle hound-strut (`reach rod`) from Rear Axle (`X=±0.290, Y=0.165, Z=-0.820`) to Mid-Belly Crossbeam (`X=±0.205, Y=0.168, Z=-0.580`)
        mb.add_chamfered_beam([sx * 0.290, 0.165, REAR_AXLE_Z_NEW], [sx * 0.205, 0.168, -0.580], 0.058*B, 0.054*B, mat_idx=2, chamfer=0.005)
        # Inboard forward hound-strut from Rear Axle (`X=±0.245, Y=0.165, Z=-0.820`) to Keel Stringer (`X=±0.115, Y=0.158, Z=-0.580`)
        mb.add_chamfered_beam([sx * 0.245, 0.165, REAR_AXLE_Z_NEW], [sx * 0.115, 0.158, -0.580], 0.050*B, 0.048*B, mat_idx=1, chamfer=0.005)
        # Rearward diagonal axle hound-strut from Rear Axle (`X=±0.290, Y=0.165, Z=-0.820`) to Rear Tail Frame (`X=±0.225, Y=0.195, Z=-1.065`)
        mb.add_chamfered_beam([sx * 0.290, 0.165, REAR_AXLE_Z_NEW], [sx * 0.225, 0.195, -1.065], 0.056*B, 0.052*B, mat_idx=2, chamfer=0.005)
        # Forged-iron U-bolt saddle clamp & brass keeper plates around the rear axle journal (`X = ±0.285 m`)
        mb.add_iron_strap_with_rivets(sx * 0.285, 0.188, REAR_AXLE_Z_NEW, 0.072, 0.088, 0.084, rivet_axis='x')
        mb.add_cylinder([sx * 0.305, 0.165, REAR_AXLE_Z_NEW], [sx * 0.365, 0.165, REAR_AXLE_Z_NEW], 0.042, mat_idx=3, segs=12)

    # Full-length under-carriage oak belly planks (`Z = +0.390 .. -0.630 m`)
    for zp in np.linspace(+0.39, -0.63, 10):
        mb.add_box(-0.205, +0.205, 0.118, 0.150, zp - 0.038, zp + 0.038, mat_idx=0, chamfer=0.004)

    # 4. Integrated Rear Driving Station (`Z = -0.710..-1.180 m`, `|X| <= 0.265 m` so inner wheel faces at `|X| = 0.312 m` have +47mm per-side clearance!)
    for side in (-1.0, +1.0):
        mb.add_chamfered_beam([side*0.235, 0.195, -0.660], [side*0.235, 0.205, -1.130], 0.068*B, 0.068*B, mat_idx=1, chamfer=0.006)
        mb.add_chamfered_beam([side*0.265, 0.565, -0.715], [side*0.265, 0.520, -1.035], 0.054*B, 0.050*B, mat_idx=1, chamfer=0.006)
        mb.add_chamfered_beam([side*0.265, 0.220, -1.080], [side*0.265, 0.525, -1.020], 0.052*B, 0.052*B, mat_idx=2, chamfer=0.005)
        mb.add_box(side*0.265 - 0.030, side*0.265 + 0.030, 0.512, 0.542, -1.055, -0.995, mat_idx=3, chamfer=0.004)

        fx = side * 0.115
        mb.add_box(fx - 0.058, fx + 0.058, 0.224, 0.254, -0.795, -0.765, mat_idx=2, chamfer=0.003)
        mb.add_box(fx - 0.058, fx - 0.038, 0.224, 0.246, -0.935, -0.775, mat_idx=2, chamfer=0.003)
        mb.add_box(fx + 0.038, fx + 0.058, 0.224, 0.246, -0.935, -0.775, mat_idx=2, chamfer=0.003)
        mb.add_box(fx - 0.048, fx + 0.048, 0.224, 0.235, -0.925, -0.785, mat_idx=3, chamfer=0.002)

    # Raised Slatted Oak Riding Platform Deck (`|X| <= 0.255 m`, `Y = +0.226 m`)
    for zp in (-0.755, -0.835, -0.915, -0.995, -1.075):
        mb.add_box(-0.255, +0.255, 0.192, 0.226, zp - 0.034, zp + 0.034, mat_idx=0, chamfer=0.004)

    mb.add_chamfered_beam([-0.265, 0.520, -1.025], [+0.265, 0.520, -1.025], 0.052, 0.052, mat_idx=1, chamfer=0.005)
    mb.add_box(-0.140, +0.140, 0.495, 0.550, -1.045, -0.985, mat_idx=4, chamfer=0.008)
    mb.add_chamfered_beam([0.0, 0.226, -0.955], [0.0, 0.465, -0.925], 0.062, 0.062, mat_idx=2, chamfer=0.005)
    mb.add_box(-0.080, +0.080, 0.455, 0.495, -0.975, -0.855, mat_idx=4, chamfer=0.008)

    mb.add_chamfered_beam([-0.265, 0.205, -1.130], [+0.265, 0.205, -1.130], 0.062, 0.055, mat_idx=2, chamfer=0.005)
    mb.add_box(-0.220, +0.220, 0.135, 0.168, -1.180, -1.120, mat_idx=2, chamfer=0.004)

    mb.add_chamfered_beam([-0.275, 0.572, -0.710], [+0.275, 0.572, -0.710], 0.058, 0.052, mat_idx=1, chamfer=0.006)
    mb.add_cylinder([+0.115, 0.195, -0.665], [+0.115, 0.600, -0.710], 0.019, mat_idx=2, segs=10)
    mb.add_cylinder([+0.055, 0.600, -0.705], [+0.185, 0.600, -0.730], 0.021, mat_idx=4, segs=10)
    mb.add_cylinder([-0.055, 0.600, -0.705], [-0.185, 0.600, -0.730], 0.021, mat_idx=4, segs=10)
    mb.add_box(+0.045, +0.075, 0.565, 0.608, -0.725, -0.695, mat_idx=2, chamfer=0.003)
    mb.add_box(-0.075, -0.045, 0.565, 0.608, -0.725, -0.695, mat_idx=2, chamfer=0.003)
    mb.add_cylinder([+0.185, 0.600, -0.730], [+0.202, 0.600, -0.734], 0.025, mat_idx=3, segs=10)
    mb.add_cylinder([-0.185, 0.600, -0.730], [-0.202, 0.600, -0.734], 0.025, mat_idx=3, segs=10)

    mb.add_box(-0.068, +0.068, 0.490, 0.585, -0.715, -0.515, mat_idx=2, chamfer=0.005)
    mb.add_box(-0.048, +0.048, 0.580, 0.598, -0.695, -0.535, mat_idx=3, chamfer=0.003)

    verts = np.array(mb.verts, dtype=np.float32)
    poly_offsets = [0]
    corner_verts, uv_map = [], []
    for pv, puv in zip(mb.poly_verts, mb.poly_uvs):
        corner_verts.extend(pv); uv_map.extend(puv); poly_offsets.append(len(corner_verts))
    return (
        verts,
        np.array(poly_offsets, dtype=np.int32),
        np.array(corner_verts, dtype=np.int32),
        np.array(uv_map, dtype=np.float32),
        np.array(mb.poly_mats, dtype=np.int32),
    )


# =============================================================================
# 4. EXPORT
def build_and_export_sofist_v25():
    bf = blend_io.BlendFile(str(WORK_DIR / "SoFist-crafted-uncompressed.blend"))
    ob_layout = bf.get_layout("Object")

    # 1. Update Carriage Main with relocated rear axle structure (`Z = -0.820 m`)
    c_pos, c_poff, c_cv, c_uv, c_midx = build_v25_integrated_axle_carriage_mesh()
    update_blend_mesh_from_gltf_arrays(bf, "MECarriage_Main_Mesh.003", c_pos, c_poff, c_cv, c_uv, c_midx)

    # 2. Update Armored Fist with crisp, deliberately faceted low-poly gauntlet geometry
    f_pos, f_poff, f_cv, f_uv, f_midx = build_v25_synthesized_armored_fist_mesh()
    update_blend_mesh_from_gltf_arrays(bf, "MEArmored_Fist_Mesh.003", f_pos, f_poff, f_cv, f_uv, f_midx)

    # 3. Update all 4 Wheels with crisp, deliberately constructed low-poly wheel geometry
    w_l_tup = build_v25_cohesive_siege_wheel_mesh(+1.0)
    w_r_tup = build_v25_cohesive_siege_wheel_mesh(-1.0)
    update_blend_mesh_from_gltf_arrays(bf, "MEWheel_FL_Mesh.004", *w_l_tup)
    update_blend_mesh_from_gltf_arrays(bf, "MEWheel_RL_Mesh.004", *w_l_tup)
    update_blend_mesh_from_gltf_arrays(bf, "MEWheel_FR_Mesh.004", *w_r_tup)
    update_blend_mesh_from_gltf_arrays(bf, "MEWheel_RR_Mesh.004", *w_r_tup)

    # 4. Relocate `OBWheel_RL.004` and `OBWheel_RR.004` in the Blender Object blocks from Z_gltf = -0.420m (`Y_blend = +0.420m`)
    #    to `Z_gltf = -0.820m` (`Y_blend = +0.820m`)!
    for b in bf.blocks:
        if b["code"] == "OB":
            ob_id = bf.get_id_name(b)
            if ob_id == "OBWheel_RL.004":
                struct.pack_into("<3f", b["payload"], ob_layout["loc"][0], +0.370, float(-REAR_AXLE_Z_NEW), +0.165)
            elif ob_id == "OBWheel_RR.004":
                struct.pack_into("<3f", b["payload"], ob_layout["loc"][0], -0.370, float(-REAR_AXLE_Z_NEW), +0.165)

    # 5. Smooth cylindrical running surfaces on Piston & Collars at 1.0x scale
    # Piston/Collar smoothing & FCurve retiming already present in v2.4 base blend

    uncomp_path = WORK_DIR / "SoFist-v25-runtime-source-uncompressed.blend"
    bf.save(str(uncomp_path))

    libzstd = ctypes.CDLL("libzstd.so.1")
    libzstd.ZSTD_compressBound.argtypes = [ctypes.c_size_t]
    libzstd.ZSTD_compressBound.restype = ctypes.c_size_t
    libzstd.ZSTD_compress.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
    libzstd.ZSTD_compress.restype = ctypes.c_size_t

    raw_b = uncomp_path.read_bytes()
    bound = libzstd.ZSTD_compressBound(len(raw_b))
    dst = ctypes.create_string_buffer(bound)
    c_size = libzstd.ZSTD_compress(dst, bound, raw_b, len(raw_b), 3)
    out_blend = OUT_DIR / "SoFist-v25-runtime-source.blend"
    out_blend.write_bytes(dst.raw[:c_size])
    blend_sha = hashlib.sha256(out_blend.read_bytes()).hexdigest()
    print(f"[OK] Exported {out_blend.name}: {c_size:,} bytes ({c_size/1048576:.2f} MB), SHA256={blend_sha}")

    # 7. Export `so-fist-ication-v25-review.glb` with crisp pairwise face-normal welding:
    #    - On `Armored_Fist_Mesh` and `Carriage_Main_Mesh`: strict `18 deg` crease threshold so every single
    #      bevel, knuckle, finger plate, and timber beam facet is 100% crisp flat-shaded!
    #    - On `Wheel_*_Mesh`: smooth circumferential normals ONLY on the outer iron running tread (`r_yz >= 0.158m`
    #      and `|fn_x| < 0.25`), while keeping all wheel sidewalls, bevels, felloes, spokes, and hubs 100% crisp flat-shaded!
    ptr_to_name = {b["old"]: bf.get_id_name(b) for b in bf.blocks}
    me_layout = bf.get_layout("Mesh")
    cd_layout = bf.get_layout("CustomData")
    cdl_layout = bf.get_layout("CustomDataLayer")

    bin_chunks = bytearray()
    buffer_views, accessors = [], []

    def add_bv(raw_bytes: bytes, target=None):
        pad = (4 - (len(bin_chunks) % 4)) % 4
        if pad: bin_chunks.extend(b"\x00" * pad)
        off = len(bin_chunks)
        bin_chunks.extend(raw_bytes)
        bv = {"buffer": 0, "byteOffset": off, "byteLength": len(raw_bytes)}
        if target is not None: bv["target"] = target
        idx = len(buffer_views)
        buffer_views.append(bv)
        return idx

    def add_acc(bv_idx: int, comp_type: int, count: int, acc_type: str, vmin=None, vmax=None):
        acc = {"bufferView": bv_idx, "componentType": comp_type, "count": count, "type": acc_type}
        if vmin is not None: acc["min"] = [float(x) if comp_type == 5126 else int(x) for x in vmin]
        if vmax is not None: acc["max"] = [float(x) if comp_type == 5126 else int(x) for x in vmax]
        idx = len(accessors)
        accessors.append(acc)
        return idx

    tex_files = [
        ("texture_diffuse", str(WORK_DIR / "IMtexture_diffuse.006.png")),
        ("texture_metallic-texture_roughness", str(WORK_DIR / "IMtexture_metallic-texture_roughness.006.png")),
        ("texture_normal", str(WORK_DIR / "IMtexture_normal.006.png")),
        ("texture_emissive", str(WORK_DIR / "IMtexture_emissive.003.png")),
    ]
    images, textures = [], []
    samplers = [{"magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497}]
    for tname, tpath in tex_files:
        im = Image.open(tpath)
        buf = io.BytesIO()
        im.save(buf, format="PNG", optimize=True, compress_level=9)
        bv_i = add_bv(buf.getvalue())
        img_i = len(images)
        images.append({"name": tname, "mimeType": "image/png", "bufferView": bv_i})
        textures.append({"sampler": 0, "source": img_i, "name": tname})

    mat_id_to_idx = {}
    gltf_materials = []
    for idx, (ma_id, spec) in enumerate(MATERIAL_DEFS_V25):
        mat_id_to_idx[ma_id] = idx
        pbr = {}
        for k in ("baseColorFactor", "metallicFactor", "roughnessFactor"):
            if k in spec: pbr[k] = spec[k]
        if "baseColorTexture" in spec: pbr["baseColorTexture"] = {"index": spec["baseColorTexture"]}
        if "metallicRoughnessTexture" in spec: pbr["metallicRoughnessTexture"] = {"index": spec["metallicRoughnessTexture"]}
        m_obj = {"name": clean_prefix(ma_id, "MA"), "pbrMetallicRoughness": pbr, "doubleSided": spec.get("doubleSided", False)}
        if "normalTexture" in spec: m_obj["normalTexture"] = {"index": spec["normalTexture"]}
        if "emissiveTexture" in spec:
            m_obj["emissiveTexture"] = {"index": spec["emissiveTexture"]}
            m_obj["emissiveFactor"] = spec.get("emissiveFactor", [1.0, 1.0, 1.0])
        gltf_materials.append(m_obj)

    me_id_to_idx = {}
    gltf_meshes = []
    total_welded_verts = 0
    total_tris = 0

    for b in bf.blocks:
        if b["code"] == "ME":
            me_id = bf.get_id_name(b)
            me_buf = b["payload"]
            totvert, totedge, totpoly, totloop = struct.unpack_from("<4i", me_buf, me_layout["totvert"][0])
            totcol = struct.unpack_from("<h", me_buf, me_layout["totcol"][0])[0]
            mat_ptr = struct.unpack_from("<Q", me_buf, me_layout["mat"][0])[0]
            mat_names = [ptr_to_name.get(p, "MARam candidate timber.003") for p in struct.unpack_from(f"<{totcol}Q", bf.ptr_map[mat_ptr]["payload"], 0)] if (mat_ptr in bf.ptr_map and totcol > 0) else ["MARam candidate timber.003"]
            poly_off_ptr = struct.unpack_from("<Q", me_buf, me_layout["poly_offset_indices"][0])[0]
            poly_offsets = np.frombuffer(bf.ptr_map[poly_off_ptr]["payload"], dtype=np.int32, count=totpoly+1).copy()

            pos, corner_verts, uv_map, mat_idx = None, None, None, np.zeros(totpoly, dtype=np.int32)
            for cname, cnt in [("vdata", totvert), ("pdata", totpoly), ("ldata", totloop)]:
                coff = me_layout[cname][0]
                lptr = struct.unpack_from("<Q", me_buf, coff + cd_layout["layers"][0])[0]
                tlay = struct.unpack_from("<i", me_buf, coff + cd_layout["totlayer"][0])[0]
                if not lptr or tlay == 0: continue
                lb = bf.ptr_map[lptr]
                for li in range(tlay):
                    loff = li * 120
                    lname = bytes(lb["payload"][loff+cdl_layout["name"][0]:loff+cdl_layout["name"][0]+68]).split(b"\x00")[0].decode("utf-8", "replace")
                    dptr = struct.unpack_from("<Q", lb["payload"], loff + cdl_layout["data"][0])[0]
                    if dptr not in bf.ptr_map: continue
                    db = bf.ptr_map[dptr]
                    if cname == "vdata" and lname == "position":
                        pos = np.frombuffer(db["payload"], dtype=np.float32, count=totvert*3).reshape(totvert, 3).copy()
                    elif cname == "pdata" and lname == "material_index":
                        mat_idx = np.frombuffer(db["payload"], dtype=np.int32, count=totpoly).copy()
                    elif cname == "ldata" and lname == ".corner_vert":
                        corner_verts = np.frombuffer(db["payload"], dtype=np.int32, count=totloop).copy()
                    elif cname == "ldata" and lname == "UVMap":
                        uv_map = np.frombuffer(db["payload"], dtype=np.float32, count=totloop*2).reshape(totloop, 2).copy()

            pos_gltf = np.column_stack([pos[:, 0], pos[:, 2], -pos[:, 1]]).astype(np.float32)

            face_norms = np.zeros((totpoly, 3), dtype=np.float32)
            vert_faces = defaultdict(list)
            for pi in range(totpoly):
                s, e = int(poly_offsets[pi]), int(poly_offsets[pi+1])
                if e - s < 3: continue
                vs = corner_verts[s:e]
                fn = np.cross(pos_gltf[vs[1]] - pos_gltf[vs[0]], pos_gltf[vs[2]] - pos_gltf[vs[0]])
                fl = float(np.linalg.norm(fn))
                if fl > 1e-10:
                    fn /= fl
                    face_norms[pi] = fn
                    for v in vs:
                        vert_faces[int(v)].append(pi)

            # Pairwise face-normal crease clustering:
            # - For Armored_Fist_Mesh and Carriage_Main_Mesh: strict 18 deg crease angle (cos = 0.951) so every single
            #   bevel, knuckle, finger plate, and timber beam facet is 100% crisp flat-shaded!
            # - For Wheel_*_Mesh: smooth ONLY circumferential tread faces (`r_yz > 0.158` and `|fn_x| < 0.25`, cos = 0.92),
            #   while keeping all sidewalls, felloes, spokes, and hub steps 100% crisp flat-shaded (cos = 0.96)!
            is_fist_or_carriage = me_id in ("MEArmored_Fist_Mesh.003", "MECarriage_Main_Mesh.003")
            is_wheel = "Wheel" in me_id

            prims_by_mat = {}
            for pi in range(totpoly):
                s, e = int(poly_offsets[pi]), int(poly_offsets[pi+1])
                if e - s < 3: continue
                fn = face_norms[pi]
                if np.linalg.norm(fn) < 1e-9: continue
                mi = int(mat_idx[pi]) if int(mat_idx[pi]) < len(mat_names) else 0
                g_mat_idx = mat_id_to_idx.get(mat_names[mi], 0)
                if g_mat_idx not in prims_by_mat:
                    prims_by_mat[g_mat_idx] = ({}, [], [], [], [])
                v_map, p_list, n_list, uv_list, idx_list = prims_by_mat[g_mat_idx]

                c_verts = corner_verts[s:e]
                c_uvs = uv_map[s:e] if uv_map is not None else np.zeros((e-s, 2), dtype=np.float32)

                corner_out_idxs = []
                for k in range(e - s):
                    vi = int(c_verts[k])
                    uv_k = c_uvs[k]
                    u_f, v_f = float(uv_k[0]), float(1.0 - uv_k[1])

                    if is_fist_or_carriage:
                        cos_thr = 0.955 # 17 deg: strictly flat-shaded facets & bevels!
                    elif is_wheel:
                        r_yz = math.hypot(pos_gltf[vi, 1], pos_gltf[vi, 2])
                        cos_thr = 0.920 if (r_yz > 0.158 and abs(float(fn[0])) < 0.25) else 0.965
                    else:
                        cos_thr = 0.780 # 38 deg on cylindrical piston/winch/springs/chains/banners

                    nsum = np.zeros(3, dtype=np.float64)
                    for pj in vert_faces[vi]:
                        if float(np.dot(fn, face_norms[pj])) >= cos_thr:
                            nsum += face_norms[pj]
                    ln = float(np.linalg.norm(nsum))
                    use_n = (nsum / ln).astype(np.float32) if ln > 1e-10 else fn

                    n_key = (int(round(use_n[0]*200)), int(round(use_n[1]*200)), int(round(use_n[2]*200)))
                    uses_tex = g_mat_idx in (1, 2, 4)
                    uv_key = (round(u_f, 3), round(v_f, 3)) if uses_tex else (0, 0)
                    key = (vi, n_key, uv_key)
                    out_i = v_map.get(key)
                    if out_i is None:
                        out_i = len(p_list)
                        v_map[key] = out_i
                        p_list.append(pos_gltf[vi])
                        n_list.append(use_n)
                        uv_list.append([u_f, v_f])
                    corner_out_idxs.append(out_i)

                for k in range(1, (e - s) - 1):
                    idx_list.extend([corner_out_idxs[0], corner_out_idxs[k], corner_out_idxs[k + 1]])

            primitives = []
            for g_mat_idx, (_, p_list, n_list, uv_list, idx_list) in sorted(prims_by_mat.items()):
                if not idx_list: continue
                p_arr = np.array(p_list, dtype=np.float32)
                n_arr = np.array(n_list, dtype=np.float32)
                uv_arr = np.array(uv_list, dtype=np.float32)
                idx_arr = np.array(idx_list, dtype=np.uint16 if len(p_arr) < 65535 else np.uint32)
                total_welded_verts += len(p_arr)
                total_tris += len(idx_arr) // 3

                bv_p = add_bv(p_arr.tobytes(), 34962)
                bv_n = add_bv(n_arr.tobytes(), 34962)
                bv_u = add_bv(uv_arr.tobytes(), 34962)
                bv_i = add_bv(idx_arr.tobytes(), 34963)

                acc_p = add_acc(bv_p, 5126, len(p_arr), "VEC3", p_arr.min(axis=0), p_arr.max(axis=0))
                acc_n = add_acc(bv_n, 5126, len(n_arr), "VEC3")
                acc_u = add_acc(bv_u, 5126, len(uv_arr), "VEC2")
                acc_i = add_acc(bv_i, 5123 if len(p_arr) < 65535 else 5125, len(idx_arr), "SCALAR", [int(idx_arr.min())], [int(idx_arr.max())])

                primitives.append({
                    "attributes": {"POSITION": acc_p, "NORMAL": acc_n, "TEXCOORD_0": acc_u},
                    "indices": acc_i,
                    "material": g_mat_idx,
                    "mode": 4,
                })

            me_idx = len(gltf_meshes)
            me_id_to_idx[me_id] = me_idx
            gltf_meshes.append({"name": clean_prefix(me_id, "ME"), "primitives": primitives})

    # Build 20 core nodes + 13 operator/entry/dismount locator nodes
    ob_info = {}
    for b in bf.blocks:
        if b["code"] == "OB":
            ob_id = bf.get_id_name(b)
            loc = struct.unpack_from("<3f", b["payload"], ob_layout["loc"][0])
            p_ptr = struct.unpack_from("<Q", b["payload"], ob_layout["parent"][0])[0]
            d_ptr = struct.unpack_from("<Q", b["payload"], ob_layout["data"][0])[0]
            loc_gltf = [round(float(loc[0]), 6), round(float(loc[2]), 6), round(float(-loc[1]), 6)]
            if ob_id == "OBRam_Assembly.003":
                loc_gltf = [0.0, 0.365, 0.520]
            elif ob_id == "OBRetraction_Chains_Aft.003":
                loc_gltf = [0.0, 0.385, -0.455]
            elif ob_id == "OBWheel_RL.004":
                loc_gltf = [+0.370, +0.165, REAR_AXLE_Z_NEW]
            elif ob_id == "OBWheel_RR.004":
                loc_gltf = [-0.370, +0.165, REAR_AXLE_Z_NEW]
            ob_info[ob_id] = {"parent": ptr_to_name.get(p_ptr), "data": ptr_to_name.get(d_ptr), "translation": loc_gltf, "children": []}

    for ob_id, info in ob_info.items():
        p = info["parent"]
        if p and p in ob_info:
            ob_info[p]["children"].append(ob_id)

    ordered_ob_ids = ["OBBattleRam_Root.003"] + [k for k in sorted(ob_info.keys()) if k != "OBBattleRam_Root.003"]
    ob_id_to_node_idx = {ob_id: i for i, ob_id in enumerate(ordered_ob_ids)}
    slot_name_to_node_idx = {}
    for ob_id, nidx in ob_id_to_node_idx.items():
        slot_name_to_node_idx[ob_id] = nidx
        base_ob = ob_id.split(".")[0]
        slot_name_to_node_idx[base_ob] = nidx
        slot_name_to_node_idx[base_ob + ".001"] = nidx

    gltf_nodes = []
    for ob_id in ordered_ob_ids:
        info = ob_info[ob_id]
        nd = {"name": clean_prefix(ob_id, "OB")}
        if any(abs(v) > 1e-6 for v in info["translation"]):
            nd["translation"] = info["translation"]
        if info["data"] and info["data"] in me_id_to_idx:
            nd["mesh"] = me_id_to_idx[info["data"]]
        if info["children"]:
            nd["children"] = [ob_id_to_node_idx[ch] for ch in sorted(info["children"])]
        gltf_nodes.append(nd)

    carriage_node_idx = ob_id_to_node_idx["OBCarriage_Main.003"]
    if "children" not in gltf_nodes[carriage_node_idx]:
        gltf_nodes[carriage_node_idx]["children"] = []
    for lname, ltr in SALVAGED_LOCATORS_1X:
        l_idx = len(gltf_nodes)
        gltf_nodes.append({"name": lname, "translation": ltr})
        gltf_nodes[carriage_node_idx]["children"].append(l_idx)

    # Extract all 4 Slotted Actions
    ac_layout = bf.get_layout("bAction")
    slot_layout = bf.get_layout("ActionSlot")
    kd_layout = bf.get_layout("ActionStripKeyframeData")
    cb_layout = bf.get_layout("ActionChannelBag")
    fc_layout = bf.get_layout("FCurve")
    bz_layout = bf.get_layout("BezTriple")

    gltf_animations = []
    for b in bf.blocks:
        if b["code"] != "AC": continue
        ac_id = bf.get_id_name(b)
        anim_name = clean_prefix(ac_id, "AC")
        slot_arr_ptr = struct.unpack_from("<Q", b["payload"], ac_layout["slot_array"][0])[0]
        slot_num = struct.unpack_from("<i", b["payload"], ac_layout["slot_array_num"][0])[0]
        slots = {}
        if slot_arr_ptr in bf.ptr_map and slot_num > 0:
            sb = bf.ptr_map[slot_arr_ptr]
            for sp in struct.unpack_from(f"<{slot_num}Q", sb["payload"], 0):
                if sp in bf.ptr_map:
                    slb = bf.ptr_map[sp]
                    sname = bytes(slb["payload"][slot_layout["name"][0]:slot_layout["name"][0]+64]).split(b"\x00")[0].decode()
                    shandle = struct.unpack_from("<i", slb["payload"], slot_layout["handle"][0])[0]
                    slots[shandle] = sname

        kd_arr_ptr = struct.unpack_from("<Q", b["payload"], ac_layout["strip_keyframe_data_array"][0])[0]
        kd_num = struct.unpack_from("<i", b["payload"], ac_layout["strip_keyframe_data_array_num"][0])[0]
        if kd_arr_ptr not in bf.ptr_map or kd_num == 0: continue

        samplers_list, channels_list = [], []
        kdb = bf.ptr_map[kd_arr_ptr]
        for kp in struct.unpack_from(f"<{kd_num}Q", kdb["payload"], 0):
            if kp not in bf.ptr_map: continue
            kb = bf.ptr_map[kp]
            cb_arr_ptr = struct.unpack_from("<Q", kb["payload"], kd_layout["channelbag_array"][0])[0]
            cb_num = struct.unpack_from("<i", kb["payload"], kd_layout["channelbag_array_num"][0])[0]
            if cb_arr_ptr not in bf.ptr_map or cb_num == 0: continue
            cbb = bf.ptr_map[cb_arr_ptr]
            for cbp in struct.unpack_from(f"<{cb_num}Q", cbb["payload"], 0):
                if cbp not in bf.ptr_map: continue
                bag = bf.ptr_map[cbp]
                sh = struct.unpack_from("<i", bag["payload"], cb_layout["slot_handle"][0])[0]
                fnum = struct.unpack_from("<i", bag["payload"], cb_layout["fcurve_array_num"][0])[0]
                farr = struct.unpack_from("<Q", bag["payload"], cb_layout["fcurve_array"][0])[0]
                target_node = slot_name_to_node_idx.get(slots.get(sh, ""))
                if target_node is None or farr not in bf.ptr_map or fnum == 0: continue

                fcurves_by_prop = {}
                fab = bf.ptr_map[farr]
                for fp in struct.unpack_from(f"<{fnum}Q", fab["payload"], 0):
                    if fp not in bf.ptr_map: continue
                    fb = bf.ptr_map[fp]
                    rptr = struct.unpack_from("<Q", fb["payload"], fc_layout["rna_path"][0])[0]
                    rpath = bytes(bf.ptr_map[rptr]["payload"]).split(b"\x00")[0].decode() if rptr in bf.ptr_map else ""
                    aidx = struct.unpack_from("<i", fb["payload"], fc_layout["array_index"][0])[0]
                    totv = struct.unpack_from("<i", fb["payload"], fc_layout["totvert"][0])[0]
                    bptr = struct.unpack_from("<Q", fb["payload"], fc_layout["bezt"][0])[0]
                    pts = {}
                    if bptr in bf.ptr_map and totv > 0:
                        bb = bf.ptr_map[bptr]
                        sz = bb["size"] // totv
                        for k in range(totv):
                            vec = struct.unpack_from("<9f", bb["payload"], k * sz + bz_layout["vec"][0])
                            pts[round(float(vec[3]), 4)] = float(vec[4])
                    fcurves_by_prop.setdefault(rpath, {})[aidx] = pts

                for rpath, idx_map in fcurves_by_prop.items():
                    frames = sorted(set().union(*(d.keys() for d in idx_map.values())))
                    if not frames: continue
                    times_sec = np.array([f / 24.0 for f in frames], dtype=np.float32)
                    bv_t = add_bv(times_sec.tobytes())
                    acc_t = add_acc(bv_t, 5126, len(times_sec), "SCALAR", [float(times_sec.min())], [float(times_sec.max())])

                    if rpath == "location":
                        vals = [[idx_map.get(0, {}).get(f, 0.0), idx_map.get(2, {}).get(f, 0.0), -idx_map.get(1, {}).get(f, 0.0)] for f in frames]
                        v_arr = np.array(vals, dtype=np.float32)
                        bv_v = add_bv(v_arr.tobytes())
                        acc_v = add_acc(bv_v, 5126, len(v_arr), "VEC3", v_arr.min(axis=0), v_arr.max(axis=0))
                        s_idx = len(samplers_list)
                        samplers_list.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
                        channels_list.append({"sampler": s_idx, "target": {"node": target_node, "path": "translation"}})
                    elif rpath == "rotation_quaternion":
                        vals = []
                        for f in frames:
                            wb, xb, yb, zb = idx_map.get(0, {}).get(f, 1.0), idx_map.get(1, {}).get(f, 0.0), idx_map.get(2, {}).get(f, 0.0), idx_map.get(3, {}).get(f, 0.0)
                            q = np.array([xb, zb, -yb, wb], dtype=np.float64)
                            n = np.linalg.norm(q)
                            if n > 1e-9: q /= n
                            vals.append(q)
                        v_arr = np.array(vals, dtype=np.float32)
                        bv_v = add_bv(v_arr.tobytes())
                        acc_v = add_acc(bv_v, 5126, len(v_arr), "VEC4", v_arr.min(axis=0), v_arr.max(axis=0))
                        s_idx = len(samplers_list)
                        samplers_list.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
                        channels_list.append({"sampler": s_idx, "target": {"node": target_node, "path": "rotation"}})
                    elif rpath == "scale":
                        vals = [[idx_map.get(0, {}).get(f, 1.0), idx_map.get(2, {}).get(f, 1.0), idx_map.get(1, {}).get(f, 1.0)] for f in frames]
                        v_arr = np.array(vals, dtype=np.float32)
                        bv_v = add_bv(v_arr.tobytes())
                        acc_v = add_acc(bv_v, 5126, len(v_arr), "VEC3", v_arr.min(axis=0), v_arr.max(axis=0))
                        s_idx = len(samplers_list)
                        samplers_list.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
                        channels_list.append({"sampler": s_idx, "target": {"node": target_node, "path": "scale"}})

        gltf_animations.append({"name": anim_name, "samplers": samplers_list, "channels": channels_list})

    pad_bin = (4 - (len(bin_chunks) % 4)) % 4
    if pad_bin: bin_chunks.extend(b"\x00" * pad_bin)

    gltf_dict = {
        "asset": {"version": "2.0", "generator": "Castleward SO-FIST-ICATION v2.5 Exporter (Synthesized Closed Fist + Cohesive Wheels + Integrated Rear Undercarriage)"},
        "scene": 0,
        "scenes": [{"name": "Scene", "nodes": [0]}],
        "nodes": gltf_nodes,
        "meshes": gltf_meshes,
        "materials": gltf_materials,
        "textures": textures,
        "images": images,
        "samplers": samplers,
        "animations": gltf_animations,
        "accessors": accessors,
        "bufferViews": buffer_views,
        "buffers": [{"byteLength": len(bin_chunks)}],
        "extras": {
            "assetId": "so-fist-ication",
            "version": "2.5.0",
            "runtimeScale": 2.85,
            "frontAxleZLocal": +0.325,
            "rearAxleZLocalOld": -0.420,
            "rearAxleZLocalNew": -0.820,
            "wheelbaseLocalOld": 0.745,
            "wheelbaseLocalNew": 1.145,
            "wheelbaseWorldOld": 2.1233,
            "wheelbaseWorldNew": 3.2633,
            "wheelRadiusLocal": 0.165,
            "wheelRadiusWorld": 0.47025,
            "totalWeldedVertices": total_welded_verts,
            "totalTriangles": total_tris,
        }
    }

    json_bytes = json.dumps(gltf_dict, separators=(",", ":")).encode("utf-8")
    pad_json = (4 - (len(json_bytes) % 4)) % 4
    if pad_json: json_bytes += b" " * pad_json

    total_len = 12 + 8 + len(json_bytes) + 8 + len(bin_chunks)
    glb_out = bytearray()
    glb_out.extend(struct.pack("<4sII", b"glTF", 2, total_len))
    glb_out.extend(struct.pack("<I4s", len(json_bytes), b"JSON"))
    glb_out.extend(json_bytes)
    glb_out.extend(struct.pack("<I4s", len(bin_chunks), b"BIN\x00"))
    glb_out.extend(bin_chunks)

    out_glb_v24 = OUT_DIR / "so-fist-ication-v25-review.glb"
    out_glb_v24.write_bytes(glb_out)
    sha = hashlib.sha256(glb_out).hexdigest()
    print(f"[OK] Exported {out_glb_v24.name}: {len(glb_out):,} bytes ({len(glb_out)/1048576:.2f} MB), welded_verts={total_welded_verts:,}, tris={total_tris:,}, SHA256={sha}")
    return gltf_dict, sha, blend_sha

if __name__ == "__main__":
    build_and_export_sofist_v25()
