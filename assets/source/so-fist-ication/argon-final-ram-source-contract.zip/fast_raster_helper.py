from pathlib import Path
import ctypes, math
import numpy as np
from PIL import Image

_lib = ctypes.CDLL("/working_dir/c_63a1f8c151a6582d/artifacts/file_generation/ttl=63d/output/raster_fast.so")
_lib.rasterize_and_shade.argtypes = [
    ctypes.c_int,
    ctypes.POINTER(ctypes.c_int32),
    ctypes.POINTER(ctypes.c_int32), ctypes.POINTER(ctypes.c_int32),
    ctypes.POINTER(ctypes.c_int32), ctypes.POINTER(ctypes.c_int32),
    ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_int32), ctypes.POINTER(ctypes.c_int32), ctypes.POINTER(ctypes.c_int32),
    ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_float),
    ctypes.c_int, ctypes.c_int, ctypes.c_int,
    ctypes.c_uint8, ctypes.c_uint8, ctypes.c_uint8,
    ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_int32),
    ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_float),
    ctypes.POINTER(ctypes.c_uint8),
]

def fast_render(sc, cam_pos, look_at, up=(0.0, 1.0, 0.0), fov_deg=38.0, img_w=800, img_h=800, ortho_scale=None, bg_color=(20, 23, 30)):
    P, N, T, VC, VM, VE = sc
    P = np.ascontiguousarray(P, dtype=np.float32)
    N = np.ascontiguousarray(N, dtype=np.float32)
    T = np.ascontiguousarray(T, dtype=np.int32).reshape(-1, 3)
    VC = np.ascontiguousarray(VC, dtype=np.float32)
    VM = np.ascontiguousarray(VM, dtype=np.float32)
    VE = np.ascontiguousarray(VE, dtype=np.float32)

    cp = np.array(cam_pos, dtype=np.float32)
    la = np.array(look_at, dtype=np.float32)
    up_v = np.array(up, dtype=np.float32)
    fwd = la - cp
    fl = float(np.linalg.norm(fwd))
    fwd = fwd / max(fl, 1e-8)
    right = np.cross(fwd, up_v)
    rl = float(np.linalg.norm(right))
    if rl < 1e-6:
        up_v = np.array([0.0, 0.0, 1.0], dtype=np.float32)
        right = np.cross(fwd, up_v)
        rl = float(np.linalg.norm(right))
    right /= max(rl, 1e-8)
    true_up = np.cross(right, fwd)

    rel = P - cp[None, :]
    cx = rel @ right
    cy = rel @ true_up
    cz = rel @ fwd

    aspect = float(img_w) / float(img_h)
    is_ortho = 1 if ortho_scale is not None else 0
    if is_ortho:
        sy = float(ortho_scale)
        sx = sy * aspect
        ndc_x = cx / sx
        ndc_y = cy / sy
        inv_z = np.ones(len(P), dtype=np.float32)
    else:
        tan_half = math.tan(math.radians(fov_deg) * 0.5)
        cz_safe = np.maximum(cz, 0.05)
        ndc_x = cx / (cz_safe * tan_half * aspect)
        ndc_y = cy / (cz_safe * tan_half)
        inv_z = (1.0 / cz_safe).astype(np.float32)

    sx_p = ((ndc_x + 1.0) * 0.5 * img_w).astype(np.float32)
    sy_p = ((1.0 - ndc_y) * 0.5 * img_h).astype(np.float32)

    t0 = np.ascontiguousarray(T[:, 0], dtype=np.int32)
    t1 = np.ascontiguousarray(T[:, 1], dtype=np.int32)
    t2 = np.ascontiguousarray(T[:, 2], dtype=np.int32)

    x0, y0, z0 = sx_p[t0], sy_p[t0], cz[t0]
    x1, y1, z1 = sx_p[t1], sy_p[t1], cz[t1]
    x2, y2, z2 = sx_p[t2], sy_p[t2], cz[t2]

    denom = ((y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)).astype(np.float32)
    xmin = np.clip(np.floor(np.minimum(np.minimum(x0, x1), x2)).astype(np.int32), 0, img_w - 1)
    xmax = np.clip(np.ceil(np.maximum(np.maximum(x0, x1), x2)).astype(np.int32), 0, img_w - 1)
    ymin = np.clip(np.floor(np.minimum(np.minimum(y0, y1), y2)).astype(np.int32), 0, img_h - 1)
    ymax = np.clip(np.ceil(np.maximum(np.maximum(y0, y1), y2)).astype(np.int32), 0, img_h - 1)

    valid = ((z0 > 0.05) & (z1 > 0.05) & (z2 > 0.05) & (np.abs(denom) > 1e-5) & (xmin <= xmax) & (ymin <= ymax)).astype(np.int32)

    n_tris = len(T)
    total_pix = img_w * img_h
    zbuf = np.empty(total_pix, dtype=np.float32)
    tri_id_buf = np.empty(total_pix, dtype=np.int32)
    bary_u_buf = np.empty(total_pix, dtype=np.float32)
    bary_v_buf = np.empty(total_pix, dtype=np.float32)
    out_img = np.empty(total_pix * 3, dtype=np.uint8)

    _lib.rasterize_and_shade(
        n_tris,
        valid.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)),
        xmin.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)),
        xmax.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)),
        ymin.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)),
        ymax.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)),
        denom.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        x0.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        y0.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        z0.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        x1.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        y1.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        z1.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        x2.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        y2.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        z2.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        t0.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)),
        t1.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)),
        t2.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)),
        inv_z.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        P.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        N.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        VC.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        VM.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        VE.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        cp.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        is_ortho, img_w, img_h,
        int(bg_color[0]), int(bg_color[1]), int(bg_color[2]),
        zbuf.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        tri_id_buf.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)),
        bary_u_buf.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        bary_v_buf.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
        out_img.ctypes.data_as(ctypes.POINTER(ctypes.c_uint8)),
    )
    return Image.fromarray(out_img.reshape((img_h, img_w, 3)), mode="RGB")
