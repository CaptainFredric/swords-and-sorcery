/**
 * Castleward — Reconciled SO-FIST-ICATION v2.2 Geometry & Timing Contract (`SO_FIST_SCALE = 2.85`)
 * Preserves 1.0x baked asset coordinates so scaling by SO_FIST_SCALE = 2.85 produces zero double-scaling.
 */

export const SO_FIST_SCALE = 2.85;

export const SO_FIST_GEOMETRY = Object.freeze({
  "assetId": "so-fist-ication",
  "version": "2.2.0-salvaged-2p85x",
  "bakedAssetScale": 1.0,
  "SO_FIST_SCALE": 2.85,
  "structuralTimberSectionThickening": 1.065,
  "sourceBlend": "assets/source/so-fist-ication/SoFist-crafted-v2_2-salvaged.blend",
  "runtimeGlb": "client/assets/props/so-fist-ication/so-fist-ication-v2_2-salvaged.glb",
  "glbSizeBytes": 5322788,
  "baselineGlbSizeBytes": 5360000,
  "preservedAuthoritativeStats": {
    "hullMaxHp": 1400,
    "armoredFistMaxHp": 500,
    "wheelMaxHp": 250,
    "ordinarySpeedMps": 4.8,
    "reverseSpeedMps": 2.6,
    "pressureChargeSpeedMps": 12.0,
    "simulationTickRateHz": 30
  },
  "dimensionsLocalMeters_1x": {
    "overallWidthX": 0.982,
    "chassisFrameWidthX": 0.864,
    "overallHeightY": 0.752,
    "overallHeightWithRiderY": 0.8596,
    "restLengthZ": 2.131,
    "retractedLengthZ": 2.026,
    "extendedLengthZ": 2.576,
    "boundingBoxRest": {
      "min": [
        -0.491,
        0.0,
        -1.18
      ],
      "max": [
        0.491,
        0.752,
        0.951
      ]
    },
    "boundingBoxExtended": {
      "min": [
        -0.491,
        0.0,
        -1.18
      ],
      "max": [
        0.491,
        0.752,
        1.396
      ]
    }
  },
  "dimensionsWorldMeters_2p85x": {
    "overallWidthX": 2.799,
    "chassisFrameWidthX": 2.462,
    "overallHeightY": 2.143,
    "overallHeightWithRiderY": 2.45,
    "restLengthZ": 6.073,
    "retractedLengthZ": 5.774,
    "extendedLengthZ": 7.342,
    "boundingBoxRest": {
      "min": [
        -1.399,
        0.0,
        -3.363
      ],
      "max": [
        1.399,
        2.143,
        2.71
      ]
    },
    "boundingBoxExtended": {
      "min": [
        -1.399,
        0.0,
        -3.363
      ],
      "max": [
        1.399,
        2.143,
        3.979
      ]
    }
  },
  "gatehouseAndConvoyClearance": {
    "honorableEntryGatehouseArchWidthWorld": 4.2,
    "honorableEntryGatehousePortalBayWidthWorld": 5.8,
    "honorableEntryGatehouseOpenPortcullisSpikeYWorld": 3.68,
    "vehicleOverallWidthWorld": 2.799,
    "archwayTotalLateralClearanceWorld": 1.401,
    "archwayPerSideClearanceWorld": 0.701,
    "overheadClearanceWithRiderWorld": 1.23,
    "convoyEscortLaneWidthPerSideInPortalBayWorld": 1.501
  },
  "wheelAndSteeringContract": {
    "wheelRadiusLocal": 0.165,
    "wheelRadiusWorld": 0.4703,
    "frontAxleZLocal": 0.325,
    "rearAxleZLocal": -0.42,
    "frontAxleZWorld": 0.9263,
    "rearAxleZWorld": -1.197,
    "wheelbaseLocal": 0.745,
    "wheelbaseWorld": 2.1233,
    "frontTrackHalfWidthXLocal": 0.43,
    "rearTrackHalfWidthXLocal": 0.37,
    "frontTrackHalfWidthXWorld": 1.2255,
    "rearTrackHalfWidthXWorld": 1.0545,
    "maxFrontSteerAngleDeg": 32.0,
    "rearCounterSteerFactor": -0.45,
    "wheelNodes": {
      "FL": {
        "name": "Wheel_FL",
        "localPos": [
          0.43,
          0.165,
          0.325
        ],
        "worldPos": [
          1.2255,
          0.4703,
          0.9263
        ]
      },
      "FR": {
        "name": "Wheel_FR",
        "localPos": [
          -0.43,
          0.165,
          0.325
        ],
        "worldPos": [
          -1.2255,
          0.4703,
          0.9263
        ]
      },
      "RL": {
        "name": "Wheel_RL",
        "localPos": [
          0.37,
          0.165,
          -0.42
        ],
        "worldPos": [
          1.0545,
          0.4703,
          -1.197
        ]
      },
      "RR": {
        "name": "Wheel_RR",
        "localPos": [
          -0.37,
          0.165,
          -0.42
        ],
        "worldPos": [
          -1.0545,
          0.4703,
          -1.197
        ]
      }
    }
  },
  "pistonAndStrikeTimingContract": {
    "cycleDurationSec": 4.0,
    "fps": 24.0,
    "totalFrames": 96,
    "windupWindowSec": [
      0.0,
      0.65
    ],
    "mechanicalReleaseSec": 0.68,
    "effectiveImpactWindowSec": [
      0.8,
      0.98
    ],
    "peakImpactExtensionSec": 0.88,
    "recoilAbsorptionWindowSec": [
      0.98,
      1.45
    ],
    "winchRetractionResetWindowSec": [
      1.45,
      4.0
    ],
    "pistonAxisYLocal": 0.365,
    "pistonAxisYWorld": 1.0402,
    "restPivotZLocal": 0.52,
    "retractedPivotZLocal": 0.415,
    "extendedPivotZLocal": 0.965,
    "retractedDeltaZLocal": -0.105,
    "extendedDeltaZLocal": 0.445,
    "totalStrokeLocal": 0.55,
    "totalStrokeWorld": 1.5675,
    "intactFistTipZLocal": {
      "rest": 0.951,
      "retracted": 0.846,
      "extended": 1.396
    },
    "intactFistTipZWorld": {
      "rest": 2.7104,
      "retracted": 2.4111,
      "extended": 3.9786
    },
    "destroyedFistShaftTipZLocal": {
      "rest": 0.553,
      "retracted": 0.448,
      "extended": 0.998
    },
    "destroyedFistShaftTipZWorld": {
      "rest": 1.5761,
      "retracted": 1.2768,
      "extended": 2.8443
    }
  },
  "operatorStationContract": {
    "separateEntryRidingExitVerified": true,
    "locatorsLocal_1x": {
      "operator_mount_entry": [
        0.0,
        0.0,
        -1.25
      ],
      "operator_onboard_rider": [
        0.0,
        0.226,
        -0.875
      ],
      "operator_pelvis_anchor": [
        0.0,
        0.515,
        -0.885
      ],
      "operator_footrest_L": [
        0.115,
        0.228,
        -0.84
      ],
      "operator_footrest_R": [
        -0.115,
        0.228,
        -0.84
      ],
      "hand_L_steering_grip": [
        0.12,
        0.6,
        -0.715
      ],
      "hand_R_attack_lever_grip": [
        -0.12,
        0.6,
        -0.715
      ],
      "hand_R_attack_lever_pull": [
        0.0,
        0.6,
        -0.515
      ],
      "operator_camera_tpv": [
        0.0,
        1.14,
        -2.1
      ],
      "operator_camera_sight": [
        0.0,
        0.835,
        -0.82
      ],
      "operator_safe_dismount": [
        0.0,
        0.0,
        -1.35
      ],
      "operator_safe_dismount_L": [
        0.76,
        0.0,
        -0.9
      ],
      "operator_safe_dismount_R": [
        -0.76,
        0.0,
        -0.9
      ]
    },
    "locatorsWorld_2p85x": {
      "operator_mount_entry": [
        0.0,
        0.0,
        -3.5625
      ],
      "operator_onboard_rider": [
        0.0,
        0.6441,
        -2.4937
      ],
      "operator_pelvis_anchor": [
        0.0,
        1.4678,
        -2.5223
      ],
      "operator_footrest_L": [
        0.3278,
        0.6498,
        -2.394
      ],
      "operator_footrest_R": [
        -0.3278,
        0.6498,
        -2.394
      ],
      "hand_L_steering_grip": [
        0.342,
        1.71,
        -2.0377
      ],
      "hand_R_attack_lever_grip": [
        -0.342,
        1.71,
        -2.0377
      ],
      "hand_R_attack_lever_pull": [
        0.0,
        1.71,
        -1.4678
      ],
      "operator_camera_tpv": [
        0.0,
        3.249,
        -5.985
      ],
      "operator_camera_sight": [
        0.0,
        2.3798,
        -2.337
      ],
      "operator_safe_dismount": [
        0.0,
        0.0,
        -3.8475
      ],
      "operator_safe_dismount_L": [
        2.166,
        0.0,
        -2.565
      ],
      "operator_safe_dismount_R": [
        -2.166,
        0.0,
        -2.565
      ]
    },
    "spellbladeRigPoses_2p85x": {
      "Braced_Driving_Pose": {
        "jointPositionsLocal_1x": {
          "root": [
            0.0,
            0.2277,
            -0.8911
          ],
          "pelvis": [
            0.0,
            0.5442,
            -0.885
          ],
          "spine": [
            0.0,
            0.5964,
            -0.885
          ],
          "chest": [
            0.0,
            0.65,
            -0.8716
          ],
          "neck": [
            0.0,
            0.7064,
            -0.8634
          ],
          "head": [
            0.0,
            0.7384,
            -0.8601
          ],
          "clavicle.L": [
            0.0261,
            0.6865,
            -0.8635
          ],
          "upper_arm.L": [
            0.0995,
            0.6919,
            -0.8565
          ],
          "forearm.L": [
            0.134,
            0.6425,
            -0.7948
          ],
          "hand.L": [
            0.0913,
            0.6474,
            -0.7272
          ],
          "socket_sorcery": [
            0.0796,
            0.6685,
            -0.6982
          ],
          "clavicle.R": [
            -0.0261,
            0.6865,
            -0.8635
          ],
          "upper_arm.R": [
            -0.0986,
            0.7004,
            -0.867
          ],
          "forearm.R": [
            -0.1273,
            0.653,
            -0.8132
          ],
          "hand.R": [
            -0.1139,
            0.6053,
            -0.7395
          ],
          "socket_sword": [
            -0.1213,
            0.5595,
            -0.8113
          ],
          "tabard_root": [
            0.0,
            0.5964,
            -0.885
          ],
          "tabard_front_01": [
            0.0,
            0.5718,
            -0.8186
          ],
          "tabard_front_02": [
            -0.0,
            0.4856,
            -0.7711
          ],
          "tabard_back_01": [
            0.0,
            0.6025,
            -0.9956
          ],
          "tabard_back_02": [
            0.0,
            0.4922,
            -1.0358
          ],
          "thigh.L": [
            0.0522,
            0.5442,
            -0.8881
          ],
          "shin.L": [
            0.0747,
            0.4143,
            -0.8251
          ],
          "foot.L": [
            0.0803,
            0.3078,
            -0.8623
          ],
          "thigh.R": [
            -0.0522,
            0.5442,
            -0.8973
          ],
          "shin.R": [
            -0.0846,
            0.4101,
            -0.8428
          ],
          "foot.R": [
            -0.1038,
            0.2995,
            -0.8487
          ]
        },
        "localBoneTransforms": {
          "root": {
            "nodeIndex": 0,
            "translation": [
              0.0,
              0.0,
              0.0
            ],
            "rotation": [
              -0.707107,
              0.0,
              0.0,
              0.707107
            ]
          },
          "pelvis": {
            "nodeIndex": 1,
            "translation": [
              0.0,
              -0.02,
              1.03
            ],
            "rotation": [
              0.0,
              0.0,
              0.0,
              1.0
            ]
          },
          "spine": {
            "nodeIndex": 2,
            "translation": [
              0.0,
              0.0,
              0.17
            ],
            "rotation": [
              0.121869,
              0.0,
              0.0,
              0.992546
            ]
          },
          "chest": {
            "nodeIndex": 3,
            "translation": [
              0.0,
              0.0,
              0.18
            ],
            "rotation": [
              0.069756,
              0.0,
              0.0,
              0.997564
            ]
          },
          "neck": {
            "nodeIndex": 4,
            "translation": [
              0.0,
              0.044,
              0.18
            ],
            "rotation": [
              -0.139173,
              0.0,
              0.0,
              0.990268
            ]
          },
          "head": {
            "nodeIndex": 5,
            "translation": [
              0.0,
              0.0,
              0.105
            ],
            "rotation": [
              -0.034899,
              0.0,
              0.0,
              0.999391
            ]
          },
          "clavicle.L": {
            "nodeIndex": 6,
            "translation": [
              0.085,
              0.02,
              0.12
            ],
            "rotation": [
              0.423655,
              0.527628,
              0.449794,
              0.582932
            ]
          },
          "upper_arm.L": {
            "nodeIndex": 7,
            "translation": [
              -0.01069,
              0.002105,
              0.240261
            ],
            "rotation": [
              0.067977,
              -0.536671,
              0.393359,
              0.743392
            ]
          },
          "forearm.L": {
            "nodeIndex": 8,
            "translation": [
              -0.001795,
              0.013426,
              0.280352
            ],
            "rotation": [
              -0.437352,
              -0.605105,
              -0.018298,
              0.665008
            ]
          },
          "hand.L": {
            "nodeIndex": 9,
            "translation": [
              0.153161,
              0.036314,
              0.208175
            ],
            "rotation": [
              -0.178957,
              0.426829,
              0.243572,
              0.852329
            ]
          },
          "socket_sorcery": {
            "nodeIndex": 10,
            "translation": [
              0.002998,
              0.016399,
              0.121491
            ],
            "rotation": [
              -0.62899,
              -0.14057,
              0.001147,
              0.764599
            ]
          },
          "clavicle.R": {
            "nodeIndex": 11,
            "translation": [
              -0.085,
              0.02,
              0.12
            ],
            "rotation": [
              -0.312515,
              0.580449,
              0.453429,
              -0.599846
            ]
          },
          "upper_arm.R": {
            "nodeIndex": 12,
            "translation": [
              0.01069,
              0.002105,
              0.240261
            ],
            "rotation": [
              0.208355,
              0.586866,
              -0.239458,
              0.744873
            ]
          },
          "forearm.R": {
            "nodeIndex": 13,
            "translation": [
              0.007078,
              -0.031543,
              0.249511
            ],
            "rotation": [
              -0.066716,
              0.155435,
              -0.003,
              0.985586
            ]
          },
          "hand.R": {
            "nodeIndex": 14,
            "translation": [
              0.069081,
              -0.02101,
              0.279897
            ],
            "rotation": [
              0.397587,
              0.250754,
              -0.131389,
              0.872803
            ]
          },
          "socket_sword": {
            "nodeIndex": 15,
            "translation": [
              0.072601,
              -0.24765,
              0.103889
            ],
            "rotation": [
              -0.24754,
              -0.619388,
              0.744994,
              -0.008127
            ]
          },
          "tabard_root": {
            "nodeIndex": 16,
            "translation": [
              0.0,
              0.0,
              0.17
            ],
            "rotation": [
              1.0,
              -0.0,
              0.0,
              0.0
            ]
          },
          "tabard_front_01": {
            "nodeIndex": 17,
            "translation": [
              0.0,
              0.216,
              0.08
            ],
            "rotation": [
              -0.249217,
              0.0,
              -0.0,
              0.968448
            ]
          },
          "tabard_front_02": {
            "nodeIndex": 18,
            "translation": [
              0.0,
              0.0,
              0.3204
            ],
            "rotation": [
              0.156434,
              -0.0,
              -0.0,
              0.987688
            ]
          },
          "tabard_back_01": {
            "nodeIndex": 19,
            "translation": [
              -0.0,
              -0.36,
              -0.02
            ],
            "rotation": [
              0.173726,
              -0.0,
              -0.0,
              0.984794
            ]
          },
          "tabard_back_02": {
            "nodeIndex": 20,
            "translation": [
              -0.0,
              0.0,
              0.3821
            ],
            "rotation": [
              0.081041,
              -0.0,
              0.0,
              0.996711
            ]
          },
          "thigh.L": {
            "nodeIndex": 21,
            "translation": [
              0.17,
              0.01,
              0.0
            ],
            "rotation": [
              0.971422,
              0.030222,
              0.072161,
              0.224095
            ]
          },
          "shin.L": {
            "nodeIndex": 22,
            "translation": [
              0.0,
              0.0,
              0.475362
            ],
            "rotation": [
              0.384104,
              -0.020964,
              -0.002404,
              0.923049
            ]
          },
          "foot.L": {
            "nodeIndex": 23,
            "translation": [
              0.0,
              -0.0,
              0.367719
            ],
            "rotation": [
              -0.695386,
              -0.052528,
              0.001568,
              0.716712
            ]
          },
          "thigh.R": {
            "nodeIndex": 24,
            "translation": [
              -0.17,
              0.04,
              0.0
            ],
            "rotation": [
              0.975212,
              -0.030979,
              -0.105717,
              0.191899
            ]
          },
          "shin.R": {
            "nodeIndex": 25,
            "translation": [
              0.0,
              -0.0,
              0.482574
            ],
            "rotation": [
              0.215124,
              0.005273,
              0.019191,
              0.976384
            ]
          },
          "foot.R": {
            "nodeIndex": 26,
            "translation": [
              0.0,
              -0.0,
              0.366003
            ],
            "rotation": [
              -0.584201,
              0.112259,
              0.039279,
              0.802847
            ]
          }
        }
      },
      "Attack_Lever_Pull_Pose": {
        "jointPositionsLocal_1x": {
          "root": [
            0.0,
            0.2277,
            -0.8911
          ],
          "pelvis": [
            0.0,
            0.5442,
            -0.885
          ],
          "spine": [
            0.0,
            0.5964,
            -0.885
          ],
          "chest": [
            0.0,
            0.65,
            -0.8716
          ],
          "neck": [
            0.0,
            0.7064,
            -0.8634
          ],
          "head": [
            0.0,
            0.7384,
            -0.8601
          ],
          "clavicle.L": [
            0.0261,
            0.6865,
            -0.8635
          ],
          "upper_arm.L": [
            0.0995,
            0.6919,
            -0.8565
          ],
          "forearm.L": [
            0.134,
            0.6425,
            -0.7948
          ],
          "hand.L": [
            0.0913,
            0.6474,
            -0.7272
          ],
          "socket_sorcery": [
            0.0796,
            0.6685,
            -0.6982
          ],
          "clavicle.R": [
            -0.0261,
            0.6865,
            -0.8635
          ],
          "upper_arm.R": [
            -0.0979,
            0.6738,
            -0.8518
          ],
          "forearm.R": [
            -0.0882,
            0.6414,
            -0.7823
          ],
          "hand.R": [
            -0.044,
            0.6325,
            -0.7058
          ],
          "socket_sword": [
            -0.1213,
            0.5595,
            -0.8113
          ],
          "tabard_root": [
            0.0,
            0.5964,
            -0.885
          ],
          "tabard_front_01": [
            0.0,
            0.5718,
            -0.8186
          ],
          "tabard_front_02": [
            -0.0,
            0.4856,
            -0.7711
          ],
          "tabard_back_01": [
            0.0,
            0.6025,
            -0.9956
          ],
          "tabard_back_02": [
            0.0,
            0.4922,
            -1.0358
          ],
          "thigh.L": [
            0.0522,
            0.5442,
            -0.8881
          ],
          "shin.L": [
            0.0747,
            0.4143,
            -0.8251
          ],
          "foot.L": [
            0.0803,
            0.3078,
            -0.8623
          ],
          "thigh.R": [
            -0.0522,
            0.5442,
            -0.8973
          ],
          "shin.R": [
            -0.0846,
            0.4101,
            -0.8428
          ],
          "foot.R": [
            -0.1038,
            0.2995,
            -0.8487
          ]
        },
        "localBoneTransforms": {
          "root": {
            "nodeIndex": 0,
            "translation": [
              0.0,
              0.0,
              0.0
            ],
            "rotation": [
              -0.707107,
              0.0,
              0.0,
              0.707107
            ]
          },
          "pelvis": {
            "nodeIndex": 1,
            "translation": [
              0.0,
              -0.02,
              1.03
            ],
            "rotation": [
              0.0,
              0.0,
              0.0,
              1.0
            ]
          },
          "spine": {
            "nodeIndex": 2,
            "translation": [
              0.0,
              0.0,
              0.17
            ],
            "rotation": [
              0.121869,
              0.0,
              0.0,
              0.992546
            ]
          },
          "chest": {
            "nodeIndex": 3,
            "translation": [
              0.0,
              0.0,
              0.18
            ],
            "rotation": [
              0.069756,
              0.0,
              0.0,
              0.997564
            ]
          },
          "neck": {
            "nodeIndex": 4,
            "translation": [
              0.0,
              0.044,
              0.18
            ],
            "rotation": [
              -0.139173,
              0.0,
              0.0,
              0.990268
            ]
          },
          "head": {
            "nodeIndex": 5,
            "translation": [
              0.0,
              0.0,
              0.105
            ],
            "rotation": [
              -0.034899,
              0.0,
              0.0,
              0.999391
            ]
          },
          "clavicle.L": {
            "nodeIndex": 6,
            "translation": [
              0.085,
              0.02,
              0.12
            ],
            "rotation": [
              0.423655,
              0.527628,
              0.449794,
              0.582932
            ]
          },
          "upper_arm.L": {
            "nodeIndex": 7,
            "translation": [
              -0.01069,
              0.002105,
              0.240261
            ],
            "rotation": [
              0.067977,
              -0.536671,
              0.393359,
              0.743392
            ]
          },
          "forearm.L": {
            "nodeIndex": 8,
            "translation": [
              -0.001795,
              0.013426,
              0.280352
            ],
            "rotation": [
              -0.437352,
              -0.605105,
              -0.018298,
              0.665008
            ]
          },
          "hand.L": {
            "nodeIndex": 9,
            "translation": [
              0.153161,
              0.036314,
              0.208175
            ],
            "rotation": [
              -0.178957,
              0.426829,
              0.243572,
              0.852329
            ]
          },
          "socket_sorcery": {
            "nodeIndex": 10,
            "translation": [
              0.002998,
              0.016399,
              0.121491
            ],
            "rotation": [
              -0.62899,
              -0.14057,
              0.001147,
              0.764599
            ]
          },
          "clavicle.R": {
            "nodeIndex": 11,
            "translation": [
              -0.085,
              0.02,
              0.12
            ],
            "rotation": [
              -0.422017,
              0.622351,
              0.265495,
              -0.603401
            ]
          },
          "upper_arm.R": {
            "nodeIndex": 12,
            "translation": [
              0.01069,
              0.002105,
              0.240261
            ],
            "rotation": [
              0.147963,
              0.659826,
              -0.188013,
              0.712311
            ]
          },
          "forearm.R": {
            "nodeIndex": 13,
            "translation": [
              0.007078,
              -0.031543,
              0.249511
            ],
            "rotation": [
              -0.106564,
              0.106846,
              -0.0026,
              0.988545
            ]
          },
          "hand.R": {
            "nodeIndex": 14,
            "translation": [
              0.069081,
              -0.02101,
              0.279897
            ],
            "rotation": [
              0.435312,
              0.307231,
              -0.114126,
              0.838503
            ]
          },
          "socket_sword": {
            "nodeIndex": 15,
            "translation": [
              0.066162,
              -0.479976,
              -0.055043
            ],
            "rotation": [
              0.251648,
              0.766982,
              -0.561891,
              0.180803
            ]
          },
          "tabard_root": {
            "nodeIndex": 16,
            "translation": [
              0.0,
              0.0,
              0.17
            ],
            "rotation": [
              1.0,
              -0.0,
              0.0,
              0.0
            ]
          },
          "tabard_front_01": {
            "nodeIndex": 17,
            "translation": [
              0.0,
              0.216,
              0.08
            ],
            "rotation": [
              -0.249217,
              0.0,
              -0.0,
              0.968448
            ]
          },
          "tabard_front_02": {
            "nodeIndex": 18,
            "translation": [
              0.0,
              0.0,
              0.3204
            ],
            "rotation": [
              0.156434,
              -0.0,
              -0.0,
              0.987688
            ]
          },
          "tabard_back_01": {
            "nodeIndex": 19,
            "translation": [
              -0.0,
              -0.36,
              -0.02
            ],
            "rotation": [
              0.173726,
              -0.0,
              -0.0,
              0.984794
            ]
          },
          "tabard_back_02": {
            "nodeIndex": 20,
            "translation": [
              -0.0,
              0.0,
              0.3821
            ],
            "rotation": [
              0.081041,
              -0.0,
              0.0,
              0.996711
            ]
          },
          "thigh.L": {
            "nodeIndex": 21,
            "translation": [
              0.17,
              0.01,
              0.0
            ],
            "rotation": [
              0.971422,
              0.030222,
              0.072161,
              0.224095
            ]
          },
          "shin.L": {
            "nodeIndex": 22,
            "translation": [
              0.0,
              0.0,
              0.475362
            ],
            "rotation": [
              0.384104,
              -0.020964,
              -0.002404,
              0.923049
            ]
          },
          "foot.L": {
            "nodeIndex": 23,
            "translation": [
              0.0,
              -0.0,
              0.367719
            ],
            "rotation": [
              -0.695386,
              -0.052528,
              0.001568,
              0.716712
            ]
          },
          "thigh.R": {
            "nodeIndex": 24,
            "translation": [
              -0.17,
              0.04,
              0.0
            ],
            "rotation": [
              0.975212,
              -0.030979,
              -0.105717,
              0.191899
            ]
          },
          "shin.R": {
            "nodeIndex": 25,
            "translation": [
              0.0,
              -0.0,
              0.482574
            ],
            "rotation": [
              0.215124,
              0.005273,
              0.019191,
              0.976384
            ]
          },
          "foot.R": {
            "nodeIndex": 26,
            "translation": [
              0.0,
              -0.0,
              0.366003
            ],
            "rotation": [
              -0.584201,
              0.112259,
              0.039279,
              0.802847
            ]
          }
        }
      }
    }
  }
});

export const SO_FIST_STRIKE_TIMING = SO_FIST_GEOMETRY.pistonAndStrikeTimingContract;
export const SO_FIST_LOCATORS_LOCAL = SO_FIST_GEOMETRY.operatorStationContract.locatorsLocal_1x;
export const SO_FIST_LOCATORS_WORLD = SO_FIST_GEOMETRY.operatorStationContract.locatorsWorld_2p85x;
export default SO_FIST_GEOMETRY;
