/**
 * Castleward — Authoritative SO-FIST-ICATION Simulation (`shared/sim/soFistication.mjs`)
 * ======================================================================================
 * Preserves Castleward's established authoritative siege-machine parameters:
 *   - 1,400 Hull HP, 500 Armored Fist HP, 250 per-wheel HP
 *   - 4.8 m/s ordinary forward speed, 12.0 m/s pressure-charge burst speed
 *   - 30 Hz authoritative simulation step (`dt = 1 / 30`)
 *   - Component destruction (including destroyed-fist blunt-shaft fallback)
 *   - Guard stamina/knockback interactions & structure damage
 *   - Terrain height/pitch/roll sampling & multiplayer replication state (`soFistPose`)
 *
 * Integrates the salvaged v2.2 upgrades without replacing the core architecture:
 *   1. Separate `operator_mount_entry` (`[0, 0, -3.5625] m`), `operator_onboard_rider` (`[0, +0.6441, -2.4938] m`),
 *      and `operator_safe_dismount` (`[0, 0, -3.8475] m`) transforms at `SO_FIST_SCALE = 2.85`.
 *   2. Frame-by-frame synchronized `evaluateSoFistPose(tSec, arrestedStrokeFraction)` matching the
 *      `0.68 s` mechanical release and `0.88 s` peak extension of `01_Ram_Strike_Full_Cycle` over `4.00 s`.
 *   3. Sweeping piston collision & obstacle-arrest clipping: if a fortified wall or gate arrests the piston
 *      at `arrestedStrokeFraction < 1.0`, both the authoritative hit volume and visible `soFistPose` stop
 *      cleanly at the obstacle face rather than clipping through it.
 */

import { SO_FIST_SCALE, SO_FIST_GEOMETRY, SO_FIST_STRIKE_TIMING, SO_FIST_LOCATORS_WORLD } from './soFistGeometry.mjs';

export const SO_FIST_AUTHORITATIVE_STATS = Object.freeze({
  HULL_MAX_HP: 1400,
  FIST_MAX_HP: 500,
  WHEEL_MAX_HP: 250,
  ORDINARY_SPEED_MPS: 4.8,
  REVERSE_SPEED_MPS: 2.6,
  PRESSURE_CHARGE_SPEED_MPS: 12.0,
  SIM_TICK_HZ: 30,
  ATTACK_CYCLE_DURATION_SEC: 4.00,
  MECHANICAL_RELEASE_SEC: 0.68,
  PEAK_IMPACT_SEC: 0.88,
  INTACT_FIST_PLAYER_DAMAGE: 65,
  INTACT_FIST_STRUCTURE_DAMAGE: 240,
  DESTROYED_FIST_PLAYER_DAMAGE: 35,
  DESTROYED_FIST_STRUCTURE_DAMAGE: 110,
});

// Exact 26-keyframe table from `AC01_Ram_Strike_Full_Cycle.003` in `SoFist-crafted-v2_2-salvaged.blend`
export const RETIMED_STRIKE_KEYFRAMES = Object.freeze([
  { t: 0.000, zPivotLocal: 0.520, springScaleZ: 1.0000, chainZLocal: -0.4550, leverRotXRad:  0.000 },
  { t: 0.080, zPivotLocal: 0.512, springScaleZ: 0.9529, chainZLocal: -0.4590, leverRotXRad:  0.060 },
  { t: 0.180, zPivotLocal: 0.492, springScaleZ: 0.8353, chainZLocal: -0.4690, leverRotXRad: -0.020 },
  { t: 0.290, zPivotLocal: 0.460, springScaleZ: 0.6471, chainZLocal: -0.4850, leverRotXRad:  0.060 },
  { t: 0.400, zPivotLocal: 0.432, springScaleZ: 0.4824, chainZLocal: -0.4990, leverRotXRad: -0.020 },
  { t: 0.490, zPivotLocal: 0.419, springScaleZ: 0.4059, chainZLocal: -0.5055, leverRotXRad:  0.050 },
  { t: 0.550, zPivotLocal: 0.415, springScaleZ: 0.3824, chainZLocal: -0.5075, leverRotXRad:  0.000 },
  { t: 0.590, zPivotLocal: 0.415, springScaleZ: 0.3824, chainZLocal: -0.5075, leverRotXRad:  0.000 },
  { t: 0.620, zPivotLocal: 0.415, springScaleZ: 0.3824, chainZLocal: -0.5075, leverRotXRad:  0.000 },
  { t: 0.640, zPivotLocal: 0.415, springScaleZ: 0.3824, chainZLocal: -0.5075, leverRotXRad:  0.000 },
  { t: 0.660, zPivotLocal: 0.415, springScaleZ: 0.3824, chainZLocal: -0.5075, leverRotXRad: -0.280 },
  { t: 0.680, zPivotLocal: 0.417, springScaleZ: 0.3941, chainZLocal: -0.5065, leverRotXRad: -0.480 }, // Mechanical release!
  { t: 0.730, zPivotLocal: 0.500, springScaleZ: 0.8824, chainZLocal: -0.4650, leverRotXRad: -0.480 },
  { t: 0.790, zPivotLocal: 0.665, springScaleZ: 1.8529, chainZLocal: -0.3825, leverRotXRad: -0.480 },
  { t: 0.830, zPivotLocal: 0.855, springScaleZ: 2.9706, chainZLocal: -0.2875, leverRotXRad: -0.480 },
  { t: 0.880, zPivotLocal: 0.965, springScaleZ: 3.6176, chainZLocal: -0.2325, leverRotXRad: -0.480 }, // Peak extension (+0.445m local / +1.268m world)!
  { t: 0.940, zPivotLocal: 0.922, springScaleZ: 3.3647, chainZLocal: -0.2540, leverRotXRad: -0.460 },
  { t: 1.000, zPivotLocal: 0.948, springScaleZ: 3.5176, chainZLocal: -0.2410, leverRotXRad: -0.420 },
  { t: 1.100, zPivotLocal: 0.932, springScaleZ: 3.4235, chainZLocal: -0.2490, leverRotXRad: -0.380 },
  { t: 1.240, zPivotLocal: 0.938, springScaleZ: 3.4588, chainZLocal: -0.2460, leverRotXRad: -0.320 },
  { t: 1.450, zPivotLocal: 0.935, springScaleZ: 3.4412, chainZLocal: -0.2475, leverRotXRad: -0.250 },
  { t: 2.050, zPivotLocal: 0.830, springScaleZ: 2.8235, chainZLocal: -0.3000, leverRotXRad: -0.150 },
  { t: 2.750, zPivotLocal: 0.685, springScaleZ: 1.9706, chainZLocal: -0.3725, leverRotXRad: -0.060 },
  { t: 3.400, zPivotLocal: 0.568, springScaleZ: 1.2824, chainZLocal: -0.4310, leverRotXRad:  0.000 },
  { t: 3.780, zPivotLocal: 0.526, springScaleZ: 1.0353, chainZLocal: -0.4520, leverRotXRad:  0.000 },
  { t: 4.000, zPivotLocal: 0.520, springScaleZ: 1.0000, chainZLocal: -0.4550, leverRotXRad:  0.000 },
]);

/**
 * Evaluates the exact frame-by-frame `soFistPose` at `tSec` in `[0.0, 4.0]`.
 * If an obstacle arrests the piston at `arrestedMaxZPivotLocal` (e.g. a wall closer than full extension),
 * clamps forward excursion at `arrestedMaxZPivotLocal` so the visible animation NEVER clips through the obstacle!
 */
export function evaluateSoFistPose(tSec, arrestedMaxZPivotLocal = 0.965) {
  if (tSec === null || tSec === undefined || tSec <= 0.0 || tSec >= 4.0) {
    return {
      active: false,
      phase: 'IDLE',
      zPivotLocal: 0.520,
      deltaZLocal: 0.000,
      deltaZWorld: 0.000,
      strokeFraction: 0.000,
      springScaleZ: 1.000,
      chainZLocal: -0.455,
      leverRotXRad: 0.000,
      arrested: false,
    };
  }

  const kf = RETIMED_STRIKE_KEYFRAMES;
  let k0 = kf[0], k1 = kf[kf.length - 1];
  for (let i = 0; i < kf.length - 1; i++) {
    if (tSec >= kf[i].t && tSec <= kf[i + 1].t) {
      k0 = kf[i];
      k1 = kf[i + 1];
      break;
    }
  }
  const span = Math.max(1e-6, k1.t - k0.t);
  const u = (tSec - k0.t) / span;

  let zPivot = k0.zPivotLocal + (k1.zPivotLocal - k0.zPivotLocal) * u;
  let springS = k0.springScaleZ + (k1.springScaleZ - k0.springScaleZ) * u;
  let chainZ  = k0.chainZLocal  + (k1.chainZLocal  - k0.chainZLocal)  * u;
  const leverR = k0.leverRotXRad + (k1.leverRotXRad - k0.leverRotXRad) * u;

  let arrested = false;
  if (zPivot > arrestedMaxZPivotLocal) {
    zPivot = arrestedMaxZPivotLocal;
    const clampedFrac = (zPivot - 0.520) / 0.170;
    springS = 1.0 + clampedFrac;
    chainZ = -0.455 + 0.5 * (zPivot - 0.520);
    arrested = true;
  }

  const deltaZLocal = zPivot - 0.520;
  const strokeFraction = Math.max(0.0, (zPivot - 0.415) / (0.965 - 0.415));
  let phase = 'WINDUP';
  if (tSec >= 0.68 && tSec < 0.80) phase = 'RELEASE_LAUNCH';
  else if (tSec >= 0.80 && tSec <= 0.98) phase = 'IMPACT_WINDOW';
  else if (tSec > 0.98 && tSec <= 1.45) phase = 'RECOIL';
  else if (tSec > 1.45) phase = 'WINCH_RESET';

  return {
    active: true,
    phase,
    zPivotLocal: Math.round(zPivot * 10000) / 10000,
    deltaZLocal: Math.round(deltaZLocal * 10000) / 10000,
    deltaZWorld: Math.round(deltaZLocal * SO_FIST_SCALE * 10000) / 10000,
    strokeFraction: Math.round(strokeFraction * 10000) / 10000,
    springScaleZ: Math.round(springS * 10000) / 10000,
    chainZLocal: Math.round(chainZ * 10000) / 10000,
    leverRotXRad: Math.round(leverR * 10000) / 10000,
    arrested,
  };
}

export function localToWorldTransform(vehicle, localOffsetWorld) {
  const cy = Math.cos(vehicle.yawRad || 0.0);
  const sy = Math.sin(vehicle.yawRad || 0.0);
  const pitch = vehicle.terrainPitchRad || 0.0;
  const roll  = vehicle.terrainRollRad  || 0.0;
  const lx = localOffsetWorld[0];
  const ly = localOffsetWorld[1] - lx * Math.sin(roll) + localOffsetWorld[2] * Math.sin(pitch);
  const lz = localOffsetWorld[2];
  return {
    x: vehicle.position.x + cy * lx + sy * lz,
    y: (vehicle.position.y || 0.0) + ly,
    z: vehicle.position.z - sy * lx + cy * lz,
  };
}

export function createAuthoritativeSoFistState({
  id = 'sofist_ram_1',
  position = { x: 0.0, y: 0.0, z: 0.0 },
  yawRad = 0.0,
} = {}) {
  return {
    id,
    position: { ...position },
    yawRad,
    terrainPitchRad: 0.0,
    terrainRollRad: 0.0,
    speedMps: 0.0,
    steerAngleRad: 0.0,
    wheelRollRad: 0.0,
    hullHp: SO_FIST_AUTHORITATIVE_STATS.HULL_MAX_HP,   // 1,400 HP preserved!
    maxHullHp: SO_FIST_AUTHORITATIVE_STATS.HULL_MAX_HP,
    fistHp: SO_FIST_AUTHORITATIVE_STATS.FIST_MAX_HP,   // 500 HP preserved!
    maxFistHp: SO_FIST_AUTHORITATIVE_STATS.FIST_MAX_HP,
    wheelsHp: {
      FL: SO_FIST_AUTHORITATIVE_STATS.WHEEL_MAX_HP,
      FR: SO_FIST_AUTHORITATIVE_STATS.WHEEL_MAX_HP,
      RL: SO_FIST_AUTHORITATIVE_STATS.WHEEL_MAX_HP,
      RR: SO_FIST_AUTHORITATIVE_STATS.WHEEL_MAX_HP,
    },
    operatorId: null,
    pressureChargeActive: false,
    pressureChargeEnergy: 0.0,
    strikeTimerSec: null,
    arrestedMaxZPivotLocal: 0.965,
    strikeHitEntitiesInCycle: new Set(),
    soFistPose: evaluateSoFistPose(null),
    events: [],
  };
}

export function tryBoardSoFist(vehicle, player) {
  if (!vehicle || vehicle.hullHp <= 0 || vehicle.operatorId || !player || player.hp <= 0) return false;
  const entryWorld = localToWorldTransform(vehicle, SO_FIST_LOCATORS_WORLD.operator_mount_entry);
  const dist = Math.hypot(player.position.x - entryWorld.x, player.position.z - entryWorld.z);
  if (dist > 2.40) return false;

  vehicle.operatorId = player.id;
  player.mountedVehicleId = vehicle.id;
  const ridingWorld = localToWorldTransform(vehicle, SO_FIST_LOCATORS_WORLD.operator_onboard_rider);
  player.position = { ...ridingWorld };
  player.yawRad = vehicle.yawRad;
  vehicle.events.push({
    type: 'sofist_boarded',
    operatorId: player.id,
    entryWorldPos: entryWorld,
    ridingWorldPos: ridingWorld,
  });
  return true;
}

export function dismountOrEjectSoFistOperator(vehicle, player, reason = 'manual_dismount', isObstacleAtPoint = null) {
  if (!vehicle || !player || vehicle.operatorId !== player.id) return false;
  const exitCandidates = [
    SO_FIST_LOCATORS_WORLD.operator_safe_dismount,
    SO_FIST_LOCATORS_WORLD.operator_safe_dismount_L,
    SO_FIST_LOCATORS_WORLD.operator_safe_dismount_R,
  ];
  let safeExit = localToWorldTransform(vehicle, exitCandidates[0]);
  if (isObstacleAtPoint) {
    for (const cand of exitCandidates) {
      const pt = localToWorldTransform(vehicle, cand);
      if (!isObstacleAtPoint(pt)) {
        safeExit = pt;
        break;
      }
    }
  }
  vehicle.operatorId = null;
  player.mountedVehicleId = null;
  player.position = { x: safeExit.x, y: Math.max(0.0, safeExit.y), z: safeExit.z };
  vehicle.events.push({
    type: 'sofist_dismounted',
    operatorId: player.id,
    reason,
    exitWorldPos: { ...player.position },
  });
  return true;
}

/**
 * Steps the authoritative 30 Hz SO-FIST-ICATION simulation (`dtSec = 1/30`).
 */
export function stepAuthoritativeSoFist(vehicle, input = {}, worldContext = {}, dtSec = 1 / 30) {
  if (!vehicle || vehicle.hullHp <= 0) return vehicle;
  const playersById = worldContext.playersById || {};
  const obstacles   = worldContext.obstacles   || [];
  const enemies     = worldContext.enemies     || [];

  // Auto-eject on operator death or disconnect
  if (vehicle.operatorId) {
    const op = playersById[vehicle.operatorId];
    if (!op || op.disconnected || op.hp <= 0) {
      if (op) dismountOrEjectSoFistOperator(vehicle, op, op.disconnected ? 'disconnect' : 'operator_death', worldContext.isBlockedFn);
      else vehicle.operatorId = null;
    }
  }

  // 1. Vehicle Speed & Pressure Charge (4.8 m/s ordinary, 12.0 m/s pressure charge)
  const maxSteerRad = (SO_FIST_GEOMETRY.wheelAndSteeringContract.maxFrontSteerAngleDeg * Math.PI) / 180.0;
  vehicle.steerAngleRad = Math.max(-maxSteerRad, Math.min(maxSteerRad, (input.steer || 0.0) * maxSteerRad));

  if (input.pressureCharge && vehicle.operatorId) {
    vehicle.pressureChargeActive = true;
    vehicle.pressureChargeEnergy = Math.min(1.0, vehicle.pressureChargeEnergy + dtSec * 0.8);
  } else {
    vehicle.pressureChargeActive = false;
  }

  const targetMaxFwd = vehicle.pressureChargeActive
    ? SO_FIST_AUTHORITATIVE_STATS.PRESSURE_CHARGE_SPEED_MPS
    : SO_FIST_AUTHORITATIVE_STATS.ORDINARY_SPEED_MPS;
  const throttle = vehicle.operatorId ? (input.throttle || 0.0) : 0.0;
  const targetSpeed = throttle >= 0 ? throttle * targetMaxFwd : throttle * SO_FIST_AUTHORITATIVE_STATS.REVERSE_SPEED_MPS;
  vehicle.speedMps += (targetSpeed - vehicle.speedMps) * Math.min(1.0, dtSec * 8.0);

  if (Math.abs(vehicle.speedMps) > 1e-4) {
    const wb = SO_FIST_GEOMETRY.wheelAndSteeringContract.wheelbaseWorld;
    const turnRate = (vehicle.speedMps / wb) * Math.tan(vehicle.steerAngleRad) * (1.0 - SO_FIST_GEOMETRY.wheelAndSteeringContract.rearCounterSteerFactor);
    vehicle.yawRad += turnRate * dtSec;
    vehicle.position.x += Math.sin(vehicle.yawRad) * vehicle.speedMps * dtSec;
    vehicle.position.z += Math.cos(vehicle.yawRad) * vehicle.speedMps * dtSec;
    vehicle.wheelRollRad += (vehicle.speedMps * dtSec) / SO_FIST_GEOMETRY.wheelAndSteeringContract.wheelRadiusWorld;
  }

  if (worldContext.sampleTerrainFn) {
    const tSample = worldContext.sampleTerrainFn(vehicle.position.x, vehicle.position.z, vehicle.yawRad);
    vehicle.position.y = tSample.y ?? 0.0;
    vehicle.terrainPitchRad = tSample.pitchRad ?? 0.0;
    vehicle.terrainRollRad  = tSample.rollRad  ?? 0.0;
  }

  // 2. Piston Attack Cycle & Sweeping Obstacle-Arrest Resolution
  if (input.attackPressed && vehicle.operatorId && vehicle.strikeTimerSec === null) {
    vehicle.strikeTimerSec = 0.0;
    vehicle.arrestedMaxZPivotLocal = 0.965;
    vehicle.strikeHitEntitiesInCycle = new Set();
    vehicle.events.push({ type: 'sofist_strike_started', releaseAtSec: 0.68, peakImpactAtSec: 0.88 });
  }

  if (vehicle.strikeTimerSec !== null) {
    const prevPose = vehicle.soFistPose;
    vehicle.strikeTimerSec = Math.round((vehicle.strikeTimerSec + dtSec) * 10000) / 10000;
    const t = vehicle.strikeTimerSec;

    // Sweeping obstacle check during forward launch (0.68s .. 0.98s)
    if (t >= 0.68 && t <= 0.98) {
      const intact = vehicle.fistHp > 0;
      const tipOffsetFromPivotLocal = intact ? (1.396 - 0.965) : (0.998 - 0.965);
      for (const obs of obstacles) {
        if (obs.hp !== undefined && obs.hp <= 0) continue;
        // Compute forward distance along vehicle +Z to obstacle surface
        const dx = obs.position.x - vehicle.position.x;
        const dz = obs.position.z - vehicle.position.z;
        const fwdDistWorld = Math.sin(vehicle.yawRad) * dx + Math.cos(vehicle.yawRad) * dz - (obs.halfDepth || 0.5);
        const maxAllowedTipLocal = fwdDistWorld / SO_FIST_SCALE;
        const maxAllowedPivotLocal = maxAllowedTipLocal - tipOffsetFromPivotLocal;
        if (maxAllowedPivotLocal < vehicle.arrestedMaxZPivotLocal && maxAllowedPivotLocal >= 0.415) {
          vehicle.arrestedMaxZPivotLocal = maxAllowedPivotLocal;
          if (!vehicle.strikeHitEntitiesInCycle.has(obs.id)) {
            vehicle.strikeHitEntitiesInCycle.add(obs.id);
            const structDmg = intact
              ? SO_FIST_AUTHORITATIVE_STATS.INTACT_FIST_STRUCTURE_DAMAGE
              : SO_FIST_AUTHORITATIVE_STATS.DESTROYED_FIST_STRUCTURE_DAMAGE;
            if (obs.hp !== undefined) obs.hp = Math.max(0, obs.hp - structDmg);
            vehicle.events.push({
              type: 'sofist_obstacle_impact_arrest',
              timeInCycleSec: t,
              obstacleId: obs.id,
              damageDealt: structDmg,
              arrestedMaxZPivotLocal: vehicle.arrestedMaxZPivotLocal,
            });
          }
        }
      }
    }

    vehicle.soFistPose = evaluateSoFistPose(t, vehicle.arrestedMaxZPivotLocal);

    if (prevPose.phase === 'WINDUP' && vehicle.soFistPose.phase !== 'WINDUP') {
      vehicle.events.push({ type: 'sofist_mechanical_release', timeInCycleSec: t });
    }

    // Sweeping player/enemy hit & Guard resolution during active forward strike (0.68s .. 0.98s)
    if (t >= 0.68 && t <= 0.98) {
      const intact = vehicle.fistHp > 0;
      const tipZLocal = vehicle.soFistPose.zPivotLocal + (intact ? 0.431 : 0.033);
      const tipWorld = localToWorldTransform(vehicle, [0.0, 0.365 * SO_FIST_SCALE, tipZLocal * SO_FIST_SCALE]);
      for (const enemy of enemies) {
        if (enemy.hp <= 0 || vehicle.strikeHitEntitiesInCycle.has(enemy.id)) continue;
        const dist = Math.hypot(enemy.position.x - tipWorld.x, enemy.position.z - tipWorld.z);
        if (dist <= (enemy.radius || 0.42) + 0.72) {
          vehicle.strikeHitEntitiesInCycle.add(enemy.id);
          const rawDmg = intact
            ? SO_FIST_AUTHORITATIVE_STATS.INTACT_FIST_PLAYER_DAMAGE
            : SO_FIST_AUTHORITATIVE_STATS.DESTROYED_FIST_PLAYER_DAMAGE;
          const guarded = Boolean(enemy.isGuarding);
          const finalDmg = guarded ? Math.round(rawDmg * 0.35) : rawDmg;
          enemy.hp = Math.max(0, enemy.hp - finalDmg);
          if (guarded) {
            enemy.guardStamina = Math.max(0, (enemy.guardStamina ?? 100) - 45);
          }
          vehicle.events.push({
            type: 'sofist_enemy_struck',
            timeInCycleSec: t,
            targetId: enemy.id,
            intactFist: intact,
            guarded,
            damageDealt: finalDmg,
          });
        }
      }
    }

    if (t >= 4.00) {
      vehicle.strikeTimerSec = null;
      vehicle.soFistPose = evaluateSoFistPose(null);
    }
  }

  // 3. Synchronize Onboard Rider Position, Hands, and First/Third-Person Camera
  if (vehicle.operatorId && playersById[vehicle.operatorId]) {
    const rider = playersById[vehicle.operatorId];
    rider.position = localToWorldTransform(vehicle, SO_FIST_LOCATORS_WORLD.operator_onboard_rider);
    rider.pelvisWorld = localToWorldTransform(vehicle, SO_FIST_LOCATORS_WORLD.operator_pelvis_anchor);
    rider.footLeftWorld = localToWorldTransform(vehicle, SO_FIST_LOCATORS_WORLD.operator_footrest_L);
    rider.footRightWorld = localToWorldTransform(vehicle, SO_FIST_LOCATORS_WORLD.operator_footrest_R);
    rider.handLeftWorld = localToWorldTransform(vehicle, SO_FIST_LOCATORS_WORLD.hand_L_steering_grip);
    const pullingLever = vehicle.strikeTimerSec !== null && vehicle.strikeTimerSec >= 0.64 && vehicle.strikeTimerSec <= 1.15;
    rider.handRightWorld = localToWorldTransform(
      vehicle,
      pullingLever ? SO_FIST_LOCATORS_WORLD.hand_R_attack_lever_pull : SO_FIST_LOCATORS_WORLD.hand_R_attack_lever_grip
    );
    rider.cameraTpvWorld = localToWorldTransform(vehicle, SO_FIST_LOCATORS_WORLD.operator_camera_tpv);
    rider.cameraSightWorld = localToWorldTransform(vehicle, SO_FIST_LOCATORS_WORLD.operator_camera_sight);
    rider.yawRad = vehicle.yawRad;
  }

  return vehicle;
}
