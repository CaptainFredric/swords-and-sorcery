import struct
import io
import numpy as np
from PIL import Image

class BlendFile:
    def __init__(self, path):
        self.path = path
        with open(path, "rb") as f:
            raw_b = f.read()
        if len(raw_b) >= 4 and raw_b[:4] == b"\x28\xb5\x2f\xfd":
            import ctypes
            libzstd = ctypes.CDLL("libzstd.so.1")
            libzstd.ZSTD_getFrameContentSize.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
            libzstd.ZSTD_getFrameContentSize.restype = ctypes.c_ulonglong
            libzstd.ZSTD_decompress.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t]
            libzstd.ZSTD_decompress.restype = ctypes.c_size_t
            d_sz = libzstd.ZSTD_getFrameContentSize(raw_b, len(raw_b))
            dst = ctypes.create_string_buffer(d_sz)
            libzstd.ZSTD_decompress(dst, d_sz, raw_b, len(raw_b))
            self.data = bytearray(dst.raw[:d_sz])
        else:
            self.data = bytearray(raw_b)
        assert self.data[:12] == b"BLENDER-v405"
        self.blocks = []
        pos = 12
        while pos < len(self.data):
            code_raw, size, old, sdna_nr, nr = struct.unpack_from("<4siQii", self.data, pos)
            code = code_raw.rstrip(b"\x00").decode("ascii", errors="replace")
            body_start = pos + 24
            body_end = body_start + size
            self.blocks.append({
                "code_raw": code_raw,
                "code": code,
                "size": size,
                "old": old,
                "sdna_nr": sdna_nr,
                "nr": nr,
                "payload": bytearray(self.data[body_start:body_end]),
            })
            pos = body_end
            if code == "ENDB":
                break
        self.ptr_map = {b["old"]: b for b in self.blocks if b["old"] != 0}
        self._parse_dna()
        # Next fresh pointer address above max existing old pointer
        max_old = max(b["old"] for b in self.blocks)
        self.next_old_ptr = ((max_old + 0x100000) & ~0xFFFF)

    def alloc_ptr(self, byte_len=64):
        p = self.next_old_ptr
        self.next_old_ptr += max(64, (byte_len + 63) & ~63)
        return p

    def _parse_dna(self):
        dna_block = [b for b in self.blocks if b["code"] == "DNA1"][0]
        buf = dna_block["payload"]
        pos = 8
        num_names = struct.unpack_from("<i", buf, pos)[0]
        pos += 4
        self.names = []
        for _ in range(num_names):
            end = buf.index(b"\x00", pos)
            self.names.append(buf[pos:end].decode("ascii"))
            pos = end + 1
        pos = (pos + 3) & ~3
        pos += 4
        num_types = struct.unpack_from("<i", buf, pos)[0]
        pos += 4
        self.types = []
        for _ in range(num_types):
            end = buf.index(b"\x00", pos)
            self.types.append(buf[pos:end].decode("ascii"))
            pos = end + 1
        pos = (pos + 3) & ~3
        pos += 4
        self.type_lens = struct.unpack_from(f"<{num_types}h", buf, pos)
        pos += 2 * num_types
        pos = (pos + 3) & ~3
        pos += 4
        num_structs = struct.unpack_from("<i", buf, pos)[0]
        pos += 4
        self.structs = []
        self.struct_by_name = {}
        for idx in range(num_structs):
            stype, nfields = struct.unpack_from("<hh", buf, pos)
            pos += 4
            fields = []
            for _ in range(nfields):
                ftype, fname = struct.unpack_from("<hh", buf, pos)
                pos += 4
                fields.append((self.types[ftype], self.names[fname], ftype))
            sname = self.types[stype]
            self.structs.append((sname, self.type_lens[stype], fields))
            self.struct_by_name[sname] = (idx, self.type_lens[stype], fields)

    def get_layout(self, sname):
        idx, slen, fields = self.struct_by_name[sname]
        layout = {}
        offset = 0
        for tname, fname, ftype_idx in fields:
            if fname.startswith("*") or fname.startswith("(*"):
                base_size = 8
            else:
                base_size = self.type_lens[ftype_idx]
            mult = 1
            if "[" in fname:
                for p in fname.split("[")[1:]:
                    mult *= int(p.split("]")[0])
            fsize = base_size * mult
            clean_name = fname.lstrip("*").split("[")[0]
            layout[clean_name] = (offset, fsize, tname, fname)
            offset += fsize
        return layout

    def get_id_name(self, b):
        return bytes(b["payload"][40:106]).split(b"\x00")[0].decode("utf-8", errors="replace")

    def replace_mesh(self, mesh_id_name, builder):
        """
        Replaces the geometry of `mesh_id_name` (e.g. 'MEHelmetShellCanonical')
        with the compiled arrays from `builder` (MeshData), while preserving
        all ID pointers, CustomDataLayer pointers, sharing_info handles, and vertex group names.
        """
        me_layout = self.get_layout("Mesh")
        cd_layout = self.get_layout("CustomData")
        cdl_layout = self.get_layout("CustomDataLayer")
        dg_layout = self.get_layout("bDeformGroup")

        # Locate the ME block and its range of following DATA blocks
        me_idx = None
        for idx, b in enumerate(self.blocks):
            if b["code"] == "ME" and self.get_id_name(b) == mesh_id_name:
                me_idx = idx
                break
        if me_idx is None:
            raise KeyError(f"Mesh {mesh_id_name} not found")

        end_idx = me_idx + 1
        while end_idx < len(self.blocks) and self.blocks[end_idx]["code"] == "DATA":
            end_idx += 1

        me_block = self.blocks[me_idx]
        me_buf = me_block["payload"]

        # Read vertex group names order on this mesh
        vg_first = struct.unpack_from("<Q", me_buf, me_layout["vertex_group_names"][0])[0]
        vgs = []
        curr_vg = vg_first
        while curr_vg and curr_vg in self.ptr_map:
            vgb = self.ptr_map[curr_vg]
            vgname = bytes(vgb["payload"][dg_layout["name"][0]:dg_layout["name"][0]+64]).split(b"\x00")[0].decode("utf-8")
            vgs.append(vgname)
            curr_vg = struct.unpack_from("<Q", vgb["payload"], 0)[0]

        # Compile builder data using the mesh's exact vertex group list
        compiled = builder.compile(vgs)
        totvert = compiled["totvert"]
        totedge = compiled["totedge"]
        totpoly = compiled["totpoly"]
        totloop = compiled["totloop"]

        # Update counts in Mesh struct
        struct.pack_into("<4i", me_buf, me_layout["totvert"][0], totvert, totedge, totpoly, totloop)
        struct.pack_into("<i", me_buf, me_layout["totselect"][0], 0)
        struct.pack_into("<i", me_buf, me_layout["act_face"][0], -1)

        # Update bounding box loc & size on Mesh
        bmin = compiled["positions"].min(axis=0)
        bmax = compiled["positions"].max(axis=0)
        loc = ((bmin + bmax) * 0.5).astype(np.float32)
        size = np.maximum((bmax - bmin) * 0.5, 1e-4).astype(np.float32)
        struct.pack_into("<3f", me_buf, me_layout["loc"][0], float(loc[0]), float(loc[1]), float(loc[2]))
        struct.pack_into("<3f", me_buf, me_layout["size"][0], float(size[0]), float(size[1]), float(size[2]))

        # Update poly_offset_indices block
        poly_off_ptr = struct.unpack_from("<Q", me_buf, me_layout["poly_offset_indices"][0])[0]
        poly_off_block = self.ptr_map[poly_off_ptr]
        poly_off_bytes = compiled["poly_offsets"].astype(np.int32).tobytes()
        poly_off_block["payload"] = bytearray(poly_off_bytes)
        poly_off_block["size"] = len(poly_off_bytes)
        poly_off_block["nr"] = 1

        # Build MDeformVert + MDeformWeight blocks if mesh has vertex groups
        dvert_ptr = None
        new_weight_blocks = []
        # Update each CustomData domain's layer data blocks
        for cname, count in [("vdata", totvert), ("edata", totedge), ("pdata", totpoly), ("ldata", totloop)]:
            coff = me_layout[cname][0]
            layers_ptr = struct.unpack_from("<Q", me_buf, coff + cd_layout["layers"][0])[0]
            totlayer = struct.unpack_from("<i", me_buf, coff + cd_layout["totlayer"][0])[0]
            if not layers_ptr or totlayer == 0:
                continue
            lb = self.ptr_map[layers_ptr]
            for li in range(totlayer):
                loff = li * 120
                ltype = struct.unpack_from("<i", lb["payload"], loff + cdl_layout["type"][0])[0]
                lname = bytes(lb["payload"][loff+cdl_layout["name"][0]:loff+cdl_layout["name"][0]+68]).split(b"\x00")[0].decode("utf-8")
                dptr = struct.unpack_from("<Q", lb["payload"], loff + cdl_layout["data"][0])[0]
                dblock = self.ptr_map[dptr]

                if cname == "vdata" and ltype == 2: # CD_MDEFORMVERT
                    dvert_ptr = dptr
                    dvert_buf = bytearray(16 * totvert)
                    for vi, wlist in enumerate(compiled["weights"]):
                        if not wlist:
                            struct.pack_into("<Qii", dvert_buf, vi * 16, 0, 0, 0)
                        else:
                            w_old = self.alloc_ptr(8 * len(wlist))
                            w_payload = bytearray(8 * len(wlist))
                            for wi, (def_nr, wval) in enumerate(wlist):
                                struct.pack_into("<if", w_payload, wi * 8, int(def_nr), float(wval))
                            wb = {
                                "code_raw": b"DATA",
                                "code": "DATA",
                                "size": len(w_payload),
                                "old": w_old,
                                "sdna_nr": 335, # MDeformWeight
                                "nr": len(wlist),
                                "payload": w_payload,
                            }
                            new_weight_blocks.append(wb)
                            self.ptr_map[w_old] = wb
                            struct.pack_into("<Qii", dvert_buf, vi * 16, w_old, len(wlist), 0)
                    dblock["payload"] = dvert_buf
                    dblock["size"] = len(dvert_buf)
                    dblock["nr"] = totvert

                elif cname == "vdata" and lname == "position":
                    raw = compiled["positions"].astype(np.float32).tobytes()
                    dblock["payload"] = bytearray(raw)
                    dblock["size"] = len(raw)
                    dblock["nr"] = totvert

                elif cname == "edata" and lname == ".edge_verts":
                    raw = compiled["edges"].astype(np.int32).tobytes()
                    dblock["payload"] = bytearray(raw)
                    dblock["size"] = len(raw)
                    dblock["nr"] = totedge

                elif cname == "ldata" and lname == ".corner_vert":
                    raw = compiled["corner_verts"].astype(np.int32).tobytes()
                    dblock["payload"] = bytearray(raw)
                    dblock["size"] = len(raw)
                    dblock["nr"] = totloop

                elif cname == "ldata" and lname == ".corner_edge":
                    raw = compiled["corner_edges"].astype(np.int32).tobytes()
                    dblock["payload"] = bytearray(raw)
                    dblock["size"] = len(raw)
                    dblock["nr"] = totloop

                elif cname == "ldata" and lname == "ArmorColor":
                    raw = compiled["armor_color"].astype(np.float32).tobytes()
                    dblock["payload"] = bytearray(raw)
                    dblock["size"] = len(raw)
                    dblock["nr"] = totloop

                elif cname == "ldata" and lname == "UVMap":
                    raw = compiled["uv_map"].astype(np.float32).tobytes()
                    dblock["payload"] = bytearray(raw)
                    dblock["size"] = len(raw)
                    dblock["nr"] = totloop

                elif cname == "pdata" and lname == "material_index":
                    raw = compiled["material_index"].astype(np.int32).tobytes()
                    dblock["payload"] = bytearray(raw)
                    dblock["size"] = len(raw)
                    dblock["nr"] = totpoly

                elif cname == "pdata" and lname == "sharp_face":
                    raw = np.ones(totpoly, dtype=np.uint8).tobytes()
                    dblock["payload"] = bytearray(raw)
                    dblock["size"] = len(raw)
                    dblock["nr"] = 1

                elif ltype == 11: # Other int32 property layers ('tag', 'edge', 'nobev', 'CanonicalArmPart', 'GauntletPart')
                    raw = np.zeros(count, dtype=np.int32).tobytes()
                    dblock["payload"] = bytearray(raw)
                    dblock["size"] = len(raw)
                    dblock["nr"] = count

                elif ltype == 50: # Other bool layers ('.select_vert', '.select_edge', '.select_poly')
                    raw = np.zeros(count, dtype=np.uint8).tobytes()
                    dblock["payload"] = bytearray(raw)
                    dblock["size"] = len(raw)
                    dblock["nr"] = 1

        # Replace the old MDeformWeight (sdna=335) blocks in blocks[me_idx+1 : end_idx] with new_weight_blocks
        # right after the MDeformVert (sdna=336) block!
        rebuilt_sub_blocks = []
        for sb in self.blocks[me_idx + 1 : end_idx]:
            if sb["sdna_nr"] == 335: # skip old MDeformWeight blocks
                continue
            rebuilt_sub_blocks.append(sb)
            if sb["sdna_nr"] == 336: # MDeformVert block -> insert new MDeformWeight blocks immediately after
                rebuilt_sub_blocks.extend(new_weight_blocks)

        self.blocks[me_idx + 1 : end_idx] = rebuilt_sub_blocks

    def update_packed_image(self, image_id_name, pil_img):
        """Updates a packed PNG image inside the blend file (e.g. IMSpellbladeBanner)."""
        im_layout = self.get_layout("Image")
        pf_layout = self.get_layout("PackedFile")
        ipf_layout = self.get_layout("ImagePackedFile")
        for b in self.blocks:
            if b["code"] == "IM" and self.get_id_name(b) == image_id_name:
                pf_ptr = struct.unpack_from("<Q", b["payload"], im_layout["packedfile"][0])[0]
                if not pf_ptr:
                    ipf_first = struct.unpack_from("<Q", b["payload"], im_layout["packedfiles"][0])[0]
                    if ipf_first in self.ptr_map:
                        ipfb = self.ptr_map[ipf_first]
                        pf_ptr = struct.unpack_from("<Q", ipfb["payload"], ipf_layout["packedfile"][0])[0]
                pfb = self.ptr_map[pf_ptr]
                data_ptr = struct.unpack_from("<Q", pfb["payload"], pf_layout["data"][0])[0]
                db = self.ptr_map[data_ptr]
                buf = io.BytesIO()
                pil_img.save(buf, format="PNG")
                raw_png = buf.getvalue()
                # Pad to 4 bytes in block payload while setting PackedFile.size to exact PNG byte length
                struct.pack_into("<i", pfb["payload"], pf_layout["size"][0], len(raw_png))
                padded = raw_png + b"\x00" * ((4 - len(raw_png) % 4) % 4)
                db["payload"] = bytearray(padded)
                db["size"] = len(padded)
                db["nr"] = 1
                return

    def set_armature_rest_pose_in_pose_channels(self):
        """
        Sets OBSpellbladeRig's current bPoseChannel transforms and pose_mat to match rest pose (arm_mat)
        so that when the file is opened at frame 1 for visual inspection alongside the concept sheet,
        it immediately displays in the canonical Hero Concept Pose (while keeping all 15 bActions intact).
        """
        ob_layout = self.get_layout("Object")
        pose_layout = self.get_layout("bPose")
        pchan_layout = self.get_layout("bPoseChannel")
        bone_layout = self.get_layout("Bone")
        adt_layout = self.get_layout("AnimData")
        for b in self.blocks:
            if b["code"] == "OB" and self.get_id_name(b) in ("OBSpellbladeRig", "OBSpellbladeFirstPersonRig"):
                p_ptr = struct.unpack_from("<Q", b["payload"], ob_layout["pose"][0])[0]
                if p_ptr in self.ptr_map:
                    pb = self.ptr_map[p_ptr]
                    curr = struct.unpack_from("<Q", pb["payload"], pose_layout["chanbase"][0])[0]
                    while curr and curr in self.ptr_map:
                        pcb = self.ptr_map[curr]
                        struct.pack_into("<3f", pcb["payload"], pchan_layout["loc"][0], 0.0, 0.0, 0.0)
                        struct.pack_into("<3f", pcb["payload"], pchan_layout["eul"][0], 0.0, 0.0, 0.0)
                        struct.pack_into("<4f", pcb["payload"], pchan_layout["quat"][0], 1.0, 0.0, 0.0, 0.0)
                        struct.pack_into("<3f", pcb["payload"], pchan_layout["size"][0], 1.0, 1.0, 1.0)
                        eye4 = np.eye(4, dtype=np.float32).tobytes()
                        pcb["payload"][pchan_layout["chan_mat"][0]:pchan_layout["chan_mat"][0]+64] = eye4
                        bone_ptr = struct.unpack_from("<Q", pcb["payload"], pchan_layout["bone"][0])[0]
                        if bone_ptr in self.ptr_map:
                            bb = self.ptr_map[bone_ptr]
                            arm_mat = bb["payload"][bone_layout["arm_mat"][0]:bone_layout["arm_mat"][0]+64]
                            arm_head = bb["payload"][bone_layout["arm_head"][0]:bone_layout["arm_head"][0]+12]
                            arm_tail = bb["payload"][bone_layout["arm_tail"][0]:bone_layout["arm_tail"][0]+12]
                            pcb["payload"][pchan_layout["pose_mat"][0]:pchan_layout["pose_mat"][0]+64] = arm_mat
                            pcb["payload"][pchan_layout["pose_head"][0]:pchan_layout["pose_head"][0]+12] = arm_head
                            pcb["payload"][pchan_layout["pose_tail"][0]:pchan_layout["pose_tail"][0]+12] = arm_tail
                        curr = struct.unpack_from("<Q", pcb["payload"], 0)[0]

    def save(self, out_path):
        out = bytearray(b"BLENDER-v405")
        for b in self.blocks:
            header = struct.pack("<4siQii", b["code_raw"], len(b["payload"]), b["old"], b["sdna_nr"], b["nr"])
            out.extend(header)
            out.extend(b["payload"])
        with open(out_path, "wb") as f:
            f.write(out)
        return len(out)
