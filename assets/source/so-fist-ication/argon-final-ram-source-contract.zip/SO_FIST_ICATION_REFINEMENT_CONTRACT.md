# SO-FIST-ICATION v2.5 — Binary-Derived Refinement & Runtime Integration Contract

## 1. Authoritative Binary & Source Checksums (`v2.5` vs `v2.4` Rollback Baseline)

| Artifact Role | File Name | Byte Size | Nodes | Meshes | Welded Verts | Triangles | Clips | SHA-256 Checksum |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| **v2.5 Runtime Candidate GLB** | `so-fist-ication-v25-review.glb` | `5,713,504 B` | `33` | `17` | `64,150` | `32,412` | `4` | `b1ea92edc3310114c4c5ec08ce68ecb4768a2fed9ee816a25040b1d2281819d1` |
| **v2.5 Editable Blender Source** | `SoFist-v25-runtime-source.blend` | `3,926,235 B` | `33` OB | `17` ME | `64,150` | `32,412` | `4` AC | `5ec0031e499d56cbbe229a1e67836a68b2af8d60bde89263ed732952d10f4384` |
| **v2.4 Rollback GLB (Preserved)** | `so-fist-ication-v24-review.glb` | `5,350,904 B` | `33` | `17` | `53,774` | `27,332` | `4` | `fa3a4428729e74f29453012cccf44f393914a04b6fc5c37db9660a9979dd93ba` |

## 2. MANDATORY CASTLEWARD RUNTIME WHEELBASE, STEERING, COLLISION & TERRAIN INTEGRATION REQUIREMENT

> **CRITICAL SIMULATION REQUIREMENT**: The `SO-FIST-ICATION v2.5` (and `v2.4`) rear wheels (`[16] Wheel_RL` and `[17] Wheel_RR`) have been structurally relocated from the legacy `Z = -0.260 m` position to **native `Z = -0.820 m`**, while the front wheels (`[14] Wheel_FL` and `[15] Wheel_FR`) remain at **native `Z = +0.325 m`**. This establishes a **native wheelbase of `1.1450 m`** (or **`3.2633 m` world wheelbase** at Castleward's `2.85x` runtime scale, up from `1.6673 m`).
>
> **Do NOT treat `so-fist-ication-v25-review.glb` as a zero-code physics drop-in if the repository's simulation still assumes the old `Z = -0.260 m` rear axle!** To prevent visual wheel-slip during steering, incorrect terrain pitch sampling, or premature rear overhang clipping, Codex must update the authoritative geometry and simulation constants in `shared/sim/soFistGeometry.mjs` and `shared/sim/soFistication.mjs` as tabulated below:

| Runtime Parameter (`shared/sim/soFistGeometry.mjs`) | Legacy Value (`Z_rear = -0.260 m`) | Required `v2.5` Value (`Z_rear = -0.820 m`) | World Value at `2.85x` Scale | Purpose in Castleward Runtime |
| :--- | :---: | :---: | :---: | :--- |
| **`frontAxleLocalZ` (`Wheel_FL` / `Wheel_FR`)** | `+0.3250 m` | **`+0.3250 m`** *(unchanged)* | **`+0.9263 m`** | Front axle terrain ground-height & steering pivot plane |
| **`rearAxleLocalZ` (`Wheel_RL` / `Wheel_RR`)** | `-0.2600 m` | **`-0.8200 m`** *(relocated -0.560 m aft)* | **`-2.3370 m`** | Rear axle terrain ground-height & non-slip turn center plane |
| **`wheelbaseLocalM` (`frontAxleZ - rearAxleZ`)** | `0.5850 m` | **`1.1450 m`** *(+95.7% stability span)* | **`3.2633 m`** | Terrain pitch angle (`atan2(h_front - h_rear, wheelbase)`) & yaw rate |
| **`frontTrackHalfWidthLocalX` (`Wheel_FL/FR`)** | `0.4300 m` | **`0.4300 m`** *(unchanged)* | **`1.2255 m`** | Front lateral roll sampling & wheel ground-dust emitter X |
| **`rearTrackHalfWidthLocalX` (`Wheel_RL/RR`)** | `0.3700 m` | **`0.3700 m`** *(unchanged)* | **`1.0545 m`** | Rear lateral roll sampling & wheel ground-dust emitter X |
| **`wheelRadiusLocalM` (`Wheel_*_Mesh`)** | `0.1650 m` | **`0.1650 m`** *(unchanged)* | **`0.4703 m`** | Wheel spin angular velocity `omega = v_longitudinal / R_wheel` |
| **`fistRestTipLocalZ` (`Ram_Assembly + Armored_Fist`)** | `+0.9510 m` | **`+0.9510 m`** *(`0.0000 m` delta)* | **`+2.7104 m`** | Rest forward battering-ram collision & strike origin |
| **`fistExtendedTipLocalZ` (`03_Pose_Extended_Launched`)** | `+1.3960 m` | **`+1.3960 m`** *(`0.0000 m` delta)* | **`+3.9786 m`** | Peak piston strike reach (`+0.4450 m` local / `+1.2683 m` world stroke) |
| **`chassisRearBoundLocalZ` (`Carriage_Main_Mesh`)** | `-1.1800 m` | **`-1.1800 m`** *(unchanged)* | **`-3.3630 m`** | Rear hull collision box boundary & `operator_mount_entry` (`Z = -1.250 m`) |

## 3. Complete Binary-Derived 33-Node Hierarchy & Mesh Table (`so-fist-ication-v25-review.glb`)

| Node | Exact Binary Node Name | Parent | Local Translation `[X, Y, Z]` (m) | World Rest `[X, Y, Z]` (m) | Mesh Name | Welded Verts | Tris | Local Bounds Min -> Max (m) |
| :---: | :--- | :--- | :---: | :---: | :--- | :---: | :---: | :--- |
| `00` | `BattleRam_Root` | `ROOT` | `[0.0, 0.0, 0.0]` | `[0.0, 0.0, 0.0]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `01` | `Arcane_Stator_Collar` | `[00] BattleRam_Root` | `[0.0, 0.365, 0.485]` | `[0.0, 0.365, 0.485]` | `Arcane_Stator_Collar_Mesh` | `1,448` | `724` | `[-0.1893, -0.1893, -0.027] -> [0.1893, 0.192, 0.055]` |
| `02` | `Armored_Fist` | `[10] Ram_Assembly` | `[0.0, 0.0, 0.0]` | `[0.0, 0.365, 0.52]` | `Armored_Fist_Mesh` | `5,400` | `2,700` | `[-0.2926, -0.2213, -0.0134] -> [0.2357, 0.2611, 0.431]` |
| `03` | `Banner_Rear_L` | `[00] BattleRam_Root` | `[0.272, 0.685, -0.76]` | `[0.272, 0.685, -0.76]` | `Banner_Rear_L_Mesh` | `1,747` | `1,102` | `[-0.0586, -0.2542, -0.0788] -> [0.0728, 0.0553, 0.0603]` |
| `04` | `Banner_Rear_R` | `[00] BattleRam_Root` | `[-0.272, 0.685, -0.76]` | `[-0.272, 0.685, -0.76]` | `Banner_Rear_R_Mesh` | `1,740` | `1,170` | `[-0.0753, -0.2546, -0.0793] -> [0.0591, 0.0554, 0.0636]` |
| `05` | `Banner_Side_L` | `[00] BattleRam_Root` | `[0.258, 0.52, 0.115]` | `[0.258, 0.52, 0.115]` | `Banner_Side_L_Mesh` | `130` | `76` | `[-0.0302, -0.1685, -0.0609] -> [0.0178, 0.0175, 0.0676]` |
| `06` | `Banner_Side_R` | `[00] BattleRam_Root` | `[-0.258, 0.52, 0.115]` | `[-0.258, 0.52, 0.115]` | `Banner_Side_R_Mesh` | `85` | `43` | `[-0.0188, -0.1543, -0.0796] -> [0.0281, 0.0113, 0.0643]` |
| `07` | `Carriage_Main` | `[00] BattleRam_Root` | `[0.0, 0.0, 0.0]` | `[0.0, 0.0, 0.0]` | `Carriage_Main_Mesh` | `12,784` | `6,288` | `[-0.43, 0.1107, -1.18] -> [0.43, 0.752, 0.4963]` |
| `08` | `Launch_Mechanism` | `[00] BattleRam_Root` | `[0.0, 0.0, 0.0]` | `[0.0, 0.0, 0.0]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `09` | `Pinion_And_Release_Lever` | `[08] Launch_Mechanism` | `[0.0, 0.465, -0.475]` | `[0.0, 0.465, -0.475]` | `Pinion_And_Release_Lever_Mesh` | `606` | `324` | `[-0.16, -0.0373, -0.0892] -> [0.16, 0.193, 0.0651]` |
| `10` | `Ram_Assembly` | `[00] BattleRam_Root` | `[0.0, 0.365, 0.52]` | `[0.0, 0.365, 0.52]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `11` | `Ram_Shaft_Piston` | `[10] Ram_Assembly` | `[0.0, 0.0, 0.0]` | `[0.0, 0.365, 0.52]` | `Ram_Shaft_Piston_Mesh` | `6,624` | `3,352` | `[-0.166, -0.166, -1.228] -> [0.166, 0.166, -0.01]` |
| `12` | `Retraction_Chains_Aft` | `[08] Launch_Mechanism` | `[0.0, 0.385, -0.455]` | `[0.0, 0.385, -0.455]` | `Retraction_Chains_Aft_Mesh` | `2,480` | `1,240` | `[-0.08, -0.018, -0.333] -> [0.08, 0.018, 0.013]` |
| `13` | `Tension_Springs` | `[08] Launch_Mechanism` | `[0.0, 0.365, -0.545]` | `[0.0, 0.365, -0.545]` | `Tension_Springs_Mesh` | `2,072` | `1,056` | `[-0.1372, -0.0316, -0.0032] -> [0.1372, 0.0316, 0.1832]` |
| `14` | `Wheel_FL` | `[00] BattleRam_Root` | `[0.43, 0.165, 0.325]` | `[0.43, 0.165, 0.325]` | `Wheel_FL_Mesh` | `5,784` | `2,836` | `[-0.074, -0.165, -0.165] -> [0.07, 0.165, 0.165]` |
| `15` | `Wheel_FR` | `[00] BattleRam_Root` | `[-0.43, 0.165, 0.325]` | `[-0.43, 0.165, 0.325]` | `Wheel_FR_Mesh` | `5,784` | `2,836` | `[-0.07, -0.165, -0.165] -> [0.074, 0.165, 0.165]` |
| `16` | `Wheel_RL` | `[00] BattleRam_Root` | `[0.37, 0.165, -0.82]` | `[0.37, 0.165, -0.82]` | `Wheel_RL_Mesh` | `5,784` | `2,836` | `[-0.074, -0.165, -0.165] -> [0.07, 0.165, 0.165]` |
| `17` | `Wheel_RR` | `[00] BattleRam_Root` | `[-0.37, 0.165, -0.82]` | `[-0.37, 0.165, -0.82]` | `Wheel_RR_Mesh` | `5,784` | `2,836` | `[-0.07, -0.165, -0.165] -> [0.074, 0.165, 0.165]` |
| `18` | `Winch_Drum_And_Gears` | `[08] Launch_Mechanism` | `[0.0, 0.385, -0.56]` | `[0.0, 0.385, -0.56]` | `Winch_Drum_And_Gears_Mesh` | `4,712` | `2,392` | `[-0.265, -0.126, -0.1118] -> [0.265, 0.126, 0.1118]` |
| `19` | `Wrist_Resonator_Ring` | `[10] Ram_Assembly` | `[0.0, 0.0, 0.0]` | `[0.0, 0.365, 0.52]` | `Wrist_Resonator_Ring_Mesh` | `1,186` | `601` | `[-0.1782, -0.1774, -0.025] -> [0.1889, 0.1774, 0.0332]` |
| `20` | `operator_mount_entry` | `[07] Carriage_Main` | `[0.0, 0.0, -1.25]` | `[0.0, 0.0, -1.25]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `21` | `operator_onboard_rider` | `[07] Carriage_Main` | `[0.0, 0.226, -0.875]` | `[0.0, 0.226, -0.875]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `22` | `operator_pelvis_anchor` | `[07] Carriage_Main` | `[0.0, 0.515, -0.885]` | `[0.0, 0.515, -0.885]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `23` | `operator_footrest_L` | `[07] Carriage_Main` | `[0.115, 0.228, -0.84]` | `[0.115, 0.228, -0.84]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `24` | `operator_footrest_R` | `[07] Carriage_Main` | `[-0.115, 0.228, -0.84]` | `[-0.115, 0.228, -0.84]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `25` | `hand_L_steering_grip` | `[07] Carriage_Main` | `[0.12, 0.6, -0.715]` | `[0.12, 0.6, -0.715]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `26` | `hand_R_attack_lever_grip` | `[07] Carriage_Main` | `[-0.12, 0.6, -0.715]` | `[-0.12, 0.6, -0.715]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `27` | `hand_R_attack_lever_pull` | `[07] Carriage_Main` | `[0.0, 0.6, -0.515]` | `[0.0, 0.6, -0.515]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `28` | `operator_camera_tpv` | `[07] Carriage_Main` | `[0.0, 1.14, -2.1]` | `[0.0, 1.14, -2.1]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `29` | `operator_camera_sight` | `[07] Carriage_Main` | `[0.0, 0.835, -0.82]` | `[0.0, 0.835, -0.82]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `30` | `operator_safe_dismount` | `[07] Carriage_Main` | `[0.0, 0.0, -1.35]` | `[0.0, 0.0, -1.35]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `31` | `operator_safe_dismount_L` | `[07] Carriage_Main` | `[0.76, 0.0, -0.9]` | `[0.76, 0.0, -0.9]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `32` | `operator_safe_dismount_R` | `[07] Carriage_Main` | `[-0.76, 0.0, -0.9]` | `[-0.76, 0.0, -0.9]` | `-` | `0` | `0` | *(Locator / Transform)* |

## 4. Complete Binary-Derived 4-Animation Manifest (`so-fist-ication-v25-review.glb`)

| Clip # | Exact Binary Animation Clip Name | Duration (s) | Keys | Channels | Animated Target Nodes & Channels (`T`/`R`/`S`) |
| :---: | :--- | :---: | :---: | :---: | :--- |
| `01` | `01_Ram_Strike_Full_Cycle` | `4.0000 s` | `26` | `15` | `[00] BattleRam_Root` (R/T), `[03] Banner_Rear_L` (R), `[04] Banner_Rear_R` (R), `[05] Banner_Side_L` (R), `[06] Banner_Side_R` (R), `[09] Pinion_And_Release_Lever` (R), `[10] Ram_Assembly` (T), `[12] Retraction_Chains_Aft` (T), `[13] Tension_Springs` (S), `[14] Wheel_FL` (R), `[15] Wheel_FR` (R), `[16] Wheel_RL` (R), `[17] Wheel_RR` (R), `[18] Winch_Drum_And_Gears` (R) |
| `02` | `02_Pose_Retracted_Charged` | `1.0000 s` | `2` | `4` | `[10] Ram_Assembly` (T), `[12] Retraction_Chains_Aft` (T), `[13] Tension_Springs` (S), `[18] Winch_Drum_And_Gears` (R) |
| `03` | `03_Pose_Extended_Launched` | `1.0000 s` | `2` | `5` | `[09] Pinion_And_Release_Lever` (R), `[10] Ram_Assembly` (T), `[12] Retraction_Chains_Aft` (T), `[13] Tension_Springs` (S), `[18] Winch_Drum_And_Gears` (R) |
| `04` | `04_Carriage_Roll_And_Banners` | `2.0000 s` | `5` | `8` | `[03] Banner_Rear_L` (R), `[04] Banner_Rear_R` (R), `[05] Banner_Side_L` (R), `[06] Banner_Side_R` (R), `[14] Wheel_FL` (R), `[15] Wheel_FR` (R), `[16] Wheel_RL` (R), `[17] Wheel_RR` (R) |
