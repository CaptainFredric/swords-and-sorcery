#!/usr/bin/env python3
"""
Exports `SoFist-crafted-v2_1-uncompressed.blend` to `so-fist-ication-refined.glb` (and `so-fist-ication.glb`)
with:
  - All 20 canonical core nodes (`BattleRam_Root` .. `Wrist_Resonator_Ring`) scaled to +8.5% substantial geometry
  - Smooth vertex normals on the outer wheel running surfaces (`r_yz > 0.145 * 1.085`), piston barrel, and collars
    while preserving crisp flat-shaded normals on the low-poly timber beams, spokes, and armor facets
  - 12 explicit operator & gameplay child locators under `Carriage_Main` with separate transforms for
    Ground-Level Entry (`operator_mount_entry`) and Onboard Riding (`operator_onboard_rider`)
  - All 4 Slotted Actions (`01_Ram_Strike_Full_Cycle` retimed to 0.68s release / 0.88s impact peak over the
    preserved 4.00s cycle, `02_Pose_Retracted_Charged`, `03_Pose_Extended_Launched`, `04_Carriage_Roll_And_Banners`).
"""
import sys, os, io, json, math, struct, hashlib, zipfile
from pathlib import Path
import numpy as np
from PIL import Image

OUT_DIR = Path("/working_dir/c_63a1f8c151a6582d/artifacts/file_generation/ttl=63d/output")
sys.path.insert(0, str(OUT_DIR))
import blend_io
from build_sofist_v2_1_candidate import S_SUBSTANTIAL

MATERIAL_DEFS = [
    ("MARam candidate chains.003",       {"baseColorFactor": [0.045, 0.053, 0.062, 1.0], "metallicFactor": 0.76, "roughnessFactor": 0.60}),
    ("MARam candidate cloth.003",        {"baseColorTexture": 0, "metallicRoughnessTexture": 1, "normalTexture": 2, "doubleSided": True}),
    ("MARam candidate collar.003",       {"baseColorFactor": [0.300, 0.190, 0.075, 1.0], "metallicFactor": 0.72, "roughnessFactor": 0.42, "emissiveTexture": 3, "emissiveFactor": [1.0, 1.0, 1.0]}),
    ("MARam candidate mechanism.003",    {"baseColorFactor": [0.105, 0.130, 0.160, 1.0], "metallicFactor": 0.76, "roughnessFactor": 0.48, "normalTexture": 2}),
    ("MARam candidate timber.003",       {"baseColorTexture": 0, "metallicRoughnessTexture": 1, "normalTexture": 2}),
    ("MARam control grip leather.001",   {"baseColorFactor": [0.045, 0.023, 0.012, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.90}),
    ("MARam forged frame walnut.003",    {"baseColorFactor": [0.130, 0.065, 0.027, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.86, "normalTexture": 2}),
    ("MARam region brass.003",           {"baseColorFactor": [0.320, 0.200, 0.080, 1.0], "metallicFactor": 0.50, "roughnessFactor": 0.58, "normalTexture": 2}),
    ("MARam region iron.003",            {"baseColorFactor": [0.055, 0.064, 0.075, 1.0], "metallicFactor": 0.50, "roughnessFactor": 0.65, "normalTexture": 2}),
    ("MARam region steel.003",           {"baseColorFactor": [0.240, 0.270, 0.300, 1.0], "metallicFactor": 0.40, "roughnessFactor": 0.58, "normalTexture": 2}),
    ("MARam region timber.003",          {"baseColorFactor": [0.160, 0.075, 0.032, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.86, "normalTexture": 2}),
    ("MARam region timberLight.003",     {"baseColorFactor": [0.240, 0.120, 0.050, 1.0], "metallicFactor": 0.00, "roughnessFactor": 0.86, "normalTexture": 2}),
    ("MARam wheel bronze.003",           {"baseColorFactor": [0.270, 0.170, 0.065, 1.0], "metallicFactor": 0.55, "roughnessFactor": 0.55, "normalTexture": 2}),
    ("MARam wheel iron.003",             {"baseColorFactor": [0.072, 0.085, 0.100, 1.0], "metallicFactor": 0.55, "roughnessFactor": 0.61, "normalTexture": 2}),
    ("MARam wheel timber detail.003",    {"baseColorTexture": 0, "metallicRoughnessTexture": 1, "normalTexture": 2}),
]

# Explicit Operator & Gameplay Locators (in 1.085x local asset space; multiply by 2.65x for world meters)
# NOTE: Ground-level entry position (`operator_mount_entry`) and onboard riding position (`operator_onboard_rider`)
# are strictly separate transforms!
S = S_SUBSTANTIAL # 1.085
OPERATOR_LOCATORS_LOCAL = [
    ("operator_mount_entry",          [0.000, 0.000, round(-1.260 * S, 4)]), # [0.000, 0.000, -1.3671] m local ([0.000, 0.000, -3.623] m world) — Ground-level rear boarding zone!
    ("operator_onboard_rider",        [0.000, round(+0.226 * S, 4), round(-0.875 * S, 4)]), # [0.000, +0.2452, -0.9494] m local ([0.000, +0.650, -2.516] m world) — Raised deck riding root!
    ("operator_pelvis_anchor",        [0.000, round(+0.535 * S, 4), round(-0.885 * S, 4)]), # [0.000, +0.5805, -0.9602] m local ([0.000, +1.538, -2.545] m world) — Braced saddle-bolster pelvis!
    ("operator_footrest_L",           [round(+0.115 * S, 4), round(+0.228 * S, 4), round(-0.840 * S, 4)]), # [+0.1248, +0.2474, -0.9114] m local
    ("operator_footrest_R",           [round(-0.115 * S, 4), round(+0.228 * S, 4), round(-0.840 * S, 4)]), # [-0.1248, +0.2474, -0.9114] m local
    ("hand_L_steering_grip",          [round(+0.125 * S, 4), round(+0.635 * S, 4), round(-0.715 * S, 4)]), # [+0.1356, +0.6890, -0.7758] m local
    ("hand_R_attack_lever_grip",      [round(-0.125 * S, 4), round(+0.635 * S, 4), round(-0.715 * S, 4)]), # [-0.1356, +0.6890, -0.7758] m local
    ("hand_R_attack_lever_pull",      [0.000, round(+0.635 * S, 4), round(-0.515 * S, 4)]), # [0.000, +0.6890, -0.5588] m local — Active lever pull reach!
    ("operator_camera_tpv",           [0.000, round(+1.180 * S, 4), round(-2.150 * S, 4)]), # [0.000, +1.2803, -2.3328] m local — Follow camera anchor!
    ("operator_camera_sight",         [0.000, round(+0.865 * S, 4), round(-0.820 * S, 4)]), # [0.000, +0.9385, -0.8897] m local — Over-the-shoulder aiming sight!
    ("operator_safe_dismount",        [0.000, 0.000, round(-1.350 * S, 4)]), # [0.000, 0.000, -1.4648] m local ([0.000, 0.000, -3.882] m world) — Primary rear safe dismount!
    ("operator_safe_dismount_L",      [round(+0.760 * S, 4), 0.000, round(-0.900 * S, 4)]), # [+0.8246, 0.000, -0.9765] m local — Left lateral fallback dismount!
    ("operator_safe_dismount_R",      [round(-0.760 * S, 4), 0.000, round(-0.900 * S, 4)]), # [-0.8246, 0.000, -0.9765] m local — Right lateral fallback dismount!
]

def clean_prefix(s: str, pfx: str) -> str:
    name = s[len(pfx):] if s.startswith(pfx) else s
    return name.split(".")[0] if "." in name else name

def export_v2_1_glb(blend_uncomp_path: Path, out_glb_path: Path):
    bf = blend_io.BlendFile(str(blend_uncomp_path))
    ptr_to_name = {b["old"]: bf.get_id_name(b) for b in bf.blocks}
    ob_layout = bf.get_layout("Object")
    me_layout = bf.get_layout("Mesh")
    cd_layout = bf.get_layout("CustomData")
    cdl_layout = bf.get_layout("CustomDataLayer")

    bin_chunks = bytearray()
    buffer_views = []
    accessors = []

    def add_bv(raw_bytes: bytes, target=None):
        pad = (4 - (len(bin_chunks) % 4)) % 4
        if pad: bin_chunks.extend(b"\x00" * pad)
        off = len(bin_chunks)
        bin_chunks.extend(raw_bytes)
        bv = {"buffer": 0, "byteOffset": off, "byteLength": len(raw_bytes)}
        if target is not None: bv["target"] = target
        idx = len(buffer_views)
        buffer_views.append(bv)
        return idx

    def add_acc(bv_idx: int, comp_type: int, count: int, acc_type: str, vmin=None, vmax=None):
        acc = {"bufferView": bv_idx, "componentType": comp_type, "count": count, "type": acc_type}
        if vmin is not None: acc["min"] = [float(x) if comp_type == 5126 else int(x) for x in vmin]
        if vmax is not None: acc["max"] = [float(x) if comp_type == 5126 else int(x) for x in vmax]
        idx = len(accessors)
        accessors.append(acc)
        return idx

    tex_files = [
        ("texture_diffuse", str(Path(__file__).resolve().parent) + "/IMtexture_diffuse.006.png"),
        ("texture_metallic-texture_roughness", str(Path(__file__).resolve().parent) + "/IMtexture_metallic-texture_roughness.006.png"),
        ("texture_normal", str(Path(__file__).resolve().parent) + "/IMtexture_normal.006.png"),
        ("texture_emissive", str(Path(__file__).resolve().parent) + "/IMtexture_emissive.003.png"),
    ]
    images, textures = [], []
    samplers = [{"magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497}]
    for tname, tpath in tex_files:
        im = Image.open(tpath)
        buf = io.BytesIO()
        im.save(buf, format="PNG", optimize=True, compress_level=9)
        bv_i = add_bv(buf.getvalue())
        img_i = len(images)
        images.append({"name": tname, "mimeType": "image/png", "bufferView": bv_i})
        textures.append({"sampler": 0, "source": img_i, "name": tname})

    mat_id_to_idx = {}
    gltf_materials = []
    for idx, (ma_id, spec) in enumerate(MATERIAL_DEFS):
        mat_id_to_idx[ma_id] = idx
        pbr = {}
        for k in ("baseColorFactor", "metallicFactor", "roughnessFactor"):
            if k in spec: pbr[k] = spec[k]
        if "baseColorTexture" in spec: pbr["baseColorTexture"] = {"index": spec["baseColorTexture"]}
        if "metallicRoughnessTexture" in spec: pbr["metallicRoughnessTexture"] = {"index": spec["metallicRoughnessTexture"]}
        m_obj = {"name": clean_prefix(ma_id, "MA"), "pbrMetallicRoughness": pbr, "doubleSided": spec.get("doubleSided", False)}
        if "normalTexture" in spec: m_obj["normalTexture"] = {"index": spec["normalTexture"]}
        if "emissiveTexture" in spec:
            m_obj["emissiveTexture"] = {"index": spec["emissiveTexture"]}
            m_obj["emissiveFactor"] = spec.get("emissiveFactor", [1.0, 1.0, 1.0])
        gltf_materials.append(m_obj)

    me_id_to_idx = {}
    gltf_meshes = []
    for b in bf.blocks:
        if b["code"] == "ME":
            me_id = bf.get_id_name(b)
            me_buf = b["payload"]
            totvert, totedge, totpoly, totloop = struct.unpack_from("<4i", me_buf, me_layout["totvert"][0])
            totcol = struct.unpack_from("<h", me_buf, me_layout["totcol"][0])[0]
            mat_ptr = struct.unpack_from("<Q", me_buf, me_layout["mat"][0])[0]
            mat_names = [ptr_to_name.get(p, "MARam candidate timber.003") for p in struct.unpack_from(f"<{totcol}Q", bf.ptr_map[mat_ptr]["payload"], 0)] if (mat_ptr in bf.ptr_map and totcol > 0) else ["MARam candidate timber.003"]
            poly_off_ptr = struct.unpack_from("<Q", me_buf, me_layout["poly_offset_indices"][0])[0]
            poly_offsets = np.frombuffer(bf.ptr_map[poly_off_ptr]["payload"], dtype=np.int32, count=totpoly+1).copy()

            pos, corner_verts, uv_map, mat_idx = None, None, None, np.zeros(totpoly, dtype=np.int32)
            for cname, cnt in [("vdata", totvert), ("pdata", totpoly), ("ldata", totloop)]:
                coff = me_layout[cname][0]
                lptr = struct.unpack_from("<Q", me_buf, coff + cd_layout["layers"][0])[0]
                tlay = struct.unpack_from("<i", me_buf, coff + cd_layout["totlayer"][0])[0]
                if not lptr or tlay == 0: continue
                lb = bf.ptr_map[lptr]
                for li in range(tlay):
                    loff = li * 120
                    lname = bytes(lb["payload"][loff+cdl_layout["name"][0]:loff+cdl_layout["name"][0]+68]).split(b"\x00")[0].decode("utf-8", "replace")
                    dptr = struct.unpack_from("<Q", lb["payload"], loff + cdl_layout["data"][0])[0]
                    if dptr not in bf.ptr_map: continue
                    db = bf.ptr_map[dptr]
                    if cname == "vdata" and lname == "position":
                        pos = np.frombuffer(db["payload"], dtype=np.float32, count=totvert*3).reshape(totvert, 3).copy()
                    elif cname == "pdata" and lname == "material_index":
                        mat_idx = np.frombuffer(db["payload"], dtype=np.int32, count=totpoly).copy()
                    elif cname == "ldata" and lname == ".corner_vert":
                        corner_verts = np.frombuffer(db["payload"], dtype=np.int32, count=totloop).copy()
                    elif cname == "ldata" and lname == "UVMap":
                        uv_map = np.frombuffer(db["payload"], dtype=np.float32, count=totloop*2).reshape(totloop, 2).copy()

            pos_gltf = np.column_stack([pos[:, 0], pos[:, 2], -pos[:, 1]]).astype(np.float32)

            # Compute smooth vertex normals for cylindrical running surfaces (wheels outer tread, piston barrel, collars)
            is_wheel = "Wheel" in me_id
            is_cyl_mech = me_id in ("MERam_Shaft_Piston_Mesh.003", "MEArcane_Stator_Collar_Mesh.003", "MEWrist_Resonator_Ring_Mesh.003")
            v_smooth_norm = np.zeros_like(pos_gltf)
            if is_wheel or is_cyl_mech:
                for pi in range(totpoly):
                    s, e = int(poly_offsets[pi]), int(poly_offsets[pi+1])
                    if e - s < 3: continue
                    vs = corner_verts[s:e]
                    fn = np.cross(pos_gltf[vs[1]] - pos_gltf[vs[0]], pos_gltf[vs[2]] - pos_gltf[vs[0]])
                    for v in vs: v_smooth_norm[v] += fn
                nl = np.linalg.norm(v_smooth_norm, axis=1, keepdims=True)
                v_smooth_norm = np.where(nl > 1e-9, v_smooth_norm / nl, 0.0)

            prims_by_mat = {}
            for pi in range(totpoly):
                s, e = int(poly_offsets[pi]), int(poly_offsets[pi+1])
                if e - s < 3: continue
                mi = int(mat_idx[pi]) if int(mat_idx[pi]) < len(mat_names) else 0
                g_mat_idx = mat_id_to_idx.get(mat_names[mi], 0)
                if g_mat_idx not in prims_by_mat:
                    prims_by_mat[g_mat_idx] = ({}, [], [], [], [])
                v_map, p_list, n_list, uv_list, idx_list = prims_by_mat[g_mat_idx]

                c_verts = corner_verts[s:e]
                c_uvs = uv_map[s:e] if uv_map is not None else np.zeros((e-s, 2), dtype=np.float32)
                v0, v1, v2 = pos_gltf[c_verts[0]], pos_gltf[c_verts[1]], pos_gltf[c_verts[2]]
                fn = np.cross(v1 - v0, v2 - v0)
                fl = float(np.linalg.norm(fn))
                if fl < 1e-10: continue
                fn /= fl

                corner_out_idxs = []
                for k in range(e - s):
                    vi = int(c_verts[k])
                    uv_k = c_uvs[k]
                    u_f, v_f = float(uv_k[0]), float(1.0 - uv_k[1])
                    use_vn = fn
                    if is_wheel:
                        r_yz = math.hypot(pos_gltf[vi, 1], pos_gltf[vi, 2])
                        if r_yz > 0.145 * S_SUBSTANTIAL and abs(fn[0]) < 0.55:
                            use_vn = 0.65 * v_smooth_norm[vi] + 0.35 * fn
                            use_vn /= max(float(np.linalg.norm(use_vn)), 1e-9)
                    elif is_cyl_mech:
                        r_xy = math.hypot(pos_gltf[vi, 0], pos_gltf[vi, 1])
                        if r_xy > 0.135 * S_SUBSTANTIAL and abs(fn[2]) < 0.55:
                            use_vn = 0.60 * v_smooth_norm[vi] + 0.40 * fn
                            use_vn /= max(float(np.linalg.norm(use_vn)), 1e-9)

                    n_key = (round(float(use_vn[0]), 3), round(float(use_vn[1]), 3), round(float(use_vn[2]), 3))
                    key = (vi, n_key, round(u_f, 4), round(v_f, 4))
                    out_i = v_map.get(key)
                    if out_i is None:
                        out_i = len(p_list)
                        v_map[key] = out_i
                        p_list.append(pos_gltf[vi])
                        n_list.append(use_vn)
                        uv_list.append([u_f, v_f])
                    corner_out_idxs.append(out_i)

                for k in range(1, (e - s) - 1):
                    idx_list.extend([corner_out_idxs[0], corner_out_idxs[k], corner_out_idxs[k + 1]])

            primitives = []
            for g_mat_idx, (_, p_list, n_list, uv_list, idx_list) in sorted(prims_by_mat.items()):
                if not idx_list: continue
                p_arr = np.array(p_list, dtype=np.float32)
                n_arr = np.array(n_list, dtype=np.float32)
                uv_arr = np.array(uv_list, dtype=np.float32)
                use_u16 = len(p_arr) < 65535
                idx_arr = np.array(idx_list, dtype=np.uint16 if use_u16 else np.uint32)

                bv_p = add_bv(p_arr.tobytes(), 34962)
                bv_n = add_bv(n_arr.tobytes(), 34962)
                bv_u = add_bv(uv_arr.tobytes(), 34962)
                bv_i = add_bv(idx_arr.tobytes(), 34963)

                acc_p = add_acc(bv_p, 5126, len(p_arr), "VEC3", p_arr.min(axis=0), p_arr.max(axis=0))
                acc_n = add_acc(bv_n, 5126, len(n_arr), "VEC3")
                acc_u = add_acc(bv_u, 5126, len(uv_arr), "VEC2")
                acc_i = add_acc(bv_i, 5123 if use_u16 else 5125, len(idx_arr), "SCALAR", [int(idx_arr.min())], [int(idx_arr.max())])

                primitives.append({
                    "attributes": {"POSITION": acc_p, "NORMAL": acc_n, "TEXCOORD_0": acc_u},
                    "indices": acc_i,
                    "material": g_mat_idx,
                    "mode": 4,
                })

            me_idx = len(gltf_meshes)
            me_id_to_idx[me_id] = me_idx
            gltf_meshes.append({"name": clean_prefix(me_id, "ME"), "primitives": primitives})

    # Build 20 core nodes + 13 operator/camera/dismount locator nodes
    ob_info = {}
    for b in bf.blocks:
        if b["code"] == "OB":
            ob_id = bf.get_id_name(b)
            loc = struct.unpack_from("<3f", b["payload"], ob_layout["loc"][0])
            parent_ptr = struct.unpack_from("<Q", b["payload"], ob_layout["parent"][0])[0]
            data_ptr = struct.unpack_from("<Q", b["payload"], ob_layout["data"][0])[0]
            pname = ptr_to_name.get(parent_ptr, None)
            dname = ptr_to_name.get(data_ptr, None)
            loc_gltf = [round(float(loc[0]), 6), round(float(loc[2]), 6), round(float(-loc[1]), 6)]
            if ob_id == "OBRam_Assembly.003":
                loc_gltf = [0.0, round(0.365 * S_SUBSTANTIAL, 6), round(0.520 * S_SUBSTANTIAL, 6)]
            elif ob_id == "OBRetraction_Chains_Aft.003":
                loc_gltf = [0.0, round(0.385 * S_SUBSTANTIAL, 6), round(-0.455 * S_SUBSTANTIAL, 6)]
            ob_info[ob_id] = {"parent": pname, "data": dname, "translation": loc_gltf, "children": []}

    for ob_id, info in ob_info.items():
        p = info["parent"]
        if p and p in ob_info:
            ob_info[p]["children"].append(ob_id)

    ordered_ob_ids = ["OBBattleRam_Root.003"] + [k for k in sorted(ob_info.keys()) if k != "OBBattleRam_Root.003"]
    ob_id_to_node_idx = {ob_id: i for i, ob_id in enumerate(ordered_ob_ids)}
    slot_name_to_node_idx = {}
    for ob_id, nidx in ob_id_to_node_idx.items():
        slot_name_to_node_idx[ob_id] = nidx
        base_ob = ob_id.split(".")[0]
        slot_name_to_node_idx[base_ob] = nidx
        slot_name_to_node_idx[base_ob + ".001"] = nidx

    gltf_nodes = []
    for ob_id in ordered_ob_ids:
        info = ob_info[ob_id]
        nd = {"name": clean_prefix(ob_id, "OB")}
        if any(abs(v) > 1e-6 for v in info["translation"]):
            nd["translation"] = info["translation"]
        if info["data"] and info["data"] in me_id_to_idx:
            nd["mesh"] = me_id_to_idx[info["data"]]
        if info["children"]:
            nd["children"] = [ob_id_to_node_idx[ch] for ch in sorted(info["children"])]
        gltf_nodes.append(nd)

    carriage_node_idx = ob_id_to_node_idx["OBCarriage_Main.003"]
    if "children" not in gltf_nodes[carriage_node_idx]:
        gltf_nodes[carriage_node_idx]["children"] = []
    for lname, ltr in OPERATOR_LOCATORS_LOCAL:
        l_idx = len(gltf_nodes)
        gltf_nodes.append({"name": lname, "translation": ltr})
        gltf_nodes[carriage_node_idx]["children"].append(l_idx)

    # Extract all 4 Slotted Actions (already retimed in SoFist-crafted-v2_1-uncompressed.blend!)
    ac_layout = bf.get_layout("bAction")
    slot_layout = bf.get_layout("ActionSlot")
    kd_layout = bf.get_layout("ActionStripKeyframeData")
    cb_layout = bf.get_layout("ActionChannelBag")
    fc_layout = bf.get_layout("FCurve")
    bz_layout = bf.get_layout("BezTriple")

    gltf_animations = []
    for b in bf.blocks:
        if b["code"] != "AC": continue
        ac_id = bf.get_id_name(b)
        anim_name = clean_prefix(ac_id, "AC")
        slot_arr_ptr = struct.unpack_from("<Q", b["payload"], ac_layout["slot_array"][0])[0]
        slot_num = struct.unpack_from("<i", b["payload"], ac_layout["slot_array_num"][0])[0]
        slots = {}
        if slot_arr_ptr in bf.ptr_map and slot_num > 0:
            sb = bf.ptr_map[slot_arr_ptr]
            for sp in struct.unpack_from(f"<{slot_num}Q", sb["payload"], 0):
                if sp in bf.ptr_map:
                    slb = bf.ptr_map[sp]
                    sname = bytes(slb["payload"][slot_layout["name"][0]:slot_layout["name"][0]+64]).split(b"\x00")[0].decode()
                    shandle = struct.unpack_from("<i", slb["payload"], slot_layout["handle"][0])[0]
                    slots[shandle] = sname

        kd_arr_ptr = struct.unpack_from("<Q", b["payload"], ac_layout["strip_keyframe_data_array"][0])[0]
        kd_num = struct.unpack_from("<i", b["payload"], ac_layout["strip_keyframe_data_array_num"][0])[0]
        if kd_arr_ptr not in bf.ptr_map or kd_num == 0: continue

        samplers_list, channels_list = [], []
        kdb = bf.ptr_map[kd_arr_ptr]
        for kp in struct.unpack_from(f"<{kd_num}Q", kdb["payload"], 0):
            if kp not in bf.ptr_map: continue
            kb = bf.ptr_map[kp]
            cb_arr_ptr = struct.unpack_from("<Q", kb["payload"], kd_layout["channelbag_array"][0])[0]
            cb_num = struct.unpack_from("<i", kb["payload"], kd_layout["channelbag_array_num"][0])[0]
            if cb_arr_ptr not in bf.ptr_map or cb_num == 0: continue
            cbb = bf.ptr_map[cb_arr_ptr]
            for cbp in struct.unpack_from(f"<{cb_num}Q", cbb["payload"], 0):
                if cbp not in bf.ptr_map: continue
                bag = bf.ptr_map[cbp]
                sh = struct.unpack_from("<i", bag["payload"], cb_layout["slot_handle"][0])[0]
                fnum = struct.unpack_from("<i", bag["payload"], cb_layout["fcurve_array_num"][0])[0]
                farr = struct.unpack_from("<Q", bag["payload"], cb_layout["fcurve_array"][0])[0]
                target_node = slot_name_to_node_idx.get(slots.get(sh, ""))
                if target_node is None or farr not in bf.ptr_map or fnum == 0: continue

                fcurves_by_prop = {}
                fab = bf.ptr_map[farr]
                for fp in struct.unpack_from(f"<{fnum}Q", fab["payload"], 0):
                    if fp not in bf.ptr_map: continue
                    fb = bf.ptr_map[fp]
                    rptr = struct.unpack_from("<Q", fb["payload"], fc_layout["rna_path"][0])[0]
                    rpath = bytes(bf.ptr_map[rptr]["payload"]).split(b"\x00")[0].decode() if rptr in bf.ptr_map else ""
                    aidx = struct.unpack_from("<i", fb["payload"], fc_layout["array_index"][0])[0]
                    totv = struct.unpack_from("<i", fb["payload"], fc_layout["totvert"][0])[0]
                    bptr = struct.unpack_from("<Q", fb["payload"], fc_layout["bezt"][0])[0]
                    pts = {}
                    if bptr in bf.ptr_map and totv > 0:
                        bb = bf.ptr_map[bptr]
                        sz = bb["size"] // totv
                        for k in range(totv):
                            vec = struct.unpack_from("<9f", bb["payload"], k * sz + bz_layout["vec"][0])
                            pts[round(float(vec[3]), 4)] = float(vec[4])
                    fcurves_by_prop.setdefault(rpath, {})[aidx] = pts

                for rpath, idx_map in fcurves_by_prop.items():
                    frames = sorted(set().union(*(d.keys() for d in idx_map.values())))
                    if not frames: continue
                    times_sec = np.array([f / 24.0 for f in frames], dtype=np.float32)
                    bv_t = add_bv(times_sec.tobytes())
                    acc_t = add_acc(bv_t, 5126, len(times_sec), "SCALAR", [float(times_sec.min())], [float(times_sec.max())])

                    if rpath == "location":
                        vals = [[idx_map.get(0, {}).get(f, 0.0), idx_map.get(2, {}).get(f, 0.0), -idx_map.get(1, {}).get(f, 0.0)] for f in frames]
                        v_arr = np.array(vals, dtype=np.float32)
                        bv_v = add_bv(v_arr.tobytes())
                        acc_v = add_acc(bv_v, 5126, len(v_arr), "VEC3", v_arr.min(axis=0), v_arr.max(axis=0))
                        s_idx = len(samplers_list)
                        samplers_list.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
                        channels_list.append({"sampler": s_idx, "target": {"node": target_node, "path": "translation"}})
                    elif rpath == "rotation_quaternion":
                        vals = []
                        for f in frames:
                            wb, xb, yb, zb = idx_map.get(0, {}).get(f, 1.0), idx_map.get(1, {}).get(f, 0.0), idx_map.get(2, {}).get(f, 0.0), idx_map.get(3, {}).get(f, 0.0)
                            q = np.array([xb, zb, -yb, wb], dtype=np.float64)
                            n = np.linalg.norm(q)
                            if n > 1e-9: q /= n
                            vals.append(q)
                        v_arr = np.array(vals, dtype=np.float32)
                        bv_v = add_bv(v_arr.tobytes())
                        acc_v = add_acc(bv_v, 5126, len(v_arr), "VEC4", v_arr.min(axis=0), v_arr.max(axis=0))
                        s_idx = len(samplers_list)
                        samplers_list.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
                        channels_list.append({"sampler": s_idx, "target": {"node": target_node, "path": "rotation"}})
                    elif rpath == "scale":
                        vals = [[idx_map.get(0, {}).get(f, 1.0), idx_map.get(2, {}).get(f, 1.0), idx_map.get(1, {}).get(f, 1.0)] for f in frames]
                        v_arr = np.array(vals, dtype=np.float32)
                        bv_v = add_bv(v_arr.tobytes())
                        acc_v = add_acc(bv_v, 5126, len(v_arr), "VEC3", v_arr.min(axis=0), v_arr.max(axis=0))
                        s_idx = len(samplers_list)
                        samplers_list.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
                        channels_list.append({"sampler": s_idx, "target": {"node": target_node, "path": "scale"}})

        gltf_animations.append({"name": anim_name, "samplers": samplers_list, "channels": channels_list})

    pad_bin = (4 - (len(bin_chunks) % 4)) % 4
    if pad_bin: bin_chunks.extend(b"\x00" * pad_bin)

    gltf_dict = {
        "asset": {"version": "2.0", "generator": "Castleward SO-FIST-ICATION v2.1 Fast-Strike & Rider Exporter"},
        "scene": 0,
        "scenes": [{"name": "Scene", "nodes": [0]}],
        "nodes": gltf_nodes,
        "meshes": gltf_meshes,
        "materials": gltf_materials,
        "textures": textures,
        "images": images,
        "samplers": samplers,
        "animations": gltf_animations,
        "accessors": accessors,
        "bufferViews": buffer_views,
        "buffers": [{"byteLength": len(bin_chunks)}],
    }

    json_bytes = json.dumps(gltf_dict, separators=(",", ":")).encode("utf-8")
    pad_json = (4 - (len(json_bytes) % 4)) % 4
    if pad_json: json_bytes += b" " * pad_json

    total_len = 12 + 8 + len(json_bytes) + 8 + len(bin_chunks)
    glb_out = bytearray()
    glb_out.extend(struct.pack("<4sII", b"glTF", 2, total_len))
    glb_out.extend(struct.pack("<I4s", len(json_bytes), b"JSON"))
    glb_out.extend(json_bytes)
    glb_out.extend(struct.pack("<I4s", len(bin_chunks), b"BIN\x00"))
    glb_out.extend(bin_chunks)

    out_glb_path.write_bytes(glb_out)
    sha = hashlib.sha256(glb_out).hexdigest()
    print(f"[OK] Exported {out_glb_path.name}: {len(glb_out):,} bytes, nodes={len(gltf_nodes)}, meshes={len(gltf_meshes)}, anims={len(gltf_animations)}, sha256={sha}")
    return gltf_dict, sha

if __name__ == "__main__":
    glb_path = OUT_DIR / "so-fist-ication-refined.glb"
    export_v2_1_glb(Path(str(Path(__file__).resolve().parent) + "/SoFist-crafted-v2_1-uncompressed.blend"), glb_path)
    # Also write zip for fast download
    zp = OUT_DIR / "so-fist-ication-refined-glb.zip"
    with zipfile.ZipFile(zp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        zf.write(glb_path, arcname="so-fist-ication.glb")
        zf.write(glb_path, arcname="so-fist-ication-refined.glb")
    print(f"[OK] Packaged {zp.name}: {zp.stat().st_size:,} bytes")
