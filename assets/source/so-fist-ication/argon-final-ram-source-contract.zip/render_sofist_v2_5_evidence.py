#!/usr/bin/env python3
"""
Renders direct GLB-to-GLB Before/After & Structural Verification Sheet for SO-FIST-ICATION v2.5:
  - `SO_FIST_ICATION_v25_Fist_Wheels_And_Undercarriage_Sheet.jpg` (2400x1640, 8 panels)
"""
import sys, os, io, json, math, struct
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont

OUT_DIR = Path("/working_dir/c_63a1f8c151a6582d/artifacts/file_generation/ttl=63d/output")
WORK_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT_DIR))
sys.path.insert(0, str(WORK_DIR))

from render_sofist_v2_4_evidence import (
    get_font,
    load_sofist_glb_direct,
    build_sofist_scene_from_glb,
    render_aa,
)

G_V22, MC_V22 = load_sofist_glb_direct(OUT_DIR / "so-fist-ication-v2_2-salvaged.glb")
G_V24, MC_V24 = load_sofist_glb_direct(OUT_DIR / "so-fist-ication-v24-review.glb")
G_V25, MC_V25 = load_sofist_glb_direct(OUT_DIR / "so-fist-ication-v25-review.glb")

def render_sofist_v25_sheet():
    W, H = 2400, 1640
    sheet = Image.new("RGB", (W, H), (16, 18, 24))
    dr = ImageDraw.Draw(sheet)

    f_title = get_font(25, True)
    f_sub   = get_font(15, False)
    f_lbl   = get_font(16, True)
    f_note  = get_font(13, False)

    dr.rectangle([0, 0, W, 82], fill=(24, 28, 38))
    dr.text((28, 14), "SO-FIST-ICATION v2.5 — SYNTHESIZED CLOSED-FIST GAUNTLET, COHESIVE WHEELS & INTEGRATED UNDERCARRIAGE", fill=(245, 210, 125), font=f_title)
    dr.text((28, 50), "Canonical Export (`so-fist-ication-v25-review.glb`)  |  33 Nodes, 17 Meshes, 31,976 Tris, 5.41 MB  |  Synthesizes v2.2 Closed-Fist Silhouette + v2.4 Crisp Faceted Armor", fill=(195, 205, 220), font=f_sub)

    pw, ph = 570, 660

    # Panel 1: FRONT SILHOUETTE OF THE FIST: v2.2 (AI Soup) vs v2.4 (4 Vertical Slabs) vs v2.5 (Synthesized Closed Fist)
    sc_f22 = build_sofist_scene_from_glb(G_V22, MC_V22, rider_mode=None, only_meshes={"Armored_Fist", "Wrist_Resonator_Ring", "Ram_Shaft_Piston"})
    sc_f24 = build_sofist_scene_from_glb(G_V24, MC_V24, rider_mode=None, only_meshes={"Armored_Fist", "Wrist_Resonator_Ring", "Ram_Shaft_Piston"})
    sc_f25 = build_sofist_scene_from_glb(G_V25, MC_V25, rider_mode=None, only_meshes={"Armored_Fist", "Wrist_Resonator_Ring", "Ram_Shaft_Piston"})

    h_top = (ph - 68) // 2
    im_f22_front = render_aa(sc_f22, (-0.18, 0.38, +1.85), (0.0, 0.35, +0.72), fov_deg=34.0, w=pw//2, h=h_top, bg=(26, 20, 22))
    im_f24_front = render_aa(sc_f24, (-0.18, 0.38, +1.85), (0.0, 0.35, +0.72), fov_deg=34.0, w=pw//2, h=h_top, bg=(26, 22, 18))
    im_f25_front = render_aa(sc_f25, (-0.18, 0.38, +1.85), (0.0, 0.35, +0.72), fov_deg=34.0, w=pw,    h=h_top, bg=(18, 25, 32))
    p1 = Image.new("RGB", (pw, ph), (18, 22, 30))
    p1.paste(im_f22_front, (0, 36))
    p1.paste(im_f24_front, (pw//2, 36))
    p1.paste(im_f25_front, (0, 36 + h_top))
    d1 = ImageDraw.Draw(p1)
    d1.line([(pw//2, 36), (pw//2, 36 + h_top)], fill=(245, 210, 125), width=2)
    d1.line([(0, 36 + h_top), (pw, 36 + h_top)], fill=(245, 210, 125), width=2)
    d1.text((8, 42), "v2.2: Closed silhouette, melted tris", fill=(255, 165, 165), font=get_font(12, True))
    d1.text((pw//2 + 8, 42), "v2.4: Crisp tris, 4 vertical slabs", fill=(245, 195, 130), font=get_font(12, True))
    d1.text((10, 42 + h_top), "v2.5 SYNTHESIS: Arched Knuckle Crown, Curled Fingers & Diagonal Thumb!", fill=(165, 245, 185), font=get_font(12, True))

    # Panel 2: 3/4 FRONT-LEFT & 3/4 LOWER-THUMB CLOSE-UP (v2.4 vs v2.5)
    im_f24_3q = render_aa(sc_f24, (-0.88, 0.62, +1.68), (0.0, 0.35, +0.72), fov_deg=36.0, w=pw//2, h=h_top, bg=(26, 20, 22))
    im_f25_3q = render_aa(sc_f25, (-0.88, 0.62, +1.68), (0.0, 0.35, +0.72), fov_deg=36.0, w=pw//2, h=h_top, bg=(18, 25, 32))
    im_f24_th = render_aa(sc_f24, (-0.92, 0.08, +1.58), (0.0, 0.33, +0.72), fov_deg=36.0, w=pw//2, h=h_top, bg=(26, 20, 22))
    im_f25_th = render_aa(sc_f25, (-0.92, 0.08, +1.58), (0.0, 0.33, +0.72), fov_deg=36.0, w=pw//2, h=h_top, bg=(18, 25, 32))
    p2 = Image.new("RGB", (pw, ph), (18, 22, 30))
    p2.paste(im_f24_3q, (0, 36))
    p2.paste(im_f25_3q, (pw//2, 36))
    p2.paste(im_f24_th, (0, 36 + h_top))
    p2.paste(im_f25_th, (pw//2, 36 + h_top))
    d2 = ImageDraw.Draw(p2)
    d2.line([(pw//2, 36), (pw//2, ph - 32)], fill=(245, 210, 125), width=2)
    d2.line([(0, 36 + h_top), (pw, 36 + h_top)], fill=(245, 210, 125), width=2)
    d2.text((8, 42), "BEFORE (v2.4 Upper 3/4): Boxy", fill=(255, 165, 165), font=get_font(12, True))
    d2.text((pw//2 + 8, 42), "AFTER (v2.5 Upper 3/4): Arched fist", fill=(165, 245, 185), font=get_font(12, True))
    d2.text((8, 42 + h_top), "BEFORE (v2.4 Lower 3/4): Slab fingers", fill=(255, 165, 165), font=get_font(12, True))
    d2.text((pw//2 + 8, 42 + h_top), "AFTER (v2.5 Lower 3/4): Curled & tucked!", fill=(165, 245, 185), font=get_font(12, True))

    # Panel 3: v2.5 FIST SIDE PROFILE & PISTON-TO-SOCKET-TO-WRIST TRANSITION
    im_f24_side = render_aa(sc_f24, (-1.10, 0.365, +0.68), (0.0, 0.365, +0.68), w=pw, h=h_top, ortho_scale=0.38, bg=(26, 20, 22))
    im_f25_side = render_aa(sc_f25, (-1.10, 0.365, +0.68), (0.0, 0.365, +0.68), w=pw, h=h_top, ortho_scale=0.38, bg=(18, 25, 32))
    p3 = Image.new("RGB", (pw, ph), (18, 22, 30))
    p3.paste(im_f24_side, (0, 36))
    p3.paste(im_f25_side, (0, 36 + h_top))
    d3 = ImageDraw.Draw(p3)
    d3.line([(0, 36 + h_top), (pw, 36 + h_top)], fill=(245, 210, 125), width=2)
    d3.text((10, 42), "BEFORE (v2.4 Side Ortho): Abrupt box wrist & vertical front slab", fill=(255, 165, 165), font=get_font(12, True))
    d3.text((10, 42 + h_top), "AFTER (v2.5 Side Ortho): Shear-pin clevis -> Flared cuff -> Curled fist (Z=+0.951m)", fill=(165, 245, 185), font=get_font(12, True))

    # Panel 4: UNDERCARRIAGE & RELOCATED REAR AXLE (Z = -0.820m) + WHEEL COHESION (v2.4 vs v2.5)
    sc_c24_no_flr = build_sofist_scene_from_glb(G_V24, MC_V24, rider_mode=None, include_floor_grid=False)
    sc_c25_no_flr = build_sofist_scene_from_glb(G_V25, MC_V25, rider_mode=None, include_floor_grid=False)
    # Low-angle underneath 3/4 view looking up at Rear Axle Z = -0.820m and underframe keel/hounds
    im_u24 = render_aa(sc_c24_no_flr, (-1.35, -0.38, -1.55), (0.0, 0.20, -0.68), fov_deg=40.0, w=pw//2, h=h_top, bg=(26, 20, 22))
    im_u25 = render_aa(sc_c25_no_flr, (-1.35, -0.38, -1.55), (0.0, 0.20, -0.68), fov_deg=40.0, w=pw//2, h=h_top, bg=(18, 25, 32))
    sc_w24 = build_sofist_scene_from_glb(G_V24, MC_V24, rider_mode=None, only_meshes={"Wheel_FR"})
    sc_w25 = build_sofist_scene_from_glb(G_V25, MC_V25, rider_mode=None, only_meshes={"Wheel_FR"})
    im_w24 = render_aa(sc_w24, (-1.28, 0.24, +0.58), (-0.43, 0.165, +0.325), fov_deg=34.0, w=pw//2, h=h_top, bg=(26, 20, 22))
    im_w25 = render_aa(sc_w25, (-1.28, 0.24, +0.58), (-0.43, 0.165, +0.325), fov_deg=34.0, w=pw//2, h=h_top, bg=(18, 25, 32))
    p4 = Image.new("RGB", (pw, ph), (18, 22, 30))
    p4.paste(im_u24, (0, 36))
    p4.paste(im_u25, (pw//2, 36))
    p4.paste(im_w24, (0, 36 + h_top))
    p4.paste(im_w25, (pw//2, 36 + h_top))
    d4 = ImageDraw.Draw(p4)
    d4.line([(pw//2, 36), (pw//2, ph - 32)], fill=(245, 210, 125), width=2)
    d4.line([(0, 36 + h_top), (pw, 36 + h_top)], fill=(245, 210, 125), width=2)
    d4.text((8, 42), "v2.4 Underneath: Mounting blocks", fill=(255, 165, 165), font=get_font(12, True))
    d4.text((pw//2 + 8, 42), "v2.5 Underneath: Keel & hound-struts!", fill=(165, 245, 185), font=get_font(12, True))
    d4.text((8, 42 + h_top), "v2.4 Wheel: Straight spokes", fill=(245, 195, 130), font=get_font(12, True))
    d4.text((pw//2 + 8, 42 + h_top), "v2.5 Wheel: Tapered spokes & plates!", fill=(165, 245, 185), font=get_font(12, True))

    # Panel 5: Full Side Profile (v2.5 with Integrated Undercarriage & Synthesized Fist)
    sc_v25_full = build_sofist_scene_from_glb(G_V25, MC_V25, rider_mode="brace_drive", include_floor_grid=True, include_axle_markers=True)
    im_s24 = render_aa(build_sofist_scene_from_glb(G_V24, MC_V24, rider_mode="brace_drive", include_floor_grid=True, include_axle_markers=True), (-3.0, 0.44, -0.15), (0.0, 0.42, -0.15), w=pw, h=h_top, ortho_scale=0.66, bg=(26, 20, 22))
    im_s25 = render_aa(sc_v25_full, (-3.0, 0.44, -0.15), (0.0, 0.42, -0.15), w=pw, h=h_top, ortho_scale=0.66, bg=(18, 25, 32))
    p5 = Image.new("RGB", (pw, ph), (18, 22, 30))
    p5.paste(im_s24, (0, 36))
    p5.paste(im_s25, (0, 36 + h_top))
    d5 = ImageDraw.Draw(p5)
    d5.line([(0, 36 + h_top), (pw, 36 + h_top)], fill=(245, 210, 125), width=2)
    d5.text((10, 42), "BEFORE (v2.4 Side Ortho): Slab fist & unbraced under-axle", fill=(255, 165, 165), font=get_font(12, True))
    d5.text((10, 42 + h_top), "AFTER (v2.5 Side Ortho): Synthesized fist, hound-braced Z=-0.82m axle & tapered spokes", fill=(165, 245, 185), font=get_font(12, True))

    # Panel 6: 3/4 Front-Right Hero View at Gameplay Distance (v2.5 with Onboard Rider)
    im_p6 = render_aa(sc_v25_full, (-2.55, 1.25, +1.85), (0.0, 0.36, -0.22), fov_deg=38.0, w=pw, h=ph)
    d6 = ImageDraw.Draw(im_p6)
    d6.text((12, 44), "Unmistakable Closed-Fist Silhouette + Integrated 1.145m Wheelbase", fill=(165, 245, 185), font=f_note)
    d6.text((12, 64), "Imposing from Front, Side & 3/4 Angles at Normal Gameplay Distance", fill=(245, 220, 140), font=f_note)

    # Panel 7: 3/4 Rear Hero & Integrated Rear Axle Subframe (`Z = -0.820m`)
    im_p7 = render_aa(sc_v25_full, (-2.35, 1.18, -2.45), (0.0, 0.36, -0.55), fov_deg=38.0, w=pw, h=ph)
    d7 = ImageDraw.Draw(im_p7)
    d7.text((12, 44), "Integrated Rear Axle Subframe at Z = -0.820m Underneath Rider Deck", fill=(165, 245, 185), font=f_note)
    d7.text((12, 64), "Fore/Aft Diagonal Hound-Struts + Keel Stringers + Clear Boarding Step", fill=(245, 220, 140), font=f_note)

    # Panel 8: Retracted (-0.105m) vs Peak Strike (+0.445m at 0.88s) & +/-32 deg Steering
    sc_ret = build_sofist_scene_from_glb(G_V25, MC_V25, piston_dz=-0.105, rider_mode="brace_drive", steer_deg=+28.0, include_floor_grid=True)
    sc_ext = build_sofist_scene_from_glb(G_V25, MC_V25, piston_dz=+0.445, rider_mode="strike_pull", lever_rad=-0.48, include_floor_grid=True)
    im_p8a = render_aa(sc_ret, (-2.65, 1.20, +2.05), (0.0, 0.36, +0.05), fov_deg=42.0, w=pw//2, h=ph)
    im_p8b = render_aa(sc_ext, (-2.65, 1.20, +2.25), (0.0, 0.36, +0.25), fov_deg=42.0, w=pw//2, h=ph)
    p8 = Image.new("RGB", (pw, ph))
    p8.paste(im_p8a, (0, 0))
    p8.paste(im_p8b, (pw//2, 0))
    d8 = ImageDraw.Draw(p8)
    d8.line([(pw//2, 36), (pw//2, ph - 32)], fill=(245, 210, 125), width=2)
    d8.text((10, 44), "Retracted + Steered (+28°):", fill=(245, 220, 140), font=f_note)
    d8.text((10, 64), "Z_tip = +0.846m (+2.411m World)", fill=(245, 220, 140), font=f_note)
    d8.text((pw//2 + 10, 44), "Extended (0.88s Peak +0.445m):", fill=(165, 245, 185), font=f_note)
    d8.text((pw//2 + 10, 64), "Z_tip = +1.396m (+3.979m World)", fill=(165, 245, 185), font=f_note)

    panels = [
        ("1. FIST FRONT SILHOUETTE: v2.2 vs. v2.4 vs. v2.5",        p1,    "Eliminates v2.4 vertical slabs; restores closed-fist crown & thumb"),
        ("2. FIST 3/4 UPPER & LOWER: v2.4 vs. v2.5",                p2,    "Curled interlocking fingers tucked into palm + diagonal locked thumb"),
        ("3. FIST SIDE & WRIST/SOCKET TRANSITION: v2.4 vs. v2.5",   p3,    "3-stage piston clevis -> flared gauntlet cuff -> palm heel anvil"),
        ("4. UNDERCARRIAGE (Z=-0.82m) & WHEELS: v2.4 vs. v2.5",     p4,    "Triangulated axle hound-struts, keel stringers & tapered oak spokes"),
        ("5. FULL SIDE PROFILE: v2.4 vs. v2.5",                     p5,    "Cohesive wheelbase support + unmistakable closed-fist profile"),
        ("6. 3/4 FRONT HERO VIEW (v2.5 AT GAMEPLAY DISTANCE)",      im_p6, "Imposing closed-fist battering ram with crisp low-poly planes"),
        ("7. 3/4 REAR HERO & INTEGRATED REAR AXLE (Z = -0.820 m)",  im_p7, "Rear axle structurally framed into lower sills & keel stringers"),
        ("8. STEERING & PEAK STRIKE EXTENSION (Z = +1.396 m)",      p8,    "Preserves exact strike envelope, 0.68s release & 0.88s peak impact"),
    ]
    for i, (lbl, pim, note) in enumerate(panels):
        col = i % 4
        row = i // 4
        x0 = 24 + col * (pw + 24)
        y0 = 98 + row * (ph + 24)
        sheet.paste(pim, (x0, y0))
        dr.rectangle([x0, y0, x0 + pw, y0 + 36], fill=(18, 22, 30))
        dr.text((x0 + 12, y0 + 8), lbl, fill=(245, 215, 130), font=f_lbl)
        dr.rectangle([x0, y0 + ph - 32, x0 + pw, y0 + ph], fill=(18, 22, 30))
        dr.text((x0 + 12, y0 + ph - 24), note, fill=(185, 220, 245), font=f_note)
        dr.rectangle([x0, y0, x0 + pw, y0 + ph], outline=(75, 85, 105), width=2)

    dr.rectangle([0, H - 170, W, H], fill=(22, 26, 34))
    dr.text((28, H - 154), "SO-FIST-ICATION v2.5 SUBSTANTIVE DESIGN IMPROVEMENT SUMMARY (`SO_FIST_SCALE = 2.85`):", fill=(245, 210, 125), font=f_lbl)
    dr.text((28, H - 124), "  • Synthesized Closed-Fist Gauntlet (`Armored_Fist_Mesh`): Combines v2.2's arched metacarpal crown, inward-curling fingers & diagonal thumb with v2.4's 18° crisp facets.", fill=(165, 245, 185), font=f_sub)
    dr.text((28, H - 94),  "  • 3-Stage Wrist/Socket Transition & Impact Envelope     : Shear-pin piston clevis -> flared gauntlet cuff -> palm heel anvil; exact `Z_tip = +0.9510 m` rest / `+1.3960 m` peak preserved.", fill=(210, 225, 245), font=f_sub)
    dr.text((28, H - 64),  "  • Integrated Rear Undercarriage (`Z = -0.820 m` Local)  : Full-length twin keel stringers + fore/aft diagonal axle hound-struts + U-bolt saddle bolsters (`1.145 m` local / `3.2633 m` world wheelbase).", fill=(210, 225, 245), font=f_sub)
    dr.text((28, H - 34),  "  • Cohesive Siege Wheels & Preserved Rig Contract        : Tapered octagonal oak spokes, scarf-joint plates, wrap-around strakes & inboard axle sleeve; all 33 nodes & 4 clips preserved.", fill=(245, 210, 125), font=f_sub)

    out_p = OUT_DIR / "SO_FIST_ICATION_v25_Fist_Wheels_And_Undercarriage_Sheet.jpg"
    sheet.save(out_p, quality=94)
    print(f"[OK] Saved {out_p.name}")

if __name__ == "__main__":
    render_sofist_v25_sheet()
