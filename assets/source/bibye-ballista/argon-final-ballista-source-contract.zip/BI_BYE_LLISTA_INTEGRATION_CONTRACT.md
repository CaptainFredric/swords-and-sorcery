# Bi-Bye-llista v4.3 — Binary-Derived Integration & Visual Hierarchy Contract

## 1. Authoritative Binary & Source Checksums (`v4.3` vs `v4.2` Rollback Baseline)

| Artifact Role | File Name | Byte Size | Nodes | Meshes | Welded Verts | Triangles | Clips | SHA-256 Checksum |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| **v4.3 Runtime Candidate GLB** | `bi-bye-llista-v4_3-review.glb` | `4,041,644 B` | `65` | `46` | `52,752` | `41,024` | `21` | `d696b66892a96c0a23a66601a1daac8bbd137e5051f620a7df581c473ba0c44a` |
| **v4.3 Editable Blender Source** | `Bi_Bye_llista_v4_3_Review.blend` | `5,915,887 B` | `65` OB | `46` ME | `52,752` | `41,024` | `21` AC | `9040d69306ae957622a165794f998499afa7c633d7d808b3d2d90e1a676b62b6` |
| **v4.2 Rollback GLB (Preserved)** | `bi-bye-llista-v4_2-review.glb` | `4,313,688 B` | `65` | `46` | `59,870` | `44,720` | `21` | `14fe4c4ce12b8ce001060d4db10a4ad1fcb9123a13f8aa3a7542e7d8778d1149` |


### Reproducibility Note (`GLB` vs Editable `.blend` Source)
- **100% Clean-Room Reproducible GLB**: Extracting `Package_C_Bi_Bye_llista_v43_Scripts_And_Contract.zip` into an empty directory and running `python3 build_bibyellista_v4_3.py` rebuilds the exact canonical `bi-bye-llista-v4_3-review.glb` (`4,041,644 B`, SHA-256 `d696b66892a96c0a23a66601a1daac8bbd137e5051f620a7df581c473ba0c44a`) using the bundled `bibye_base_basic_pbr.glb` and Python geometry builders.
- **Separately Delivered Editable Blender Source (`Bi_Bye_llista_v4_3_Review.blend`)**: Delivered as a standalone `5,915,887 B` file on Google Drive (`SHA-256: 9040d69306ae957622a165794f998499afa7c633d7d808b3d2d90e1a676b62b6`). If `Spellblade-production-third-person.blend` is also placed in the build directory, `build_bibyellista_v4_3.py` automatically regenerates `Bi_Bye_llista_v4_3_Review.blend` as well.

## 2. Four-Tier Visual Hierarchy & Two-Launcher Mechanical Clearance Summary (`v4.3`)

1. **Zero Gameplay or Rig Breaking Changes**: `bi-bye-llista-v4_3-review.glb` preserves the exact 65-node hierarchy (`[00] BiBye_Root` .. `[64] mounted_camera_upper_360`), all 19 locators (`main_bolt_muzzle` `[30]`, `aim_direction` `[31]`, `small_bolt_muzzle` `[34]`, `operator_station` `[35]`, `operator_seat_pivot` `[56]`, etc.), and all 21 animation clips (`01_BiBye_LoadedIdle` .. `21_BiBye_Delayed_Shot2_Release_And_Recoil`).
2. **Tier 1 (Grounded Dark-Oak & Blackened-Iron Wagon Base — `Nodes 01..11, 39..48`)**: Removed competing bright gold trim from wheel cleats, inner rim bands, spoke ferrules, stabilizer spades, and lower carriage crossbeams so the lower wagon anchors the silhouette in deep Quarter-Sawn Dark Oak and Blackened Charcoal Iron.
3. **Tier 2 (Primary Heavy Siege Launcher II — `Nodes 13..19`, Muzzle `[30] main_bolt_muzzle` at World `[0.000, +1.835, +1.520] m`)**: `5.10 m` span Honed Silver-Steel Greatsword prods (`Main_Limb_L/R`) with `0.62 m` swept golden crossguard quillons, blackened cast-iron torsion cages, cantilevered 4-roller forward bolt trough, and `3.75 m` barbed steel siege spear-bolt (`Main_Siege_Bolt`).
4. **Open Center Daylight Sight Window (`Y_world = 1.88..2.58 m` on `[12] Traverse_Mount`)**: Removed the diagonal brass clutter bars between `Elevation_Cradle` (`Y = 1.62 m`) and `Upper_Turret_Mount` (`Y = 2.78 m`), opening a `0.70 m` vertical daylight window with zero mechanical interference across `±30°` yaw / `-12°..+22°` pitch sweeps.
5. **Tier 3 & Tier 4 (Upper Conditioning Arbalest I — `Nodes 23..29`, Muzzle `[34] small_bolt_muzzle` at World `[0.000, +2.945, +0.920] m`, & Coupled Release Linkage `Nodes 52..55`)**: Forward-swept dihedral recurve limbs (`Upper_Limb_L/R`, `2.36 m` span) in Royal Crimson and Arcane Cyan with open front Focusing Fork, `1.65 m` Conditioning Bolt (`Upper_Conditioning_Bolt`), and external crimson-and-brass coupled `I -> II` mechanical interlink (`Coupling_Clutch_Collar` `[52]`, `Coupling_Transfer_Linkage` `[53]`, `Delay_Escapement_Gear` `[54]`, `Heavy_Sear_Trip_Bar` `[55]`).

## 3. Complete Binary-Derived 65-Node Hierarchy & Mesh Table (`bi-bye-llista-v4_3-review.glb`)

| Node | Exact Binary Node Name | Parent | Local Translation `[X, Y, Z]` (m) | World Rest `[X, Y, Z]` (m) | Mesh Name | Welded Verts | Tris | Local Bounds Min -> Max (m) |
| :---: | :--- | :--- | :---: | :---: | :--- | :---: | :---: | :--- |
| `00` | `BiBye_Root` | `ROOT` | `[0.0, 0.0, 0.0]` | `[0.0, 0.0, 0.0]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `01` | `Carriage_Chassis` | `[00] BiBye_Root` | `[0.0, 0.0, 0.0]` | `[0.0, 0.0, 0.0]` | `Carriage_Chassis_Mesh` | `4,256` | `2,968` | `[-1.1869, 0.24, -2.385] -> [1.1869, 1.66, 1.4854]` |
| `02` | `Wheel_FL` | `[01] Carriage_Chassis` | `[-1.075, 0.55, 1.2]` | `[-1.075, 0.55, 1.2]` | `Wheel_FL_Mesh` | `2,594` | `1,888` | `[-0.192, -0.556, -0.556] -> [0.155, 0.556, 0.556]` |
| `03` | `Wheel_FR` | `[01] Carriage_Chassis` | `[1.075, 0.55, 1.2]` | `[1.075, 0.55, 1.2]` | `Wheel_FR_Mesh` | `2,594` | `1,888` | `[-0.155, -0.556, -0.556] -> [0.192, 0.556, 0.556]` |
| `04` | `Wheel_ML` | `[01] Carriage_Chassis` | `[-1.075, 0.55, -0.34]` | `[-1.075, 0.55, -0.34]` | `Wheel_ML_Mesh` | `2,594` | `1,888` | `[-0.192, -0.556, -0.556] -> [0.155, 0.556, 0.556]` |
| `05` | `Wheel_MR` | `[01] Carriage_Chassis` | `[1.075, 0.55, -0.34]` | `[1.075, 0.55, -0.34]` | `Wheel_MR_Mesh` | `2,594` | `1,888` | `[-0.155, -0.556, -0.556] -> [0.192, 0.556, 0.556]` |
| `06` | `Wheel_RL` | `[01] Carriage_Chassis` | `[-1.075, 0.55, -1.715]` | `[-1.075, 0.55, -1.715]` | `Wheel_RL_Mesh` | `2,594` | `1,888` | `[-0.192, -0.556, -0.556] -> [0.155, 0.556, 0.556]` |
| `07` | `Wheel_RR` | `[01] Carriage_Chassis` | `[1.075, 0.55, -1.715]` | `[1.075, 0.55, -1.715]` | `Wheel_RR_Mesh` | `2,594` | `1,888` | `[-0.155, -0.556, -0.556] -> [0.192, 0.556, 0.556]` |
| `08` | `Stabilizer_FL` | `[01] Carriage_Chassis` | `[-1.18, 0.82, 1.05]` | `[-1.18, 0.82, 1.05]` | `Stabilizer_FL_Mesh` | `510` | `452` | `[-0.935, -0.82, -0.2216] -> [0.088, 0.088, 0.2216]` |
| `09` | `Stabilizer_FR` | `[01] Carriage_Chassis` | `[1.18, 0.82, 1.05]` | `[1.18, 0.82, 1.05]` | `Stabilizer_FR_Mesh` | `510` | `452` | `[-0.088, -0.82, -0.2216] -> [0.935, 0.088, 0.2216]` |
| `10` | `Stabilizer_RL` | `[01] Carriage_Chassis` | `[-1.18, 0.82, -1.42]` | `[-1.18, 0.82, -1.42]` | `Stabilizer_RL_Mesh` | `510` | `452` | `[-0.935, -0.82, -0.2216] -> [0.088, 0.088, 0.2216]` |
| `11` | `Stabilizer_RR` | `[01] Carriage_Chassis` | `[1.18, 0.82, -1.42]` | `[1.18, 0.82, -1.42]` | `Stabilizer_RR_Mesh` | `510` | `452` | `[-0.088, -0.82, -0.2216] -> [0.935, 0.088, 0.2216]` |
| `12` | `Traverse_Mount` | `[01] Carriage_Chassis` | `[0.0, 1.24, 0.0]` | `[0.0, 1.24, 0.0]` | `Traverse_Mount_Mesh` | `3,178` | `2,072` | `[-0.884, -0.0194, -0.9889] -> [0.884, 1.395, 0.884]` |
| `13` | `Elevation_Cradle` | `[12] Traverse_Mount` | `[0.0, 0.38, -0.12]` | `[0.0, 1.62, -0.12]` | `Elevation_Cradle_Mesh` | `2,396` | `1,712` | `[-1.14, -0.345, -0.9207] -> [1.14, 0.51, 1.78]` |
| `14` | `Main_Limb_L` | `[13] Elevation_Cradle` | `[-0.88, 0.18, 1.04]` | `[-0.88, 1.8, 0.92]` | `Main_Limb_L_Mesh` | `895` | `748` | `[-1.8308, -0.23, -0.321] -> [0.162, 0.23, 0.3137]` |
| `15` | `Main_Limb_R` | `[13] Elevation_Cradle` | `[0.88, 0.18, 1.04]` | `[0.88, 1.8, 0.92]` | `Main_Limb_R_Mesh` | `895` | `748` | `[-0.162, -0.23, -0.321] -> [1.8308, 0.23, 0.3137]` |
| `16` | `Main_String_L` | `[13] Elevation_Cradle` | `[0.0, 0.18, -0.7459]` | `[0.0, 1.8, -0.8659]` | `Main_String_L_Mesh` | `218` | `152` | `[-2.443, -0.048, -0.0614] -> [0.0, 0.048, 0.0614]` |
| `17` | `Main_String_R` | `[13] Elevation_Cradle` | `[0.0, 0.18, -0.7459]` | `[0.0, 1.8, -0.8659]` | `Main_String_R_Mesh` | `218` | `152` | `[0.0, -0.048, -0.0614] -> [2.443, 0.048, 0.0614]` |
| `18` | `Main_Draw_Catch` | `[13] Elevation_Cradle` | `[0.0, 0.145, -0.7459]` | `[0.0, 1.765, -0.8659]` | `Main_Draw_Catch_Mesh` | `224` | `112` | `[-0.184, -0.069, -0.253] -> [0.184, 0.184, 0.138]` |
| `19` | `Main_Siege_Bolt` | `[13] Elevation_Cradle` | `[0.0, 0.215, -0.7459]` | `[0.0, 1.835, -0.8659]` | `Main_Siege_Bolt_Mesh` | `982` | `800` | `[-0.1527, -0.1527, 0.0] -> [0.1527, 0.1527, 3.75]` |
| `20` | `Winch_Drum_And_Cranks` | `[12] Traverse_Mount` | `[0.0, 0.2, -0.92]` | `[0.0, 1.44, -0.92]` | `Winch_Drum_And_Cranks_Mesh` | `1,020` | `1,072` | `[-0.805, -0.305, -0.22] -> [0.805, 0.305, 0.22]` |
| `21` | `Winch_Ratchet_Gear` | `[12] Traverse_Mount` | `[0.42, 0.2, -0.92]` | `[0.42, 1.44, -0.92]` | `Winch_Ratchet_Gear_Mesh` | `1,186` | `600` | `[-0.0832, -0.25, -0.25] -> [0.0833, 0.25, 0.25]` |
| `22` | `Winch_Pawl_And_Lever` | `[12] Traverse_Mount` | `[-0.42, 0.32, -0.92]` | `[-0.42, 1.56, -0.92]` | `Winch_Pawl_And_Lever_Mesh` | `142` | `84` | `[-0.055, -0.04, -0.0448] -> [0.055, 0.466, 0.0448]` |
| `23` | `Upper_Turret_Mount` | `[12] Traverse_Mount` | `[0.0, 1.54, 0.08]` | `[0.0, 2.78, 0.08]` | `Upper_Turret_Mount_Mesh` | `1,242` | `876` | `[-0.412, -0.1788, -0.7607] -> [0.412, 0.27, 0.8951]` |
| `24` | `Upper_Limb_L` | `[23] Upper_Turret_Mount` | `[-0.3, 0.14, 0.26]` | `[-0.3, 2.92, 0.34]` | `Upper_Limb_L_Mesh` | `596` | `476` | `[-0.9555, -0.115, -0.1755] -> [0.086, 0.115, 0.1138]` |
| `25` | `Upper_Limb_R` | `[23] Upper_Turret_Mount` | `[0.3, 0.14, 0.26]` | `[0.3, 2.92, 0.34]` | `Upper_Limb_R_Mesh` | `596` | `476` | `[-0.086, -0.115, -0.1755] -> [0.9555, 0.115, 0.1138]` |
| `26` | `Upper_String_L` | `[23] Upper_Turret_Mount` | `[0.0, 0.14, -0.702]` | `[0.0, 2.92, -0.622]` | `Upper_String_L_Mesh` | `218` | `152` | `[-1.1286, -0.0256, -0.0328] -> [0.0, 0.0256, 0.0328]` |
| `27` | `Upper_String_R` | `[23] Upper_Turret_Mount` | `[0.0, 0.14, -0.702]` | `[0.0, 2.92, -0.622]` | `Upper_String_R_Mesh` | `218` | `152` | `[0.0, -0.0256, -0.0328] -> [1.1286, 0.0256, 0.0328]` |
| `28` | `Upper_Catch_And_Trigger` | `[23] Upper_Turret_Mount` | `[0.0, 0.112, -0.702]` | `[0.0, 2.892, -0.622]` | `Upper_Catch_And_Trigger_Mesh` | `224` | `112` | `[-0.0992, -0.0372, -0.1364] -> [0.0992, 0.0992, 0.0744]` |
| `29` | `Upper_Conditioning_Bolt` | `[23] Upper_Turret_Mount` | `[0.0, 0.165, -0.702]` | `[0.0, 2.945, -0.622]` | `Upper_Conditioning_Bolt_Mesh` | `1,170` | `800` | `[-0.0788, -0.0788, 0.0] -> [0.0788, 0.0788, 1.65]` |
| `30` | `main_bolt_muzzle` | `[13] Elevation_Cradle` | `[0.0, 0.215, 1.64]` | `[0.0, 1.835, 1.52]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `31` | `aim_direction` | `[13] Elevation_Cradle` | `[0.0, 0.56, 3.72]` | `[0.0, 2.18, 3.6]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `32` | `winch_crank_L` | `[12] Traverse_Mount` | `[-0.68, 0.2, -0.92]` | `[-0.68, 1.44, -0.92]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `33` | `winch_crank_R` | `[12] Traverse_Mount` | `[0.68, 0.2, -0.92]` | `[0.68, 1.44, -0.92]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `34` | `small_bolt_muzzle` | `[23] Upper_Turret_Mount` | `[0.0, 0.165, 0.84]` | `[0.0, 2.945, 0.92]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `35` | `operator_station` | `[00] BiBye_Root` | `[0.0, 0.0, -2.55]` | `[0.0, 0.0, -2.55]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `36` | `transport_push_station` | `[00] BiBye_Root` | `[0.0, 0.0, -2.45]` | `[0.0, 0.0, -2.45]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `37` | `mounted_camera_tpv` | `[12] Traverse_Mount` | `[0.0, 2.61, -4.8]` | `[0.0, 3.85, -4.8]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `38` | `mounted_camera_sight` | `[13] Elevation_Cradle` | `[0.0, 0.56, -1.33]` | `[0.0, 2.18, -1.45]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `39` | `Wheel_FL_Damaged` | `[01] Carriage_Chassis` | `[-1.075, 0.55, 1.2]` | `[-1.075, 0.55, 1.2]` | `Wheel_FL_Damaged_Mesh` | `1,670` | `1,664` | `[-0.196, -0.5544, -0.5519] -> [0.1768, 0.5533, 0.5128]` |
| `40` | `Wheel_FR_Damaged` | `[01] Carriage_Chassis` | `[1.075, 0.55, 1.2]` | `[1.075, 0.55, 1.2]` | `Wheel_FR_Damaged_Mesh` | `1,670` | `1,664` | `[-0.1768, -0.5544, -0.5519] -> [0.196, 0.5533, 0.5128]` |
| `41` | `Wheel_ML_Damaged` | `[01] Carriage_Chassis` | `[-1.075, 0.55, -0.34]` | `[-1.075, 0.55, -0.34]` | `Wheel_ML_Damaged_Mesh` | `1,670` | `1,664` | `[-0.196, -0.5544, -0.5519] -> [0.1768, 0.5533, 0.5128]` |
| `42` | `Wheel_MR_Damaged` | `[01] Carriage_Chassis` | `[1.075, 0.55, -0.34]` | `[1.075, 0.55, -0.34]` | `Wheel_MR_Damaged_Mesh` | `1,670` | `1,664` | `[-0.1768, -0.5544, -0.5519] -> [0.196, 0.5533, 0.5128]` |
| `43` | `Wheel_RL_Damaged` | `[01] Carriage_Chassis` | `[-1.075, 0.55, -1.715]` | `[-1.075, 0.55, -1.715]` | `Wheel_RL_Damaged_Mesh` | `1,670` | `1,664` | `[-0.196, -0.5544, -0.5519] -> [0.1768, 0.5533, 0.5128]` |
| `44` | `Wheel_RR_Damaged` | `[01] Carriage_Chassis` | `[1.075, 0.55, -1.715]` | `[1.075, 0.55, -1.715]` | `Wheel_RR_Damaged_Mesh` | `1,670` | `1,664` | `[-0.1768, -0.5544, -0.5519] -> [0.196, 0.5533, 0.5128]` |
| `45` | `Stabilizer_FL_Damaged` | `[01] Carriage_Chassis` | `[-1.18, 0.82, 1.05]` | `[-1.18, 0.82, 1.05]` | `Stabilizer_FL_Damaged_Mesh` | `532` | `412` | `[-0.83, -0.6224, -0.14] -> [0.088, 0.0867, 0.32]` |
| `46` | `Stabilizer_FR_Damaged` | `[01] Carriage_Chassis` | `[1.18, 0.82, 1.05]` | `[1.18, 0.82, 1.05]` | `Stabilizer_FR_Damaged_Mesh` | `532` | `412` | `[-0.088, -0.6224, -0.14] -> [0.83, 0.0867, 0.32]` |
| `47` | `Stabilizer_RL_Damaged` | `[01] Carriage_Chassis` | `[-1.18, 0.82, -1.42]` | `[-1.18, 0.82, -1.42]` | `Stabilizer_RL_Damaged_Mesh` | `532` | `412` | `[-0.83, -0.6224, -0.14] -> [0.088, 0.0867, 0.32]` |
| `48` | `Stabilizer_RR_Damaged` | `[01] Carriage_Chassis` | `[1.18, 0.82, -1.42]` | `[1.18, 0.82, -1.42]` | `Stabilizer_RR_Damaged_Mesh` | `532` | `412` | `[-0.088, -0.6224, -0.14] -> [0.83, 0.0867, 0.32]` |
| `49` | `Operator_Steering_Tiller` | `[01] Carriage_Chassis` | `[0.28, 1.02, -1.46]` | `[0.28, 1.02, -1.46]` | `Operator_Steering_Tiller_Mesh` | `182` | `160` | `[-0.075, -0.052, -0.0712] -> [0.075, 0.272, 0.0507]` |
| `50` | `Operator_Traverse_Wheel` | `[01] Carriage_Chassis` | `[-0.28, 1.18, -1.44]` | `[-0.28, 1.18, -1.44]` | `Operator_Traverse_Wheel_Mesh` | `560` | `448` | `[-0.15, -0.15, -0.09] -> [0.15, 0.161, 0.035]` |
| `51` | `Operator_Fire_And_Couple_Lever` | `[01] Carriage_Chassis` | `[-0.16, 1.04, -1.42]` | `[-0.16, 1.04, -1.42]` | `Operator_Fire_And_Couple_Lever_Mesh` | `182` | `160` | `[-0.06, -0.048, -0.0468] -> [0.06, 0.279, 0.0581]` |
| `52` | `Coupling_Clutch_Collar` | `[12] Traverse_Mount` | `[0.0, 1.365, -0.18]` | `[0.0, 2.605, -0.18]` | `Coupling_Clutch_Collar_Mesh` | `400` | `268` | `[-0.095, -0.0652, -0.0936] -> [0.3475, 0.088, 0.0936]` |
| `53` | `Coupling_Transfer_Linkage` | `[13] Elevation_Cradle` | `[0.36, 0.56, -0.04]` | `[0.36, 2.18, -0.16]` | `Coupling_Transfer_Linkage_Mesh` | `254` | `188` | `[-0.0476, -0.3385, -0.3607] -> [0.045, 0.3441, 0.145]` |
| `54` | `Delay_Escapement_Gear` | `[13] Elevation_Cradle` | `[0.34, 0.22, -0.4]` | `[0.34, 1.84, -0.52]` | `Delay_Escapement_Gear_Mesh` | `1,370` | `664` | `[-0.074, -0.168, -0.2018] -> [0.0812, 0.215, 0.168]` |
| `55` | `Heavy_Sear_Trip_Bar` | `[13] Elevation_Cradle` | `[0.18, 0.145, -0.66]` | `[0.18, 1.765, -0.78]` | `Heavy_Sear_Trip_Bar_Mesh` | `178` | `104` | `[-0.205, -0.035, -0.095] -> [0.185, 0.085, 0.155]` |
| `56` | `operator_seat_pivot` | `[01] Carriage_Chassis` | `[0.0, 0.96, -1.86]` | `[0.0, 0.96, -1.86]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `57` | `seat_pelvis_anchor` | `[01] Carriage_Chassis` | `[0.0, 0.98, -1.86]` | `[0.0, 0.98, -1.86]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `58` | `seat_backrest_support` | `[01] Carriage_Chassis` | `[0.0, 1.32, -2.04]` | `[0.0, 1.32, -2.04]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `59` | `operator_footrest_L` | `[01] Carriage_Chassis` | `[0.21, 0.52, -1.36]` | `[0.21, 0.52, -1.36]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `60` | `operator_footrest_R` | `[01] Carriage_Chassis` | `[-0.21, 0.52, -1.36]` | `[-0.21, 0.52, -1.36]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `61` | `hand_L_steering_grip` | `[49] Operator_Steering_Tiller` | `[0.0, 0.24, 0.0]` | `[0.28, 1.26, -1.46]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `62` | `hand_R_traverse_grip` | `[50] Operator_Traverse_Wheel` | `[0.0, 0.08, 0.0]` | `[-0.28, 1.26, -1.44]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `63` | `hand_R_fire_lever_grip` | `[51] Operator_Fire_And_Couple_Lever` | `[0.0, 0.24, 0.0]` | `[-0.16, 1.28, -1.42]` | `-` | `0` | `0` | *(Locator / Transform)* |
| `64` | `mounted_camera_upper_360` | `[23] Upper_Turret_Mount` | `[0.0, 0.38, -0.86]` | `[0.0, 3.16, -0.78]` | `-` | `0` | `0` | *(Locator / Transform)* |

## 4. Complete Binary-Derived 21-Animation Manifest (`bi-bye-llista-v4_3-review.glb`)

| Clip # | Exact Binary Animation Clip Name | Duration (s) | Keys | Channels | Animated Target Node Count & Primary Subsystems |
| :---: | :--- | :---: | :---: | :---: | :--- |
| `01` | `01_BiBye_LoadedIdle` | `1.2000 s` | `2` | `114` | `[01] Carriage_Chassis` (R/T), `[02] Wheel_FL` (R/S/T), `[03] Wheel_FR` (R/S/T), `[04] Wheel_ML` (R/S/T), `[05] Wheel_MR` (R/S/T), `[06] Wheel_RL` (R/S/T) + 40 more nodes |
| `02` | `02_BiBye_TwoStage_Fire` | `3.2000 s` | `21` | `48` | `[13] Elevation_Cradle` (R/T), `[14] Main_Limb_L` (R/T), `[15] Main_Limb_R` (R/T), `[16] Main_String_L` (R/T), `[17] Main_String_R` (R/T), `[18] Main_Draw_Catch` (R/T) + 17 more nodes |
| `03` | `03_BiBye_Spent_Recovery` | `1.2000 s` | `2` | `114` | `[01] Carriage_Chassis` (R/T), `[02] Wheel_FL` (R/S/T), `[03] Wheel_FR` (R/S/T), `[04] Wheel_ML` (R/S/T), `[05] Wheel_MR` (R/S/T), `[06] Wheel_RL` (R/S/T) + 40 more nodes |
| `04` | `04_BiBye_Mechanical_Reload` | `6.0000 s` | `19` | `48` | `[13] Elevation_Cradle` (R/T), `[14] Main_Limb_L` (R/T), `[15] Main_Limb_R` (R/T), `[16] Main_String_L` (R/T), `[17] Main_String_R` (R/T), `[18] Main_Draw_Catch` (R/T) + 17 more nodes |
| `05` | `05_BiBye_Stabilizer_Deploy` | `1.6000 s` | `9` | `14` | `[01] Carriage_Chassis` (R/T), `[08] Stabilizer_FL` (R/S/T), `[09] Stabilizer_FR` (R/S/T), `[10] Stabilizer_RL` (R/S/T), `[11] Stabilizer_RR` (R/S/T) |
| `06` | `06_BiBye_Travel_Ready` | `1.2000 s` | `2` | `114` | `[01] Carriage_Chassis` (R/T), `[02] Wheel_FL` (R/S/T), `[03] Wheel_FR` (R/S/T), `[04] Wheel_ML` (R/S/T), `[05] Wheel_MR` (R/S/T), `[06] Wheel_RL` (R/S/T) + 40 more nodes |
| `07` | `07_BiBye_Stabilizer_Retract` | `1.6000 s` | `8` | `14` | `[01] Carriage_Chassis` (R/T), `[08] Stabilizer_FL` (R/S/T), `[09] Stabilizer_FR` (R/S/T), `[10] Stabilizer_RL` (R/S/T), `[11] Stabilizer_RR` (R/S/T) |
| `08` | `08_BiBye_Wheel_Roll_Forward` | `1.6000 s` | `9` | `18` | `[02] Wheel_FL` (R/S/T), `[03] Wheel_FR` (R/S/T), `[04] Wheel_ML` (R/S/T), `[05] Wheel_MR` (R/S/T), `[06] Wheel_RL` (R/S/T), `[07] Wheel_RR` (R/S/T) |
| `09` | `09_BiBye_Mobile_Shot1_Fire` | `1.6000 s` | `11` | `15` | `[23] Upper_Turret_Mount` (R/T), `[24] Upper_Limb_L` (R/T), `[25] Upper_Limb_R` (R/T), `[26] Upper_String_L` (R/T), `[27] Upper_String_R` (R/T), `[28] Upper_Catch_And_Trigger` (R/T) + 1 more nodes |
| `10` | `10_BiBye_Mobile_Shot1_Reload` | `2.5000 s` | `10` | `15` | `[23] Upper_Turret_Mount` (R/T), `[24] Upper_Limb_L` (R/T), `[25] Upper_Limb_R` (R/T), `[26] Upper_String_L` (R/T), `[27] Upper_String_R` (R/T), `[28] Upper_Catch_And_Trigger` (R/T) + 1 more nodes |
| `11` | `11_BiBye_Aim_Traverse_Elevation_Sweep` | `4.0000 s` | `7` | `6` | `[12] Traverse_Mount` (R/T), `[13] Elevation_Cradle` (R/T), `[50] Operator_Traverse_Wheel` (R/T) |
| `12` | `12_BiBye_Damaged_Destroyed` | `1.8000 s` | `7` | `114` | `[01] Carriage_Chassis` (R/T), `[02] Wheel_FL` (R/S/T), `[03] Wheel_FR` (R/S/T), `[04] Wheel_ML` (R/S/T), `[05] Wheel_MR` (R/S/T), `[06] Wheel_RL` (R/S/T) + 40 more nodes |
| `13` | `13_BiBye_Partial_Wheel_Damage_Limp` | `2.4000 s` | `17` | `40` | `[01] Carriage_Chassis` (R/T), `[02] Wheel_FL` (R/S/T), `[03] Wheel_FR` (R/S/T), `[04] Wheel_ML` (R/S/T), `[05] Wheel_MR` (R/S/T), `[06] Wheel_RL` (R/S/T) + 8 more nodes |
| `14` | `14_BiBye_Stabilizer_Failure_Abort` | `2.2000 s` | `11` | `26` | `[01] Carriage_Chassis` (R/T), `[08] Stabilizer_FL` (R/S/T), `[09] Stabilizer_FR` (R/S/T), `[10] Stabilizer_RL` (R/S/T), `[11] Stabilizer_RR` (R/S/T), `[45] Stabilizer_FL_Damaged` (R/S/T) + 3 more nodes |
| `15` | `15_BiBye_Wide_Traverse_60_Turret_70_Sweep` | `4.8000 s` | `8` | `8` | `[12] Traverse_Mount` (R/T), `[13] Elevation_Cradle` (R/T), `[23] Upper_Turret_Mount` (R/T), `[50] Operator_Traverse_Wheel` (R/T) |
| `16` | `16_BiBye_Upper_Turret_360_And_Pitch_Sweep` | `4.8000 s` | `17` | `2` | `[23] Upper_Turret_Mount` (R/T) |
| `17` | `17_BiBye_Upper_Align_And_Couple` | `0.6000 s` | `5` | `4` | `[51] Operator_Fire_And_Couple_Lever` (R/T), `[52] Coupling_Clutch_Collar` (R/T) |
| `18` | `18_BiBye_Upper_Uncouple_Release` | `0.6000 s` | `5` | `4` | `[51] Operator_Fire_And_Couple_Lever` (R/T), `[52] Coupling_Clutch_Collar` (R/T) |
| `19` | `19_BiBye_Main_Winch_Reload_Only` | `4.5000 s` | `13` | `27` | `[14] Main_Limb_L` (R/T), `[15] Main_Limb_R` (R/T), `[16] Main_String_L` (R/T), `[17] Main_String_R` (R/T), `[18] Main_Draw_Catch` (R/T), `[19] Main_Siege_Bolt` (R/S/T) + 7 more nodes |
| `20` | `20_BiBye_Coupled_Shot1_Trigger_And_Delay` | `0.7000 s` | `11` | `23` | `[23] Upper_Turret_Mount` (R/T), `[24] Upper_Limb_L` (R/T), `[25] Upper_Limb_R` (R/T), `[26] Upper_String_L` (R/T), `[27] Upper_String_R` (R/T), `[28] Upper_Catch_And_Trigger` (R/T) + 5 more nodes |
| `21` | `21_BiBye_Delayed_Shot2_Release_And_Recoil` | `2.5500 s` | `12` | `25` | `[13] Elevation_Cradle` (R/T), `[14] Main_Limb_L` (R/T), `[15] Main_Limb_R` (R/T), `[16] Main_String_L` (R/T), `[17] Main_String_R` (R/T), `[18] Main_Draw_Catch` (R/T) + 6 more nodes |
