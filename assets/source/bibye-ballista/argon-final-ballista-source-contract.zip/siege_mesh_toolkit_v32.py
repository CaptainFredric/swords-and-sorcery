#!/usr/bin/env python3
"""
Precision Stylized Low-Poly Siege Geometry & Crease-Angle Smooth Normal Toolkit (v3.2)
For Castleward's The Bi-Bye-llista:
  - Area-weighted crease-angle vertex normal smoothing (smooths curved surfaces <= crease_deg
    while keeping crisp hard bevels and sword edges > crease_deg).
  - Lathe / surface-of-revolution builder for load-bearing wheels, bronze hubs, torsion drums, and bolts.
  - Multi-station curved spline loft builder for engineered forged spring-steel sword-limbs,
    curved trunnion cheeks, and wide-framing Gothic gunner sight arches.
"""
import math
import numpy as np


def compute_crease_normals(pos: np.ndarray, tris: np.ndarray, uv: np.ndarray, crease_deg: float = 42.0):
    """
    Splits vertices along hard edges (dihedral angle > crease_deg) and computes
    area-weighted smooth normals across all faces sharing a vertex within <= crease_deg.
    Returns (new_pos, new_norm, new_uv, new_tris) with zero faceted shading artifacts on curves
    and crisp hard edges on bevels/blades.
    """
    pos = np.ascontiguousarray(pos, dtype=np.float32)
    uv  = np.ascontiguousarray(uv, dtype=np.float32)
    tris = np.ascontiguousarray(tris, dtype=np.int32).reshape(-1, 3)

    v0 = pos[tris[:, 0]]
    v1 = pos[tris[:, 1]]
    v2 = pos[tris[:, 2]]
    fn_raw = np.cross(v1 - v0, v2 - v0)
    fn_len = np.linalg.norm(fn_raw, axis=1, keepdims=True)
    valid = (fn_len[:, 0] > 1e-10)
    if not np.all(valid):
        tris = tris[valid]
        fn_raw = fn_raw[valid]
        fn_len = fn_len[valid]
    fn_unit = fn_raw / np.maximum(fn_len, 1e-10)

    q_pos = np.round(pos * 10000.0).astype(np.int64)
    _, inv_idx = np.unique(q_pos, axis=0, return_inverse=True)

    cos_thresh = math.cos(math.radians(crease_deg))
    n_tris = len(tris)

    vert_to_corners = {}
    for t_i in range(n_tris):
        for c_i in range(3):
            v_id = int(inv_idx[tris[t_i, c_i]])
            vert_to_corners.setdefault(v_id, []).append((t_i, c_i))

    new_p = []
    new_n = []
    new_u = []
    new_tris = np.empty_like(tris)
    out_v_idx = 0

    for v_id, corners in vert_to_corners.items():
        clusters = []
        for (t_i, c_i) in corners:
            orig_v = tris[t_i, c_i]
            f_u = fn_unit[t_i]
            f_w = fn_raw[t_i]
            c_uv = uv[orig_v]
            placed = False
            for cl in clusters:
                if (
                    float(np.dot(f_u, cl[1])) >= cos_thresh
                    and float(np.max(np.abs(c_uv - cl[2]))) < 0.08
                ):
                    cl[0] = cl[0] + f_w
                    cl[3].append((t_i, c_i, orig_v))
                    placed = True
                    break
            if not placed:
                clusters.append([f_w.copy(), f_u.copy(), c_uv.copy(), [(t_i, c_i, orig_v)]])

        for cl in clusters:
            n_sum = cl[0]
            n_norm = float(np.linalg.norm(n_sum))
            n_final = (n_sum / n_norm) if n_norm > 1e-10 else cl[1]
            rep_v = cl[3][0][2]
            new_p.append(pos[rep_v])
            new_n.append(n_final)
            new_u.append(uv[rep_v])
            for (t_i, c_i, _) in cl[3]:
                new_tris[t_i, c_i] = out_v_idx
            out_v_idx += 1

    return (
        np.array(new_p, dtype=np.float32),
        np.array(new_n, dtype=np.float32),
        np.array(new_u, dtype=np.float32),
        new_tris.astype(np.int32),
    )


def make_lathe_mesh(profile_ar_uv, axis='x', center=(0.0, 0.0, 0.0), segs=28, crease_deg=48.0):
    """
    Revolves a 2D profile [(axial_coord, radius, (u, v)), ...] around `axis` ('x', 'y', or 'z').
    Produces a watertight, smooth-shaded lathe mesh with crisp bevel creases.
    """
    cx, cy, cz = float(center[0]), float(center[1]), float(center[2])
    angles = np.linspace(0.0, 2.0 * math.pi, segs, endpoint=False)
    cos_a = np.cos(angles)
    sin_a = np.sin(angles)

    n_prof = len(profile_ar_uv)
    pos_list = []
    uv_list  = []
    tris_list = []

    for i_p, (ax_val, r_val, uv_c) in enumerate(profile_ar_uv):
        ax_f = float(ax_val)
        r_f  = float(r_val)
        uc, vc = float(uv_c[0]), float(uv_c[1])
        for j_s in range(segs):
            c = float(cos_a[j_s])
            s = float(sin_a[j_s])
            if axis == 'x':
                px, py, pz = cx + ax_f, cy + r_f * c, cz + r_f * s
            elif axis == 'y':
                px, py, pz = cx + r_f * c, cy + ax_f, cz + r_f * s
            else:
                px, py, pz = cx + r_f * c, cy + r_f * s, cz + ax_f
            pos_list.append([px, py, pz])
            uv_list.append([uc + 0.008 * c, vc + 0.008 * s])

    for i_p in range(n_prof - 1):
        r0 = float(profile_ar_uv[i_p][1])
        r1 = float(profile_ar_uv[i_p + 1][1])
        if r0 < 1e-5 and r1 < 1e-5:
            continue
        row0 = i_p * segs
        row1 = (i_p + 1) * segs
        for j_s in range(segs):
            jn = (j_s + 1) % segs
            v00 = row0 + j_s
            v01 = row0 + jn
            v11 = row1 + jn
            v10 = row1 + j_s
            if r0 > 1e-5:
                tris_list.append([v00, v10, v11])
            if r1 > 1e-5:
                tris_list.append([v00, v11, v01])

    p_arr = np.array(pos_list, dtype=np.float32)
    u_arr = np.array(uv_list, dtype=np.float32)
    t_arr = np.array(tris_list, dtype=np.int32)
    return compute_crease_normals(p_arr, t_arr, u_arr, crease_deg=crease_deg)


def make_swept_octagonal_beam(path_pts, radii_yz, uv_center, crease_deg=38.0):
    """
    Lofts a chamfered 8-sided cross-section along a 3D spine `path_pts` [(x,y,z), ...]
    with per-station `(ry, rz)` half-dimensions and end caps.
    """
    pts = np.array(path_pts, dtype=np.float32)
    n_st = len(pts)
    c_off = 0.78
    ring_uv = np.array([
        [-1.0, -c_off], [-c_off, -1.0], [+c_off, -1.0], [+1.0, -c_off],
        [+1.0, +c_off], [+c_off, +1.0], [-c_off, +1.0], [-1.0, +c_off],
    ], dtype=np.float32)
    n_ring = len(ring_uv)

    pos_list = []
    uv_list  = []
    tris_list = []
    uc, vc = float(uv_center[0]), float(uv_center[1])

    for i in range(n_st):
        if i == 0:
            tang = pts[1] - pts[0]
        elif i == n_st - 1:
            tang = pts[-1] - pts[-2]
        else:
            tang = pts[i + 1] - pts[i - 1]
        t_norm = float(np.linalg.norm(tang))
        tang = tang / max(t_norm, 1e-8)

        up_ref = np.array([0.0, 1.0, 0.0], dtype=np.float32)
        if abs(float(np.dot(tang, up_ref))) > 0.92:
            up_ref = np.array([0.0, 0.0, 1.0], dtype=np.float32)
        b_vec = np.cross(tang, up_ref)
        b_vec /= max(float(np.linalg.norm(b_vec)), 1e-8)
        n_vec = np.cross(b_vec, tang)
        n_vec /= max(float(np.linalg.norm(n_vec)), 1e-8)

        rw, rh = float(radii_yz[i][0]), float(radii_yz[i][1])
        for k in range(n_ring):
            pt = pts[i] + ring_uv[k, 0] * rw * b_vec + ring_uv[k, 1] * rh * n_vec
            pos_list.append(pt)
            uv_list.append([uc + 0.008 * ring_uv[k, 0], vc + 0.008 * ring_uv[k, 1]])

    for i in range(n_st - 1):
        r0 = i * n_ring
        r1 = (i + 1) * n_ring
        for k in range(n_ring):
            kn = (k + 1) % n_ring
            tris_list.append([r0 + k, r1 + k, r1 + kn])
            tris_list.append([r0 + k, r1 + kn, r0 + kn])

    c_start = len(pos_list)
    pos_list.append(pts[0])
    uv_list.append([uc, vc])
    c_end = len(pos_list)
    pos_list.append(pts[-1])
    uv_list.append([uc, vc])
    last_r = (n_st - 1) * n_ring
    for k in range(n_ring):
        kn = (k + 1) % n_ring
        tris_list.append([c_start, kn, k])
        tris_list.append([c_end, last_r + k, last_r + kn])

    return compute_crease_normals(
        np.array(pos_list, dtype=np.float32),
        np.array(tris_list, dtype=np.int32),
        np.array(uv_list, dtype=np.float32),
        crease_deg=crease_deg,
    )
