#!/usr/bin/env python3
"""
Production Salvage, Mechanical Reconstruction, Rigging & Animation Pipeline (v2.0) for:
The Bi-Bye-llista (Castleward Two-Stage Heavy Siege Ballista — Launchers I & II)

Refinements in v2.0:
  1. Distinctively Sculpted Forged Spring-Steel Sword-Shaped Bow Limbs (Main_Limb_L/R & Upper_Limb_L/R):
     - Continuous 20-station lofted double-edged greatsword blades with a controlled forward/outward
       spring-bow recurve arch, broad leaf/ogive blade profile (0.43 m vertical width, 0.26 m horizontal chord),
       deep darkened-iron central fuller framed by brass ribs, polished bright-steel honed cutting bevels,
       reinforced torsion-skein root housings, flared greatsword crossguard quillons & ricasso,
       forged-brass bowstring nock shackles at r = limb_len, and 0.34 m projecting diamond sword points.
     - High-contrast angular excursion across states: 0.0 deg (Discharged/Spent) -> 25.0 deg (LoadedIdle)
       -> 30.0 deg (Peak Final Draw), sweeping the main sword tips through 0.72 m of rearward arc.
  2. Coherent Parent-Child Hierarchy under BiBye_Root (Node 0):
     - Carriage_Chassis (Node 1) parents all carriage-mounted launcher mechanisms (Nodes 6..20)
       and weapon/winch locators (small_bolt_muzzle, main_bolt_muzzle, aim_direction, winch_crank_L/R),
       while ground-planted Stabilizers (Nodes 2..5) and operator_station (Node 24) sit under BiBye_Root.
     - Rotating or translating BiBye_Root transforms the entire machine, stabilizers, and locators coherently,
       and carriage recoil (-0.115 m, -1.85 deg pitch) moves all mounted launchers and muzzles rigidly.
  3. Complete Machine-Readable glTF Animation Event & Projectile Handoff Metadata:
     - Embedded in gltf.extras.animationEvents, gltf.extras.projectileHandoff, scene.extras,
       BiBye_Root.extras, and per-clip animations[i].extras.
     - Zero leftover gatehouse generator or scene strings.
  4. Unambiguous Gameplay Projectile Handoff (Zero Visual Duplication):
     - During 02_BiBye_TwoStage_Fire, Upper_Conditioning_Bolt (Node 17, 1.650 m length) is pushed along the
       upper track by the upper bowstring from small_bolt_fire (0.450 s) to small_bolt_handoff (0.485 s), then
       instantaneously hidden via STEP scale channel (scale = [0, 0, 0]).
     - Main_Siege_Bolt (Node 11, 3.750 m length) is pushed along the open lower rail by the main bowstring
       from main_bolt_fire (0.650 s, Δt = 0.200 s after Shot I) to main_bolt_handoff (0.705 s), then
       instantaneously hidden via STEP scale channel (scale = [0, 0, 0]).
     - Exact Nock Origin, Geometric Center, Forward Tip, and Muzzle Locator transforms are embedded and documented.
"""
import io
import os
import sys
import json
import math
import struct
import hashlib
from pathlib import Path
import numpy as np
from PIL import Image

WORK_ROOT = Path(__file__).resolve().parent
BIBYE_DIR = WORK_ROOT / 'bibyellista'
OUT_DIR   = Path(__file__).resolve().parent
OUT_DIR.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(WORK_ROOT / '04_RECONSTRUCTION_SCRIPTS'))
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(OUT_DIR))
import mesh_builder_utils as mbu
import blend_io
import build_honorable_gatehouse as bhg

# Canonical Scale & Symmetry Constants
SCALE  = 2.50
X0_RAW = 0.0225

# Authentic Sampled UV Patches on Bi-Bye-llista's 2048x2048 base_basic_pbr.glb Texture Atlas
UV_CRIMSON = (0.8279, 0.7765)
UV_BRASS   = (0.1119, 0.0779)
UV_CYAN    = (0.9548, 0.7925)
UV_OAK     = (0.8504, 0.1357)
UV_BLADE   = (0.2231, 0.6436)
UV_IRON    = (0.3433, 0.0247)

# Linkage Constants for Main Launcher (II) at Y = 1.800 m
MAIN_LIMB_ROOT_X  = 0.880
MAIN_LIMB_ROOT_Y  = 1.800
MAIN_LIMB_ROOT_Z  = 0.920
MAIN_LIMB_LEN     = 1.480  # radial distance from torsion pivot to string-nock shackle (sword tip extends +0.34m further to 1.820m!)
MAIN_TIP_OVERHANG = 0.340  # projecting diamond sword-point past the bowstring shackle
MAIN_BASE_SWEEP   = 6.0    # deg rearward sweep in Spent/Discharged state (0.0 deg flex)
MAIN_FLEX_LOADED  = 25.0   # deg limb flex in 01_BiBye_LoadedIdle
MAIN_FLEX_PEAK    = 30.0   # deg limb flex at peak of final short draw (0.450..0.650 s)
MAIN_STR_LEN      = 2.380  # constant physical half-string length (meters)
MAIN_BOLT_LEN     = 3.750  # exact total length of Main_Siege_Bolt (nock Z=0.000 to broadhead tip Z=+3.750 m)

# Linkage Constants for Upper Launcher (I) at Y = 2.760 m
UPPER_LIMB_ROOT_X  = 0.300
UPPER_LIMB_ROOT_Y  = 2.760
UPPER_LIMB_ROOT_Z  = 0.340
UPPER_LIMB_LEN     = 0.780
UPPER_TIP_OVERHANG = 0.180
UPPER_BASE_SWEEP   = 8.0
UPPER_FLEX_LOADED  = 25.0
UPPER_STR_LEN      = 1.095
UPPER_BOLT_LEN     = 1.650 # exact total length of Upper_Conditioning_Bolt (nock Z=0.000 to tip Z=+1.650 m)


def solve_bow_linkage(root_x, root_z, limb_len, base_sweep_deg, str_len, flex_deg):
    """
    Given limb flex angle `flex_deg` (>= 0), returns:
      - tip_x, tip_z (carriage-space X/Z of the left/right limb string-nock shackle)
      - z_nock       (exact centerline Z where strings of fixed length `str_len` meet at X=0)
      - str_yaw_deg  (exact yaw angle in degrees for the rigid string half-span from centerline nock to limb shackle)
    Guarantees 0.000000 m string-to-tip and string-to-catch disconnection across all angles!
    """
    ang_rad = math.radians(base_sweep_deg + flex_deg)
    tip_x = root_x + limb_len * math.cos(ang_rad)
    tip_z = root_z - limb_len * math.sin(ang_rad)
    dz = math.sqrt(max(1e-6, str_len * str_len - tip_x * tip_x))
    z_nock = tip_z - dz
    str_yaw_deg = math.degrees(math.atan2(dz, tip_x))
    return tip_x, tip_z, z_nock, str_yaw_deg


MAIN_TIP_X_SPENT,  MAIN_TIP_Z_SPENT,  MAIN_Z_NOCK_SPENT,  MAIN_STR_ANG_SPENT  = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, 0.0)
MAIN_TIP_X_LOADED, MAIN_TIP_Z_LOADED, MAIN_Z_NOCK_LOADED, MAIN_STR_ANG_LOADED = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, MAIN_FLEX_LOADED)
MAIN_TIP_X_PEAK,   MAIN_TIP_Z_PEAK,   MAIN_Z_NOCK_PEAK,   MAIN_STR_ANG_PEAK   = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, MAIN_FLEX_PEAK)

UPPER_TIP_X_SPENT,  UPPER_TIP_Z_SPENT,  UPPER_Z_NOCK_SPENT,  UPPER_STR_ANG_SPENT  = solve_bow_linkage(UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Z, UPPER_LIMB_LEN, UPPER_BASE_SWEEP, UPPER_STR_LEN, 0.0)
UPPER_TIP_X_LOADED, UPPER_TIP_Z_LOADED, UPPER_Z_NOCK_LOADED, UPPER_STR_ANG_LOADED = solve_bow_linkage(UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Z, UPPER_LIMB_LEN, UPPER_BASE_SWEEP, UPPER_STR_LEN, UPPER_FLEX_LOADED)

PIVOTS = {
    "Carriage_Chassis":        [0.000, 0.000, 0.000],
    "Stabilizer_FL":           [-1.180, 0.820, +1.050],
    "Stabilizer_FR":           [+1.180, 0.820, +1.050],
    "Stabilizer_RL":           [-1.180, 0.820, -1.420],
    "Stabilizer_RR":           [+1.180, 0.820, -1.420],
    "Main_Limb_L":             [-MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Y, MAIN_LIMB_ROOT_Z],
    "Main_Limb_R":             [+MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Y, MAIN_LIMB_ROOT_Z],
    "Main_String_L":           [0.000, MAIN_LIMB_ROOT_Y, round(MAIN_Z_NOCK_LOADED, 4)],
    "Main_String_R":           [0.000, MAIN_LIMB_ROOT_Y, round(MAIN_Z_NOCK_LOADED, 4)],
    "Main_Draw_Catch":         [0.000, MAIN_LIMB_ROOT_Y - 0.040, round(MAIN_Z_NOCK_LOADED, 4)],
    "Main_Siege_Bolt":         [0.000, MAIN_LIMB_ROOT_Y + 0.035, round(MAIN_Z_NOCK_LOADED, 4)],
    "Upper_Limb_L":            [-UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Y, UPPER_LIMB_ROOT_Z],
    "Upper_Limb_R":            [+UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Y, UPPER_LIMB_ROOT_Z],
    "Upper_String_L":          [0.000, UPPER_LIMB_ROOT_Y, round(UPPER_Z_NOCK_LOADED, 4)],
    "Upper_String_R":          [0.000, UPPER_LIMB_ROOT_Y, round(UPPER_Z_NOCK_LOADED, 4)],
    "Upper_Catch_And_Trigger": [0.000, UPPER_LIMB_ROOT_Y - 0.030, round(UPPER_Z_NOCK_LOADED, 4)],
    "Upper_Conditioning_Bolt": [0.000, UPPER_LIMB_ROOT_Y + 0.025, round(UPPER_Z_NOCK_LOADED, 4)],
    "Winch_Drum_And_Cranks":   [0.000, 1.500, -1.360],
    "Winch_Ratchet_Gear":      [+0.420, 1.500, -1.580],
    "Winch_Pawl_And_Lever":    [-0.420, 1.660, -1.560],
}

ORDERED_NODES = list(PIVOTS.keys())

LOCATORS = {
    "small_bolt_muzzle": {
        "translation": [0.000, 2.785, +0.920],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Carriage_Chassis",
        "description": "Stage I conditioning bolt muzzle locator at the front end of the upper loading track (+Z firing axis)."
    },
    "main_bolt_muzzle": {
        "translation": [0.000, 1.835, +1.520],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Carriage_Chassis",
        "description": "Stage II heavy physical siege bolt muzzle locator at the front end of the lower guide rail (+Z firing axis)."
    },
    "aim_direction": {
        "translation": [0.000, 2.150, +3.600],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Carriage_Chassis",
        "description": "Committed forward aim reference point along the +Z ballistic axis (zero projectile homing)."
    },
    "operator_station": {
        "translation": [0.000, 0.000, -2.550],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "BiBye_Root",
        "description": "Ground-level standing mark for a 1.80 m Spellblade operating the rear winch and release lever."
    },
    "winch_crank_L": {
        "translation": [-0.860, 1.500, -1.360],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Carriage_Chassis",
        "description": "Left rear winch crank handle interaction anchor (ergonomic chest height Y = 1.500 m)."
    },
    "winch_crank_R": {
        "translation": [+0.860, 1.500, -1.360],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Carriage_Chassis",
        "description": "Right rear winch crank handle interaction anchor (ergonomic chest height Y = 1.500 m)."
    },
}

PROJECTILE_HANDOFF = {
    "handoffMechanism": (
        "Both embedded demonstration bolt nodes (Upper_Conditioning_Bolt Node 17 and Main_Siege_Bolt Node 11) "
        "are visible on their rails in 01_BiBye_LoadedIdle (scale = [1, 1, 1]). In 02_BiBye_TwoStage_Fire, "
        "each bowstring physically pushes its bolt along the rail from the fire event (small_bolt_fire = 0.450 s, "
        "main_bolt_fire = 0.650 s) to the forward string stop (small_bolt_handoff = 0.485 s, main_bolt_handoff = 0.705 s). "
        "At the handoff timestamp, the embedded bolt node's glTF scale channel steps via STEP interpolation from "
        "[1.0, 1.0, 1.0] to [0.0, 0.0, 0.0] (and remains [0, 0, 0] throughout 03_BiBye_Spent_Recovery until "
        "re-seated in 04_BiBye_Mechanical_Reload), preventing any visual duplication with gameplay-spawned projectiles. "
        "If gameplay spawns its runtime projectile immediately at small_bolt_fire (0.450 s) / main_bolt_fire (0.650 s), "
        "the client renderer may also set node.visible = false on that timestamp."
    ),
    "stage1_conditioning_bolt": {
        "nodeIndex": 17,
        "nodeName": "Upper_Conditioning_Bolt",
        "muzzleLocator": "small_bolt_muzzle",
        "fireEvent": "small_bolt_fire",
        "fireTimeSec": 0.450,
        "handoffEvent": "small_bolt_handoff",
        "handoffTimeSec": 0.485,
        "powerStrokeDurationSec": 0.035,
        "boltLengthMeters": UPPER_BOLT_LEN,
        "localMeshBoundsZ": [0.000, UPPER_BOLT_LEN],
        "localMeshOriginRole": "rear_bowstring_nock",
        "localCenterOffsetZ": round(0.5 * UPPER_BOLT_LEN, 4),
        "localTipOffsetZ": UPPER_BOLT_LEN,
        "launchDirectionLocal": [0.0, 0.0, +1.0],
        "launchOrientationQuat": [0.0, 0.0, 0.0, 1.0],
        "recommendedSpeedMetersPerSec": 28.0,
        "transformsAtLoadedIdle": {
            "nockOrigin":   [0.000, 2.785, round(UPPER_Z_NOCK_LOADED, 4)],
            "boltCenter":   [0.000, 2.785, round(UPPER_Z_NOCK_LOADED + 0.5 * UPPER_BOLT_LEN, 4)],
            "forwardTip":   [0.000, 2.785, round(UPPER_Z_NOCK_LOADED + UPPER_BOLT_LEN, 4)],
            "muzzleLocator":[0.000, 2.785, +0.920],
        },
        "transformsAtFireEvent_0p450s": {
            "nockOrigin":   [0.000, 2.785, round(UPPER_Z_NOCK_LOADED, 4)],
            "boltCenter":   [0.000, 2.785, round(UPPER_Z_NOCK_LOADED + 0.5 * UPPER_BOLT_LEN, 4)],
            "forwardTip":   [0.000, 2.785, round(UPPER_Z_NOCK_LOADED + UPPER_BOLT_LEN, 4)],
            "muzzleLocator":[0.000, 2.785, +0.920],
        },
        "transformsAtHandoffEvent_0p485s": {
            "nockOrigin":   [0.000, 2.785, round(UPPER_Z_NOCK_SPENT, 4)],
            "boltCenter":   [0.000, 2.785, round(UPPER_Z_NOCK_SPENT + 0.5 * UPPER_BOLT_LEN, 4)],
            "forwardTip":   [0.000, 2.785, round(UPPER_Z_NOCK_SPENT + UPPER_BOLT_LEN, 4)],
            "muzzleLocator":[0.000, 2.785, +0.920],
        },
    },
    "stage2_main_siege_bolt": {
        "nodeIndex": 11,
        "nodeName": "Main_Siege_Bolt",
        "muzzleLocator": "main_bolt_muzzle",
        "fireEvent": "main_bolt_fire",
        "fireTimeSec": 0.650,
        "interShotIntervalSec": 0.200,
        "handoffEvent": "main_bolt_handoff",
        "handoffTimeSec": 0.705,
        "powerStrokeDurationSec": 0.055,
        "boltLengthMeters": MAIN_BOLT_LEN,
        "localMeshBoundsZ": [0.000, MAIN_BOLT_LEN],
        "localMeshOriginRole": "rear_bowstring_nock",
        "localCenterOffsetZ": round(0.5 * MAIN_BOLT_LEN, 4),
        "localTipOffsetZ": MAIN_BOLT_LEN,
        "launchDirectionLocal": [0.0, 0.0, +1.0],
        "launchOrientationQuat": [0.0, 0.0, 0.0, 1.0],
        "recommendedSpeedMetersPerSec": 26.0,
        "transformsAtLoadedIdle": {
            "nockOrigin":   [0.000, 1.835, round(MAIN_Z_NOCK_LOADED, 4)],
            "boltCenter":   [0.000, 1.835, round(MAIN_Z_NOCK_LOADED + 0.5 * MAIN_BOLT_LEN, 4)],
            "forwardTip":   [0.000, 1.835, round(MAIN_Z_NOCK_LOADED + MAIN_BOLT_LEN, 4)],
            "muzzleLocator":[0.000, 1.835, +1.520],
        },
        "transformsAtFireEvent_0p650s": {
            "nockOrigin":   [0.000, 1.835, round(MAIN_Z_NOCK_PEAK, 4)],
            "boltCenter":   [0.000, 1.835, round(MAIN_Z_NOCK_PEAK + 0.5 * MAIN_BOLT_LEN, 4)],
            "forwardTip":   [0.000, 1.835, round(MAIN_Z_NOCK_PEAK + MAIN_BOLT_LEN, 4)],
            "muzzleLocator":[0.000, 1.835, +1.520],
        },
        "transformsAtHandoffEvent_0p705s": {
            "nockOrigin":   [0.000, 1.835, round(MAIN_Z_NOCK_SPENT, 4)],
            "boltCenter":   [0.000, 1.835, round(MAIN_Z_NOCK_SPENT + 0.5 * MAIN_BOLT_LEN, 4)],
            "forwardTip":   [0.000, 1.835, round(MAIN_Z_NOCK_SPENT + MAIN_BOLT_LEN, 4)],
            "muzzleLocator":[0.000, 1.835, +1.520],
        },
    },
}

ANIMATION_EVENTS = {
    "01_BiBye_LoadedIdle": {
        "duration_sec": 1.20,
        "loop": True,
        "events": {
            "loaded_idle_ready": 0.000,
        },
        "state_summary": "Both Launchers I & II cocked at 25.0 deg limb flex; both projectiles visible on rails (scale=[1,1,1]); stabilizers planted (0.0 deg)."
    },
    "02_BiBye_TwoStage_Fire": {
        "duration_sec": 3.20,
        "loop": False,
        "events": {
            "aim_committed": 0.000,
            "final_short_draw_start": 0.100,
            "small_bolt_fire": 0.450,
            "small_bolt_handoff": 0.485,
            "main_bolt_fire": 0.650,
            "main_bolt_handoff": 0.705,
            "recoil_peak": 0.850,
            "recovery_complete": 2.200,
        },
        "inter_shot_interval_sec": 0.200,
        "projectile_handoff": PROJECTILE_HANDOFF,
        "state_summary": (
            "0.000s aim_committed; 0.100..0.450s final short main-launcher draw (25.0 -> 30.0 deg); "
            "0.450s small_bolt_fire (Upper Launcher I releases conditioning bolt, pushed by string to 0.485s small_bolt_handoff where Node 17 hides to scale=[0,0,0]); "
            "0.650s main_bolt_fire (Δt=0.200s later, Main Launcher II releases 3.75m siege bolt, pushed by string to 0.705s main_bolt_handoff where Node 11 hides to scale=[0,0,0]); "
            "0.850s recoil_peak (-0.115m / -1.85 deg pitch); 2.200s recovery_complete into Spent state."
        )
    },
    "03_BiBye_Spent_Recovery": {
        "duration_sec": 1.20,
        "loop": True,
        "events": {
            "spent_recovery_idle": 0.000,
        },
        "state_summary": "Post-fire spent state: both bowstrings forward at rest (0.0 deg limb flex), both rails empty (Node 11 & Node 17 scale=[0,0,0])."
    },
    "04_BiBye_Mechanical_Reload": {
        "duration_sec": 6.00,
        "loop": False,
        "events": {
            "main_catch_slide_forward": 0.000,
            "main_winch_draw_start": 0.750,
            "main_catch_lock": 2.850,
            "main_bolt_place_on_rail": 3.100,
            "upper_cock_and_load": 4.100,
            "reload_ready_state": 5.350,
        },
        "event_windows": {
            "main_catch_slide_forward": [0.000, 0.750],
            "main_winch_draw_start": [0.750, 2.850],
            "main_catch_lock": [2.850, 3.100],
            "main_bolt_place_on_rail": [3.100, 4.100],
            "upper_cock_and_load": [4.100, 5.350],
            "reload_ready_state": [5.350, 6.000],
        },
        "state_summary": (
            "5-step mechanical reload: (1) 0.000..0.750s Main_Draw_Catch slides forward to +0.401m & clamps slack main string; "
            "(2) 0.750..2.850s Rear winch winds (-720 deg) & ratchet gear spins (+1080 deg), hauling main string to -0.865m and bending giant sword-limbs to 25.0 deg; "
            "(3) 2.850..3.100s Main catch locks; (4) 3.100..4.100s Main_Siege_Bolt (scale -> [1,1,1]) seats onto lower rail; "
            "(5) 4.100..5.350s Upper Launcher I cocks to 25.0 deg & seats Upper_Conditioning_Bolt (scale -> [1,1,1]); 5.350..6.000s reload_ready_state."
        )
    },
    "05_BiBye_Stabilizer_Deploy": {
        "duration_sec": 2.40,
        "loop": False,
        "events": {
            "stabilizers_fold_up_start": 0.000,
            "stabilizers_folded_travel_peak": 0.750,
            "stabilizers_plant_down_start": 0.750,
            "stabilizers_planted_lock": 1.650,
            "stabilizers_deploy_complete": 2.050,
        },
        "state_summary": "4 outrigger stabilizers fold upward (+/-32.0 deg, 0.00..0.75s) for wheeled travel and plant back down (0.75..1.65s) with chassis settle (1.65..2.05s)."
    },
}


def make_sword_limb_mesh(side_sign: float, limb_len: float, tip_overhang: float, base_sweep_deg: float, is_upper=False):
    s = 0.48 if is_upper else 1.00
    parts = []

    # 1. Heavy Torsion-Skein Cylinder & Reinforced Mechanical Root Attachment at (0, 0, 0)
    parts.append(mbu.make_cylinder([0.0, 0.0, 0.0], 0.165 * s, 0.28 * s, axis='y', segs=18, uv_center=UV_BRASS))
    parts.append(mbu.make_cylinder([0.0, 0.0, 0.0], 0.195 * s, 0.11 * s, axis='y', segs=18, uv_center=UV_IRON))
    parts.append(mbu.make_cylinder([0.0, +0.25 * s, 0.0], 0.180 * s, 0.04 * s, axis='y', segs=18, uv_center=UV_BRASS))
    parts.append(mbu.make_cylinder([0.0, -0.25 * s, 0.0], 0.180 * s, 0.04 * s, axis='y', segs=18, uv_center=UV_BRASS))

    # 2. Forged Greatsword Crossguard / Quillons at r = 0.15 * s
    rx_g = side_sign * 0.15 * s
    parts.append(mbu.make_beveled_box(
        [rx_g - 0.065 * s, -0.25 * s, -0.19 * s],
        [rx_g + 0.065 * s, +0.25 * s, +0.21 * s],
        bevel=0.018 * s, uv_center=UV_BRASS
    ))
    for sy in (-1.0, +1.0):
        qp, qn, qu, qt = bhg.make_frustum_seg(
            [rx_g, sy * 0.22 * s, +0.02 * s],
            [rx_g - side_sign * 0.04 * s, sy * 0.34 * s, +0.06 * s],
            0.065 * s, 0.028 * s, 8, UV_BRASS
        )
        parts.append((qp, qn, qu, qt))
    for sz in (-1.0, +1.0):
        qp, qn, qu, qt = bhg.make_frustum_seg(
            [rx_g, 0.0, sz * 0.16 * s],
            [rx_g - side_sign * 0.03 * s, 0.0, sz * 0.28 * s],
            0.065 * s, 0.026 * s, 8, UV_BRASS
        )
        parts.append((qp, qn, qu, qt))

    # 3. Structural Ricasso Clamp Collar (r = 0.18*s .. 0.34*s)
    r_ric0, r_ric1 = 0.18 * s, 0.34 * s
    xmin_r, xmax_r = min(side_sign * r_ric0, side_sign * r_ric1), max(side_sign * r_ric0, side_sign * r_ric1)
    parts.append(mbu.make_beveled_box(
        [xmin_r, -0.185 * s, -0.115 * s],
        [xmax_r, +0.185 * s, +0.145 * s],
        bevel=0.015 * s, uv_center=UV_IRON
    ))

    # 4. Continuous Multi-Station Lofted Sword-Blade Spring Limb (from r = 0.16*s to r_total = limb_len + tip_overhang)
    r_start = 0.16 * s
    r_total = limb_len + tip_overhang
    r_stations = np.unique(np.concatenate([
        np.linspace(r_start, limb_len, 15),
        np.linspace(limb_len, r_total, 7),
    ]))

    def blade_station_profile(r_val):
        if r_val <= limb_len:
            u = (r_val - r_start) / max(1e-6, limb_len - r_start)
            z_c = (+0.205 * s) * math.sin(math.pi * (u ** 0.82))
            hy = s * (0.195 + 0.032 * math.sin(math.pi * u) - 0.030 * (u ** 1.4))
            hz_f = s * (0.145 * (1.0 - 0.22 * u))
            hz_r = s * (0.115 * (1.0 - 0.28 * u))
            f_frac = 0.38 * (1.0 - 0.15 * u)
        else:
            ut = (r_val - limb_len) / max(1e-6, tip_overhang)
            z_c = (-0.045 * s) * ut
            taper = max(0.03, math.cos(0.5 * math.pi * (ut ** 0.88)))
            hy   = s * 0.165 * taper
            hz_f = s * 0.113 * taper
            hz_r = s * 0.083 * taper
            f_frac = 0.32 * (1.0 - ut)
        return z_c, hy, hz_f, hz_r, f_frac

    seg_uvs = [UV_BLADE, UV_BRASS, UV_IRON, UV_BRASS, UV_BLADE, UV_BLADE, UV_IRON, UV_BLADE]

    rings = []
    for r_val in r_stations:
        z_c, hy, hz_f, hz_r, _ = blade_station_profile(float(r_val))
        x_val = side_sign * float(r_val)
        ring = [
            [x_val, +hy,        z_c],
            [x_val, +0.44 * hy, z_c + 0.88 * hz_f],
            [x_val, +0.25 * hy, z_c + 0.54 * hz_f],
            [x_val, -0.25 * hy, z_c + 0.54 * hz_f],
            [x_val, -0.44 * hy, z_c + 0.88 * hz_f],
            [x_val, -hy,        z_c],
            [x_val, -0.42 * hy, z_c - hz_r],
            [x_val, +0.42 * hy, z_c - hz_r],
        ]
        rings.append(np.array(ring, dtype=np.float32))

    for i in range(len(rings) - 1):
        R0 = rings[i]
        R1 = rings[i + 1]
        for k in range(8):
            kn = (k + 1) % 8
            if side_sign > 0:
                v0, v1, v2, v3 = R0[k], R1[k], R1[kn], R0[kn]
            else:
                v0, v1, v2, v3 = R0[kn], R1[kn], R1[k], R0[k]
            e1 = v1 - v0
            e2 = v3 - v0
            n_vec = np.cross(e1, e2)
            parts.append(bhg.make_quad(v0, v1, v2, v3, seg_uvs[k], n_vec))

    tip_ring = rings[-1]
    tip_apex = np.array([side_sign * (r_total + 0.04 * s), 0.0, (-0.052 * s)], dtype=np.float32)
    for k in range(8):
        kn = (k + 1) % 8
        v0 = tip_ring[k] if side_sign > 0 else tip_ring[kn]
        v1 = tip_apex
        v2 = tip_ring[kn] if side_sign > 0 else tip_ring[k]
        n_vec = np.cross(v1 - v0, v2 - v0)
        parts.append(bhg.make_quad(v0, v1, v2, v0, UV_BLADE, n_vec))

    # 5. Reinforced Forged-Brass Bowstring Attachment Shackle & Clevis Pin at exact (side_sign * limb_len, 0.0, 0.0)
    x_nock = side_sign * limb_len
    parts.append(mbu.make_beveled_box(
        [x_nock - 0.045 * s, -0.185 * s, -0.105 * s],
        [x_nock + 0.045 * s, +0.185 * s, +0.065 * s],
        bevel=0.012 * s, uv_center=UV_BRASS
    ))
    parts.append(mbu.make_cylinder([x_nock, 0.0, 0.0], 0.068 * s, 0.115 * s, axis='y', segs=14, uv_center=UV_BRASS))
    parts.append(mbu.make_cylinder([x_nock, 0.0, 0.0], 0.042 * s, 0.145 * s, axis='y', segs=12, uv_center=UV_IRON))

    mesh_local = mbu.concat_meshes(parts)
    ang = math.radians(side_sign * base_sweep_deg)
    ca, sa = math.cos(ang), math.sin(ang)
    R = np.array([[ca, 0.0, sa], [0.0, 1.0, 0.0], [-sa, 0.0, ca]], dtype=np.float32)
    mp, mn, mu, mt = mesh_local
    return (mp @ R.T, mn @ R.T, mu, mt)


def make_bowstring_half_mesh(side_sign: float, str_len: float, is_upper=False):
    r_str = 0.015 if is_upper else 0.025
    parts = [
        mbu.make_cylinder([side_sign * (0.5 * str_len), 0.0, 0.0], r_str, 0.5 * str_len, axis='x', segs=10, uv_center=UV_BLADE),
        mbu.make_cylinder([side_sign * 0.045, 0.0, 0.0], r_str * 1.70, 0.045, axis='x', segs=10, uv_center=UV_BRASS),
        mbu.make_cylinder([side_sign * (str_len - 0.045), 0.0, 0.0], r_str * 1.70, 0.045, axis='x', segs=10, uv_center=UV_BRASS),
    ]
    return mbu.concat_meshes(parts)


def make_siege_bolt_mesh(is_upper=False):
    if not is_upper:
        parts = [
            mbu.make_cylinder([0.0, 0.0, +1.51], 0.062, 1.51, axis='z', segs=14, uv_center=UV_OAK),
            mbu.make_cylinder([0.0, 0.0, +0.08], 0.070, 0.06, axis='z', segs=14, uv_center=UV_BRASS),
            mbu.make_cylinder([0.0, 0.0, +0.85], 0.067, 0.05, axis='z', segs=14, uv_center=UV_IRON),
            mbu.make_cylinder([0.0, 0.0, +1.65], 0.067, 0.05, axis='z', segs=14, uv_center=UV_BRASS),
            mbu.make_cylinder([0.0, 0.0, +2.35], 0.067, 0.05, axis='z', segs=14, uv_center=UV_IRON),
            mbu.make_cylinder([0.0, 0.0, +2.96], 0.078, 0.09, axis='z', segs=14, uv_center=UV_BRASS),
            bhg.make_frustum_seg([0.0, 0.0, +3.00], [0.0, 0.0, +3.75], 0.135, 0.010, 6, UV_BLADE),
            mbu.make_beveled_box([-0.220, -0.024, +2.98], [+0.220, +0.024, +3.42], bevel=0.008, uv_center=UV_BLADE),
            mbu.make_beveled_box([-0.145, -0.018, +3.38], [+0.145, +0.018, +3.60], bevel=0.006, uv_center=UV_BLADE),
            mbu.make_beveled_box([-0.024, -0.165, +2.98], [+0.024, +0.165, +3.42], bevel=0.008, uv_center=UV_BLADE),
            mbu.make_beveled_box([-0.240, -0.020, +2.88], [-0.130, +0.020, +3.04], bevel=0.006, uv_center=UV_BLADE),
            mbu.make_beveled_box([+0.130, -0.020, +2.88], [+0.240, +0.020, +3.04], bevel=0.006, uv_center=UV_BLADE),
            mbu.make_beveled_box([-0.210, -0.012, +0.10], [+0.210, +0.012, +0.68], bevel=0.005, uv_center=UV_CRIMSON),
            mbu.make_beveled_box([-0.012, +0.025, +0.10], [+0.012, +0.195, +0.68], bevel=0.005, uv_center=UV_BRASS),
        ]
        return mbu.concat_meshes(parts)
    else:
        parts = [
            mbu.make_cylinder([0.0, 0.0, +0.61], 0.032, 0.61, axis='z', segs=12, uv_center=UV_IRON),
            mbu.make_cylinder([0.0, 0.0, +0.88], 0.038, 0.040, axis='z', segs=12, uv_center=UV_CYAN),
            mbu.make_cylinder([0.0, 0.0, +1.14], 0.042, 0.050, axis='z', segs=12, uv_center=UV_CYAN),
            bhg.make_frustum_seg([0.0, 0.0, +1.20], [0.0, 0.0, +1.65], 0.072, 0.006, 6, UV_BLADE),
            mbu.make_beveled_box([-0.115, -0.014, +1.22], [+0.115, +0.014, +1.48], bevel=0.004, uv_center=UV_CYAN),
            mbu.make_beveled_box([-0.014, -0.095, +1.22], [+0.014, +0.095, +1.48], bevel=0.004, uv_center=UV_CYAN),
            mbu.make_beveled_box([-0.105, -0.008, +0.05], [+0.105, +0.008, +0.36], bevel=0.003, uv_center=UV_CYAN),
            mbu.make_beveled_box([-0.008, +0.012, +0.05], [+0.008, +0.098, +0.36], bevel=0.003, uv_center=UV_CRIMSON),
        ]
        return mbu.concat_meshes(parts)


def make_draw_catch_mesh(is_upper=False):
    s = 0.55 if is_upper else 1.00
    parts = [
        mbu.make_beveled_box([-0.14 * s, -0.06 * s, -0.16 * s], [+0.14 * s, +0.06 * s, +0.12 * s], bevel=0.015 * s, uv_center=UV_IRON),
        mbu.make_beveled_box([-0.11 * s, +0.02 * s, -0.05 * s], [-0.04 * s, +0.13 * s, +0.05 * s], bevel=0.01 * s, uv_center=UV_BRASS),
        mbu.make_beveled_box([+0.04 * s, +0.02 * s, -0.05 * s], [+0.11 * s, +0.13 * s, +0.05 * s], bevel=0.01 * s, uv_center=UV_BRASS),
        mbu.make_cylinder([0.0, 0.0, -0.18 * s], 0.045 * s, 0.04 * s, axis='x', segs=10, uv_center=UV_BRASS),
    ]
    return mbu.concat_meshes(parts)


def make_winch_drum_and_cranks_mesh():
    parts = [
        mbu.make_cylinder([0.0, 0.0, 0.0], 0.22, 0.34, axis='x', segs=24, uv_center=UV_BLADE),
        mbu.make_cylinder([-0.35, 0.0, 0.0], 0.28, 0.03, axis='x', segs=24, uv_center=UV_BRASS),
        mbu.make_cylinder([+0.35, 0.0, 0.0], 0.28, 0.03, axis='x', segs=24, uv_center=UV_BRASS),
        mbu.make_cylinder([0.0, 0.0, 0.0], 0.060, 0.88, axis='x', segs=14, uv_center=UV_IRON),
    ]
    for k in range(6):
        ang = (2.0 * math.pi * k) / 6.0
        ry, rz = 0.225 * math.cos(ang), 0.225 * math.sin(ang)
        parts.append(mbu.make_beveled_box([-0.33, ry - 0.025, rz - 0.025], [+0.33, ry + 0.025, rz + 0.025], bevel=0.006, uv_center=UV_IRON if k % 2 == 0 else UV_BRASS))

    for sx in (-1.0, +1.0):
        x_arm = sx * 0.82
        parts.append(mbu.make_beveled_box([x_arm - 0.03, -0.36, -0.05], [x_arm + 0.03, +0.36, +0.05], bevel=0.01, uv_center=UV_BRASS))
        parts.append(mbu.make_beveled_box([x_arm - 0.03, -0.05, -0.36], [x_arm + 0.03, +0.05, +0.36], bevel=0.01, uv_center=UV_BRASS))
        parts.append(mbu.make_cylinder([x_arm + sx * 0.10, +0.32, 0.0], 0.032, 0.10, axis='x', segs=10, uv_center=UV_OAK))
        parts.append(mbu.make_cylinder([x_arm + sx * 0.10, -0.32, 0.0], 0.032, 0.10, axis='x', segs=10, uv_center=UV_OAK))
    return mbu.concat_meshes(parts)


def build_bibyellista_meshes_and_textures():
    in_glb = BIBYE_DIR / 'base_basic_pbr.glb'
    j, b, pos_raw, norm_raw, uv_raw, tris_raw, imgs = bhg.load_glb_any(str(in_glb))
    mesh0 = bhg.compact_mesh((pos_raw, norm_raw, uv_raw, tris_raw))
    p, n, u, t = mesh0

    xc = p[:, 0] - X0_RAW
    yr = p[:, 1]
    zr = p[:, 2]
    tc_x = xc[t].mean(axis=1)
    tc_y = yr[t].mean(axis=1)
    tc_z = zr[t].mean(axis=1)

    shield_II_keep = (np.abs(tc_x) >= 0.22) & (np.abs(tc_x) <= 0.41) & (tc_y >= 0.50) & (tc_y <= 0.755) & (tc_z >= 0.48)
    shield_I_keep  = (np.abs(tc_x) < 0.10)  & (tc_y >= 0.86) & (tc_y <= 1.065) & (tc_z >= 0.17) & (tc_z <= 0.26)

    excise_lower_limbs = (np.abs(tc_x) > 0.355) & (tc_y > 0.52) & (~shield_II_keep)
    excise_strings     = (np.abs(tc_x) > 0.18)  & (tc_y > 0.74) & (tc_y < 1.04) & (tc_z > -0.28) & (tc_z < 0.48)
    excise_front_blob  = (np.abs(tc_x) < 0.22)  & (tc_y > 0.48) & (tc_y < 0.85) & (tc_z > 0.22)
    excise_upper       = ((tc_y > 1.02) & (~shield_I_keep)) | ((tc_y > 0.96) & (tc_z > 0.25))
    excise_rear_drum   = (np.abs(tc_x) < 0.165) & (tc_y > 0.52) & (tc_y < 0.78) & (tc_z > -0.68) & (tc_z < -0.28)

    excise_all = excise_lower_limbs | excise_strings | excise_front_blob | excise_upper | excise_rear_drum

    rem_mask = ~excise_all
    stab_fl_mask = rem_mask & (tc_x < -0.47) & (tc_y < 0.39) & (tc_z > +0.28)
    stab_fr_mask = rem_mask & (tc_x > +0.47) & (tc_y < 0.39) & (tc_z > +0.28)
    stab_rl_mask = rem_mask & (tc_x < -0.47) & (tc_y < 0.39) & (tc_z < -0.38)
    stab_rr_mask = rem_mask & (tc_x > +0.47) & (tc_y < 0.39) & (tc_z < -0.38)
    chassis_mask = rem_mask & (~(stab_fl_mask | stab_fr_mask | stab_rl_mask | stab_rr_mask))

    pw = np.column_stack([xc * SCALE, yr * SCALE, zr * SCALE]).astype(np.float32)

    def extract_part(mask):
        return bhg.compact_mesh((pw, n, u, t[mask]))

    chassis_base = extract_part(chassis_mask)
    stab_fl_base = extract_part(stab_fl_mask)
    stab_fr_base = extract_part(stab_fr_mask)
    stab_rl_base = extract_part(stab_rl_mask)
    stab_rr_base = extract_part(stab_rr_mask)

    chassis_parts = [
        chassis_base,
        mbu.make_beveled_box([-0.19, 1.60, -1.35], [+0.19, 1.77, +1.52], bevel=0.02, uv_center=UV_OAK),
        mbu.make_beveled_box([-0.155, 1.76, -1.32], [-0.068, 1.825, +1.50], bevel=0.01, uv_center=UV_IRON),
        mbu.make_beveled_box([+0.068, 1.76, -1.32], [+0.155, 1.825, +1.50], bevel=0.01, uv_center=UV_IRON),
        mbu.make_beveled_box([-0.98, 1.56, +0.74], [+0.98, 1.75, +1.10], bevel=0.025, uv_center=UV_IRON),
        mbu.make_beveled_box([-1.04, 1.58, +0.72], [-0.68, 2.06, +1.12], bevel=0.02, uv_center=UV_BRASS),
        mbu.make_beveled_box([+0.68, 1.58, +0.72], [+1.04, 2.06, +1.12], bevel=0.02, uv_center=UV_BRASS),
        mbu.make_beveled_box([-0.875, 1.48, +1.36], [-0.835, 1.71, +1.41], bevel=0.005, uv_center=UV_BRASS),
        mbu.make_beveled_box([-0.795, 1.48, +1.36], [-0.755, 1.71, +1.41], bevel=0.005, uv_center=UV_BRASS),
        mbu.make_beveled_box([+0.755, 1.48, +1.36], [+0.795, 1.71, +1.41], bevel=0.005, uv_center=UV_BRASS),
        mbu.make_beveled_box([+0.835, 1.48, +1.36], [+0.875, 1.71, +1.41], bevel=0.005, uv_center=UV_BRASS),
        mbu.make_beveled_box([-0.11, 2.62, -0.72], [+0.11, 2.74, +0.92], bevel=0.015, uv_center=UV_OAK),
        mbu.make_beveled_box([-0.088, 2.73, -0.70], [-0.036, 2.78, +0.90], bevel=0.008, uv_center=UV_IRON),
        mbu.make_beveled_box([+0.036, 2.73, -0.70], [+0.088, 2.78, +0.90], bevel=0.008, uv_center=UV_IRON),
        mbu.make_beveled_box([-0.36, 2.60, +0.24], [+0.36, 2.73, +0.44], bevel=0.015, uv_center=UV_BRASS),
        mbu.make_beveled_box([-0.40, 2.63, +0.23], [-0.18, 2.88, +0.45], bevel=0.015, uv_center=UV_BRASS),
        mbu.make_beveled_box([+0.18, 2.63, +0.23], [+0.40, 2.88, +0.45], bevel=0.015, uv_center=UV_BRASS),
        mbu.make_beveled_box([-0.022, 2.35, +0.57], [+0.022, 2.57, +0.61], bevel=0.005, uv_center=UV_BRASS),
        mbu.make_beveled_box([-0.48, 1.25, -1.66], [-0.35, 1.72, -1.18], bevel=0.02, uv_center=UV_IRON),
        mbu.make_beveled_box([+0.35, 1.25, -1.66], [+0.48, 1.72, -1.18], bevel=0.02, uv_center=UV_IRON),
    ]

    meshes_dict = {
        "Carriage_Chassis":        bhg.shift_mesh_to_pivot(mbu.concat_meshes(chassis_parts), PIVOTS["Carriage_Chassis"]),
        "Stabilizer_FL":           bhg.shift_mesh_to_pivot(stab_fl_base, PIVOTS["Stabilizer_FL"]),
        "Stabilizer_FR":           bhg.shift_mesh_to_pivot(stab_fr_base, PIVOTS["Stabilizer_FR"]),
        "Stabilizer_RL":           bhg.shift_mesh_to_pivot(stab_rl_base, PIVOTS["Stabilizer_RL"]),
        "Stabilizer_RR":           bhg.shift_mesh_to_pivot(stab_rr_base, PIVOTS["Stabilizer_RR"]),
        "Main_Limb_L":             make_sword_limb_mesh(-1.0, MAIN_LIMB_LEN, MAIN_TIP_OVERHANG, MAIN_BASE_SWEEP, is_upper=False),
        "Main_Limb_R":             make_sword_limb_mesh(+1.0, MAIN_LIMB_LEN, MAIN_TIP_OVERHANG, MAIN_BASE_SWEEP, is_upper=False),
        "Main_String_L":           make_bowstring_half_mesh(-1.0, MAIN_STR_LEN, is_upper=False),
        "Main_String_R":           make_bowstring_half_mesh(+1.0, MAIN_STR_LEN, is_upper=False),
        "Main_Draw_Catch":         make_draw_catch_mesh(is_upper=False),
        "Main_Siege_Bolt":         make_siege_bolt_mesh(is_upper=False),
        "Upper_Limb_L":            make_sword_limb_mesh(-1.0, UPPER_LIMB_LEN, UPPER_TIP_OVERHANG, UPPER_BASE_SWEEP, is_upper=True),
        "Upper_Limb_R":            make_sword_limb_mesh(+1.0, UPPER_LIMB_LEN, UPPER_TIP_OVERHANG, UPPER_BASE_SWEEP, is_upper=True),
        "Upper_String_L":          make_bowstring_half_mesh(-1.0, UPPER_STR_LEN, is_upper=True),
        "Upper_String_R":          make_bowstring_half_mesh(+1.0, UPPER_STR_LEN, is_upper=True),
        "Upper_Catch_And_Trigger": make_draw_catch_mesh(is_upper=True),
        "Upper_Conditioning_Bolt": make_siege_bolt_mesh(is_upper=True),
        "Winch_Drum_And_Cranks":   make_winch_drum_and_cranks_mesh(),
        "Winch_Ratchet_Gear":      bhg.shift_mesh_to_pivot(bhg.make_toothed_gear(PIVOTS["Winch_Ratchet_Gear"], r_root=0.19, r_tip=0.25, half_thick=0.045, n_teeth=12, uv_body=UV_IRON, uv_rim=UV_BRASS), PIVOTS["Winch_Ratchet_Gear"]),
        "Winch_Pawl_And_Lever":    mbu.concat_meshes([
            mbu.make_beveled_box([-0.035, -0.04, -0.04], [+0.035, +0.42, +0.04], bevel=0.008, uv_center=UV_BRASS),
            mbu.make_cylinder([0.0, +0.42, 0.0], 0.045, 0.05, axis='x', segs=10, uv_center=UV_CRIMSON),
        ]),
    }

    for name, m in meshes_dict.items():
        print(f"  Mesh [{name:24s}]: {len(m[0]):6d} verts, {len(m[3]):6d} tris")

    pil_imgs = [
        Image.fromarray(np.clip(imgs['texture_normal'] * 255.0, 0, 255).astype(np.uint8)),
        Image.fromarray(np.clip(imgs['texture_diffuse'] * 255.0, 0, 255).astype(np.uint8)),
        Image.fromarray(np.clip(imgs['texture_metallic-texture_roughness'] * 255.0, 0, 255).astype(np.uint8)),
    ]
    return meshes_dict, pil_imgs


def quat_x(deg):
    return bhg.quat_from_axis_angle([1.0, 0.0, 0.0], deg)


def quat_y(deg):
    return bhg.quat_from_axis_angle([0.0, 1.0, 0.0], deg)


def quat_z(deg):
    return bhg.quat_from_axis_angle([0.0, 0.0, 1.0], deg)


def build_bibye_pose(
    chassis_dz=0.0,
    chassis_pitch_deg=0.0,
    stab_fold_deg=0.0,
    main_flex_deg=MAIN_FLEX_LOADED,
    main_catch_z=None,
    main_catch_pitch_deg=0.0,
    main_bolt_z=None,
    main_bolt_dy=0.0,
    main_bolt_visible=True,
    upper_flex_deg=UPPER_FLEX_LOADED,
    upper_catch_z=None,
    upper_catch_pitch_deg=0.0,
    upper_bolt_z=None,
    upper_bolt_dy=0.0,
    upper_bolt_visible=True,
    winch_deg=0.0,
    gear_deg=0.0,
    pawl_deg=0.0,
):
    _, _, m_znock, m_str_yaw = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, main_flex_deg)
    _, _, u_znock, u_str_yaw = solve_bow_linkage(UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Z, UPPER_LIMB_LEN, UPPER_BASE_SWEEP, UPPER_STR_LEN, upper_flex_deg)

    m_cz = m_znock if main_catch_z is None else float(main_catch_z)
    m_bz = m_znock if main_bolt_z  is None else float(main_bolt_z)
    u_cz = u_znock if upper_catch_z is None else float(upper_catch_z)
    u_bz = u_znock if upper_bolt_z  is None else float(upper_bolt_z)

    m_scale = [1.0, 1.0, 1.0] if main_bolt_visible else [0.0, 0.0, 0.0]
    u_scale = [1.0, 1.0, 1.0] if upper_bolt_visible else [0.0, 0.0, 0.0]

    return {
        1:  ([0.000, 0.000, chassis_dz], quat_x(chassis_pitch_deg), [1.0, 1.0, 1.0]),
        2:  (list(PIVOTS["Stabilizer_FL"]), quat_z(-stab_fold_deg), [1.0, 1.0, 1.0]),
        3:  (list(PIVOTS["Stabilizer_FR"]), quat_z(+stab_fold_deg), [1.0, 1.0, 1.0]),
        4:  (list(PIVOTS["Stabilizer_RL"]), quat_z(-stab_fold_deg), [1.0, 1.0, 1.0]),
        5:  (list(PIVOTS["Stabilizer_RR"]), quat_z(+stab_fold_deg), [1.0, 1.0, 1.0]),
        6:  (list(PIVOTS["Main_Limb_L"]), quat_y(-main_flex_deg), [1.0, 1.0, 1.0]),
        7:  (list(PIVOTS["Main_Limb_R"]), quat_y(+main_flex_deg), [1.0, 1.0, 1.0]),
        8:  ([0.000, MAIN_LIMB_ROOT_Y, m_znock], quat_y(+m_str_yaw), [1.0, 1.0, 1.0]),
        9:  ([0.000, MAIN_LIMB_ROOT_Y, m_znock], quat_y(-m_str_yaw), [1.0, 1.0, 1.0]),
        10: ([0.000, MAIN_LIMB_ROOT_Y - 0.040, m_cz], quat_x(main_catch_pitch_deg), [1.0, 1.0, 1.0]),
        11: ([0.000, MAIN_LIMB_ROOT_Y + 0.035 + main_bolt_dy, m_bz], [0.0, 0.0, 0.0, 1.0], m_scale),
        12: (list(PIVOTS["Upper_Limb_L"]), quat_y(-upper_flex_deg), [1.0, 1.0, 1.0]),
        13: (list(PIVOTS["Upper_Limb_R"]), quat_y(+upper_flex_deg), [1.0, 1.0, 1.0]),
        14: ([0.000, UPPER_LIMB_ROOT_Y, u_znock], quat_y(+u_str_yaw), [1.0, 1.0, 1.0]),
        15: ([0.000, UPPER_LIMB_ROOT_Y, u_znock], quat_y(-u_str_yaw), [1.0, 1.0, 1.0]),
        16: ([0.000, UPPER_LIMB_ROOT_Y - 0.030, u_cz], quat_x(upper_catch_pitch_deg), [1.0, 1.0, 1.0]),
        17: ([0.000, UPPER_LIMB_ROOT_Y + 0.025 + upper_bolt_dy, u_bz], [0.0, 0.0, 0.0, 1.0], u_scale),
        18: (list(PIVOTS["Winch_Drum_And_Cranks"]), quat_x(winch_deg), [1.0, 1.0, 1.0]),
        19: (list(PIVOTS["Winch_Ratchet_Gear"]), quat_x(gear_deg), [1.0, 1.0, 1.0]),
        20: (list(PIVOTS["Winch_Pawl_And_Lever"]), quat_x(pawl_deg), [1.0, 1.0, 1.0]),
    }


def smoothstep(u):
    u = max(0.0, min(1.0, float(u)))
    return u * u * (3.0 - 2.0 * u)


def build_5_animation_clips():
    pose_loaded = build_bibye_pose(main_flex_deg=MAIN_FLEX_LOADED, upper_flex_deg=UPPER_FLEX_LOADED, main_bolt_visible=True, upper_bolt_visible=True)
    pose_spent  = build_bibye_pose(
        main_flex_deg=0.0,
        main_catch_z=MAIN_Z_NOCK_PEAK,
        main_bolt_z=MAIN_Z_NOCK_SPENT,
        main_bolt_visible=False,
        upper_flex_deg=0.0,
        upper_catch_z=UPPER_Z_NOCK_LOADED,
        upper_bolt_z=UPPER_Z_NOCK_SPENT,
        upper_bolt_visible=False,
        winch_deg=-95.0, gear_deg=+142.5, pawl_deg=0.0
    )

    clip_loaded_idle = [(0.00, pose_loaded), (1.20, pose_loaded)]

    fire_times = [
        0.000, 0.100, 0.250, 0.400, 0.450, 0.468, 0.485, 0.540, 0.600,
        0.650, 0.678, 0.705, 0.760, 0.850, 0.980, 1.150, 1.400, 1.750, 2.200, 3.200
    ]
    clip_fire = []

    for t in fire_times:
        if t <= 0.001:
            clip_fire.append((t, pose_loaded))
            continue
        if t >= 2.200:
            clip_fire.append((t, pose_spent))
            continue

        if t < 0.450:
            u_flex = UPPER_FLEX_LOADED
            u_cz = UPPER_Z_NOCK_LOADED
            u_cpitch = 0.0
            u_bz = UPPER_Z_NOCK_LOADED
            u_vis = True
        elif t < 0.485:
            u_s = (t - 0.450) / 0.035
            u_flex = UPPER_FLEX_LOADED * (1.0 - u_s)
            _, _, u_zn, _ = solve_bow_linkage(UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Z, UPPER_LIMB_LEN, UPPER_BASE_SWEEP, UPPER_STR_LEN, u_flex)
            u_cz = UPPER_Z_NOCK_LOADED
            u_cpitch = -28.0
            u_bz = u_zn
            u_vis = True
        else:
            dt_u = t - 0.485
            u_flex = max(0.0, 2.5 * math.exp(-6.0 * dt_u) * math.sin(28.0 * dt_u))
            u_cz = UPPER_Z_NOCK_LOADED
            u_cpitch = -28.0 * max(0.0, 1.0 - dt_u * 3.0)
            u_bz = UPPER_Z_NOCK_SPENT
            u_vis = False

        if t < 0.100:
            m_flex = MAIN_FLEX_LOADED
            m_cz = MAIN_Z_NOCK_LOADED
            m_cpitch = 0.0
            m_bz = MAIN_Z_NOCK_LOADED
            m_vis = True
            w_deg, g_deg, p_deg = 0.0, 0.0, 0.0
        elif t <= 0.450:
            u_d = smoothstep((t - 0.100) / 0.350)
            m_flex = MAIN_FLEX_LOADED + (MAIN_FLEX_PEAK - MAIN_FLEX_LOADED) * u_d
            _, _, m_zn, _ = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, m_flex)
            m_cz = m_zn
            m_cpitch = 0.0
            m_bz = m_zn
            m_vis = True
            w_deg = -95.0 * u_d
            g_deg = +142.5 * u_d
            p_deg = +12.0 * math.sin(u_d * math.pi * 2.0)
        elif t < 0.650:
            m_flex = MAIN_FLEX_PEAK
            m_cz = MAIN_Z_NOCK_PEAK
            m_cpitch = -10.0 * smoothstep((t - 0.600) / 0.050) if t > 0.600 else 0.0
            m_bz = MAIN_Z_NOCK_PEAK
            m_vis = True
            w_deg, g_deg = -95.0, +142.5
            p_deg = -30.0 * smoothstep((t - 0.600) / 0.050) if t > 0.600 else 0.0
        elif t < 0.705:
            u_m = (t - 0.650) / 0.055
            m_flex = MAIN_FLEX_PEAK * (1.0 - u_m)
            _, _, m_zn, _ = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, m_flex)
            m_cz = MAIN_Z_NOCK_PEAK
            m_cpitch = -32.0
            m_bz = m_zn
            m_vis = True
            w_deg, g_deg, p_deg = -95.0, +142.5, -32.0
        else:
            dt_m = t - 0.705
            m_flex = max(0.0, 3.8 * math.exp(-4.5 * dt_m) * math.sin(22.0 * dt_m))
            m_cz = MAIN_Z_NOCK_PEAK
            m_cpitch = -32.0 * max(0.0, 1.0 - dt_m * 2.2)
            m_bz = MAIN_Z_NOCK_SPENT
            m_vis = False
            w_deg, g_deg = -95.0, +142.5
            p_deg = -32.0 * max(0.0, 1.0 - dt_m * 2.2)

        if t < 0.450:
            c_dz, c_pitch = 0.0, 0.0
        elif t < 0.650:
            u_r1 = (t - 0.450) / 0.200
            c_dz = -0.024 * math.sin(u_r1 * math.pi)
            c_pitch = -0.35 * math.sin(u_r1 * math.pi)
        elif t < 0.850:
            u_r2 = smoothstep((t - 0.650) / 0.200)
            c_dz = -0.115 * u_r2
            c_pitch = -1.85 * math.sin(u_r2 * math.pi)
        else:
            u_rec = smoothstep((t - 0.850) / (2.200 - 0.850))
            c_dz = -0.115 * (1.0 - u_rec)
            c_pitch = +0.45 * math.sin(u_rec * math.pi) * (1.0 - u_rec)

        clip_fire.append((t, build_bibye_pose(
            chassis_dz=c_dz, chassis_pitch_deg=c_pitch,
            main_flex_deg=m_flex, main_catch_z=m_cz, main_catch_pitch_deg=m_cpitch,
            main_bolt_z=m_bz, main_bolt_dy=0.0, main_bolt_visible=m_vis,
            upper_flex_deg=u_flex, upper_catch_z=u_cz, upper_catch_pitch_deg=u_cpitch,
            upper_bolt_z=u_bz, upper_bolt_dy=0.0, upper_bolt_visible=u_vis,
            winch_deg=w_deg, gear_deg=g_deg, pawl_deg=p_deg
        )))

    clip_spent = [(0.00, pose_spent), (1.20, pose_spent)]

    reload_times = [
        0.00, 0.35, 0.60, 0.75, 1.15, 1.55, 1.95, 2.35, 2.85, 3.10,
        3.45, 3.80, 4.10, 4.35, 4.65, 4.95, 5.35, 5.65, 6.00
    ]
    clip_reload = []
    for t in reload_times:
        if t <= 0.001:
            clip_reload.append((t, pose_spent))
            continue
        if t >= 5.65:
            clip_reload.append((t, pose_loaded))
            continue

        if t < 0.60:
            u_fwd = smoothstep(t / 0.60)
            m_flex = 0.0
            m_cz = MAIN_Z_NOCK_PEAK * (1.0 - u_fwd) + MAIN_Z_NOCK_SPENT * u_fwd
            m_cpitch = -24.0 * math.sin(u_fwd * math.pi)
            w_deg = -95.0 * (1.0 - u_fwd) + 260.0 * u_fwd
            g_deg = +142.5 * (1.0 - u_fwd) - 390.0 * u_fwd
            p_deg = -18.0
        elif t < 0.75:
            m_flex = 0.0
            m_cz = MAIN_Z_NOCK_SPENT
            m_cpitch = 0.0
            w_deg, g_deg, p_deg = 260.0, -390.0, 0.0
        elif t < 2.85:
            u_wind = smoothstep((t - 0.75) / (2.85 - 0.75))
            m_flex = MAIN_FLEX_LOADED * u_wind
            _, _, m_zn, _ = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, m_flex)
            m_cz = m_zn
            m_cpitch = 0.0
            w_deg = 260.0 * (1.0 - u_wind) + (-720.0) * u_wind
            g_deg = -390.0 * (1.0 - u_wind) + (+1080.0) * u_wind
            p_deg = +14.0 * abs(math.sin(u_wind * math.pi * 8.0))
        else:
            m_flex = MAIN_FLEX_LOADED
            m_cz = MAIN_Z_NOCK_LOADED
            m_cpitch = 0.0
            u_wset = smoothstep(min(1.0, (t - 2.85) / 2.50))
            w_deg = -720.0 * (1.0 - u_wset)
            g_deg = +1080.0 * (1.0 - u_wset)
            p_deg = 0.0

        if t < 3.10:
            m_bz, m_bdy, m_vis = MAIN_Z_NOCK_SPENT, 0.0, False
        elif t < 3.80:
            u_mb = smoothstep((t - 3.10) / 0.70)
            m_bz = (MAIN_Z_NOCK_LOADED + 0.45) * (1.0 - u_mb) + MAIN_Z_NOCK_LOADED * u_mb
            m_bdy = +0.52 * (1.0 - u_mb)
            m_vis = True
        else:
            m_bz, m_bdy, m_vis = MAIN_Z_NOCK_LOADED, 0.0, True

        if t < 4.10:
            u_flex = 0.0
            u_cz = UPPER_Z_NOCK_LOADED
            u_cpitch = 0.0
            u_bz, u_bdy, u_vis = UPPER_Z_NOCK_SPENT, 0.0, False
        elif t < 4.35:
            u_ufwd = smoothstep((t - 4.10) / 0.25)
            u_flex = 0.0
            u_cz = UPPER_Z_NOCK_LOADED * (1.0 - u_ufwd) + UPPER_Z_NOCK_SPENT * u_ufwd
            u_cpitch = -20.0 * math.sin(u_ufwd * math.pi)
            u_bz, u_bdy, u_vis = UPPER_Z_NOCK_SPENT, 0.0, False
        elif t < 4.95:
            u_udraw = smoothstep((t - 4.35) / 0.60)
            u_flex = UPPER_FLEX_LOADED * u_udraw
            _, _, u_zn, _ = solve_bow_linkage(UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Z, UPPER_LIMB_LEN, UPPER_BASE_SWEEP, UPPER_STR_LEN, u_flex)
            u_cz = u_zn
            u_cpitch = 0.0
            u_bz, u_bdy, u_vis = UPPER_Z_NOCK_SPENT, 0.0, False
        else:
            u_flex = UPPER_FLEX_LOADED
            u_cz = UPPER_Z_NOCK_LOADED
            u_cpitch = 0.0
            u_ub = smoothstep(min(1.0, (t - 4.95) / 0.40))
            u_bz = (UPPER_Z_NOCK_LOADED + 0.28) * (1.0 - u_ub) + UPPER_Z_NOCK_LOADED * u_ub
            u_bdy = +0.30 * (1.0 - u_ub)
            u_vis = True

        clip_reload.append((t, build_bibye_pose(
            main_flex_deg=m_flex, main_catch_z=m_cz, main_catch_pitch_deg=m_cpitch,
            main_bolt_z=m_bz, main_bolt_dy=m_bdy, main_bolt_visible=m_vis,
            upper_flex_deg=u_flex, upper_catch_z=u_cz, upper_catch_pitch_deg=u_cpitch,
            upper_bolt_z=u_bz, upper_bolt_dy=u_bdy, upper_bolt_visible=u_vis,
            winch_deg=w_deg, gear_deg=g_deg, pawl_deg=p_deg
        )))

    deploy_times = [0.00, 0.30, 0.75, 1.25, 1.65, 1.85, 2.05, 2.40]
    clip_deploy = []
    for t in deploy_times:
        if t <= 0.001 or t >= 2.05:
            clip_deploy.append((t, pose_loaded))
            continue
        if t < 0.75:
            u_up = smoothstep(t / 0.75)
            s_deg = 32.0 * u_up
            c_pitch = 0.0
        elif t < 1.65:
            u_dn = smoothstep((t - 0.75) / 0.90)
            s_deg = 32.0 * (1.0 - u_dn)
            c_pitch = 0.0
        else:
            s_deg = 0.0
            u_sh = (t - 1.65) / 0.40
            c_pitch = -0.8 * math.sin(u_sh * math.pi)
        clip_deploy.append((t, build_bibye_pose(chassis_pitch_deg=c_pitch, stab_fold_deg=s_deg)))

    return [
        ("01_BiBye_LoadedIdle",        clip_loaded_idle),
        ("02_BiBye_TwoStage_Fire",     clip_fire),
        ("03_BiBye_Spent_Recovery",    clip_spent),
        ("04_BiBye_Mechanical_Reload", clip_reload),
        ("05_BiBye_Stabilizer_Deploy", clip_deploy),
    ]


class BiByellistaGLBBuilder(bhg.GLBBuilder):
    def add_animation_with_scale(self, name: str, times: list, tracks: dict, extras: dict = None):
        t_arr = np.ascontiguousarray(times, dtype=np.float32)
        t_acc = self._append_accessor(t_arr, 5126, "SCALAR")
        samplers = []
        channels = []
        for n_idx, tr_dict in tracks.items():
            if "translation" in tr_dict:
                tr_arr = np.ascontiguousarray(tr_dict["translation"], dtype=np.float32)
                tr_acc = self._append_accessor(tr_arr, 5126, "VEC3")
                s_idx = len(samplers)
                samplers.append({"input": t_acc, "interpolation": "LINEAR", "output": tr_acc})
                channels.append({"sampler": s_idx, "target": {"node": n_idx, "path": "translation"}})
            if "rotation" in tr_dict:
                rt_arr = np.ascontiguousarray(tr_dict["rotation"], dtype=np.float32)
                norms = np.linalg.norm(rt_arr, axis=1, keepdims=True)
                rt_arr = rt_arr / np.maximum(norms, 1e-9)
                rt_acc = self._append_accessor(rt_arr, 5126, "VEC4")
                s_idx = len(samplers)
                samplers.append({"input": t_acc, "interpolation": "LINEAR", "output": rt_acc})
                channels.append({"sampler": s_idx, "target": {"node": n_idx, "path": "rotation"}})
            if "scale" in tr_dict:
                sc_arr = np.ascontiguousarray(tr_dict["scale"], dtype=np.float32)
                sc_acc = self._append_accessor(sc_arr, 5126, "VEC3")
                s_idx = len(samplers)
                samplers.append({"input": t_acc, "interpolation": "STEP", "output": sc_acc})
                channels.append({"sampler": s_idx, "target": {"node": n_idx, "path": "scale"}})
        anim = {"name": name, "samplers": samplers, "channels": channels}
        if extras:
            anim["extras"] = extras
        self.animations.append(anim)

    def build_bibye_glb_bytes(self, extras: dict = None):
        while len(self.bin_buf) % 4 != 0:
            self.bin_buf.append(0)
        j = {
            "asset": {"version": "2.0", "generator": "Castleward Bi-Bye-llista Siege Engine Builder v2.0"},
            "scene": 0,
            "scenes": [{"name": "BiByellistaSiegeScene", "nodes": [0]}],
            "nodes": self.nodes,
            "meshes": self.meshes,
            "materials": self.materials,
            "textures": self.textures,
            "images": self.images,
            "accessors": self.accessors,
            "bufferViews": self.buffer_views,
            "buffers": [{"byteLength": len(self.bin_buf)}],
            "animations": self.animations,
        }
        if extras:
            j["extras"] = extras
            j["scenes"][0]["extras"] = extras
            self.nodes[0]["extras"] = extras
        json_bytes = bytearray(json.dumps(j, separators=(',', ':')).encode('utf-8'))
        while len(json_bytes) % 4 != 0:
            json_bytes.append(0x20)
        total_len = 12 + 8 + len(json_bytes) + 8 + len(self.bin_buf)
        out = bytearray()
        out.extend(struct.pack('<4sII', b'glTF', 2, total_len))
        out.extend(struct.pack('<I4s', len(json_bytes), b'JSON'))
        out.extend(json_bytes)
        out.extend(struct.pack('<I4s', len(self.bin_buf), b'BIN\x00'))
        out.extend(self.bin_buf)
        return bytes(out)


def export_bibyellista_glb(meshes_dict, imgs, clips, out_glb_path: Path):
    builder = BiByellistaGLBBuilder()

    tex_diffuse = imgs[1].resize((1024, 1024), Image.LANCZOS)
    tex_norm    = imgs[0].resize((1024, 1024), Image.LANCZOS)
    tex_mr      = imgs[2].resize((1024, 1024), Image.LANCZOS)

    idx_diff = builder.add_image_pil(tex_diffuse, "bibye_diffuse", "JPEG", quality=92)
    idx_norm = builder.add_image_pil(tex_norm,    "bibye_normal",  "JPEG", quality=92)
    idx_mr   = builder.add_image_pil(tex_mr,      "bibye_mr",      "JPEG", quality=92)

    builder.materials.append({
        "name": "Castleward_BiByellista_PBR",
        "pbrMetallicRoughness": {
            "baseColorTexture": {"index": idx_diff},
            "metallicRoughnessTexture": {"index": idx_mr},
            "metallicFactor": 1.0,
            "roughnessFactor": 1.0,
        },
        "normalTexture": {"index": idx_norm, "scale": 1.0},
        "doubleSided": True,
    })

    mesh_indices = {}
    for name in ORDERED_NODES:
        p, n, u, t = meshes_dict[name]
        mesh_indices[name] = builder.add_mesh(f"{name}_Mesh", p, n, u, t, mat_idx=0)

    root_children = [1, 2, 3, 4, 5, 24]
    chassis_children = list(range(6, 21)) + [21, 22, 23, 25, 26]

    builder.add_node("BiBye_Root", translation=[0.0, 0.0, 0.0], rotation=[0.0, 0.0, 0.0, 1.0], children=root_children)

    pose0 = build_bibye_pose(main_flex_deg=MAIN_FLEX_LOADED, upper_flex_deg=UPPER_FLEX_LOADED)
    for idx_off, name in enumerate(ORDERED_NODES):
        n_idx = idx_off + 1
        tr0, rt0, sc0 = pose0[n_idx]
        ch = chassis_children if n_idx == 1 else None
        builder.add_node(name, mesh_idx=mesh_indices[name], translation=tr0, rotation=rt0, children=ch)
        builder.nodes[n_idx]["scale"] = [float(x) for x in sc0]

    for loc_name, loc_info in LOCATORS.items():
        n_idx = builder.add_node(loc_name, translation=loc_info["translation"], rotation=loc_info["rotation"])
        builder.nodes[n_idx]["extras"] = {
            "role": "castleward_bibyellista_locator",
            "parent": loc_info["parent"],
            "description": loc_info["description"]
        }

    target_nodes = list(range(1, 1 + len(ORDERED_NODES)))
    scale_nodes = {11, 17}
    for clip_name, kf_list in clips:
        times = [t for (t, _) in kf_list]
        tracks = {}
        for n_idx in target_nodes:
            tr_dict = {
                "translation": [pose[n_idx][0] for (_, pose) in kf_list],
                "rotation":    [pose[n_idx][1] for (_, pose) in kf_list],
            }
            if n_idx in scale_nodes:
                tr_dict["scale"] = [pose[n_idx][2] for (_, pose) in kf_list]
            tracks[n_idx] = tr_dict
        builder.add_animation_with_scale(clip_name, times, tracks, extras=ANIMATION_EVENTS[clip_name])

    extras = {
        "assetId": "bi-bye-llista",
        "version": "2.0",
        "scaleFactor": SCALE,
        "symmetryCenterOffsetRawX": X0_RAW,
        "dimensionsMeters": {
            "overallHeight": 3.100,
            "mainSwordBowWingspanUnflexed": 5.388,
            "mainSwordBowNockSpanUnflexed": round(2.0 * MAIN_TIP_X_SPENT, 3),
            "mainSwordBowNockSpanLoaded": round(2.0 * MAIN_TIP_X_LOADED, 3),
            "mainSwordBowNockSpanPeak": round(2.0 * MAIN_TIP_X_PEAK, 3),
            "upperBowNockSpanUnflexed": round(2.0 * UPPER_TIP_X_SPENT, 3),
            "mainSiegeBoltLength": MAIN_BOLT_LEN,
            "upperConditioningBoltLength": UPPER_BOLT_LEN,
            "chassisLength": 3.735,
            "loadedTotalLengthWithBolt": round(2.055 + MAIN_Z_NOCK_LOADED + MAIN_BOLT_LEN, 3),
        },
        "pivots": PIVOTS,
        "locators": LOCATORS,
        "animationEvents": ANIMATION_EVENTS,
        "projectileHandoff": PROJECTILE_HANDOFF,
        "twoStageFiringSpec": {
            "small_bolt_fire_sec": 0.450,
            "small_bolt_handoff_sec": 0.485,
            "main_bolt_fire_sec": 0.650,
            "main_bolt_handoff_sec": 0.705,
            "inter_shot_interval_sec": 0.200,
            "small_bolt_muzzle": "small_bolt_muzzle",
            "main_bolt_muzzle": "main_bolt_muzzle",
        }
    }
    out_bytes = builder.build_bibye_glb_bytes(extras=extras)
    out_glb_path.write_bytes(out_bytes)
    sha256 = hashlib.sha256(out_bytes).hexdigest()
    print(f"[OK] Exported GLB: {out_glb_path} ({len(out_bytes):,} bytes / {len(out_bytes)/1048576:.2f} MB, SHA-256: {sha256})")
    return sha256


def export_bibyellista_blend(meshes_dict, imgs, out_blend_path: Path):
    template_blend = (Path(__file__).resolve().parent / 'Spellblade-production-third-person.blend')
    bf = blend_io.BlendFile(str(template_blend))

    stab_front_mesh = mbu.concat_meshes([
        bhg.shift_mesh_to_pivot(meshes_dict["Stabilizer_FL"], [-x for x in PIVOTS["Stabilizer_FL"]]),
        bhg.shift_mesh_to_pivot(meshes_dict["Stabilizer_FR"], [-x for x in PIVOTS["Stabilizer_FR"]]),
    ])
    stab_rear_mesh = mbu.concat_meshes([
        bhg.shift_mesh_to_pivot(meshes_dict["Stabilizer_RL"], [-x for x in PIVOTS["Stabilizer_RL"]]),
        bhg.shift_mesh_to_pivot(meshes_dict["Stabilizer_RR"], [-x for x in PIVOTS["Stabilizer_RR"]]),
    ])

    blend_slots = [
        ("OBBreastplate",    "MEBreastplate",          "Carriage_Chassis",        meshes_dict["Carriage_Chassis"],        PIVOTS["Carriage_Chassis"]),
        ("OBBoot.L",         "MEBoot.L",               "Stabilizers_Front",       stab_front_mesh,                        [0.0, 0.0, 0.0]),
        ("OBBoot.R",         "MEBoot.R",               "Stabilizers_Rear",        stab_rear_mesh,                         [0.0, 0.0, 0.0]),
        ("OBHeroSword",      "MEHeroSword",            "Main_Limb_L",             meshes_dict["Main_Limb_L"],             PIVOTS["Main_Limb_L"]),
        ("OBHelmetShell",    "MEHelmetShellCanonical", "Main_Limb_R",             meshes_dict["Main_Limb_R"],             PIVOTS["Main_Limb_R"]),
        ("OBPauldron.L",     "MEPauldron.L",           "Main_String_L",           meshes_dict["Main_String_L"],           PIVOTS["Main_String_L"]),
        ("OBPauldron.R",     "MEPauldron.R",           "Main_String_R",           meshes_dict["Main_String_R"],           PIVOTS["Main_String_R"]),
        ("OBGreave.L",       "MEGreave.L",             "Main_Draw_Catch",         meshes_dict["Main_Draw_Catch"],         PIVOTS["Main_Draw_Catch"]),
        ("OBGreave.R",       "MEGreave.R",             "Main_Siege_Bolt",         meshes_dict["Main_Siege_Bolt"],         PIVOTS["Main_Siege_Bolt"]),
        ("OBGauntlet.L",     "MEGauntlet.L.001",       "Upper_Limb_L",            meshes_dict["Upper_Limb_L"],            PIVOTS["Upper_Limb_L"]),
        ("OBGauntlet.R",     "MEGauntlet.R.001",       "Upper_Limb_R",            meshes_dict["Upper_Limb_R"],            PIVOTS["Upper_Limb_R"]),
        ("OBHelmetJaw",      "MEHelmetJawCanonical",   "Upper_String_L",          meshes_dict["Upper_String_L"],          PIVOTS["Upper_String_L"]),
        ("OBVisor",          "MEVisorCanonical",       "Upper_String_R",          meshes_dict["Upper_String_R"],          PIVOTS["Upper_String_R"]),
        ("OBCrest",          "MECrestCanonical",       "Upper_Catch_And_Trigger", meshes_dict["Upper_Catch_And_Trigger"], PIVOTS["Upper_Catch_And_Trigger"]),
        ("OBPalmRune",       "MEPalmRune.001",         "Upper_Conditioning_Bolt", meshes_dict["Upper_Conditioning_Bolt"], PIVOTS["Upper_Conditioning_Bolt"]),
        ("OBTabardFront",    "METabardFront",          "Winch_Drum_And_Cranks",   meshes_dict["Winch_Drum_And_Cranks"],   PIVOTS["Winch_Drum_And_Cranks"]),
        ("OBTabardBack",     "METabardBack",           "Winch_Ratchet_Gear",      meshes_dict["Winch_Ratchet_Gear"],      PIVOTS["Winch_Ratchet_Gear"]),
        ("OBSpellbladeReviewFloor", "MEPlane",         "Winch_Pawl_And_Lever",    meshes_dict["Winch_Pawl_And_Lever"],    PIVOTS["Winch_Pawl_And_Lever"]),
    ]
    ob_layout = bf.get_layout("Object")
    for old_ob, old_me, new_name, m_tup, pv in blend_slots:
        bf.replace_mesh(old_me, bhg.TriangleMeshAdapter(m_tup))
        for b in bf.blocks:
            if b["code"] == "ME" and bf.get_id_name(b) == old_me:
                bhg.set_id_name(b, f"ME{new_name}")
            elif b["code"] == "OB" and bf.get_id_name(b) == old_ob:
                bhg.set_id_name(b, f"OB{new_name}")
                struct.pack_into("<3f", b["payload"], ob_layout["loc"][0], float(pv[0]), float(pv[1]), float(pv[2]))

    ac_blocks = [b for b in bf.blocks if b["code"] == "AC"]
    clip_names = [
        "AC01_BiBye_LoadedIdle",
        "AC02_BiBye_TwoStage_Fire",
        "AC03_BiBye_Spent_Recovery",
        "AC04_BiBye_Mechanical_Reload",
        "AC05_BiBye_Stabilizer_Deploy",
    ]
    for ac_b, cname in zip(ac_blocks[:5], clip_names):
        bhg.set_id_name(ac_b, cname)

    bf.update_packed_image("IMSpellbladeBanner", imgs[1].resize((512, 512), Image.LANCZOS))
    bf.update_packed_image("IMKitMetalWear",     imgs[0].resize((512, 512), Image.LANCZOS))
    bf.update_packed_image("IMKitMatteWear",     imgs[2].resize((512, 512), Image.LANCZOS))

    n_bytes = bf.save(str(out_blend_path))
    sha256 = hashlib.sha256(out_blend_path.read_bytes()).hexdigest()
    print(f"[OK] Exported Blend: {out_blend_path} ({n_bytes:,} bytes / {n_bytes/1048576:.2f} MB, SHA-256: {sha256})")
    return sha256


def verify_reimported_bibye_glb(glb_path: Path):
    raw = glb_path.read_bytes()
    magic, version, total_len = struct.unpack('<4sII', raw[:12])
    assert magic == b'glTF' and version == 2 and total_len == len(raw)
    j_len, _ = struct.unpack('<I4s', raw[12:20])
    j_str = raw[20:20 + j_len].decode('utf-8')
    j = json.loads(j_str)
    b_off = 20 + j_len
    b_len, _ = struct.unpack('<I4s', raw[b_off:b_off + 8])
    bin_buf = raw[b_off + 8:b_off + 8 + b_len]

    assert "Gatehouse" not in j_str and "gatehouse" not in j_str, "Found leftover gatehouse string in GLB JSON!"
    assert "extras" in j and "animationEvents" in j["extras"], "Missing gltf.extras.animationEvents!"
    assert "projectileHandoff" in j["extras"], "Missing gltf.extras.projectileHandoff!"

    print("\n=== BI-BYE-LLISTA v2.0 REIMPORT & TRANSITION VERIFICATION REPORT ===")
    print(f"File: {glb_path.name} ({len(raw):,} bytes)")
    print(f"Generator: {j['asset']['generator']} | Scene: {j['scenes'][0]['name']}")
    print(f"Nodes: {len(j['nodes'])} | Meshes: {len(j['meshes'])} | Materials: {len(j['materials'])} | Textures: {len(j['textures'])} | Animations: {len(j['animations'])}")

    def read_acc(acc_idx):
        acc = j['accessors'][acc_idx]
        bv = j['bufferViews'][acc['bufferView']]
        off = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
        cnt = acc['count']
        n_comp = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}[acc['type']]
        arr = np.frombuffer(bin_buf, dtype=np.float32, count=cnt * n_comp, offset=off)
        return arr.reshape(cnt, n_comp) if n_comp > 1 else arr

    anim_map = {}
    for idx, anim in enumerate(j['animations']):
        times = read_acc(anim['samplers'][0]['input'])
        dur = float(times[-1] - times[0])
        ev_keys = list(anim.get('extras', {}).get('events', {}).keys())
        print(f"  Anim[{idx}] {anim['name']:28s}: duration={dur:.2f}s, keyframes={len(times):2d}, channels={len(anim['channels']):2d}, events={ev_keys}")
        anim_map[anim['name']] = anim

    def sample_endpoints(anim):
        s_dict, e_dict = {}, {}
        for ch in anim['channels']:
            key = (ch['target']['node'], ch['target']['path'])
            vals = read_acc(anim['samplers'][ch['sampler']]['output'])
            s_dict[key] = vals[0]
            e_dict[key] = vals[-1]
        return s_dict, e_dict

    l_s, l_e   = sample_endpoints(anim_map["01_BiBye_LoadedIdle"])
    f_s, f_e   = sample_endpoints(anim_map["02_BiBye_TwoStage_Fire"])
    sp_s, sp_e = sample_endpoints(anim_map["03_BiBye_Spent_Recovery"])
    r_s, r_e   = sample_endpoints(anim_map["04_BiBye_Mechanical_Reload"])
    d_s, d_e   = sample_endpoints(anim_map["05_BiBye_Stabilizer_Deploy"])

    err_fire_start  = max(float(np.max(np.abs(f_s[k] - l_e[k]))) for k in l_e)
    err_fire_to_sp  = max(float(np.max(np.abs(f_e[k] - sp_s[k]))) for k in sp_s)
    err_rel_start   = max(float(np.max(np.abs(r_s[k] - sp_e[k]))) for k in sp_e)
    err_rel_to_load = max(float(np.max(np.abs(r_e[k] - l_s[k]))) for k in l_s)
    err_dep_loop    = max(float(np.max(np.abs(d_e[k] - l_s[k]))) for k in l_s)

    mount_nodes = [6, 7, 12, 13, 18, 19, 20]
    max_mount_drift = 0.0
    for anim in j['animations']:
        for ch in anim['channels']:
            if ch['target']['node'] in mount_nodes and ch['target']['path'] == 'translation':
                vals = read_acc(anim['samplers'][ch['sampler']]['output'])
                drift = float(np.max(np.abs(vals - vals[0:1])))
                max_mount_drift = max(max_mount_drift, drift)

    print(f"  Transition Continuity Drift -> Loaded->Fire: {err_fire_start:.6f} | Fire->Spent: {err_fire_to_sp:.6f} | Spent->Reload: {err_rel_start:.6f} | Reload->Loaded: {err_rel_to_load:.6f} | Deploy->Loaded: {err_dep_loop:.6f}")
    print(f"  Interrupted Transition Mount Drift (Nodes 6,7,12,13,18,19,20 under Carriage_Chassis): {max_mount_drift:.6f} m")
    assert max(err_fire_start, err_fire_to_sp, err_rel_start, err_rel_to_load, err_dep_loop, max_mount_drift) < 1e-6
    print("=== BI-BYE-LLISTA v2.0 REIMPORT VERIFICATION PASSED (0.000000 DRIFT) ===\n")


if __name__ == '__main__':
    meshes_dict, imgs = build_bibyellista_meshes_and_textures()
    clips = build_5_animation_clips()
    out_glb   = OUT_DIR / 'Bi_Bye_llista_GameReady_PBR.glb'
    out_blend = OUT_DIR / 'Bi_Bye_llista.blend'
    export_bibyellista_glb(meshes_dict, imgs, clips, out_glb)
    export_bibyellista_blend(meshes_dict, imgs, out_blend)
    verify_reimported_bibye_glb(out_glb)

    # Also export the preserved v1.0 baseline GLB and Blend for comparison
    sys.path.insert(0, "/tmp")
    import build_v1_baseline as bv1
    meshes_v1 = dict(meshes_dict)
    meshes_v1["Main_Limb_L"]  = bv1.make_v1_sword_limb_mesh(-1.0, bv1.MAIN_LIMB_LEN, MAIN_BASE_SWEEP, is_upper=False)
    meshes_v1["Main_Limb_R"]  = bv1.make_v1_sword_limb_mesh(+1.0, bv1.MAIN_LIMB_LEN, MAIN_BASE_SWEEP, is_upper=False)
    meshes_v1["Upper_Limb_L"] = bv1.make_v1_sword_limb_mesh(-1.0, bv1.UPPER_LIMB_LEN, UPPER_BASE_SWEEP, is_upper=True)
    meshes_v1["Upper_Limb_R"] = bv1.make_v1_sword_limb_mesh(+1.0, bv1.UPPER_LIMB_LEN, UPPER_BASE_SWEEP, is_upper=True)
    export_bibyellista_glb(meshes_v1, imgs, clips, OUT_DIR / 'Bi_Bye_llista_v1_Baseline_PBR.glb')
    export_bibyellista_blend(meshes_v1, imgs, OUT_DIR / 'Bi_Bye_llista_v1_Baseline.blend')
