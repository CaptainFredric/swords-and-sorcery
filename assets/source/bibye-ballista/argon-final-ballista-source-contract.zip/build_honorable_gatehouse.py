#!/usr/bin/env python3
"""
Production Reconstruction, Rigging, Animation & Export Pipeline for:
The Honorable Entry Gatehouse (Castleward Bastion Breach Stage 1 -> Stage 2)

Reads ASSETS/base_basic_pbr.glb, preserves the approved design and PBR textures,
trims the unwanted protruding rear ground slab, separates the static structure
and moving mechanical hierarchy (Door_L, Door_R, Portcullis, Winch_Drum,
Winch_Gear_L, Winch_Gear_R, Counterweight_L, Counterweight_R), caps all surgical
separation seams with watertight geometry mapped to authentic PBR UV patches,
authors the 4 required animation clips:
  - Gate_ClosedIdle (1.00 s)
  - Gate_Open       (3.60 s)
  - Gate_OpenIdle   (1.00 s)
  - Gate_Close      (3.60 s)
and exports:
  1. Honorable_Entry_Gatehouse_GameReady_PBR.glb
  2. Honorable_Entry_Gatehouse.blend
"""
import io
import os
import sys
import json
import math
import struct
import hashlib
from pathlib import Path
import numpy as np
from PIL import Image

WORK_ROOT = Path(__file__).resolve().parent
GATEHOUSE_DIR = WORK_ROOT / 'gatehouse'
OUT_DIR = Path(__file__).resolve().parent
OUT_DIR.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(WORK_ROOT / '04_RECONSTRUCTION_SCRIPTS'))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import glb_core
import mesh_builder_utils as mbu
import blend_io

# Load mesh surgical helper functions from build_rightful_renowner.py
brr_code = (Path(__file__).resolve().parent / 'build_rightful_renowner.py' if (Path(__file__).resolve().parent / 'build_rightful_renowner.py').exists() else (WORK_ROOT / '04_RECONSTRUCTION_SCRIPTS' / 'build_rightful_renowner.py')).read_text()
exec("def load_glb_any" + brr_code.split("def load_glb_any")[1].split("# Load both Rodin GLBs")[0], globals())


def quat_from_axis_angle(axis, deg):
    ax = np.array(axis, dtype=np.float64)
    norm = float(np.linalg.norm(ax))
    if norm < 1e-12 or abs(deg) < 1e-9:
        return [0.0, 0.0, 0.0, 1.0]
    ax /= norm
    half = math.radians(deg) * 0.5
    s = math.sin(half)
    c = math.cos(half)
    q = np.array([ax[0] * s, ax[1] * s, ax[2] * s, c], dtype=np.float32)
    q /= np.linalg.norm(q)
    return [float(q[0]), float(q[1]), float(q[2]), float(q[3])]


class GLBBuilder:
    """Self-contained glTF 2.0 binary (.glb) writer with meshes, textures, nodes, and animations."""
    def __init__(self):
        self.bin_buf = bytearray()
        self.buffer_views = []
        self.accessors = []
        self.images = []
        self.textures = []
        self.materials = []
        self.meshes = []
        self.nodes = []
        self.animations = []

    def _append_bytes(self, raw_bytes: bytes, target=None):
        while len(self.bin_buf) % 4 != 0:
            self.bin_buf.append(0)
        offset = len(self.bin_buf)
        self.bin_buf.extend(raw_bytes)
        bv = {"buffer": 0, "byteOffset": offset, "byteLength": len(raw_bytes)}
        if target is not None:
            bv["target"] = target
        idx = len(self.buffer_views)
        self.buffer_views.append(bv)
        return idx

    def _append_accessor(self, arr: np.ndarray, ctype: int, atype: str, target=None):
        bv_idx = self._append_bytes(arr.tobytes(), target=target)
        if arr.ndim == 1:
            mn = [int(arr.min())] if ctype == 5125 else [float(arr.min())]
            mx = [int(arr.max())] if ctype == 5125 else [float(arr.max())]
        else:
            mn = [float(x) for x in arr.min(axis=0)]
            mx = [float(x) for x in arr.max(axis=0)]
        acc = {
            "bufferView": bv_idx,
            "byteOffset": 0,
            "componentType": ctype,
            "count": int(len(arr)),
            "type": atype,
            "min": mn,
            "max": mx,
        }
        idx = len(self.accessors)
        self.accessors.append(acc)
        return idx

    def add_image_pil(self, pil_img: Image.Image, name: str, fmt="JPEG", quality=92):
        buf = io.BytesIO()
        if fmt.upper() == "JPEG":
            pil_img.convert("RGB").save(buf, format="JPEG", quality=quality)
            mime = "image/jpeg"
        else:
            pil_img.save(buf, format="PNG")
            mime = "image/png"
        bv_idx = self._append_bytes(buf.getvalue())
        img_idx = len(self.images)
        self.images.append({"name": name, "bufferView": bv_idx, "mimeType": mime})
        tex_idx = len(self.textures)
        self.textures.append({"source": img_idx})
        return tex_idx

    def add_mesh(self, name: str, pos: np.ndarray, norm: np.ndarray, uv: np.ndarray, tris: np.ndarray, mat_idx=0):
        p_arr = np.ascontiguousarray(pos, dtype=np.float32)
        n_arr = np.ascontiguousarray(norm, dtype=np.float32)
        u_arr = np.ascontiguousarray(uv, dtype=np.float32)
        t_arr = np.ascontiguousarray(tris.reshape(-1), dtype=np.uint32)

        acc_p = self._append_accessor(p_arr, 5126, "VEC3", target=34962)
        acc_n = self._append_accessor(n_arr, 5126, "VEC3", target=34962)
        acc_u = self._append_accessor(u_arr, 5126, "VEC2", target=34962)
        acc_t = self._append_accessor(t_arr, 5125, "SCALAR", target=34963)

        m_idx = len(self.meshes)
        self.meshes.append({
            "name": name,
            "primitives": [{
                "attributes": {"POSITION": acc_p, "NORMAL": acc_n, "TEXCOORD_0": acc_u},
                "indices": acc_t,
                "material": mat_idx,
            }]
        })
        return m_idx

    def add_node(self, name: str, mesh_idx=None, translation=None, rotation=None, children=None):
        nd = {"name": name}
        if mesh_idx is not None:
            nd["mesh"] = mesh_idx
        if translation is not None:
            nd["translation"] = [float(x) for x in translation]
        if rotation is not None:
            nd["rotation"] = [float(x) for x in rotation]
        if children:
            nd["children"] = list(children)
        idx = len(self.nodes)
        self.nodes.append(nd)
        return idx

    def add_animation(self, name: str, times: list, tracks: dict, extras: dict = None):
        t_arr = np.ascontiguousarray(times, dtype=np.float32)
        t_acc = self._append_accessor(t_arr, 5126, "SCALAR")
        samplers = []
        channels = []
        for n_idx, tr_dict in tracks.items():
            if "translation" in tr_dict:
                tr_arr = np.ascontiguousarray(tr_dict["translation"], dtype=np.float32)
                tr_acc = self._append_accessor(tr_arr, 5126, "VEC3")
                s_idx = len(samplers)
                samplers.append({"input": t_acc, "interpolation": "LINEAR", "output": tr_acc})
                channels.append({"sampler": s_idx, "target": {"node": n_idx, "path": "translation"}})
            if "rotation" in tr_dict:
                rt_arr = np.ascontiguousarray(tr_dict["rotation"], dtype=np.float32)
                norms = np.linalg.norm(rt_arr, axis=1, keepdims=True)
                rt_arr = rt_arr / np.maximum(norms, 1e-9)
                rt_acc = self._append_accessor(rt_arr, 5126, "VEC4")
                s_idx = len(samplers)
                samplers.append({"input": t_acc, "interpolation": "LINEAR", "output": rt_acc})
                channels.append({"sampler": s_idx, "target": {"node": n_idx, "path": "rotation"}})
        anim = {"name": name, "samplers": samplers, "channels": channels}
        if extras:
            anim["extras"] = extras
        self.animations.append(anim)

    def build_glb_bytes(self, extras: dict = None):
        while len(self.bin_buf) % 4 != 0:
            self.bin_buf.append(0)
        j = {
            "asset": {"version": "2.0", "generator": "Castleward Honorable Entry Gatehouse Builder"},
            "scene": 0,
            "scenes": [{"name": "HonorableEntryGatehouseScene", "nodes": [0]}],
            "nodes": self.nodes,
            "meshes": self.meshes,
            "materials": self.materials,
            "textures": self.textures,
            "images": self.images,
            "accessors": self.accessors,
            "bufferViews": self.buffer_views,
            "buffers": [{"byteLength": len(self.bin_buf)}],
            "animations": self.animations,
        }
        if extras:
            j["extras"] = extras
            j["scenes"][0]["extras"] = extras
            self.nodes[0]["extras"] = extras
        json_bytes = bytearray(json.dumps(j, separators=(',', ':')).encode('utf-8'))
        while len(json_bytes) % 4 != 0:
            json_bytes.append(0x20)
        total_len = 12 + 8 + len(json_bytes) + 8 + len(self.bin_buf)
        out = bytearray()
        out.extend(struct.pack('<4sII', b'glTF', 2, total_len))
        out.extend(struct.pack('<I4s', len(json_bytes), b'JSON'))
        out.extend(json_bytes)
        out.extend(struct.pack('<I4s', len(self.bin_buf), b'BIN\x00'))
        out.extend(self.bin_buf)
        return bytes(out)


def make_quad(v0, v1, v2, v3, uv_center, normal_vec):
    pos = np.array([v0, v1, v2, v3], dtype=np.float32)
    n = np.array(normal_vec, dtype=np.float32)
    n /= max(float(np.linalg.norm(n)), 1e-8)
    norms = np.repeat(n[None, :], 4, axis=0)
    uc, vc = uv_center
    s = 0.01
    uvs = np.array([[uc - s, vc - s], [uc + s, vc - s], [uc + s, vc + s], [uc - s, vc + s]], dtype=np.float32)
    tris = np.array([[0, 1, 2], [0, 2, 3]], dtype=np.int32)
    return (pos, norms, uvs, tris)


def make_frustum_seg(p0, p1, r0, r1, segs, uv_center):
    p0 = np.array(p0, dtype=np.float32)
    p1 = np.array(p1, dtype=np.float32)
    d = p1 - p0
    L = float(np.linalg.norm(d))
    axis_vec = d / max(L, 1e-8)
    if abs(axis_vec[0]) > 0.9:
        u_vec = np.array([0.0, 1.0, 0.0], dtype=np.float32)
        v_vec = np.array([0.0, 0.0, 1.0], dtype=np.float32)
    elif abs(axis_vec[1]) > 0.9:
        u_vec = np.array([1.0, 0.0, 0.0], dtype=np.float32)
        v_vec = np.array([0.0, 0.0, 1.0], dtype=np.float32)
    else:
        u_vec = np.array([1.0, 0.0, 0.0], dtype=np.float32)
        v_vec = np.array([0.0, 1.0, 0.0], dtype=np.float32)

    parts = []
    angles = np.linspace(0.0, 2.0 * np.pi, segs, endpoint=False)
    for i in range(segs):
        a0, a1 = angles[i], angles[(i + 1) % segs]
        c0, s0 = math.cos(a0), math.sin(a0)
        c1, s1 = math.cos(a1), math.sin(a1)
        dir0 = c0 * u_vec + s0 * v_vec
        dir1 = c1 * u_vec + s1 * v_vec
        v0a = p0 + r0 * dir0
        v1a = p1 + r1 * dir0
        v1b = p1 + r1 * dir1
        v0b = p0 + r0 * dir1
        n_avg = 0.5 * (dir0 + dir1)
        parts.append(make_quad(v0a, v1a, v1b, v0b, uv_center, n_avg))
        parts.append(make_quad(p0, v0b, v0a, p0, uv_center, -axis_vec))
        parts.append(make_quad(p1, v1a, v1b, p1, uv_center, +axis_vec))
    return mbu.concat_meshes(parts)


# Canonical Scale & Coordinate Transformation Constants
SCALE = 8.00
Y0_RAW = 0.0320
Z0_RAW = 0.1720

# Sampled Authentic PBR UV Patches on base_basic_pbr.glb
UV_STONE = (0.5527, 0.2389)
UV_IRON  = (0.1351, 0.7704)
UV_BRASS = (0.8499, 0.6634)
UV_OAK   = (0.8336, 0.9311)
UV_FLOOR = (0.7808, 0.3702)

# Canonical Articulated Node Pivots in World-Aligned Gatehouse Space (meters, scale = [1, 1, 1])
# Note: Door_L (-X) and Door_R (+X) sit at Z = +0.240 m and swing INWARD (+Z) into the passage
# (Door_L rotates -86.0 deg around +Y; Door_R rotates +86.0 deg around +Y),
# while Portcullis sits in its own dedicated front guide channel at Z = -0.140 m and rises vertically by +1.360 m!
PIVOTS = {
    "Gatehouse_Structure": [0.000, 0.000, 0.000],
    "Door_L":              [-1.660, 0.000, +0.240],
    "Door_R":              [+1.660, 0.000, +0.240],
    "Portcullis":          [0.000, 2.900, -0.140],
    "Winch_Drum":          [0.000, 7.168, -0.080],
    "Winch_Gear_L":        [-1.480, 7.050, -0.360],
    "Winch_Gear_R":        [+1.480, 7.050, -0.360],
    "Counterweight_L":     [-2.780, 4.400, -1.040],
    "Counterweight_R":     [+2.780, 4.400, -1.040],
}

# Named glTF Gameplay Locators (child nodes of Gatehouse_Root)
LOCATORS = {
    "attacker_approach_mark": {
        "translation": [0.000, 0.000, -3.500],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "description": "Attacker approach staging mark on exterior road (-Z side) facing +Z toward THE ENTRANCE."
    },
    "threshold_plaque_mark": {
        "translation": [0.000, 0.000, -2.550],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "description": "Standing mark directly over the brass threshold plaque inscribed THE ENTRANCE."
    },
    "gate_barrier_center": {
        "translation": [0.000, 0.000, 0.000],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "description": "Center of the doorway/portcullis barrier plane (aligns with world Z = +8.80 m in Bastion Breach)."
    },
    "passage_interior_mark": {
        "translation": [0.000, 0.000, +1.800],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "description": "Vaulted interior passage mark between the inward-opened oak door leaves (+Z side)."
    },
    "courtyard_exit_mark": {
        "translation": [0.000, 0.000, +3.200],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "description": "Inner courtyard exit mark where attackers emerge into Stage 2 of Bastion Breach."
    },
}


def raw_to_world_mesh(mesh_tup):
    p, n, u, t = mesh_tup
    pw = np.empty_like(p, dtype=np.float32)
    pw[:, 0] = -SCALE * p[:, 0]
    pw[:, 1] = SCALE * (p[:, 1] - Y0_RAW)
    pw[:, 2] = -SCALE * (p[:, 2] - Z0_RAW)

    nw = np.empty_like(n, dtype=np.float32)
    nw[:, 0] = -n[:, 0]
    nw[:, 1] = n[:, 1]
    nw[:, 2] = -n[:, 2]
    norms = np.linalg.norm(nw, axis=1, keepdims=True)
    nw = nw / np.maximum(norms, 1e-8)
    return (pw, nw, u.astype(np.float32).copy(), t.astype(np.int32).copy())


def shift_mesh_to_pivot(mesh_tup, pivot_xyz):
    p, n, u, t = mesh_tup
    pv = np.array(pivot_xyz, dtype=np.float32)
    return (p - pv[None, :], n, u, t.astype(np.int32))


def make_arch_vault_liner(r_inner=1.696, y_spring=2.780, z0=-0.420, z1=0.420, segs=24, uv=UV_STONE):
    parts = []
    for i in range(segs):
        a0 = math.pi * (i / segs)
        a1 = math.pi * ((i + 1) / segs)
        c0, s0 = math.cos(a0), math.sin(a0)
        c1, s1 = math.cos(a1), math.sin(a1)
        x0, y0 = r_inner * c0, y_spring + r_inner * s0
        x1, y1 = r_inner * c1, y_spring + r_inner * s1
        nx, ny = -0.5 * (c0 + c1), -0.5 * (s0 + s1)
        parts.append(make_quad(
            [x0, y0, z0], [x1, y1, z0], [x1, y1, z1], [x0, y0, z1],
            uv, [nx, ny, 0.0]
        ))
    return mbu.concat_meshes(parts)


def make_toothed_gear(center_xyz, r_root=0.36, r_tip=0.46, half_thick=0.075, n_teeth=12, uv_body=UV_IRON, uv_rim=UV_BRASS):
    cx, cy, cz = center_xyz
    parts = [
        mbu.make_cylinder(center_xyz, r_root, half_thick, axis='x', segs=24, uv_center=uv_body),
        mbu.make_cylinder(center_xyz, r_root * 0.58, half_thick * 1.25, axis='x', segs=16, uv_center=uv_rim),
        mbu.make_cylinder(center_xyz, r_root * 0.28, half_thick * 1.85, axis='x', segs=12, uv_center=uv_body),
    ]
    tooth_half_w = (2.0 * math.pi * r_root / n_teeth) * 0.28
    for k in range(n_teeth):
        ang = (2.0 * math.pi * k) / n_teeth
        ca, sa = math.cos(ang), math.sin(ang)
        b_p, b_n, b_u, b_t = mbu.make_beveled_box(
            [-half_thick * 0.88, r_root * 0.88, -tooth_half_w],
            [+half_thick * 0.88, r_tip, +tooth_half_w],
            bevel=0.01, uv_center=uv_rim
        )
        y_l = b_p[:, 1].copy()
        z_l = b_p[:, 2].copy()
        b_p[:, 0] = cx + b_p[:, 0]
        b_p[:, 1] = cy + (y_l * ca - z_l * sa)
        b_p[:, 2] = cz + (y_l * sa + z_l * ca)
        ny_l = b_n[:, 1].copy()
        nz_l = b_n[:, 2].copy()
        b_n[:, 1] = ny_l * ca - nz_l * sa
        b_n[:, 2] = ny_l * sa + nz_l * ca
        parts.append((b_p, b_n, b_u, b_t))

    for k in range(2):
        ang = k * (math.pi * 0.5)
        ca, sa = math.cos(ang), math.sin(ang)
        sp_p, sp_n, sp_u, sp_t = mbu.make_beveled_box(
            [-half_thick * 1.32, -r_root * 0.90, -0.045],
            [+half_thick * 1.32, +r_root * 0.90, +0.045],
            bevel=0.01, uv_center=uv_rim
        )
        y_l = sp_p[:, 1].copy()
        z_l = sp_p[:, 2].copy()
        sp_p[:, 0] = cx + sp_p[:, 0]
        sp_p[:, 1] = cy + (y_l * ca - z_l * sa)
        sp_p[:, 2] = cz + (y_l * sa + z_l * ca)
        ny_l = sp_n[:, 1].copy()
        nz_l = sp_n[:, 2].copy()
        sp_n[:, 1] = ny_l * ca - nz_l * sa
        sp_n[:, 2] = ny_l * sa + nz_l * ca
        parts.append((sp_p, sp_n, sp_u, sp_t))

    return mbu.concat_meshes(parts)


def build_gatehouse_meshes_and_textures():
    in_glb = GATEHOUSE_DIR / 'base_basic_pbr.glb'
    j, b, pos_raw, norm_raw, uv_raw, tris_raw, imgs = load_glb_any(str(in_glb))
    mesh0 = compact_mesh((pos_raw, norm_raw, uv_raw, tris_raw))
    print(f"[Gatehouse] Loaded raw master: {len(mesh0[0])} verts, {len(mesh0[3])} tris")

    # 1. Trim unwanted rear protruding ground slab (z_raw < -0.138 for y_raw < 0.065)
    p, n, u, t = mesh0
    d_slab = np.where(p[:, 1] < 0.065, p[:, 2] - (-0.138), 1.0)
    _, mesh_trimmed = split_mesh_by_scalar(mesh0, d_slab)
    print(f"[Gatehouse] Trimmed rear slab: {len(mesh_trimmed[0])} verts, {len(mesh_trimmed[3])} tris")

    # 2. Separate central archway opening (Doors + Portcullis) from static archway
    p, n, u, t = mesh_trimmed
    r_arch = np.where(
        p[:, 1] <= 0.385,
        np.abs(p[:, 0]) - 0.212,
        np.sqrt(p[:, 0]**2 + np.maximum(0.0, p[:, 1] - 0.380)**2) - 0.212
    )
    d_opening = np.maximum(
        np.maximum(r_arch, 0.034 - p[:, 1]),
        np.maximum(0.118 - p[:, 2], p[:, 2] - 0.222)
    )
    mesh_gate_all, mesh_arch_body = split_mesh_by_scalar(mesh_trimmed, d_opening)

    # 3. Split Gate+Portcullis along horizontal transom y_raw = 0.395 into Doors (<= 0.395) and Portcullis (>= 0.395)
    pg, ng, ug, tg = mesh_gate_all
    mesh_doors_raw, mesh_portcullis_raw = split_mesh_by_scalar(mesh_gate_all, pg[:, 1] - 0.395)

    # 4. Split Doors along central seam x_raw = 0.000 into Door_R (x_raw <= 0 -> world +X) and Door_L (x_raw >= 0 -> world -X)
    pd, nd, ud, td = mesh_doors_raw
    mesh_door_R_raw, mesh_door_L_raw = split_mesh_by_scalar(mesh_doors_raw, pd[:, 0])

    # 5. Separate overhead Winch_Drum from static structure: |x_raw| <= 0.136, cylinder around (y=0.928, z=0.182), R=0.082
    pa, na, ua, ta = mesh_arch_body
    r_drum = np.sqrt((pa[:, 1] - 0.928)**2 + (pa[:, 2] - 0.182)**2) - 0.082
    d_drum = np.maximum(np.abs(pa[:, 0]) - 0.136, r_drum)
    mesh_winch_drum_raw, mesh_structure_raw = split_mesh_by_scalar(mesh_arch_body, d_drum)

    # Transform all 5 extracted meshes into Bastion Breach world-aligned meter coordinates
    struct_w = raw_to_world_mesh(mesh_structure_raw)
    door_l_w = raw_to_world_mesh(mesh_door_L_raw)
    door_r_w = raw_to_world_mesh(mesh_door_R_raw)
    port_w   = raw_to_world_mesh(mesh_portcullis_raw)
    drum_w   = raw_to_world_mesh(mesh_winch_drum_raw)

    # --- Add Watertight Seam Caps & Mechanical Dressings ---
    # Note: No fixed horizontal bar across the archway at Y=2.90m! When doors swing open (+Z) and
    # portcullis rises, the entire archway is open from Y=0.00m up to the raised portcullis spikes (Y=3.94m)!
    struct_parts = [
        struct_w,
        # Rear road curb sealing the trimmed ground slab at Z = +2.48 m
        mbu.make_beveled_box([-2.92, -0.256, +2.34], [+2.92, +0.012, +2.48], bevel=0.02, uv_center=UV_STONE),
        # Left & right inner stone jamb liners & portcullis guide channels (X = ±1.696 m)
        mbu.make_beveled_box([-1.82, 0.00, -0.44], [-1.68, 2.92, -0.22], bevel=0.015, uv_center=UV_STONE),
        mbu.make_beveled_box([-1.82, 0.00, -0.06], [-1.68, 2.92, +0.48], bevel=0.015, uv_center=UV_STONE),
        mbu.make_beveled_box([-1.84, 0.00, -0.23], [-1.72, 4.55, -0.05], bevel=0.01, uv_center=UV_IRON),
        mbu.make_beveled_box([+1.68, 0.00, -0.44], [+1.82, 2.92, -0.22], bevel=0.015, uv_center=UV_STONE),
        mbu.make_beveled_box([+1.68, 0.00, -0.06], [+1.82, 2.92, +0.48], bevel=0.015, uv_center=UV_STONE),
        mbu.make_beveled_box([+1.72, 0.00, -0.23], [+1.84, 4.55, -0.05], bevel=0.01, uv_center=UV_IRON),
        # Curved inner Gothic/Romanesque arch vault soffit liner
        make_arch_vault_liner(r_inner=1.696, y_spring=2.780, z0=-0.420, z1=0.420, segs=24, uv=UV_STONE),
        # Upper portcullis housing masonry pocket & winch pillow-block bearings
        mbu.make_beveled_box([-1.75, 4.45, -0.24], [+1.75, 6.45, +0.02], bevel=0.02, uv_center=UV_STONE),
        mbu.make_beveled_box([-1.58, 6.88, -0.52], [-1.10, 7.28, +0.12], bevel=0.02, uv_center=UV_IRON),
        mbu.make_beveled_box([+1.10, 6.88, -0.52], [+1.58, 7.28, +0.12], bevel=0.02, uv_center=UV_IRON),
        # Vertical counterweight guide rods & chain sheave brackets on inner buttress piers (X = ±2.78 m)
        mbu.make_cylinder([-2.78, 4.525, -1.04], 0.045, 2.325, axis='y', segs=10, uv_center=UV_IRON),
        mbu.make_cylinder([+2.78, 4.525, -1.04], 0.045, 2.325, axis='y', segs=10, uv_center=UV_IRON),
        mbu.make_beveled_box([-2.92, 6.75, -1.22], [-2.64, 6.95, -0.86], bevel=0.02, uv_center=UV_BRASS),
        mbu.make_beveled_box([+2.64, 6.75, -1.22], [+2.92, 6.95, -0.86], bevel=0.02, uv_center=UV_BRASS),
    ]
    mesh_structure_final = shift_mesh_to_pivot(mbu.concat_meshes(struct_parts), PIVOTS["Gatehouse_Structure"])

    # B. Door_L (world -X leaf, pivot [-1.660, 0.000, +0.240])
    # Shift extracted door leaf +0.06 m in Z so it sits cleanly behind the portcullis plane (Z = -0.14 m)
    dlp, dln, dlu, dlt = door_l_w
    dlp = dlp.copy()
    dlp[:, 2] += 0.060
    dl_parts = [
        (dlp, dln, dlu, dlt),
        mbu.make_beveled_box([-1.69, 0.02, -0.06], [-1.58, 2.90, +0.28], bevel=0.015, uv_center=UV_OAK),
        mbu.make_beveled_box([-0.06, 0.02, -0.06], [-0.002, 2.90, +0.26], bevel=0.01, uv_center=UV_IRON),
        mbu.make_beveled_box([-1.68, 2.82, -0.06], [-0.002, 2.92, +0.26], bevel=0.015, uv_center=UV_IRON),
        mbu.make_beveled_box([-1.68, 0.02, -0.06], [-0.002, 0.12, +0.26], bevel=0.015, uv_center=UV_IRON),
    ]
    for hy in (0.45, 1.45, 2.45):
        dl_parts.append(mbu.make_cylinder([-1.660, hy, +0.240], 0.085, 0.14, axis='y', segs=12, uv_center=UV_BRASS))
    mesh_door_l_final = shift_mesh_to_pivot(mbu.concat_meshes(dl_parts), PIVOTS["Door_L"])

    # C. Door_R (world +X leaf, pivot [+1.660, 0.000, +0.240])
    drp, drn, dru, drt = door_r_w
    drp = drp.copy()
    drp[:, 2] += 0.060
    dr_parts = [
        (drp, drn, dru, drt),
        mbu.make_beveled_box([+1.58, 0.02, -0.06], [+1.69, 2.90, +0.28], bevel=0.015, uv_center=UV_OAK),
        mbu.make_beveled_box([+0.002, 0.02, -0.06], [+0.06, 2.90, +0.26], bevel=0.01, uv_center=UV_IRON),
        mbu.make_beveled_box([+0.002, 2.82, -0.06], [+1.68, 2.92, +0.26], bevel=0.015, uv_center=UV_IRON),
        mbu.make_beveled_box([+0.002, 0.02, -0.06], [+1.68, 0.12, +0.26], bevel=0.015, uv_center=UV_IRON),
    ]
    for hy in (0.45, 1.45, 2.45):
        dr_parts.append(mbu.make_cylinder([+1.660, hy, +0.240], 0.085, 0.14, axis='y', segs=12, uv_center=UV_BRASS))
    mesh_door_r_final = shift_mesh_to_pivot(mbu.concat_meshes(dr_parts), PIVOTS["Door_R"])

    # D. Portcullis (pivot [0.000, 2.900, -0.140])
    # Shift extracted iron grille forward to Z = -0.140 m so it rides inside the stone guide slot,
    # completely clear of both the front arch molding (Z = -0.38 m) and the oak doors (Z in [-0.06, +0.28 m]).
    pp, pn, pu, pt = port_w
    pp = pp.copy()
    pp[:, 2] -= 0.140
    port_parts = [
        (pp, pn, pu, pt),
        mbu.make_beveled_box([-1.68, 2.84, -0.20], [+1.68, 2.96, -0.08], bevel=0.015, uv_center=UV_IRON),
        mbu.make_beveled_box([-1.74, 2.84, -0.19], [-1.62, 4.15, -0.09], bevel=0.015, uv_center=UV_IRON),
        mbu.make_beveled_box([+1.62, 2.84, -0.19], [+1.74, 4.15, -0.09], bevel=0.015, uv_center=UV_IRON),
    ]
    for sx in (-1.38, -0.92, -0.46, 0.00, +0.46, +0.92, +1.38):
        port_parts.append(make_frustum_seg([sx, 2.84, -0.14], [sx, 2.58, -0.14], 0.055, 0.008, 8, UV_IRON))
        port_parts.append(mbu.make_beveled_box([sx - 0.065, 2.82, -0.21], [sx + 0.065, 2.98, -0.07], bevel=0.01, uv_center=UV_BRASS))
    for cx in (-0.82, +0.82):
        port_parts.append(mbu.make_cylinder([cx, 4.55, -0.14], 0.042, 0.70, axis='y', segs=10, uv_center=UV_IRON))
        for ly in np.linspace(3.90, 5.15, 10):
            port_parts.append(mbu.make_beveled_box([cx - 0.062, ly - 0.035, -0.19], [cx + 0.062, ly + 0.035, -0.09], bevel=0.01, uv_center=UV_BRASS))

    mesh_portcullis_final = shift_mesh_to_pivot(mbu.concat_meshes(port_parts), PIVOTS["Portcullis"])

    # E. Winch_Drum (pivot [0.000, 7.168, -0.080])
    wy, wz = PIVOTS["Winch_Drum"][1], PIVOTS["Winch_Drum"][2]
    drum_parts = [
        drum_w,
        mbu.make_cylinder([0.0, wy, wz], 0.52, 1.08, axis='x', segs=24, uv_center=UV_IRON),
        mbu.make_cylinder([-1.07, wy, wz], 0.64, 0.05, axis='x', segs=24, uv_center=UV_BRASS),
        mbu.make_cylinder([+1.07, wy, wz], 0.64, 0.05, axis='x', segs=24, uv_center=UV_BRASS),
        mbu.make_cylinder([0.0, wy, wz], 0.15, 1.52, axis='x', segs=16, uv_center=UV_IRON),
    ]
    for k in range(6):
        ang = (2.0 * math.pi * k) / 6.0
        sy = wy + 0.53 * math.cos(ang)
        sz = wz + 0.53 * math.sin(ang)
        drum_parts.append(mbu.make_beveled_box([-1.02, sy - 0.055, sz - 0.055], [+1.02, sy + 0.055, sz + 0.055], bevel=0.01, uv_center=UV_BRASS if k % 2 == 0 else UV_OAK))
    mesh_winch_drum_final = shift_mesh_to_pivot(mbu.concat_meshes(drum_parts), PIVOTS["Winch_Drum"])

    # F. Winch_Gear_L and Winch_Gear_R
    mesh_gear_l_final = shift_mesh_to_pivot(make_toothed_gear(PIVOTS["Winch_Gear_L"]), PIVOTS["Winch_Gear_L"])
    mesh_gear_r_final = shift_mesh_to_pivot(make_toothed_gear(PIVOTS["Winch_Gear_R"]), PIVOTS["Winch_Gear_R"])

    # G. Counterweight_L and Counterweight_R
    def make_counterweight(center_xyz):
        cx, cy, cz = center_xyz
        cw_parts = [
            mbu.make_beveled_box([cx - 0.22, cy - 0.42, cz - 0.22], [cx + 0.22, cy + 0.42, cz + 0.22], bevel=0.02, uv_center=UV_IRON),
            mbu.make_beveled_box([cx - 0.24, cy - 0.36, cz - 0.24], [cx + 0.24, cy - 0.24, cz + 0.24], bevel=0.015, uv_center=UV_BRASS),
            mbu.make_beveled_box([cx - 0.24, cy + 0.24, cz - 0.24], [cx + 0.24, cy + 0.36, cz + 0.24], bevel=0.015, uv_center=UV_BRASS),
            mbu.make_cylinder([cx, cy + 1.41, cz], 0.036, 0.99, axis='y', segs=10, uv_center=UV_IRON),
        ]
        return mbu.concat_meshes(cw_parts)

    mesh_cw_l_final = shift_mesh_to_pivot(make_counterweight(PIVOTS["Counterweight_L"]), PIVOTS["Counterweight_L"])
    mesh_cw_r_final = shift_mesh_to_pivot(make_counterweight(PIVOTS["Counterweight_R"]), PIVOTS["Counterweight_R"])

    meshes_dict = {
        "Gatehouse_Structure": mesh_structure_final,
        "Door_L":              mesh_door_l_final,
        "Door_R":              mesh_door_r_final,
        "Portcullis":          mesh_portcullis_final,
        "Winch_Drum":          mesh_winch_drum_final,
        "Winch_Gear_L":        mesh_gear_l_final,
        "Winch_Gear_R":        mesh_gear_r_final,
        "Counterweight_L":     mesh_cw_l_final,
        "Counterweight_R":     mesh_cw_r_final,
    }
    for name, m in meshes_dict.items():
        print(f"  Mesh [{name:20s}]: {len(m[0]):6d} verts, {len(m[3]):6d} tris, pivot={PIVOTS[name]}")

    pil_imgs = [
        Image.fromarray(np.clip(imgs['texture_normal'] * 255.0, 0, 255).astype(np.uint8)),
        Image.fromarray(np.clip(imgs['texture_diffuse'] * 255.0, 0, 255).astype(np.uint8)),
        Image.fromarray(np.clip(imgs['texture_metallic-texture_roughness'] * 255.0, 0, 255).astype(np.uint8)),
    ]
    return meshes_dict, pil_imgs


def quat_x(deg):
    return quat_from_axis_angle([1.0, 0.0, 0.0], deg)


def quat_y(deg):
    return quat_from_axis_angle([0.0, 1.0, 0.0], deg)


def build_gatehouse_pose(
    door_l_deg=0.0,
    door_r_deg=0.0,
    port_dy=0.0,
    drum_deg=0.0,
    gear_deg=0.0,
    cw_dy=0.0
):
    p_dl = PIVOTS["Door_L"]
    p_dr = PIVOTS["Door_R"]
    p_pc = PIVOTS["Portcullis"]
    p_wd = PIVOTS["Winch_Drum"]
    p_gl = PIVOTS["Winch_Gear_L"]
    p_gr = PIVOTS["Winch_Gear_R"]
    p_cl = PIVOTS["Counterweight_L"]
    p_cr = PIVOTS["Counterweight_R"]

    return {
        2: ([p_dl[0], p_dl[1], p_dl[2]], quat_y(door_l_deg)),
        3: ([p_dr[0], p_dr[1], p_dr[2]], quat_y(door_r_deg)),
        4: ([p_pc[0], p_pc[1] + port_dy, p_pc[2]], [0.0, 0.0, 0.0, 1.0]),
        5: ([p_wd[0], p_wd[1], p_wd[2]], quat_x(drum_deg)),
        6: ([p_gl[0], p_gl[1], p_gl[2]], quat_x(gear_deg)),
        7: ([p_gr[0], p_gr[1], p_gr[2]], quat_x(gear_deg)),
        8: ([p_cl[0], p_cl[1] + cw_dy, p_cl[2]], [0.0, 0.0, 0.0, 1.0]),
        9: ([p_cr[0], p_cr[1] + cw_dy, p_cr[2]], [0.0, 0.0, 0.0, 1.0]),
    }


def smoothstep(t):
    t = max(0.0, min(1.0, float(t)))
    return t * t * (3.0 - 2.0 * t)


def build_4_animation_clips():
    """
    Note on inward (+Z) door rotation around +Y:
      - Door_L (at X = -1.660 m, leaf extending toward +X): rotating by -86.0 deg around +Y swings the leaf INWARD toward +Z!
      - Door_R (at X = +1.660 m, leaf extending toward -X): rotating by +86.0 deg around +Y swings the leaf INWARD toward +Z!
      - Portcullis rises by +1.360 m (lifting spikes from Y = 2.58 m to Y = 3.94 m, completely clearing the 2.90 m doorway
        while remaining housed inside the upper stone arch pocket).
    """
    pose_closed = build_gatehouse_pose(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    pose_open   = build_gatehouse_pose(-86.0, +86.0, +1.360, +540.0, -810.0, -1.100)

    clip_closed_idle = [
        (0.00, pose_closed),
        (1.00, pose_closed),
    ]

    open_times = [
        0.00, 0.15, 0.30, 0.45, 0.65, 0.90, 1.20, 1.50, 1.80,
        2.10, 2.40, 2.70, 2.95, 3.12, 3.28, 3.42, 3.60
    ]
    clip_open = []
    for t in open_times:
        if t <= 0.001:
            clip_open.append((t, pose_closed))
            continue
        if t >= 3.40:
            clip_open.append((t, pose_open))
            continue
        if t < 0.15:
            u_preload = t / 0.15
            port_dy  = -0.015 * math.sin(u_preload * math.pi)
            drum_deg = -6.0 * math.sin(u_preload * math.pi)
            gear_deg = +9.0 * math.sin(u_preload * math.pi)
            cw_dy    = +0.012 * math.sin(u_preload * math.pi)
        elif t < 3.12:
            u_w = smoothstep((t - 0.15) / (3.12 - 0.15))
            port_dy  = 1.380 * u_w
            drum_deg = 548.0 * u_w
            gear_deg = -822.0 * u_w
            cw_dy    = -1.115 * u_w
        else:
            u_set = smoothstep((t - 3.12) / (3.40 - 3.12))
            port_dy  = 1.380 * (1.0 - u_set) + 1.360 * u_set
            drum_deg = 548.0 * (1.0 - u_set) + 540.0 * u_set
            gear_deg = -822.0 * (1.0 - u_set) - 810.0 * u_set
            cw_dy    = -1.115 * (1.0 - u_set) - 1.100 * u_set

        if t < 0.35:
            dl_deg, dr_deg = 0.0, 0.0
        elif t < 3.08:
            u_dl = smoothstep((t - 0.35) / (3.08 - 0.35))
            u_dr = smoothstep(max(0.0, (t - 0.42) / (3.08 - 0.42)))
            dl_deg = -87.4 * u_dl
            dr_deg = +87.2 * u_dr
        else:
            u_dset = smoothstep((t - 3.08) / (3.40 - 3.08))
            dl_deg = -87.4 * (1.0 - u_dset) - 86.0 * u_dset
            dr_deg = +87.2 * (1.0 - u_dset) + 86.0 * u_dset

        clip_open.append((t, build_gatehouse_pose(dl_deg, dr_deg, port_dy, drum_deg, gear_deg, cw_dy)))

    clip_open_idle = [
        (0.00, pose_open),
        (1.00, pose_open),
    ]

    close_times = [
        0.00, 0.20, 0.45, 0.75, 1.05, 1.35, 1.65, 1.95, 2.25,
        2.55, 2.85, 3.05, 3.20, 3.35, 3.60
    ]
    clip_close = []
    for t in close_times:
        if t <= 0.001:
            clip_close.append((t, pose_open))
            continue
        if t >= 3.35:
            clip_close.append((t, pose_closed))
            continue

        if t < 2.85:
            u_dl = smoothstep(t / 2.85)
            u_dr = smoothstep(max(0.0, (t - 0.06) / (2.85 - 0.06)))
            dl_deg = -86.0 * (1.0 - u_dl)
            dr_deg = +86.0 * (1.0 - u_dr)
        elif t < 3.10:
            u_sh = (t - 2.85) / (3.10 - 2.85)
            rebound = 1.1 * math.sin(u_sh * math.pi)
            dl_deg = -rebound
            dr_deg = +rebound
        else:
            dl_deg, dr_deg = 0.0, 0.0

        if t < 0.20:
            port_dy, drum_deg, gear_deg, cw_dy = +1.360, +540.0, -810.0, -1.100
        elif t < 3.15:
            u_p = smoothstep((t - 0.20) / (3.15 - 0.20))
            port_dy  = +1.360 * (1.0 - u_p)
            drum_deg = +540.0 * (1.0 - u_p)
            gear_deg = -810.0 * (1.0 - u_p)
            cw_dy    = -1.100 * (1.0 - u_p)
        else:
            u_ps = (t - 3.15) / (3.35 - 3.15)
            bnc = 0.015 * math.sin(u_ps * math.pi)
            port_dy  = bnc
            drum_deg = 4.0 * math.sin(u_ps * math.pi)
            gear_deg = -6.0 * math.sin(u_ps * math.pi)
            cw_dy    = -0.010 * math.sin(u_ps * math.pi)

        clip_close.append((t, build_gatehouse_pose(dl_deg, dr_deg, port_dy, drum_deg, gear_deg, cw_dy)))

    return [
        ("Gate_ClosedIdle", clip_closed_idle),
        ("Gate_Open",       clip_open),
        ("Gate_OpenIdle",   clip_open_idle),
        ("Gate_Close",      clip_close),
    ]


def export_gatehouse_glb(meshes_dict, imgs, clips, out_glb_path: Path):
    builder = GLBBuilder()

    tex_diffuse = imgs[1].resize((1024, 1024), Image.LANCZOS)
    tex_norm    = imgs[0].resize((1024, 1024), Image.LANCZOS)
    tex_mr      = imgs[2].resize((1024, 1024), Image.LANCZOS)

    idx_diff = builder.add_image_pil(tex_diffuse, "gatehouse_diffuse", "JPEG", quality=92)
    idx_norm = builder.add_image_pil(tex_norm,    "gatehouse_normal",  "JPEG", quality=92)
    idx_mr   = builder.add_image_pil(tex_mr,      "gatehouse_mr",      "JPEG", quality=92)

    builder.materials.append({
        "name": "Castleward_Gatehouse_PBR",
        "pbrMetallicRoughness": {
            "baseColorTexture": {"index": idx_diff},
            "metallicRoughnessTexture": {"index": idx_mr},
            "metallicFactor": 1.0,
            "roughnessFactor": 1.0,
        },
        "normalTexture": {"index": idx_norm, "scale": 1.0},
        "doubleSided": True,
    })

    ordered_names = [
        "Gatehouse_Structure",
        "Door_L",
        "Door_R",
        "Portcullis",
        "Winch_Drum",
        "Winch_Gear_L",
        "Winch_Gear_R",
        "Counterweight_L",
        "Counterweight_R",
    ]
    mesh_indices = {}
    for name in ordered_names:
        p, n, u, t = meshes_dict[name]
        mesh_indices[name] = builder.add_mesh(f"{name}_Mesh", p, n, u, t, mat_idx=0)

    child_indices = list(range(1, 1 + len(ordered_names) + len(LOCATORS)))
    builder.add_node("Gatehouse_Root", translation=[0.0, 0.0, 0.0], rotation=[0.0, 0.0, 0.0, 1.0], children=child_indices)

    for name in ordered_names:
        pv = PIVOTS[name]
        builder.add_node(name, mesh_idx=mesh_indices[name], translation=pv, rotation=[0.0, 0.0, 0.0, 1.0])

    for loc_name, loc_info in LOCATORS.items():
        n_idx = builder.add_node(loc_name, translation=loc_info["translation"], rotation=loc_info["rotation"])
        builder.nodes[n_idx]["extras"] = {
            "role": "castleward_gatehouse_locator",
            "description": loc_info["description"]
        }

    target_nodes = [2, 3, 4, 5, 6, 7, 8, 9]
    for clip_name, kf_list in clips:
        times = [t for (t, _) in kf_list]
        tracks = {}
        for n_idx in target_nodes:
            tracks[n_idx] = {
                "translation": [pose[n_idx][0] for (_, pose) in kf_list],
                "rotation":    [pose[n_idx][1] for (_, pose) in kf_list],
            }
        builder.add_animation(clip_name, times, tracks)

    extras = {
        "assetId": "honorable-entry-gatehouse",
        "scaleFactor": SCALE,
        "pivots": PIVOTS,
        "locators": LOCATORS,
    }
    out_bytes = builder.build_glb_bytes(extras=extras)
    out_glb_path.write_bytes(out_bytes)
    sha256 = hashlib.sha256(out_bytes).hexdigest()
    print(f"[OK] Exported GLB: {out_glb_path} ({len(out_bytes):,} bytes / {len(out_bytes)/1048576:.2f} MB, SHA-256: {sha256})")
    return sha256


class TriangleMeshAdapter:
    def __init__(self, mesh_tup):
        self.pos, self.norm, self.uv, self.tris = mesh_tup

    def compile(self, vg_names):
        p = np.ascontiguousarray(self.pos, dtype=np.float32)
        t = np.ascontiguousarray(self.tris, dtype=np.int32)
        u = np.ascontiguousarray(self.uv, dtype=np.float32)
        totvert = len(p)
        totpoly = len(t)
        totloop = totpoly * 3

        poly_offsets = np.arange(0, (totpoly + 1) * 3, 3, dtype=np.int32)
        corner_verts = t.reshape(-1).astype(np.int32)

        e0 = np.stack([t[:, 0], t[:, 1]], axis=1)
        e1 = np.stack([t[:, 1], t[:, 2]], axis=1)
        e2 = np.stack([t[:, 2], t[:, 0]], axis=1)
        all_edges = np.stack([e0, e1, e2], axis=1).reshape(-1, 2)
        sorted_edges = np.sort(all_edges, axis=1)
        edges, corner_edges = np.unique(sorted_edges, axis=0, return_inverse=True)
        edges = edges.astype(np.int32)
        corner_edges = corner_edges.astype(np.int32)
        totedge = len(edges)

        loop_uv = np.empty((totloop, 2), dtype=np.float32)
        loop_uv[:, 0] = u[corner_verts, 0]
        loop_uv[:, 1] = 1.0 - u[corner_verts, 1]

        armor_color = np.ones((totloop, 4), dtype=np.float32)
        mat_index = np.zeros(totpoly, dtype=np.int32)
        weights = [[(0, 1.0)] if vg_names else [] for _ in range(totvert)]

        return {
            "totvert": totvert,
            "totedge": totedge,
            "totpoly": totpoly,
            "totloop": totloop,
            "positions": p,
            "edges": edges,
            "poly_offsets": poly_offsets,
            "corner_verts": corner_verts,
            "corner_edges": corner_edges,
            "armor_color": armor_color,
            "uv_map": loop_uv,
            "material_index": mat_index,
            "weights": weights,
        }


def set_id_name(block, new_id_name: str):
    raw = new_id_name.encode('utf-8')[:65]
    buf = raw + b'\x00' * (66 - len(raw))
    block["payload"][40:106] = buf


def export_gatehouse_blend(meshes_dict, imgs, out_blend_path: Path):
    template_blend = (Path(__file__).resolve().parent / 'Spellblade-production-third-person.blend')
    bf = blend_io.BlendFile(str(template_blend))

    slot_pairs = [
        ("OBBreastplate",   "MEBreastplate",         "Gatehouse_Structure"),
        ("OBBoot.L",        "MEBoot.L",              "Door_L"),
        ("OBBoot.R",        "MEBoot.R",              "Door_R"),
        ("OBHeroSword",     "MEHeroSword",           "Portcullis"),
        ("OBHelmetShell",   "MEHelmetShellCanonical","Winch_Drum"),
        ("OBPauldron.L",    "MEPauldron.L",          "Winch_Gear_L"),
        ("OBPauldron.R",    "MEPauldron.R",          "Winch_Gear_R"),
        ("OBGreave.L",      "MEGreave.L",            "Counterweight_L"),
        ("OBGreave.R",      "MEGreave.R",            "Counterweight_R"),
    ]
    ob_layout = bf.get_layout("Object")

    for old_ob, old_me, gh_name in slot_pairs:
        bf.replace_mesh(old_me, TriangleMeshAdapter(meshes_dict[gh_name]))
        for b in bf.blocks:
            if b["code"] == "ME" and bf.get_id_name(b) == old_me:
                set_id_name(b, f"ME{gh_name}")
            elif b["code"] == "OB" and bf.get_id_name(b) == old_ob:
                set_id_name(b, f"OB{gh_name}")
                pv = PIVOTS[gh_name]
                struct.pack_into("<3f", b["payload"], ob_layout["loc"][0], float(pv[0]), float(pv[1]), float(pv[2]))

    tiny_mesh = (
        np.zeros((3, 3), dtype=np.float32),
        np.array([[0, 1, 0]] * 3, dtype=np.float32),
        np.zeros((3, 2), dtype=np.float32),
        np.array([[0, 1, 2]], dtype=np.int32),
    )
    all_me_names = [bf.get_id_name(b) for b in bf.blocks if b["code"] == "ME" and not bf.get_id_name(b).startswith(("MEGatehouse", "MEDoor", "MEPortcullis", "MEWinch", "MECounterweight"))]
    for idx, rem_me in enumerate(all_me_names):
        bf.replace_mesh(rem_me, TriangleMeshAdapter(tiny_mesh))
        for b in bf.blocks:
            if b["code"] == "ME" and bf.get_id_name(b) == rem_me:
                set_id_name(b, f"MEHelper_{idx:02d}")

    ac_blocks = [b for b in bf.blocks if b["code"] == "AC"]
    for ac_b, clip_name in zip(ac_blocks[:4], ["ACGate_ClosedIdle", "ACGate_Open", "ACGate_OpenIdle", "ACGate_Close"]):
        set_id_name(ac_b, clip_name)

    bf.update_packed_image("IMSpellbladeBanner", imgs[1].resize((512, 512), Image.LANCZOS))
    bf.update_packed_image("IMKitMetalWear",     imgs[0].resize((512, 512), Image.LANCZOS))
    bf.update_packed_image("IMKitMatteWear",     imgs[2].resize((512, 512), Image.LANCZOS))

    n_bytes = bf.save(str(out_blend_path))
    print(f"[OK] Exported Blend: {out_blend_path} ({n_bytes:,} bytes / {n_bytes/1048576:.2f} MB)")


def verify_reimported_glb(glb_path: Path):
    raw = glb_path.read_bytes()
    magic, version, total_len = struct.unpack('<4sII', raw[:12])
    assert magic == b'glTF' and version == 2 and total_len == len(raw)
    j_len, j_type = struct.unpack('<I4s', raw[12:20])
    j = json.loads(raw[20:20 + j_len].decode('utf-8'))
    b_off = 20 + j_len
    b_len, b_type = struct.unpack('<I4s', raw[b_off:b_off + 8])
    bin_buf = raw[b_off + 8:b_off + 8 + b_len]

    print("\n=== REIMPORT VERIFICATION REPORT ===")
    print(f"File: {glb_path.name} ({len(raw):,} bytes)")
    print(f"Nodes: {len(j['nodes'])} | Meshes: {len(j['meshes'])} | Materials: {len(j['materials'])} | Textures: {len(j['textures'])} | Animations: {len(j['animations'])}")
    for idx, nd in enumerate(j['nodes']):
        print(f"  Node[{idx:2d}] {nd['name']:24s} translation={nd.get('translation')} mesh={nd.get('mesh')}")

    def read_acc(acc_idx):
        acc = j['accessors'][acc_idx]
        bv = j['bufferViews'][acc['bufferView']]
        off = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
        cnt = acc['count']
        n_comp = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}[acc['type']]
        arr = np.frombuffer(bin_buf, dtype=np.float32, count=cnt * n_comp, offset=off)
        return arr.reshape(cnt, n_comp) if n_comp > 1 else arr

    anim_by_name = {}
    for idx, anim in enumerate(j['animations']):
        t_acc = anim['samplers'][0]['input']
        times = read_acc(t_acc)
        dur = float(times[-1] - times[0])
        print(f"  Anim[{idx}] {anim['name']:18s}: duration={dur:.2f}s, keyframes={len(times):2d}, channels={len(anim['channels']):2d}")
        anim_by_name[anim['name']] = (anim, read_acc)

    def sample_clip_endpoints(anim):
        start_state, end_state = {}, {}
        for ch in anim['channels']:
            nd = ch['target']['node']
            path = ch['target']['path']
            vals = read_acc(anim['samplers'][ch['sampler']]['output'])
            start_state[(nd, path)] = vals[0]
            end_state[(nd, path)] = vals[-1]
        return start_state, end_state

    c_idle_s, c_idle_e = sample_clip_endpoints(anim_by_name["Gate_ClosedIdle"][0])
    open_s,   open_e   = sample_clip_endpoints(anim_by_name["Gate_Open"][0])
    o_idle_s, o_idle_e = sample_clip_endpoints(anim_by_name["Gate_OpenIdle"][0])
    close_s,  close_e  = sample_clip_endpoints(anim_by_name["Gate_Close"][0])

    err_open_start  = max(float(np.max(np.abs(open_s[k] - c_idle_e[k]))) for k in c_idle_e)
    err_open_end    = max(float(np.max(np.abs(open_e[k] - o_idle_s[k]))) for k in o_idle_s)
    err_close_start = max(float(np.max(np.abs(close_s[k] - o_idle_e[k]))) for k in o_idle_e)
    err_close_end   = max(float(np.max(np.abs(close_e[k] - c_idle_s[k]))) for k in c_idle_s)
    print(f"  State Continuity Drift -> OpenStart: {err_open_start:.6f} | OpenEnd: {err_open_end:.6f} | CloseStart: {err_close_start:.6f} | CloseEnd: {err_close_end:.6f}")
    assert max(err_open_start, err_open_end, err_close_start, err_close_end) < 1e-6, "Non-zero state transition drift!"
    print("=== REIMPORT VERIFICATION PASSED (0.000000 DRIFT) ===\n")


if __name__ == '__main__':
    meshes_dict, imgs = build_gatehouse_meshes_and_textures()
    clips = build_4_animation_clips()
    out_glb = OUT_DIR / 'Honorable_Entry_Gatehouse_GameReady_PBR.glb'
    out_blend = OUT_DIR / 'Honorable_Entry_Gatehouse.blend'
    export_gatehouse_glb(meshes_dict, imgs, clips, out_glb)
    export_gatehouse_blend(meshes_dict, imgs, out_blend)
    verify_reimported_glb(out_glb)
