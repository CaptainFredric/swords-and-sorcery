#!/usr/bin/env python3
"""
Deterministic Build, Touch-Up & Polishing Pipeline for:
The Rightful Renowner (Castleward Honors Monument & Mechanical Renown Dispenser)
Produces:
  1. Rightful_Renowner_GameReady_PBR.glb
  2. Rightful_Renowner_High_PBR.glb
  3. Rightful_Renowner_High_Shaded.glb
"""
import os, sys, json, struct, io
import cv2
import numpy as np
from PIL import Image

exec(open(str(Path(__file__).resolve().parent / 'mesh_builder_utils.py')).read())

INPUT_DIR = str(Path(__file__).resolve().parent)
OUT_DIR   = str(Path(__file__).resolve().parent)
os.makedirs(OUT_DIR, exist_ok=True)

def load_glb_any(path):
    with open(path, 'rb') as f:
        data = f.read()
    offset = 12
    j, b = None, None
    while offset < len(data):
        clen, ctype = struct.unpack('<I4s', data[offset:offset+8])
        offset += 8
        cbytes = data[offset:offset+clen]
        offset += clen
        if ctype == b'JSON':
            j = json.loads(cbytes.decode('utf-8'))
        elif ctype[:3] == b'BIN':
            b = cbytes
    ctype_map = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
    type_cols = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}
    def get_buf(acc_idx):
        acc = j['accessors'][acc_idx]
        bv = j['bufferViews'][acc['bufferView']]
        off = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
        cnt = acc['count']
        dtype = ctype_map[acc['componentType']]
        cols = type_cols[acc['type']]
        arr = np.frombuffer(b, dtype=dtype, count=cnt*cols, offset=off).copy()
        return arr.reshape((cnt, cols)) if cols > 1 else arr
    prim = j['meshes'][0]['primitives'][0]
    pos = get_buf(prim['attributes']['POSITION'])
    norm = get_buf(prim['attributes']['NORMAL'])
    uv = get_buf(prim['attributes']['TEXCOORD_0'])
    tris = get_buf(prim['indices']).astype(np.int32).reshape((-1, 3))
    imgs = {}
    for idx, img_info in enumerate(j.get('images', [])):
        bv = j['bufferViews'][img_info['bufferView']]
        img_bytes = b[bv.get('byteOffset', 0):bv.get('byteOffset', 0)+bv['byteLength']]
        im = Image.open(io.BytesIO(img_bytes)).convert('RGB')
        imgs[img_info.get('name', f'img_{idx}')] = np.array(im, dtype=np.float32) / 255.0
    return j, b, pos, norm, uv, tris, imgs

def sample_tex(tex, uv):
    H, W, _ = tex.shape
    u_px = np.clip((uv[:, 0] % 1.0) * (W - 1), 0, W - 1).astype(np.int32)
    v_px = np.clip((uv[:, 1] % 1.0) * (H - 1), 0, H - 1).astype(np.int32)
    return tex[v_px, u_px]

def rotate_mesh_x(mesh, pivot, deg):
    p, n, u, t = mesh
    pv = np.array(pivot, dtype=np.float32)
    rad = np.radians(deg)
    c, s = np.cos(rad), np.sin(rad)
    R = np.array([[1,0,0],[0,c,-s],[0,s,c]], dtype=np.float32)
    return (p - pv) @ R.T + pv, n @ R.T, u, t

def compact_mesh(mesh):
    p, n, u, t = mesh
    if len(t) == 0:
        return (np.zeros((0,3), dtype=np.float32),
                np.zeros((0,3), dtype=np.float32),
                np.zeros((0,2), dtype=np.float32),
                np.zeros((0,3), dtype=np.int32))
    used = np.unique(t)
    remap0 = np.zeros(int(used.max()) + 1, dtype=np.int32)
    remap0[used] = np.arange(len(used), dtype=np.int32)
    p = p[used]; n = n[used]; u = u[used]; t = remap0[t]

    qp = np.round(p * 10000.0).astype(np.int64)
    qu = np.round(u * 16384.0).astype(np.int64)
    qn = np.round(n * 200.0).astype(np.int64)
    keys = np.column_stack([qp, qu, qn])
    _, unique_idx, inv = np.unique(keys, axis=0, return_index=True, return_inverse=True)
    p_new = p[unique_idx].astype(np.float32)
    u_new = u[unique_idx].astype(np.float32)
    n_new = n[unique_idx].astype(np.float32)
    n_len = np.linalg.norm(n_new, axis=1, keepdims=True)
    n_new = np.where(n_len > 1e-9, n_new / np.maximum(n_len, 1e-9), np.array([0.0, 1.0, 0.0], dtype=np.float32)).astype(np.float32)
    t_new = inv[t].astype(np.int32)
    non_deg = (t_new[:,0] != t_new[:,1]) & (t_new[:,1] != t_new[:,2]) & (t_new[:,2] != t_new[:,0])
    return p_new, n_new, u_new, t_new[non_deg]

def split_mesh_by_scalar(mesh, d):
    p, n, u, t = mesh
    d0, d1, d2 = d[t[:,0]], d[t[:,1]], d[t[:,2]]
    all_neg = (d0 <= 0) & (d1 <= 0) & (d2 <= 0)
    all_pos = (d0 >= 0) & (d1 >= 0) & (d2 >= 0)
    t_neg_list = [t[all_neg]]
    t_pos_list = [t[all_pos]]
    straddle = ~(all_neg | all_pos)
    if np.any(straddle):
        ts = t[straddle]
        p_extra, n_extra, u_extra = [], [], []
        neg_new, pos_new = [], []
        base_v = len(p)
        for tri in ts:
            i0, i1, i2 = int(tri[0]), int(tri[1]), int(tri[2])
            vals = [float(d[i0]), float(d[i1]), float(d[i2])]
            idxs = [i0, i1, i2]
            signs = [v >= 0.0 for v in vals]
            if signs[0] == signs[1]:
                idxs = [idxs[2], idxs[0], idxs[1]]
                vals = [vals[2], vals[0], vals[1]]
                signs = [signs[2], signs[0], signs[1]]
            elif signs[0] == signs[2]:
                idxs = [idxs[1], idxs[2], idxs[0]]
                vals = [vals[1], vals[2], vals[0]]
                signs = [signs[1], signs[2], signs[0]]
            v_a, v_b, v_c = idxs
            da, db, dc = vals
            ta = da / (da - db) if abs(da - db) > 1e-9 else 0.5
            tc_val = da / (da - dc) if abs(da - dc) > 1e-9 else 0.5
            p_ab = (1.0 - ta) * p[v_a] + ta * p[v_b]
            n_ab = (1.0 - ta) * n[v_a] + ta * n[v_b]
            n_ab /= max(np.linalg.norm(n_ab), 1e-9)
            u_ab = (1.0 - ta) * u[v_a] + ta * u[v_b]

            p_ac = (1.0 - tc_val) * p[v_a] + tc_val * p[v_c]
            n_ac = (1.0 - tc_val) * n[v_a] + tc_val * n[v_c]
            n_ac /= max(np.linalg.norm(n_ac), 1e-9)
            u_ac = (1.0 - tc_val) * u[v_a] + tc_val * u[v_c]

            i_ab = base_v + len(p_extra)
            p_extra.append(p_ab); n_extra.append(n_ab); u_extra.append(u_ab)
            i_ac = base_v + len(p_extra)
            p_extra.append(p_ac); n_extra.append(n_ac); u_extra.append(u_ac)

            t_iso = [v_a, i_ab, i_ac]
            t_quad1 = [i_ab, v_b, v_c]
            t_quad2 = [i_ab, v_c, i_ac]
            if signs[0]:
                pos_new.append(t_iso)
                neg_new.extend([t_quad1, t_quad2])
            else:
                neg_new.append(t_iso)
                pos_new.extend([t_quad1, t_quad2])
        if len(p_extra) > 0:
            p = np.vstack([p, np.array(p_extra, dtype=np.float32)])
            n = np.vstack([n, np.array(n_extra, dtype=np.float32)])
            u = np.vstack([u, np.array(u_extra, dtype=np.float32)])
        if len(neg_new) > 0:
            t_neg_list.append(np.array(neg_new, dtype=np.int32))
        if len(pos_new) > 0:
            t_pos_list.append(np.array(pos_new, dtype=np.int32))
    t_neg = np.vstack(t_neg_list) if len(t_neg_list) > 0 else np.zeros((0,3), dtype=np.int32)
    t_pos = np.vstack(t_pos_list) if len(t_pos_list) > 0 else np.zeros((0,3), dtype=np.int32)
    return compact_mesh((p, n, u, t_neg)), compact_mesh((p, n, u, t_pos))
