import struct, json, io
import numpy as np
from PIL import Image, ImageDraw
import cv2

# Registry mapping (id_or_first_vertex_tuple, n_verts) -> (uv_array, tex_d, tex_n, tex_m, tex_e)
_UV_TEX_REGISTRY = []

def register_uv_mesh(pos_arr, uv_arr, tex_d, tex_n=None, tex_m=None, tex_e=None):
    global _UV_TEX_REGISTRY
    key = (len(pos_arr), float(pos_arr[0, 0]), float(pos_arr[0, 1]), float(pos_arr[0, 2]))
    # Keep last 8 registered meshes
    _UV_TEX_REGISTRY = [(k, v) for (k, v) in _UV_TEX_REGISTRY if k != key][-7:]
    _UV_TEX_REGISTRY.append((key, (uv_arr.astype(np.float32), tex_d, tex_n, tex_m, tex_e)))

def load_glb(path):
    with open(path, 'rb') as f:
        data = f.read()
    offset = 12
    j, b = None, None
    while offset < len(data):
        clen, ctype = struct.unpack('<I4s', data[offset:offset+8])
        offset += 8
        cbytes = data[offset:offset+clen]
        offset += clen
        if ctype == b'JSON':
            j = json.loads(cbytes.decode('utf-8'))
        elif ctype[:3] == b'BIN':
            b = cbytes
    def get_buf(acc_idx, dtype, cols):
        acc = j['accessors'][acc_idx]
        bv = j['bufferViews'][acc['bufferView']]
        off = bv.get('byteOffset', 0) + acc.get('byteOffset', 0)
        cnt = acc['count']
        arr = np.frombuffer(b, dtype=dtype, count=cnt*cols, offset=off).copy()
        return arr.reshape((cnt, cols)) if cols > 1 else arr
    pos = get_buf(0, np.float32, 3)
    norm = get_buf(1, np.float32, 3)
    uv = get_buf(2, np.float32, 2)
    tris = get_buf(3, np.uint32, 1).reshape((-1, 3))
    imgs = {}
    for idx, img_info in enumerate(j.get('images', [])):
        bv = j['bufferViews'][img_info['bufferView']]
        img_bytes = b[bv['byteOffset']:bv['byteOffset']+bv['byteLength']]
        im = Image.open(io.BytesIO(img_bytes)).convert('RGB')
        imgs[img_info.get('name', f'img_{idx}')] = np.array(im, dtype=np.float32) / 255.0
    return j, b, pos, norm, uv, tris, imgs

def _sample_bilinear(tex, uv_coords):
    H_t, W_t, _ = tex.shape
    u = (uv_coords[:, 0] % 1.0) * (W_t - 1)
    v = (uv_coords[:, 1] % 1.0) * (H_t - 1)
    x0 = np.floor(u).astype(np.int32)
    y0 = np.floor(v).astype(np.int32)
    x1 = np.minimum(x0 + 1, W_t - 1)
    y1 = np.minimum(y0 + 1, H_t - 1)
    du = (u - x0)[:, None]
    dv = (v - y0)[:, None]
    return ((1.0 - du) * (1.0 - dv) * tex[y0, x0] +
            du * (1.0 - dv) * tex[y0, x1] +
            (1.0 - du) * dv * tex[y1, x0] +
            du * dv * tex[y1, x1])

def render_view(pos, norm, tris, v_color, v_mr, v_emit, cam_pos, look_at, up=np.array([0.,1.,0.]),
                fov_deg=38.0, img_w=800, img_h=600, mode='pbr', ortho_scale=None, bg_color=(34, 34, 38)):
    """
    True per-pixel Z-buffered rasterizer with perspective-correct barycentric interpolation,
    2048x2048 bilinear UV texture sampling + tangent-space normal map perturbation (when registered),
    and smooth per-pixel Phong/PBR lighting + emissive bloom.
    """
    fwd = look_at - cam_pos
    fwd = fwd / np.linalg.norm(fwd)
    right = np.cross(fwd, up)
    if np.linalg.norm(right) < 1e-6:
        right = np.cross(fwd, np.array([0.,0.,1.]))
    right = right / np.linalg.norm(right)
    up_vec = np.cross(right, fwd)

    rel = pos - cam_pos
    cx = rel @ right
    cy = rel @ up_vec
    cz = rel @ fwd

    aspect = img_w / img_h
    if ortho_scale is not None:
        sx = (cx / (ortho_scale * aspect) * 0.5 + 0.5) * img_w
        sy = (0.5 - cy / ortho_scale * 0.5) * img_h
        inv_z = 1.0 / np.maximum(cz, 0.05)
    else:
        f = 1.0 / np.tan(np.radians(fov_deg) * 0.5)
        cz_safe = np.maximum(cz, 0.05)
        sx = ((cx * f / (cz_safe * aspect)) * 0.5 + 0.5) * img_w
        sy = (0.5 - (cy * f / cz_safe) * 0.5) * img_h
        inv_z = 1.0 / cz_safe

    zbuf = np.full((img_h, img_w), np.inf, dtype=np.float32)
    tri_id_buf = np.full((img_h, img_w), -1, dtype=np.int32)
    bary_u_buf = np.zeros((img_h, img_w), dtype=np.float32)
    bary_v_buf = np.zeros((img_h, img_w), dtype=np.float32)

    t0, t1, t2 = tris[:, 0], tris[:, 1], tris[:, 2]
    x0, y0, z0 = sx[t0], sy[t0], cz[t0]
    x1, y1, z1 = sx[t1], sy[t1], cz[t1]
    x2, y2, z2 = sx[t2], sy[t2], cz[t2]

    valid = (z0 > 0.08) & (z1 > 0.08) & (z2 > 0.08)
    xmin = np.maximum(0, np.floor(np.minimum(x0, np.minimum(x1, x2))).astype(np.int32))
    xmax = np.minimum(img_w - 1, np.ceil(np.maximum(x0, np.maximum(x1, x2))).astype(np.int32))
    ymin = np.maximum(0, np.floor(np.minimum(y0, np.minimum(y1, y2))).astype(np.int32))
    ymax = np.minimum(img_h - 1, np.ceil(np.maximum(y0, np.maximum(y1, y2))).astype(np.int32))
    denom = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
    valid &= (xmin <= xmax) & (ymin <= ymax) & (np.abs(denom) > 1e-4)

    for ti in np.where(valid)[0]:
        x_a, x_b = xmin[ti], xmax[ti]
        y_a, y_b = ymin[ti], ymax[ti]
        d_inv = 1.0 / denom[ti]
        px = np.arange(x_a, x_b + 1, dtype=np.float32)[None, :] + 0.5
        py = np.arange(y_a, y_b + 1, dtype=np.float32)[:, None] + 0.5
        w0 = ((y1[ti] - y2[ti]) * (px - x2[ti]) + (x2[ti] - x1[ti]) * (py - y2[ti])) * d_inv
        w1 = ((y2[ti] - y0[ti]) * (px - x2[ti]) + (x0[ti] - x2[ti]) * (py - y2[ti])) * d_inv
        w2 = 1.0 - w0 - w1
        inside = (w0 >= -1e-4) & (w1 >= -1e-4) & (w2 >= -1e-4)
        if not np.any(inside):
            continue
        if ortho_scale is not None:
            z_pix = w0 * z0[ti] + w1 * z1[ti] + w2 * z2[ti]
        else:
            iz_pix = w0 * inv_z[t0[ti]] + w1 * inv_z[t1[ti]] + w2 * inv_z[t2[ti]]
            z_pix = 1.0 / np.maximum(iz_pix, 1e-6)
        cur_z = zbuf[y_a:y_b+1, x_a:x_b+1]
        hit = inside & (z_pix < cur_z)
        if np.any(hit):
            cur_z[hit] = z_pix[hit]
            tri_id_buf[y_a:y_b+1, x_a:x_b+1][hit] = ti
            bary_u_buf[y_a:y_b+1, x_a:x_b+1][hit] = w0[hit]
            bary_v_buf[y_a:y_b+1, x_a:x_b+1][hit] = w1[hit]

    img = np.full((img_h, img_w, 3), bg_color, dtype=np.uint8)
    hit_mask = tri_id_buf >= 0
    if not np.any(hit_mask):
        return Image.fromarray(img)

    ty, tx = np.where(hit_mask)
    t_hit = tri_id_buf[ty, tx]
    w0 = bary_u_buf[ty, tx]
    w1 = bary_v_buf[ty, tx]
    w2 = 1.0 - w0 - w1

    i0, i1, i2 = tris[t_hit, 0], tris[t_hit, 1], tris[t_hit, 2]
    if ortho_scale is None:
        c0 = w0 * inv_z[i0]
        c1 = w1 * inv_z[i1]
        c2 = w2 * inv_z[i2]
        csum = np.maximum(c0 + c1 + c2, 1e-8)
        w0, w1, w2 = c0 / csum, c1 / csum, c2 / csum

    n_pix = w0[:, None] * norm[i0] + w1[:, None] * norm[i1] + w2[:, None] * norm[i2]
    n_pix /= np.maximum(np.linalg.norm(n_pix, axis=1, keepdims=True), 1e-8)
    p_pix = w0[:, None] * pos[i0] + w1[:, None] * pos[i1] + w2[:, None] * pos[i2]

    # Check if the leading vertices of `pos` match a registered UV-textured mesh (and `v_color` is not a custom rig tint)
    matched_uv_entry = None
    for (n_reg, p0x, p0y, p0z), reg_val in reversed(_UV_TEX_REGISTRY):
        if len(pos) >= n_reg and abs(float(pos[0,0]) - p0x) < 1e-4 and abs(float(pos[0,1]) - p0y) < 1e-4 and abs(float(pos[0,2]) - p0z) < 1e-4:
            # Check if v_color[0] matches the unmodified sampled color (not tinted for the 19-node diagram)
            uv_r, td_r, tn_r, tm_r, te_r = reg_val
            u0_px = int(np.clip((uv_r[0,0] % 1.0) * (td_r.shape[1] - 1), 0, td_r.shape[1] - 1))
            v0_px = int(np.clip((uv_r[0,1] % 1.0) * (td_r.shape[0] - 1), 0, td_r.shape[0] - 1))
            if np.linalg.norm(v_color[0] - td_r[v0_px, u0_px]) < 0.05:
                matched_uv_entry = (n_reg, uv_r, td_r, tn_r, tm_r, te_r)
                break

    base_c = w0[:, None] * v_color[i0] + w1[:, None] * v_color[i1] + w2[:, None] * v_color[i2]
    mr_c   = w0[:, None] * v_mr[i0]    + w1[:, None] * v_mr[i1]    + w2[:, None] * v_mr[i2]
    emit_c = w0[:, None] * v_emit[i0]  + w1[:, None] * v_emit[i1]  + w2[:, None] * v_emit[i2]

    if matched_uv_entry is not None and mode != 'clay':
        n_reg, uv_r, td_r, tn_r, tm_r, te_r = matched_uv_entry
        in_mon = (i0 < n_reg) & (i1 < n_reg) & (i2 < n_reg)
        if np.any(in_mon):
            idx_m = np.where(in_mon)[0]
            uv_pix = w0[idx_m, None] * uv_r[i0[idx_m]] + w1[idx_m, None] * uv_r[i1[idx_m]] + w2[idx_m, None] * uv_r[i2[idx_m]]
            base_c[idx_m] = _sample_bilinear(td_r, uv_pix)
            if tm_r is not None:
                mr_c[idx_m] = _sample_bilinear(tm_r, uv_pix)
            if te_r is not None:
                emit_c[idx_m] = _sample_bilinear(te_r, uv_pix)
            if tn_r is not None:
                nm_s = _sample_bilinear(tn_r, uv_pix) * 2.0 - 1.0
                np_m = n_pix[idx_m]
                up_t = np.where(np.abs(np_m[:, 1:2]) < 0.99, np.array([[0.0, 1.0, 0.0]]), np.array([[1.0, 0.0, 0.0]]))
                tang = np.cross(up_t, np_m)
                tang /= np.maximum(np.linalg.norm(tang, axis=1, keepdims=True), 1e-8)
                bitang = np.cross(np_m, tang)
                n_pert = tang * nm_s[:, 0:1] * 0.60 + bitang * nm_s[:, 1:2] * 0.60 + np_m * np.maximum(nm_s[:, 2:3], 0.25)
                n_pix[idx_m] = n_pert / np.maximum(np.linalg.norm(n_pert, axis=1, keepdims=True), 1e-8)

    l1 = np.array([0.45, 0.72, 0.52], dtype=np.float32); l1 /= np.linalg.norm(l1)
    l2 = np.array([-0.60, 0.35, 0.35], dtype=np.float32); l2 /= np.linalg.norm(l2)
    l3 = np.array([0.0, 0.25, -0.90], dtype=np.float32); l3 /= np.linalg.norm(l3)
    v_dir = cam_pos[None, :] - p_pix
    v_dir /= np.maximum(np.linalg.norm(v_dir, axis=1, keepdims=True), 1e-8)

    dot_v = np.sum(n_pix * v_dir, axis=1, keepdims=True)
    n_pix = np.where(dot_v < 0, -n_pix, n_pix)

    ndotl1 = np.clip(np.sum(n_pix * l1, axis=1, keepdims=True), 0.0, 1.0)
    ndotl2 = np.clip(np.sum(n_pix * l2, axis=1, keepdims=True), 0.0, 1.0)
    ndotl3 = np.clip(np.sum(n_pix * l3, axis=1, keepdims=True), 0.0, 1.0)
    h1 = l1 + v_dir; h1 /= np.maximum(np.linalg.norm(h1, axis=1, keepdims=True), 1e-8)
    ndoth1 = np.clip(np.sum(n_pix * h1, axis=1, keepdims=True), 0.0, 1.0)

    if mode == 'clay':
        bc = np.full((len(ty), 3), 0.72, dtype=np.float32)
        spec = (ndoth1 ** 24) * 0.25
        col = bc * (0.28 + 0.62 * ndotl1 + 0.25 * ndotl2 + 0.10 * ndotl3) + spec
    else:
        rough = np.clip(mr_c[:, 1:2], 0.12, 1.0)
        metal = np.clip(mr_c[:, 2:3], 0.0, 1.0)
        shininess = np.clip(2.0 / (rough**2 + 0.03), 4.0, 56.0)
        spec_str = (0.04 * (1.0 - metal) + base_c * metal) * (1.1 - 0.6 * rough)
        spec = (ndoth1 ** shininess) * spec_str * 0.55
        diff_light = 0.48 + 0.54 * ndotl1 + 0.20 * ndotl2 + 0.10 * ndotl3
        col = base_c * (1.0 - 0.22 * metal) * diff_light + spec + emit_c * 1.20

    img[ty, tx] = np.clip(col * 255.0, 0, 255).astype(np.uint8)
    return Image.fromarray(img)
