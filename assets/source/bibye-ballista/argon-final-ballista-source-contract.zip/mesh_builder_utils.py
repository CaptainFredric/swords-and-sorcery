import numpy as np

# UV coordinates in the original 2048x2048 Rodin PBR texture for key materials:
# Let's sample or assign authentic UVs from the Rodin texture!
# Better yet, we can find exact UV patches on the Rodin texture for:
# - Chiseled grey stone block
# - Polished Castleward brass/gold
# - Deep royal crimson banner/carpet
# - Dark forged iron / gunmetal
# - Glowing cyan arcane core (which is bright in both diffuse and emissive!)

def make_box(pmin, pmax, uv_center=(0.5, 0.5), uv_span=0.02):
    x0, y0, z0 = pmin
    x1, y1, z1 = pmax
    faces = [
        # +Z front
        ([[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]], [0,0,1]),
        # -Z back
        ([[x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0]], [0,0,-1]),
        # +X right
        ([[x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1]], [1,0,0]),
        # -X left
        ([[x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0]], [-1,0,0]),
        # +Y top
        ([[x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0]], [0,1,0]),
        # -Y bottom
        ([[x0,y0,z0],[x1,y0,z0],[x1,y0,z1],[x0,y0,z1]], [0,-1,0]),
    ]
    pos_list, norm_list, uv_list, tri_list = [], [], [], []
    uc, vc = uv_center
    s = uv_span * 0.5
    quad_uv = np.array([[uc-s, vc-s], [uc+s, vc-s], [uc+s, vc+s], [uc-s, vc+s]], dtype=np.float32)
    for v_quad, n in faces:
        base = len(pos_list)
        pos_list.extend(v_quad)
        norm_list.extend([n]*4)
        uv_list.append(quad_uv)
        tri_list.extend([[base, base+1, base+2], [base, base+2, base+3]])
    return (np.array(pos_list, dtype=np.float32),
            np.array(norm_list, dtype=np.float32),
            np.vstack(uv_list),
            np.array(tri_list, dtype=np.int32))

def make_beveled_box(pmin, pmax, bevel=0.015, uv_center=(0.5, 0.5), uv_span=0.02):
    # Creates a clean chamfered architectural block (great for stone courses, brass frames, carpet borders)
    x0, y0, z0 = pmin
    x1, y1, z1 = pmax
    b = min(bevel, (x1-x0)*0.3, (y1-y0)*0.3, (z1-z0)*0.3)
    # Build as a prism with beveled top & front/side edges using 3 stacked sections in Y
    pos_all, norm_all, uv_all, tri_all = [], [], [], []
    def add_quad(v0, v1, v2, v3):
        n = np.cross(np.array(v1)-np.array(v0), np.array(v2)-np.array(v0))
        nl = np.linalg.norm(n)
        if nl > 1e-9: n = n / nl
        else: n = np.array([0,1,0], dtype=np.float32)
        base = len(pos_all)
        pos_all.extend([v0, v1, v2, v3])
        norm_all.extend([n]*4)
        uc, vc = uv_center
        s = uv_span * 0.5
        uv_all.extend([[uc-s, vc-s], [uc+s, vc-s], [uc+s, vc+s], [uc-s, vc+s]])
        tri_all.extend([[base, base+1, base+2], [base, base+2, base+3]])

    # Bottom ring (at y0, inset by b) to mid-lower ring (at y0+b, full width) to mid-upper ring (at y1-b, full width) to top ring (at y1, inset by b)
    rings = [
        (y0,   x0+b, x1-b, z0+b, z1-b),
        (y0+b, x0,   x1,   z0,   z1),
        (y1-b, x0,   x1,   z0,   z1),
        (y1,   x0+b, x1-b, z0+b, z1-b),
    ]
    for i in range(len(rings)-1):
        ya, xa0, xa1, za0, za1 = rings[i]
        yb, xb0, xb1, zb0, zb1 = rings[i+1]
        # +Z
        add_quad([xa0,ya,za1], [xa1,ya,za1], [xb1,yb,zb1], [xb0,yb,zb1])
        # -Z
        add_quad([xa1,ya,za0], [xa0,ya,za0], [xb0,yb,zb0], [xb1,yb,zb0])
        # +X
        add_quad([xa1,ya,za1], [xa1,ya,za0], [xb1,yb,zb0], [xb1,yb,zb1])
        # -X
        add_quad([xa0,ya,za0], [xa0,ya,za1], [xb0,yb,zb1], [xb0,yb,zb0])
    # Top cap
    yt, xt0, xt1, zt0, zt1 = rings[-1]
    add_quad([xt0,yt,zt1], [xt1,yt,zt1], [xt1,yt,zt0], [xt0,yt,zt0])
    # Bottom cap
    yb0, xb0, xb1, zb0, zb1 = rings[0]
    add_quad([xb0,yb0,zb0], [xb1,yb0,zb0], [xb1,yb0,zb1], [xb0,yb0,zb1])
    return (np.array(pos_all, dtype=np.float32),
            np.array(norm_all, dtype=np.float32),
            np.array(uv_all, dtype=np.float32),
            np.array(tri_all, dtype=np.int32))

def make_cylinder(center, radius, half_len, axis='x', segs=20, uv_center=(0.5, 0.5), uv_span=0.02):
    pos_all, norm_all, uv_all, tri_all = [], [], [], []
    uc, vc = uv_center
    s = uv_span * 0.5
    angles = np.linspace(0, 2*np.pi, segs, endpoint=False)
    for i in range(segs):
        a0, a1 = angles[i], angles[(i+1)%segs]
        c0, s0 = np.cos(a0), np.sin(a0)
        c1, s1 = np.cos(a1), np.sin(a1)
        if axis == 'x':
            p0a = [center[0]-half_len, center[1]+radius*c0, center[2]+radius*s0]
            p1a = [center[0]+half_len, center[1]+radius*c0, center[2]+radius*s0]
            p1b = [center[0]+half_len, center[1]+radius*c1, center[2]+radius*s1]
            p0b = [center[0]-half_len, center[1]+radius*c1, center[2]+radius*s1]
            n0 = [0, c0, s0]; n1 = [0, c1, s1]
            c_neg = [center[0]-half_len, center[1], center[2]]
            c_pos = [center[0]+half_len, center[1], center[2]]
            n_neg = [-1, 0, 0]; n_pos = [1, 0, 0]
        elif axis == 'y':
            p0a = [center[0]+radius*c0, center[1]-half_len, center[2]+radius*s0]
            p1a = [center[0]+radius*c0, center[1]+half_len, center[2]+radius*s0]
            p1b = [center[0]+radius*c1, center[1]+half_len, center[2]+radius*s1]
            p0b = [center[0]+radius*c1, center[1]-half_len, center[2]+radius*s1]
            n0 = [c0, 0, s0]; n1 = [c1, 0, s1]
            c_neg = [center[0], center[1]-half_len, center[2]]
            c_pos = [center[0], center[1]+half_len, center[2]]
            n_neg = [0, -1, 0]; n_pos = [0, 1, 0]
        else: # 'z'
            p0a = [center[0]+radius*c0, center[1]+radius*s0, center[2]-half_len]
            p1a = [center[0]+radius*c0, center[1]+radius*s0, center[2]+half_len]
            p1b = [center[0]+radius*c1, center[1]+radius*s1, center[2]+half_len]
            p0b = [center[0]+radius*c1, center[1]+radius*s1, center[2]-half_len]
            n0 = [c0, s0, 0]; n1 = [c1, s1, 0]
            c_neg = [center[0], center[1], center[2]-half_len]
            c_pos = [center[0], center[1], center[2]+half_len]
            n_neg = [0, 0, -1]; n_pos = [0, 0, 1]
        base = len(pos_all)
        pos_all.extend([p0a, p1a, p1b, p0b])
        norm_all.extend([n0, n0, n1, n1])
        uv_all.extend([[uc-s, vc-s], [uc+s, vc-s], [uc+s, vc+s], [uc-s, vc+s]])
        tri_all.extend([[base, base+1, base+2], [base, base+2, base+3]])
        # Caps
        b_cap = len(pos_all)
        pos_all.extend([c_pos, p1a, p1b, c_neg, p0b, p0a])
        norm_all.extend([n_pos]*3 + [n_neg]*3)
        uv_all.extend([[uc, vc], [uc+s*c0, vc+s*s0], [uc+s*c1, vc+s*s1]]*2)
        tri_all.extend([[b_cap, b_cap+1, b_cap+2], [b_cap+3, b_cap+4, b_cap+5]])
    return (np.array(pos_all, dtype=np.float32),
            np.array(norm_all, dtype=np.float32),
            np.array(uv_all, dtype=np.float32),
            np.array(tri_all, dtype=np.int32))

def make_ellipsoid(center, radii, u_segs=18, v_segs=12, uv_center=(0.5, 0.5), uv_span=0.02):
    pos_all, norm_all, uv_all, tri_all = [], [], [], []
    rx, ry, rz = radii
    uc, vc = uv_center
    s = uv_span * 0.5
    for iv in range(v_segs):
        v0 = np.pi * iv / v_segs
        v1 = np.pi * (iv + 1) / v_segs
        for iu in range(u_segs):
            u0 = 2 * np.pi * iu / u_segs
            u1 = 2 * np.pi * ((iu + 1) % u_segs) / u_segs
            pts_uv = [(u0, v0), (u1, v0), (u1, v1), (u0, v1)]
            base = len(pos_all)
            for u, v in pts_uv:
                nx = np.sin(v) * np.cos(u)
                ny = np.cos(v)
                nz = np.sin(v) * np.sin(u)
                pos_all.append([center[0] + rx*nx, center[1] + ry*ny, center[2] + rz*nz])
                n = np.array([nx/rx, ny/ry, nz/rz], dtype=np.float32)
                n /= np.maximum(np.linalg.norm(n), 1e-9)
                norm_all.append(n)
                uv_all.append([uc + s*nx, vc + s*nz])
            tri_all.extend([[base, base+1, base+2], [base, base+2, base+3]])
    return (np.array(pos_all, dtype=np.float32),
            np.array(norm_all, dtype=np.float32),
            np.array(uv_all, dtype=np.float32),
            np.array(tri_all, dtype=np.int32))

def concat_meshes(mesh_list):
    pos_l, norm_l, uv_l, tri_l = [], [], [], []
    v_off = 0
    for p, n, u, t in mesh_list:
        if len(p) == 0 or len(t) == 0:
            continue
        pos_l.append(p.astype(np.float32))
        norm_l.append(n.astype(np.float32))
        uv_l.append(u.astype(np.float32))
        tri_l.append(t.astype(np.int32) + v_off)
        v_off += len(p)
    return (np.vstack(pos_l), np.vstack(norm_l), np.vstack(uv_l), np.vstack(tri_l))
