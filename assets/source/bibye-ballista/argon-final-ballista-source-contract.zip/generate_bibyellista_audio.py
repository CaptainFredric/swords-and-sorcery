#!/usr/bin/env python3
"""
Procedural Physical/Modal Acoustic Synthesizer for The Bi-Bye-llista (v3.3)
Generates 9 original, game-ready WAV (44.1 kHz, 16-bit PCM) and OGG (Vorbis) mechanical
sound effect assets synchronized to the Bi-Bye-llista's animation events, completely
decoupled from gameplay logic so Codex can integrate them directly.
"""
import math
import wave
import zipfile
import subprocess
from pathlib import Path
import numpy as np

OUT_DIR   = Path('/working_dir/c_63a1f8c151a6582d/artifacts/file_generation/ttl=63d/output')
AUDIO_DIR = OUT_DIR / 'audio'
AUDIO_DIR.mkdir(parents=True, exist_ok=True)

SR = 44100


def lowpass_1pole(sig: np.ndarray, cutoff_hz: float) -> np.ndarray:
    rc = 1.0 / (2.0 * math.pi * max(cutoff_hz, 10.0))
    dt = 1.0 / SR
    alpha = dt / (rc + dt)
    out = np.empty_like(sig)
    y = 0.0
    for i in range(len(sig)):
        y += alpha * (float(sig[i]) - y)
        out[i] = y
    return out


def add_burst(buf: np.ndarray, t_start: float, dur: float, fn_gen):
    i0 = max(0, int(round(t_start * SR)))
    n = int(round(dur * SR))
    i1 = min(len(buf), i0 + n)
    if i1 <= i0:
        return
    t = np.arange(i1 - i0, dtype=np.float64) / SR
    buf[i0:i1] += fn_gen(t)


def modal_strike(t: np.ndarray, freqs_amps_decays, noise_amt=0.15, noise_decay=35.0, seed=42):
    rng = np.random.default_rng(seed)
    sig = np.zeros_like(t)
    for f, a, d in freqs_amps_decays:
        sig += a * np.sin(2.0 * math.pi * f * t) * np.exp(-d * t)
    if noise_amt > 0:
        n_raw = rng.standard_normal(len(t))
        sig += noise_amt * lowpass_1pole(n_raw, 1800.0) * np.exp(-noise_decay * t)
    return sig


def save_wav_and_ogg(stem: str, sig: np.ndarray):
    peak = float(np.max(np.abs(sig)))
    if peak > 1e-6:
        sig = (sig / peak) * 0.88
    pcm = np.clip(sig * 32767.0, -32768, 32767).astype(np.int16)
    wav_path = AUDIO_DIR / f"{stem}.wav"
    ogg_path = AUDIO_DIR / f"{stem}.ogg"
    with wave.open(str(wav_path), 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(SR)
        wf.writeframes(pcm.tobytes())
    subprocess.run(
        ["ffmpeg", "-y", "-i", str(wav_path), "-c:a", "libvorbis", "-q:a", "5", str(ogg_path)],
        check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )
    print(f"  [OK] Audio {stem:34s}: WAV={wav_path.stat().st_size:7,d} B | OGG={ogg_path.stat().st_size:6,d} B")
    return wav_path, ogg_path


def build_all_bibyellista_audio():
    rng = np.random.default_rng(1337)
    generated = []

    # 1. bibye_01_drive_loop (2.40 s seamless loop: 6-wheel oak felloe rumble + iron tire clatter + axle journal groan)
    dur1 = 2.40
    t1 = np.arange(int(dur1 * SR), dtype=np.float64) / SR
    rumble = lowpass_1pole(rng.standard_normal(len(t1)), 135.0) * (0.45 + 0.20 * np.sin(2 * math.pi * (4.0 / dur1) * t1))
    groan = 0.16 * np.sin(2 * math.pi * 82.0 * t1 + 1.8 * np.sin(2 * math.pi * (2.0 / dur1) * t1))
    groan += 0.09 * np.sin(2 * math.pi * 164.0 * t1 + 1.2 * np.cos(2 * math.pi * (2.0 / dur1) * t1))
    sig1 = rumble + groan
    for k in range(16):
        tk = (k / 16.0) * dur1
        add_burst(sig1, tk, 0.09, lambda t, s=k: modal_strike(
            t, [(95.0, 0.35, 28.0), (240.0, 0.18, 45.0), (680.0, 0.08, 70.0)], noise_amt=0.14, noise_decay=55.0, seed=100+s
        ))
    fade_n = int(0.04 * SR)
    w_fade = np.linspace(0.0, 1.0, fade_n)
    sig1[:fade_n] = sig1[:fade_n] * w_fade + sig1[-fade_n:] * (1.0 - w_fade)
    generated.append(save_wav_and_ogg("bibye_01_drive_loop", sig1))

    # 2. bibye_02_steer_creak (1.10 s: Ackermann kingpin groan & oak bolster flex)
    dur2 = 1.10
    t2 = np.arange(int(dur2 * SR), dtype=np.float64) / SR
    env2 = np.sin(np.pi * (t2 / dur2)) ** 0.8
    f_creak = 118.0 + 38.0 * np.sin(2 * math.pi * 2.2 * t2) + 14.0 * np.cos(2 * math.pi * 7.5 * t2)
    phase2 = np.cumsum(2 * math.pi * f_creak / SR)
    sig2 = env2 * (0.35 * np.sin(phase2) + 0.22 * np.sin(2.0 * phase2 + 0.4) + 0.12 * np.sin(3.0 * phase2))
    add_burst(sig2, 0.05, 0.14, lambda t: modal_strike(t, [(180.0, 0.30, 26.0), (540.0, 0.16, 48.0)], 0.12, 45.0, 201))
    add_burst(sig2, 0.82, 0.16, lambda t: modal_strike(t, [(155.0, 0.28, 24.0), (480.0, 0.14, 42.0)], 0.10, 45.0, 202))
    generated.append(save_wav_and_ogg("bibye_02_steer_creak", sig2))

    # 3. bibye_03_stabilizer_deploy (1.60 s synchronized to 05_BiBye_Stabilizer_Deploy)
    sig3 = np.zeros(int(1.60 * SR), dtype=np.float64)
    add_burst(sig3, 0.01, 0.18, lambda t: modal_strike(t, [(320.0, 0.45, 32.0), (780.0, 0.28, 50.0), (1420.0, 0.12, 75.0)], 0.20, 60.0, 301))
    for k, tk in enumerate(np.linspace(0.15, 0.88, 7)):
        add_burst(sig3, float(tk), 0.10, lambda t, s=k: modal_strike(t, [(140.0 + 12*s, 0.22, 30.0), (620.0, 0.10, 65.0)], 0.10, 50.0, 310+s))
    add_burst(sig3, 1.02, 0.42, lambda t: modal_strike(
        t, [(58.0, 0.85, 14.0), (112.0, 0.55, 20.0), (265.0, 0.30, 28.0), (510.0, 0.18, 40.0)], 0.35, 30.0, 320
    ))
    add_burst(sig3, 1.33, 0.20, lambda t: modal_strike(t, [(280.0, 0.40, 30.0), (890.0, 0.25, 55.0)], 0.15, 60.0, 330))
    generated.append(save_wav_and_ogg("bibye_03_stabilizer_deploy", sig3))

    # 4. bibye_04_stabilizer_retract (1.60 s synchronized to 07_BiBye_Stabilizer_Retract)
    sig4 = np.zeros(int(1.60 * SR), dtype=np.float64)
    add_burst(sig4, 0.01, 0.28, lambda t: modal_strike(t, [(72.0, 0.65, 16.0), (240.0, 0.35, 28.0), (680.0, 0.20, 48.0)], 0.22, 40.0, 401))
    for k, tk in enumerate(np.linspace(0.24, 1.15, 8)):
        add_burst(sig4, float(tk), 0.10, lambda t, s=k: modal_strike(t, [(165.0 + 18*s, 0.24, 32.0), (740.0, 0.12, 60.0)], 0.10, 55.0, 410+s))
    add_burst(sig4, 1.24, 0.24, lambda t: modal_strike(t, [(340.0, 0.50, 28.0), (920.0, 0.32, 48.0), (1650.0, 0.15, 70.0)], 0.18, 65.0, 420))
    generated.append(save_wav_and_ogg("bibye_04_stabilizer_retract", sig4))

    # 5. bibye_05_traverse_elevate_loop (1.50 s seamless loop: 24-tooth bronze turntable gear meshing & trunnion creak)
    dur5 = 1.50
    sig5 = np.zeros(int(dur5 * SR), dtype=np.float64)
    t5 = np.arange(len(sig5), dtype=np.float64) / SR
    sig5 += 0.18 * np.sin(2 * math.pi * 96.0 * t5 + 0.8 * np.sin(2 * math.pi * 4.0 * t5))
    for k in range(12):
        tk = (k / 12.0) * dur5
        add_burst(sig5, tk, 0.08, lambda t, s=k: modal_strike(
            t, [(220.0, 0.32, 38.0), (580.0, 0.22, 55.0), (1180.0, 0.12, 80.0)], 0.12, 65.0, 500+s
        ))
    sig5[:fade_n] = sig5[:fade_n] * w_fade + sig5[-fade_n:] * (1.0 - w_fade)
    generated.append(save_wav_and_ogg("bibye_05_traverse_elevate_loop", sig5))

    # 6. bibye_06_mobile_shot1_fire (1.20 s synchronized to 09_BiBye_Mobile_Shot1_Fire)
    sig6 = np.zeros(int(1.20 * SR), dtype=np.float64)
    add_burst(sig6, 0.02, 0.08, lambda t: modal_strike(t, [(640.0, 0.28, 65.0), (1480.0, 0.20, 90.0)], 0.10, 80.0, 601))
    add_burst(sig6, 0.200, 0.55, lambda t: modal_strike(
        t,
        [(185.0, 0.65, 18.0), (440.0, 0.48, 14.0), (880.0, 0.35, 11.0), (1760.0, 0.22, 9.0), (2640.0, 0.12, 12.0)],
        0.42, 38.0, 602
    ))
    add_burst(sig6, 0.310, 0.25, lambda t: modal_strike(t, [(92.0, 0.45, 22.0), (230.0, 0.25, 35.0)], 0.15, 45.0, 603))
    generated.append(save_wav_and_ogg("bibye_06_mobile_shot1_fire", sig6))

    # 7. bibye_07_twostage_volley_fire (2.60 s synchronized to 02_BiBye_TwoStage_Fire: 0.450s Shot I -> 0.650s Shot II, dt=0.200s!)
    sig7 = np.zeros(int(2.60 * SR), dtype=np.float64)
    for k, tk in enumerate((0.12, 0.23, 0.34)):
        add_burst(sig7, tk, 0.08, lambda t, s=k: modal_strike(t, [(420.0 + 40*s, 0.30, 50.0), (1120.0, 0.18, 75.0)], 0.10, 70.0, 700+s))
    add_burst(sig7, 0.450, 0.48, lambda t: modal_strike(
        t, [(195.0, 0.55, 20.0), (460.0, 0.42, 15.0), (920.0, 0.32, 12.0), (1840.0, 0.20, 10.0)], 0.35, 40.0, 710
    ))
    add_burst(sig7, 0.650, 1.35, lambda t: modal_strike(
        t,
        [(62.0, 0.95, 9.5), (118.0, 0.80, 11.0), (215.0, 0.65, 6.5), (430.0, 0.42, 7.5), (645.0, 0.25, 9.0)],
        0.65, 24.0, 720
    ))
    add_burst(sig7, 0.850, 0.55, lambda t: modal_strike(
        t, [(52.0, 0.78, 12.0), (105.0, 0.52, 18.0), (280.0, 0.28, 28.0)], 0.30, 32.0, 730
    ))
    generated.append(save_wav_and_ogg("bibye_07_twostage_volley_fire", sig7))

    # 8. bibye_08_mechanical_reload (6.00 s synchronized to 04_BiBye_Mechanical_Reload)
    sig8 = np.zeros(int(6.00 * SR), dtype=np.float64)
    for k, tk in enumerate(np.linspace(0.05, 0.52, 5)):
        add_burst(sig8, float(tk), 0.08, lambda t, s=k: modal_strike(t, [(280.0 + 20*s, 0.25, 42.0), (760.0, 0.15, 65.0)], 0.12, 55.0, 800+s))
    add_burst(sig8, 0.60, 0.16, lambda t: modal_strike(t, [(350.0, 0.45, 35.0), (980.0, 0.28, 55.0)], 0.15, 60.0, 809))
    for k, tk in enumerate(np.linspace(0.78, 2.78, 16)):
        pitch_rise = 1.0 + 0.35 * (k / 15.0)
        add_burst(sig8, float(tk), 0.11, lambda t, pr=pitch_rise, s=k: modal_strike(
            t, [(145.0 * pr, 0.32, 26.0), (480.0 * pr, 0.28, 48.0), (1180.0 * pr, 0.16, 70.0)], 0.10, 55.0, 810+s
        ))
    add_burst(sig8, 2.85, 0.24, lambda t: modal_strike(t, [(165.0, 0.60, 22.0), (520.0, 0.42, 38.0), (1340.0, 0.22, 60.0)], 0.20, 50.0, 830))
    add_burst(sig8, 3.15, 0.30, lambda t: modal_strike(t, [(88.0, 0.55, 20.0), (210.0, 0.35, 32.0)], 0.20, 40.0, 831))
    add_burst(sig8, 3.65, 0.22, lambda t: modal_strike(t, [(135.0, 0.45, 26.0), (410.0, 0.25, 45.0)], 0.15, 50.0, 832))
    for k, tk in enumerate(np.linspace(4.35, 4.90, 5)):
        add_burst(sig8, float(tk), 0.08, lambda t, s=k: modal_strike(t, [(380.0 + 35*s, 0.26, 50.0), (1280.0, 0.16, 75.0)], 0.08, 65.0, 840+s))
    add_burst(sig8, 5.25, 0.25, lambda t: modal_strike(t, [(310.0, 0.42, 30.0), (880.0, 0.28, 45.0), (1760.0, 0.18, 55.0)], 0.14, 60.0, 850))
    generated.append(save_wav_and_ogg("bibye_08_mechanical_reload", sig8))

    # 9. bibye_09_subsystem_break (1.20 s: oak wheel-spoke/stabilizer splinter crack + sprung iron tire shear + collapse thud)
    sig9 = np.zeros(int(1.20 * SR), dtype=np.float64)
    add_burst(sig9, 0.02, 0.22, lambda t: modal_strike(t, [(140.0, 0.75, 24.0), (420.0, 0.55, 38.0), (1150.0, 0.38, 55.0)], 0.65, 42.0, 901))
    add_burst(sig9, 0.14, 0.55, lambda t: modal_strike(t, [(195.0, 0.50, 16.0), (345.0, 0.48, 9.5), (690.0, 0.32, 12.0)], 0.45, 35.0, 902))
    add_burst(sig9, 0.36, 0.50, lambda t: modal_strike(t, [(54.0, 0.85, 12.0), (108.0, 0.55, 18.0), (245.0, 0.25, 30.0)], 0.30, 28.0, 903))
    generated.append(save_wav_and_ogg("bibye_09_subsystem_break", sig9))

    zip_path = OUT_DIR / "Bi_Bye_llista_Audio_Assets.zip"
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for wav_p, ogg_p in generated:
            zf.write(wav_p, arcname=f"audio/{wav_p.name}")
            zf.write(ogg_p, arcname=f"audio/{ogg_p.name}")
    print(f"[OK] Packed 18 audio files (9 WAV + 9 OGG) into {zip_path.name} ({zip_path.stat().st_size:,} bytes)")


if __name__ == '__main__':
    build_all_bibyellista_audio()
