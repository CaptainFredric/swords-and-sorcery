#!/usr/bin/env python3
"""
Production Art, Geometry, Smooth-Normal, PBR Material & Animation Naturalism Pipeline (v3.2) for:
The Bi-Bye-llista (Castleward Mobile Two-Stage Heavy Siege Ballista — Launchers I & II)

Major Art & Engineering Upgrades in v3.2:
  1. Four-Tier Architectural Silhouette & De-Cluttered Midsection:
     - Eliminates all 17,352 triangles of jagged marching-cubes boolean scraps and Y=1.48m midsection clutter
       from Carriage_Chassis (now cleanly capped at Y <= 1.140m outside the turntable ring).
     - Establishes clear visual separation between Tier 1 (Heavy 6-Wheel Wagon), Tier 2 (Geared Bronze Turntable
       & Cantilevered Rear Winch Frame), Tier 3 (Massive 5.48m Primary Siege Launcher II with cylindrical bronze
       torsion drums & angled II mantlet shields), and Tier 4 (Compact 1.86m Upper Conditioning Turret I).
  2. Wide-Framing Curved Siege-Iron Gunner Sight Arch & +160mm Physical Elevation Clearance:
     - Sculpted outward-flaring Gothic/siege-iron arch ribs (|X| = 0.33..0.42m, clear inner window 0.66m wide)
       built into Elevation_Cradle (Node 13), supporting Upper_Turret_Mount (Node 23) at pivot [0.000, 2.540, +0.080].
     - Swiveling or pitching the upper turret in Travel Mode never intrudes into the central sight window, and
       mounted_camera_sight (Node 38) frames a wide, unobstructed view of the battlefield across all +/-45 deg
       traverse and -8..+20 deg elevation angles.
     - Raising Elevation_Cradle's trunnion pivot to [0.000, 1.620, -0.120] and contouring the rear cradle tail
       increases physical rear-deck clearance at +20.0 deg uphill elevation from 7 mm (v3.1) to +287.3 mm above
       the Y=1.020m side escutcheon rails (+387.3 mm above the Y=0.920m recessed center oak deck, and +78.4 mm
       above the Traverse_Mount turntable platform rim)!
  3. Lathe-Turned & Spline-Lofted Subassemblies with Crease-Angle Smooth Normals (42 deg Threshold):
     - 32-segment lathe-profiled load-bearing wheels (crowned forged-iron tires, chamfered sidewalls, smooth oak
       felloes, 8 tapered octagonal spokes with brass ferrules, and turned bronze nave hubs).
     - Multi-station curved spline-lofted forged spring-steel sword-limbs with 3 stepped laminated spring-steel
       backer leaves, brass keeper bands, recessed fuller grooves, smooth longitudinal normals, and crisp blade edges.
     - 100% symmetrical articulated A-frame outrigger stabilizers with diagonal turnbuckle struts and bronze ground spades.
  4. Upgraded PBR Texture Atlas & Material Differentiation:
     - Distinct, well-separated UV material zones (quarter-sawn dark oak, oiled spring steel, charcoal forged iron,
       burnished siege brass, braided hemp cordage, royal crimson lacquer, and glowing cyan frost crystal) with
       deliberate roughness contrast and normal-map surface grain.
  5. Mechanical Animation Naturalism Across All 12 Clips (Preserving 0.450s / 0.650s Discharge Interval):
     - Stabilizers visibly take the machine's weight during deployment (+0.022m chassis lift & damped settle).
     - Independent upper-turret recoil during mobile firing (09) and substantial primary cradle recoil (-0.155m slide,
       -2.85 deg pitch kick, damped spring-steel limb ring, and chassis suspension compression) during full volley (02).
     - Torque-pulsed 4-stroke winch cranking and tooth-by-tooth ratchet pawl clicking during mechanical reload (04).
"""
import io
import os
import sys
import json
import math
import struct
import hashlib
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

SCRIPT_DIR = Path(__file__).resolve().parent
WORK_ROOT  = Path(os.environ.get('CASTLEWARD_WORK_ROOT', str(SCRIPT_DIR)))
BIBYE_DIR  = SCRIPT_DIR if (SCRIPT_DIR / 'bibye_base_basic_pbr.glb').exists() else (WORK_ROOT / 'bibyellista')
INTER_DIR  = SCRIPT_DIR
OUT_DIR    = Path(os.environ.get('BIBYE_OUT_DIR', str(SCRIPT_DIR)))
OUT_DIR.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(SCRIPT_DIR))
import mesh_builder_utils as mbu
import blend_io
import build_honorable_gatehouse as bhg

class smt:
    @staticmethod
    def compute_crease_normals(pos: np.ndarray, tris: np.ndarray, uv: np.ndarray, crease_deg: float = 42.0):
        pos = np.ascontiguousarray(pos, dtype=np.float32)
        uv  = np.ascontiguousarray(uv, dtype=np.float32)
        tris = np.ascontiguousarray(tris, dtype=np.int32).reshape(-1, 3)

        v0 = pos[tris[:, 0]]
        v1 = pos[tris[:, 1]]
        v2 = pos[tris[:, 2]]
        fn_raw = np.cross(v1 - v0, v2 - v0)
        fn_len = np.linalg.norm(fn_raw, axis=1, keepdims=True)
        valid = (fn_len[:, 0] > 1e-10)
        if not np.all(valid):
            tris = tris[valid]
            fn_raw = fn_raw[valid]
            fn_len = fn_len[valid]
        fn_unit = fn_raw / np.maximum(fn_len, 1e-10)

        q_pos = np.round(pos * 10000.0).astype(np.int64)
        _, inv_idx = np.unique(q_pos, axis=0, return_inverse=True)

        cos_thresh = math.cos(math.radians(crease_deg))
        n_tris = len(tris)

        vert_to_corners = {}
        for t_i in range(n_tris):
            for c_i in range(3):
                v_id = int(inv_idx[tris[t_i, c_i]])
                vert_to_corners.setdefault(v_id, []).append((t_i, c_i))

        new_p, new_n, new_u = [], [], []
        new_tris = np.empty_like(tris)
        out_v_idx = 0

        for v_id, corners in vert_to_corners.items():
            clusters = []
            for (t_i, c_i) in corners:
                orig_v = tris[t_i, c_i]
                f_u = fn_unit[t_i]
                f_w = fn_raw[t_i]
                c_uv = uv[orig_v]
                placed = False
                for cl in clusters:
                    if float(np.dot(f_u, cl[1])) >= cos_thresh and float(np.max(np.abs(c_uv - cl[2]))) < 0.085:
                        cl[0] = cl[0] + f_w
                        cl[3].append((t_i, c_i, orig_v))
                        placed = True
                        break
                if not placed:
                    clusters.append([f_w.copy(), f_u.copy(), c_uv.copy(), [(t_i, c_i, orig_v)]])

            for cl in clusters:
                n_sum = cl[0]
                n_norm = float(np.linalg.norm(n_sum))
                n_final = (n_sum / n_norm) if n_norm > 1e-10 else cl[1]
                rep_v = cl[3][0][2]
                new_p.append(pos[rep_v])
                new_n.append(n_final)
                new_u.append(uv[rep_v])
                for (t_i, c_i, _) in cl[3]:
                    new_tris[t_i, c_i] = out_v_idx
                out_v_idx += 1

        p_out = np.array(new_p, dtype=np.float32)
        n_out = np.array(new_n, dtype=np.float32)
        u_out = np.array(new_u, dtype=np.float32)
        t_out = new_tris.astype(np.int32)

        # Guarantee zero 1D-stretched / degenerate UV triangles:
        # Check 2D UV area of every triangle; if any triangle has area_uv < 1e-6, re-unwrap its vertices
        # using tangent-plane world-scale projection around its material swatch center!
        u0, u1, u2 = u_out[t_out[:, 0]], u_out[t_out[:, 1]], u_out[t_out[:, 2]]
        area_uv = 0.5 * np.abs((u1[:, 0] - u0[:, 0]) * (u2[:, 1] - u0[:, 1]) - (u2[:, 0] - u0[:, 0]) * (u1[:, 1] - u0[:, 1]))
        bad_mask = area_uv < 1e-6
        if np.any(bad_mask):
            # Snap each bad triangle's UV center to nearest canonical swatch or its mean UV
            bad_indices = np.where(bad_mask)[0]
            # Split shared vertices on bad triangles so planar projection never corrupts adjacent good triangles
            p_list = p_out.tolist()
            n_list = n_out.tolist()
            u_list = u_out.tolist()
            swatches = np.array([
                [0.8279, 0.7765], [0.1119, 0.0779], [0.9548, 0.7925], [0.8504, 0.1357],
                [0.2231, 0.6436], [0.3433, 0.0247], [0.6200, 0.1800], [0.4800, 0.1800],
            ], dtype=np.float32)
            for ti in bad_indices:
                ia, ib, ic = int(t_out[ti, 0]), int(t_out[ti, 1]), int(t_out[ti, 2])
                pa, pb, pc = p_out[ia], p_out[ib], p_out[ic]
                fn_t = fn_unit[ti]
                uv_mean = (u_out[ia] + u_out[ib] + u_out[ic]) / 3.0
                d_sw = np.linalg.norm(swatches - uv_mean[None, :], axis=1)
                uc, vc = swatches[int(np.argmin(d_sw))] if float(np.min(d_sw)) < 0.09 else (float(uv_mean[0]), float(uv_mean[1]))
                up_r = np.array([0.0, 1.0, 0.0], dtype=np.float32) if abs(float(fn_t[1])) < 0.9 else np.array([1.0, 0.0, 0.0], dtype=np.float32)
                t1 = np.cross(up_r, fn_t); t1 /= max(float(np.linalg.norm(t1)), 1e-8)
                t2 = np.cross(fn_t, t1);   t2 /= max(float(np.linalg.norm(t2)), 1e-8)
                p_cent = (pa + pb + pc) / 3.0
                tri_scale = 0.018 / max(float(np.linalg.norm(pb - pa)), float(np.linalg.norm(pc - pa)), 1e-5)
                new_ids = []
                for idx_v, pv in ((ia, pa), (ib, pb), (ic, pc)):
                    dp = pv - p_cent
                    du = float(np.dot(dp, t1)) * tri_scale
                    dv = float(np.dot(dp, t2)) * tri_scale
                    du = max(-0.022, min(+0.022, du))
                    dv = max(-0.022, min(+0.022, dv))
                    nid = len(p_list)
                    p_list.append(pv.tolist())
                    n_list.append(n_out[idx_v].tolist())
                    u_list.append([float(uc + du), float(vc + dv)])
                    new_ids.append(nid)
                t_out[ti] = new_ids
            p_out = np.array(p_list, dtype=np.float32)
            n_out = np.array(n_list, dtype=np.float32)
            u_out = np.array(u_list, dtype=np.float32)

        return (p_out, n_out, u_out, t_out)

    @staticmethod
    def make_lathe_mesh(profile_ar_uv, axis='x', center=(0.0, 0.0, 0.0), segs=28, crease_deg=48.0):
        cx, cy, cz = float(center[0]), float(center[1]), float(center[2])
        if segs % 2 != 0:
            segs += 1
        angles = np.linspace(0.0, 2.0 * math.pi, segs, endpoint=False)
        cos_a = np.cos(angles)
        sin_a = np.sin(angles)

        n_prof = len(profile_ar_uv)
        pos_list, uv_list, tris_list = [], [], []

        for i_p in range(n_prof - 1):
            ax0, r0, uv0 = float(profile_ar_uv[i_p][0]), float(profile_ar_uv[i_p][1]), profile_ar_uv[i_p][2]
            ax1, r1, _   = float(profile_ar_uv[i_p + 1][0]), float(profile_ar_uv[i_p + 1][1]), profile_ar_uv[i_p + 1][2]
            if r0 < 1e-5 and r1 < 1e-5:
                continue
            uc, vc = float(uv0[0]), float(uv0[1])
            base_idx = len(pos_list)
            is_cap = (r0 < 1e-5 or r1 < 1e-5)
            r_max = max(r0, r1, 1e-4)
            v_sign = 1.0 if (i_p % 2 == 0) else -1.0

            for row_i, (ax_f, r_f) in enumerate(((ax0, r0), (ax1, r1))):
                v_band = vc + v_sign * (-0.018 if row_i == 0 else +0.018)
                for j_s in range(segs):
                    c = float(cos_a[j_s])
                    s = float(sin_a[j_s])
                    if axis == 'x':
                        px, py, pz = cx + ax_f, cy + r_f * c, cz + r_f * s
                    elif axis == 'y':
                        px, py, pz = cx + r_f * c, cy + ax_f, cz + r_f * s
                    else:
                        px, py, pz = cx + r_f * c, cy + r_f * s, cz + ax_f
                    pos_list.append([px, py, pz])
                    if is_cap:
                        rad_uv = 0.020 * (r_f / r_max)
                        uv_list.append([uc + rad_uv * c, vc + rad_uv * s])
                    else:
                        # Symmetric circumference unwrap: strictly monotonic on both halves [0..segs/2] and [segs/2..segs]
                        u_circ = uc + 0.022 * (abs(j_s - (segs // 2)) / float(segs // 2) - 0.5)
                        uv_list.append([u_circ, v_band])

            row0 = base_idx
            row1 = base_idx + segs
            for j_s in range(segs):
                jn = (j_s + 1) % segs
                v00, v01 = row0 + j_s, row0 + jn
                v10, v11 = row1 + j_s, row1 + jn
                for tri in (([v00, v10, v11] if r1 > 1e-5 else None), ([v00, v11, v01] if r0 > 1e-5 else None)):
                    if tri is None:
                        continue
                    p0, p1, p2 = np.array(pos_list[tri[0]]), np.array(pos_list[tri[1]]), np.array(pos_list[tri[2]])
                    fn = np.cross(p1 - p0, p2 - p0)
                    tc = (p0 + p1 + p2) / 3.0
                    if abs(r0 - r1) > 1e-4 and (r0 < 1e-5 or r1 < 1e-5):
                        ax_idx = {'x': 0, 'y': 1, 'z': 2}[axis]
                        c_ax = [cx, cy, cz][ax_idx]
                        out_dir = np.zeros(3)
                        out_dir[ax_idx] = 1.0 if tc[ax_idx] >= c_ax else -1.0
                    else:
                        if axis == 'x':
                            out_dir = np.array([0.0, tc[1] - cy, tc[2] - cz])
                        elif axis == 'y':
                            out_dir = np.array([tc[0] - cx, 0.0, tc[2] - cz])
                        else:
                            out_dir = np.array([tc[0] - cx, tc[1] - cy, 0.0])
                    if float(np.dot(fn, out_dir)) < 0.0:
                        tri = [tri[0], tri[2], tri[1]]
                    tris_list.append(tri)

        p_arr = np.array(pos_list, dtype=np.float32)
        u_arr = np.array(uv_list, dtype=np.float32)
        t_arr = np.array(tris_list, dtype=np.int32)
        return smt.compute_crease_normals(p_arr, t_arr, u_arr, crease_deg=crease_deg)

    @staticmethod
    def make_swept_octagonal_beam(path_pts, radii_yz, uv_center, crease_deg=38.0):
        pts = np.array(path_pts, dtype=np.float32)
        n_st = len(pts)
        c_off = 0.78
        ring_uv = np.array([
            [-1.0, -c_off], [-c_off, -1.0], [+c_off, -1.0], [+1.0, -c_off],
            [+1.0, +c_off], [+c_off, +1.0], [-c_off, +1.0], [-1.0, +c_off],
        ], dtype=np.float32)
        n_ring = len(ring_uv)

        pos_list, uv_list, tris_list = [], [], []
        uc, vc = float(uv_center[0]), float(uv_center[1])

        # Cumulative arc length along the beam for distortion-free wood/metal grain flow
        arc_s = np.zeros(n_st, dtype=np.float32)
        for i in range(1, n_st):
            arc_s[i] = arc_s[i - 1] + max(float(np.linalg.norm(pts[i] - pts[i - 1])), 1e-4)
        total_len = max(float(arc_s[-1]), 1e-4)

        for i in range(n_st):
            if i == 0:
                tang = pts[1] - pts[0]
            elif i == n_st - 1:
                tang = pts[-1] - pts[-2]
            else:
                tang = pts[i + 1] - pts[i - 1]
            t_norm = float(np.linalg.norm(tang))
            tang = tang / max(t_norm, 1e-8)

            up_ref = np.array([0.0, 1.0, 0.0], dtype=np.float32)
            if abs(float(np.dot(tang, up_ref))) > 0.92:
                up_ref = np.array([0.0, 0.0, 1.0], dtype=np.float32)
            b_vec = np.cross(tang, up_ref)
            b_vec /= max(float(np.linalg.norm(b_vec)), 1e-8)
            n_vec = np.cross(b_vec, tang)
            n_vec /= max(float(np.linalg.norm(n_vec)), 1e-8)

            rw, rh = float(radii_yz[i][0]), float(radii_yz[i][1])
            u_long = uc + 0.042 * (float(arc_s[i]) / total_len - 0.5)
            for k in range(n_ring):
                pt = pts[i] + ring_uv[k, 0] * rw * b_vec + ring_uv[k, 1] * rh * n_vec
                pos_list.append(pt)
                v_perim = vc + 0.022 * (abs(k - 4) / 4.0 - 0.5)
                uv_list.append([u_long, v_perim])

        for i in range(n_st - 1):
            r0 = i * n_ring
            r1 = (i + 1) * n_ring
            seg_c = 0.5 * (pts[i] + pts[i + 1])
            for k in range(n_ring):
                kn = (k + 1) % n_ring
                for tri in ([r0 + k, r1 + k, r1 + kn], [r0 + k, r1 + kn, r0 + kn]):
                    p0, p1, p2 = np.array(pos_list[tri[0]]), np.array(pos_list[tri[1]]), np.array(pos_list[tri[2]])
                    fn = np.cross(p1 - p0, p2 - p0)
                    tc = (p0 + p1 + p2) / 3.0
                    if float(np.dot(fn, tc - seg_c)) < 0.0:
                        tri = [tri[0], tri[2], tri[1]]
                    tris_list.append(tri)

        # Dedicated end-cap rings with 2D planar octagonal UVs (zero UV stretching on end caps!)
        cap_start_base = len(pos_list)
        for k in range(n_ring):
            pos_list.append(pos_list[k])
            uv_list.append([uc + 0.018 * float(ring_uv[k, 0]), vc + 0.018 * float(ring_uv[k, 1])])
        c_start = len(pos_list)
        pos_list.append(pts[0])
        uv_list.append([uc, vc])

        last_r = (n_st - 1) * n_ring
        cap_end_base = len(pos_list)
        for k in range(n_ring):
            pos_list.append(pos_list[last_r + k])
            uv_list.append([uc + 0.018 * float(ring_uv[k, 0]), vc + 0.018 * float(ring_uv[k, 1])])
        c_end = len(pos_list)
        pos_list.append(pts[-1])
        uv_list.append([uc, vc])

        t_start = pts[0] - pts[1]
        t_end   = pts[-1] - pts[-2]
        for k in range(n_ring):
            kn = (k + 1) % n_ring
            tri_s = [c_start, cap_start_base + kn, cap_start_base + k]
            p0, p1, p2 = np.array(pos_list[tri_s[0]]), np.array(pos_list[tri_s[1]]), np.array(pos_list[tri_s[2]])
            if float(np.dot(np.cross(p1 - p0, p2 - p0), t_start)) < 0.0:
                tri_s = [tri_s[0], tri_s[2], tri_s[1]]
            tris_list.append(tri_s)

            tri_e = [c_end, cap_end_base + k, cap_end_base + kn]
            p0, p1, p2 = np.array(pos_list[tri_e[0]]), np.array(pos_list[tri_e[1]]), np.array(pos_list[tri_e[2]])
            if float(np.dot(np.cross(p1 - p0, p2 - p0), t_end)) < 0.0:
                tri_e = [tri_e[0], tri_e[2], tri_e[1]]
            tris_list.append(tri_e)

        return smt.compute_crease_normals(
            np.array(pos_list, dtype=np.float32),
            np.array(tris_list, dtype=np.int32),
            np.array(uv_list, dtype=np.float32),
            crease_deg=crease_deg,
        )


# Canonical Scale & Symmetry Constants
SCALE  = 2.50
X0_RAW = 0.0225

# Distinct PBR Material Swatch Centers on the 1024x1024 Texture Atlas
UV_CRIMSON = (0.8279, 0.7765)
UV_BRASS   = (0.1119, 0.0779)
UV_CYAN    = (0.9548, 0.7925)
UV_OAK     = (0.8504, 0.1357)
UV_BLADE   = (0.2231, 0.6436)
UV_IRON    = (0.3433, 0.0247)
UV_ROPE    = (0.6200, 0.1800)
UV_TIRE    = (0.4800, 0.1800)

# Wheel & Locomotion Constants
WHEEL_RADIUS   = 0.550  # meters (exact axle height Y = 0.550 m, ground contact Y = 0.000 m)
WHEEL_HALF_W   = 0.140  # meters (wheel width = 0.280 m)
WHEEL_X_OFFSET = 1.075  # meters (lateral distance from centerline X = 0 to wheel center)
AXLE_Z_FRONT   = +1.200 # meters
AXLE_Z_MID     = -0.340 # meters
AXLE_Z_REAR    = -1.715 # meters
WHEEL_CIRCUMF  = round(2.0 * math.pi * WHEEL_RADIUS, 4) # 3.4558 m per revolution

# Stabilizer Constants
STAB_FOLD_TRAVEL_DEG = 68.0  # deg upward fold in TRAVEL_READY (clears ground by +0.52 m)
STAB_PLANTED_DEG     = 0.0   # deg planted on ground in DEPLOYED_READY

# Linkage Constants for Main Launcher (II) at Y = 1.800 m
MAIN_LIMB_ROOT_X  = 0.880
MAIN_LIMB_ROOT_Y  = 1.800
MAIN_LIMB_ROOT_Z  = 0.920
MAIN_LIMB_LEN     = 1.480
MAIN_TIP_OVERHANG = 0.360
MAIN_BASE_SWEEP   = 6.0
MAIN_FLEX_LOADED  = 25.0
MAIN_FLEX_PEAK    = 30.0
MAIN_STR_LEN      = 2.380
MAIN_BOLT_LEN     = 3.750

# Linkage Constants for Upper Launcher (I) at Y = 2.760 m
UPPER_LIMB_ROOT_X  = 0.300
UPPER_LIMB_ROOT_Y  = 2.920
UPPER_LIMB_ROOT_Z  = 0.340
UPPER_LIMB_LEN     = 0.780
UPPER_TIP_OVERHANG = 0.180
UPPER_BASE_SWEEP   = 8.0
UPPER_FLEX_LOADED  = 25.0
UPPER_STR_LEN      = 1.095
UPPER_BOLT_LEN     = 1.650


def solve_bow_linkage(root_x, root_z, limb_len, base_sweep_deg, str_len, flex_deg):
    ang_rad = math.radians(base_sweep_deg + flex_deg)
    tip_x = root_x + limb_len * math.cos(ang_rad)
    tip_z = root_z - limb_len * math.sin(ang_rad)
    dz = math.sqrt(max(1e-6, str_len * str_len - tip_x * tip_x))
    z_nock = tip_z - dz
    str_yaw_deg = math.degrees(math.atan2(dz, tip_x))
    return tip_x, tip_z, z_nock, str_yaw_deg


MAIN_TIP_X_SPENT,  MAIN_TIP_Z_SPENT,  MAIN_Z_NOCK_SPENT,  MAIN_STR_ANG_SPENT  = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, 0.0)
MAIN_TIP_X_LOADED, MAIN_TIP_Z_LOADED, MAIN_Z_NOCK_LOADED, MAIN_STR_ANG_LOADED = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, MAIN_FLEX_LOADED)
MAIN_TIP_X_PEAK,   MAIN_TIP_Z_PEAK,   MAIN_Z_NOCK_PEAK,   MAIN_STR_ANG_PEAK   = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, MAIN_FLEX_PEAK)

UPPER_TIP_X_SPENT,  UPPER_TIP_Z_SPENT,  UPPER_Z_NOCK_SPENT,  UPPER_STR_ANG_SPENT  = solve_bow_linkage(UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Z, UPPER_LIMB_LEN, UPPER_BASE_SWEEP, UPPER_STR_LEN, 0.0)
UPPER_TIP_X_LOADED, UPPER_TIP_Z_LOADED, UPPER_Z_NOCK_LOADED, UPPER_STR_ANG_LOADED = solve_bow_linkage(UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Z, UPPER_LIMB_LEN, UPPER_BASE_SWEEP, UPPER_STR_LEN, UPPER_FLEX_LOADED)

# Carriage-Space Rest Pivots (LoadedDeployed rest state, meters)
# Note in v3.2:
#   - Elevation_Cradle (Node 13) trunnion pivot is raised to [0.000, 1.620, -0.120] (+287.3 mm side-rail / +387.3 mm center-deck clearance at +20 deg elevation!)
#   - Upper_Turret_Mount (Node 23) swivel pivot sits atop the Curved Sight Arch at [0.000, 2.540, +0.080] so mobile turret
#     rotation never moves the sight arch columns!
#   - Winch_Drum_And_Cranks (Node 20), Winch_Ratchet_Gear (Node 21), and Winch_Pawl_And_Lever (Node 22) are parented to
#     Traverse_Mount (Node 12) at ergonomic chest height Y = 1.420 m, Z = -1.380 m.
PIVOTS = {
    "Carriage_Chassis":        [0.000, 0.000, 0.000],
    "Wheel_FL":                [-WHEEL_X_OFFSET, WHEEL_RADIUS, AXLE_Z_FRONT],
    "Wheel_FR":                [+WHEEL_X_OFFSET, WHEEL_RADIUS, AXLE_Z_FRONT],
    "Wheel_ML":                [-WHEEL_X_OFFSET, WHEEL_RADIUS, AXLE_Z_MID],
    "Wheel_MR":                [+WHEEL_X_OFFSET, WHEEL_RADIUS, AXLE_Z_MID],
    "Wheel_RL":                [-WHEEL_X_OFFSET, WHEEL_RADIUS, AXLE_Z_REAR],
    "Wheel_RR":                [+WHEEL_X_OFFSET, WHEEL_RADIUS, AXLE_Z_REAR],
    "Stabilizer_FL":           [-1.180, 0.820, +1.050],
    "Stabilizer_FR":           [+1.180, 0.820, +1.050],
    "Stabilizer_RL":           [-1.180, 0.820, -1.420],
    "Stabilizer_RR":           [+1.180, 0.820, -1.420],
    "Traverse_Mount":          [0.000, 1.240, 0.000],
    "Elevation_Cradle":        [0.000, 1.620, -0.120],
    "Main_Limb_L":             [-MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Y, MAIN_LIMB_ROOT_Z],
    "Main_Limb_R":             [+MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Y, MAIN_LIMB_ROOT_Z],
    "Main_String_L":           [0.000, MAIN_LIMB_ROOT_Y, round(MAIN_Z_NOCK_LOADED, 4)],
    "Main_String_R":           [0.000, MAIN_LIMB_ROOT_Y, round(MAIN_Z_NOCK_LOADED, 4)],
    "Main_Draw_Catch":         [0.000, MAIN_LIMB_ROOT_Y - 0.035, round(MAIN_Z_NOCK_LOADED, 4)],
    "Main_Siege_Bolt":         [0.000, MAIN_LIMB_ROOT_Y + 0.035, round(MAIN_Z_NOCK_LOADED, 4)],
    "Winch_Drum_And_Cranks":   [0.000, 1.440, -0.920],
    "Winch_Ratchet_Gear":      [+0.420, 1.440, -0.920],
    "Winch_Pawl_And_Lever":    [-0.420, 1.560, -0.920],
    "Upper_Turret_Mount":      [0.000, 2.780, +0.080],
    "Upper_Limb_L":            [-UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Y, UPPER_LIMB_ROOT_Z],
    "Upper_Limb_R":            [+UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Y, UPPER_LIMB_ROOT_Z],
    "Upper_String_L":          [0.000, UPPER_LIMB_ROOT_Y, round(UPPER_Z_NOCK_LOADED, 4)],
    "Upper_String_R":          [0.000, UPPER_LIMB_ROOT_Y, round(UPPER_Z_NOCK_LOADED, 4)],
    "Upper_Catch_And_Trigger": [0.000, UPPER_LIMB_ROOT_Y - 0.028, round(UPPER_Z_NOCK_LOADED, 4)],
    "Upper_Conditioning_Bolt": [0.000, UPPER_LIMB_ROOT_Y + 0.025, round(UPPER_Z_NOCK_LOADED, 4)],
}

ORDERED_NODES = list(PIVOTS.keys()) # Nodes 1..29

NODE_PARENT_NAME = {
    "Carriage_Chassis":        "BiBye_Root",
    "Wheel_FL":                "Carriage_Chassis",
    "Wheel_FR":                "Carriage_Chassis",
    "Wheel_ML":                "Carriage_Chassis",
    "Wheel_MR":                "Carriage_Chassis",
    "Wheel_RL":                "Carriage_Chassis",
    "Wheel_RR":                "Carriage_Chassis",
    "Stabilizer_FL":           "Carriage_Chassis",
    "Stabilizer_FR":           "Carriage_Chassis",
    "Stabilizer_RL":           "Carriage_Chassis",
    "Stabilizer_RR":           "Carriage_Chassis",
    "Traverse_Mount":          "Carriage_Chassis",
    "Elevation_Cradle":        "Traverse_Mount",
    "Main_Limb_L":             "Elevation_Cradle",
    "Main_Limb_R":             "Elevation_Cradle",
    "Main_String_L":           "Elevation_Cradle",
    "Main_String_R":           "Elevation_Cradle",
    "Main_Draw_Catch":         "Elevation_Cradle",
    "Main_Siege_Bolt":         "Elevation_Cradle",
    "Winch_Drum_And_Cranks":   "Traverse_Mount",
    "Winch_Ratchet_Gear":      "Traverse_Mount",
    "Winch_Pawl_And_Lever":    "Traverse_Mount",
    "Upper_Turret_Mount":      "Traverse_Mount",
    "Upper_Limb_L":            "Upper_Turret_Mount",
    "Upper_Limb_R":            "Upper_Turret_Mount",
    "Upper_String_L":          "Upper_Turret_Mount",
    "Upper_String_R":          "Upper_Turret_Mount",
    "Upper_Catch_And_Trigger": "Upper_Turret_Mount",
    "Upper_Conditioning_Bolt": "Upper_Turret_Mount",
}

V4_MECHANISM_NODES = [
    ("Operator_Steering_Tiller",      "Carriage_Chassis", 1,  49, [+0.280, 1.020, -1.460]),
    ("Operator_Traverse_Wheel",       "Carriage_Chassis", 1,  50, [-0.280, 1.180, -1.440]),
    ("Operator_Fire_And_Couple_Lever","Carriage_Chassis", 1,  51, [-0.160, 1.040, -1.420]),
    ("Coupling_Clutch_Collar",        "Traverse_Mount",   12, 52, [0.000,  2.540, -0.180]),
    ("Coupling_Transfer_Linkage",     "Elevation_Cradle", 13, 53, [+0.360, 2.180, -0.160]),
    ("Delay_Escapement_Gear",         "Elevation_Cradle", 13, 54, [+0.340, 1.840, -0.520]),
    ("Heavy_Sear_Trip_Bar",           "Elevation_Cradle", 13, 55, [+0.180, 1.765, -0.780]),
]

for _v4_name, _v4_parent, _, _, _v4_piv in V4_MECHANISM_NODES:
    PIVOTS[_v4_name] = _v4_piv
    NODE_PARENT_NAME[_v4_name] = _v4_parent

LOCATORS = {
    "main_bolt_muzzle": {
        "world_translation": [0.000, 1.835, +1.520],
        "translation": [0.000, round(1.835 - 1.620, 4), round(1.520 - (-0.120), 4)],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Elevation_Cradle",
        "description": "Stage II heavy physical siege bolt muzzle locator at the front end of the lower guide rail (+Z firing axis); follows Traverse_Mount and Elevation_Cradle."
    },
    "aim_direction": {
        "world_translation": [0.000, 2.180, +3.600],
        "translation": [0.000, round(2.180 - 1.620, 4), round(3.600 - (-0.120), 4)],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Elevation_Cradle",
        "description": "Committed forward aim reference point along the +Z ballistic axis through the wide Gunner Sight Arch; follows Traverse_Mount and Elevation_Cradle."
    },
    "winch_crank_L": {
        "world_translation": [-0.680, 1.440, -0.920],
        "translation": [-0.680, round(1.440 - 1.240, 4), -0.920],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Traverse_Mount",
        "description": "Left compact winch crank handle anchor on Traverse_Mount (Z = -0.920 m, clear of the seated operator station)."
    },
    "winch_crank_R": {
        "world_translation": [+0.680, 1.440, -0.920],
        "translation": [+0.680, round(1.440 - 1.240, 4), -0.920],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Traverse_Mount",
        "description": "Right compact winch crank handle anchor on Traverse_Mount (Z = -0.920 m, clear of the seated operator station)."
    },
    "small_bolt_muzzle": {
        "world_translation": [0.000, 2.945, +0.920],
        "translation": [0.000, round(2.945 - 2.780, 4), round(0.920 - 0.080, 4)],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Upper_Turret_Mount",
        "description": "Stage I conditioning bolt muzzle locator at the front end of the 360-deg upper loading track (+Z firing axis); follows Upper_Turret_Mount, Elevation_Cradle, and Traverse_Mount."
    },
    "operator_station": {
        "world_translation": [0.000, 0.000, -2.550],
        "translation": [0.000, 0.000, -2.550],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "BiBye_Root",
        "description": "Ground-level rear dismount / approach mark behind the operator cockpit."
    },
    "transport_push_station": {
        "world_translation": [0.000, 0.000, -2.450],
        "translation": [0.000, 0.000, -2.450],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "BiBye_Root",
        "description": "Ground-level rear transport/push interaction station."
    },
    "mounted_camera_tpv": {
        "world_translation": [0.000, 3.850, -4.800],
        "translation": [0.000, round(3.850 - 1.240, 4), -4.800],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Traverse_Mount",
        "description": "Elevated third-person siege camera anchor (Y = 3.850 m, Z = -4.800 m) above the 360-deg upper turret; follows horizontal traverse."
    },
    "mounted_camera_sight": {
        "world_translation": [0.000, 2.180, -1.450],
        "translation": [0.000, round(2.180 - 1.620, 4), round(-1.450 - (-0.120), 4)],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Elevation_Cradle",
        "description": "First-person coupled gunner sightline camera anchor looking through the 0.70m-wide Curved Gunner Sight Arch; follows Traverse_Mount and Elevation_Cradle."
    },
}

V4_SEATED_OPERATOR_LOCATORS = {
    "operator_seat_pivot": {
        "node_index": 56,
        "world_translation": [0.000, 0.960, -1.860],
        "translation": [0.000, 0.960, -1.860],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Carriage_Chassis",
        "parent_idx": 1,
        "spellblade_bone": "root",
        "description": "Seated operator saddle-chair surface center on Carriage_Chassis (faces +Z with carriage; does not spin when upper turret rotates)."
    },
    "seat_pelvis_anchor": {
        "node_index": 57,
        "world_translation": [0.000, 0.980, -1.860],
        "translation": [0.000, 0.980, -1.860],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Carriage_Chassis",
        "parent_idx": 1,
        "spellblade_bone": "pelvis",
        "description": "Exact seated pelvis/hip placement anchor for ARSpellbladeRig pelvis bone (1.80 m Spellblade helmet crest at Y = 1.853 m)."
    },
    "seat_backrest_support": {
        "node_index": 58,
        "world_translation": [0.000, 1.320, -2.040],
        "translation": [0.000, 1.320, -2.040],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Carriage_Chassis",
        "parent_idx": 1,
        "spellblade_bone": "chest",
        "description": "Armored backrest thoracic support anchor for ARSpellbladeRig chest bone."
    },
    "operator_footrest_L": {
        "node_index": 59,
        "world_translation": [+0.210, 0.520, -1.360],
        "translation": [+0.210, 0.520, -1.360],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Carriage_Chassis",
        "parent_idx": 1,
        "spellblade_bone": "foot.L",
        "description": "Left (+X when facing +Z) iron-grated footrest stirrup anchor for SpellbladeRig foot.L bone."
    },
    "operator_footrest_R": {
        "node_index": 60,
        "world_translation": [-0.210, 0.520, -1.360],
        "translation": [-0.210, 0.520, -1.360],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Carriage_Chassis",
        "parent_idx": 1,
        "spellblade_bone": "foot.R",
        "description": "Right (-X when facing +Z) iron-grated footrest stirrup anchor for SpellbladeRig foot.R bone."
    },
    "hand_L_steering_grip": {
        "node_index": 61,
        "world_translation": [+0.280, 1.260, -1.460],
        "translation": [0.000, +0.240, 0.000],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Operator_Steering_Tiller",
        "parent_idx": 49,
        "spellblade_bone": "hand.L",
        "description": "Left (+X when facing +Z) gauntlet control grip on Operator_Steering_Tiller (Node 49); moves with steering input."
    },
    "hand_R_traverse_grip": {
        "node_index": 62,
        "world_translation": [-0.280, 1.260, -1.440],
        "translation": [0.000, +0.080, 0.000],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Operator_Traverse_Wheel",
        "parent_idx": 50,
        "spellblade_bone": "hand.R",
        "description": "Right (-X when facing +Z) gauntlet primary grip on Operator_Traverse_Wheel (Node 50); rotates with aiming and winch feedback."
    },
    "hand_R_fire_lever_grip": {
        "node_index": 63,
        "world_translation": [-0.160, 1.280, -1.420],
        "translation": [0.000, +0.240, 0.000],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Operator_Fire_And_Couple_Lever",
        "parent_idx": 51,
        "spellblade_bone": "hand.R",
        "description": "Right (-X when facing +Z) gauntlet secondary grip on Operator_Fire_And_Couple_Lever (Node 51) for coupling and firing."
    },
    "mounted_camera_upper_360": {
        "node_index": 64,
        "world_translation": [0.000, 3.160, -0.780],
        "translation": [0.000, +0.380, -0.860],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "parent": "Upper_Turret_Mount",
        "parent_idx": 23,
        "spellblade_bone": "camera_eye",
        "description": "Dedicated 360-deg upper-turret sight camera anchor that rotates and pitches with Upper_Turret_Mount (Node 23) through all 360 degrees."
    },
}

# =============================================================================
# 1. BESPOKE V3.2 SUBASSEMBLY GEOMETRY BUILDERS (SMOOTH CURVES & CLEAN BEVELS)
# =============================================================================

def smooth_box(bmin, bmax, bevel=0.015, uv_center=UV_OAK, crease_deg=35.0):
    p, n, u, t = mbu.make_beveled_box(bmin, bmax, bevel=bevel, uv_center=uv_center)
    # Unwrap each triangle with triplanar world-space projection so side/top/end faces never stretch!
    uc, vc = float(uv_center[0]), float(uv_center[1])
    center = 0.5 * (np.array(bmin, dtype=np.float32) + np.array(bmax, dtype=np.float32))
    span = np.maximum(np.array(bmax, dtype=np.float32) - np.array(bmin, dtype=np.float32), 0.04)
    p_new, u_new, t_new = [], [], []
    for tri in t.reshape(-1, 3):
        v0, v1, v2 = p[tri[0]], p[tri[1]], p[tri[2]]
        fn = np.cross(v1 - v0, v2 - v0)
        ax = int(np.argmax(np.abs(fn)))
        base = len(p_new)
        for vv in (v0, v1, v2):
            dp = vv - center
            if ax == 0:
                du, dv = dp[2] / max(span[2], 0.1), dp[1] / max(span[1], 0.1)
            elif ax == 1:
                du, dv = dp[0] / max(span[0], 0.1), dp[2] / max(span[2], 0.1)
            else:
                du, dv = dp[0] / max(span[0], 0.1), dp[1] / max(span[1], 0.1)
            p_new.append(vv)
            u_new.append([uc + 0.038 * float(du), vc + 0.038 * float(dv)])
        t_new.append([base, base + 1, base + 2])
    return smt.compute_crease_normals(
        np.array(p_new, dtype=np.float32),
        np.array(t_new, dtype=np.int32),
        np.array(u_new, dtype=np.float32),
        crease_deg=crease_deg
    )


def make_v32_siege_wheel_mesh(side_sign: float):
    """
    Builds a 100% clean, lathe-turned, load-bearing medieval siege wheel (R = 0.550 m, width = 0.280 m)
    with zero marching-cubes boolean artifacts:
      - Crowned forged-iron tire (R = 0.514..0.550 m) with 18 mm chamfered sidewalls & 16 countersunk rivets
      - 8 low-profile beveled traction cleats around the outer iron tread
      - Smoothly curved dark-oak felloe ring (R = 0.412..0.514 m) with inner bronze stiffening ring
      - 8 tapered octagonal oak spokes (R = 0.142..0.418 m) with turned bronze base & rim ferrules
      - Lathe-turned cast-iron & burnished-bronze nave hub (R = 0.168 m) with outer hexagonal linchpin cap
    """
    parts = []
    w_half = 0.132

    # 1. Continuous Lathe Rim (Inner Bronze Band -> Oak Felloe -> Crowned Forged-Iron Tire -> Inner Bronze Band)
    # Build outer tire & felloe sidewalls + inner felloe face as two clean outward-oriented lathe profiles
    rim_profile = [
        (-w_half * 0.88, 0.402, UV_BRASS),
        (-w_half * 0.96, 0.418, UV_OAK),
        (-w_half * 0.98, 0.512, UV_OAK),
        (-w_half * 1.00, 0.518, UV_TIRE),
        (-w_half * 0.86, 0.545, UV_TIRE),
        ( 0.000,         0.550, UV_TIRE),
        (+w_half * 0.86, 0.545, UV_TIRE),
        (+w_half * 1.00, 0.518, UV_TIRE),
        (+w_half * 0.98, 0.512, UV_OAK),
        (+w_half * 0.96, 0.418, UV_OAK),
        (+w_half * 0.88, 0.402, UV_BRASS),
    ]
    parts.append(smt.make_lathe_mesh(rim_profile, axis='x', segs=32, crease_deg=46.0))

    # 2. Solid Lathe-Turned Nave Hub + Inner Backing Disc (zero gaps or holes from any camera angle)
    hub_pts = [
        (-0.155, 0.000, UV_IRON),
        (-0.155, 0.235, UV_IRON),
        (-0.125, 0.235, UV_BRASS),
        (-0.120, 0.172, UV_BRASS),
        (-0.080, 0.172, UV_OAK),
        (+0.085, 0.172, UV_OAK),
        (+0.120, 0.158, UV_BRASS),
        (+0.155, 0.132, UV_BRASS),
        (+0.188, 0.092, UV_IRON),
        (+0.192, 0.000, UV_BRASS),
    ]
    hp, hn, hu, ht = smt.make_lathe_mesh(hub_pts, axis='x', segs=24, crease_deg=44.0)
    if side_sign < 0:
        hp = hp.copy(); hp[:, 0] *= -1.0
        hn = hn.copy(); hn[:, 0] *= -1.0
        ht = ht[:, [0, 2, 1]].copy()
    parts.append((hp, hn, hu, ht))

    # 3. 8 Tapered Octagonal Oak Spokes with Turned Bronze Ferrules + 8 Low-Profile Beveled Tire Cleats
    for k in range(8):
        ang = k * (math.pi / 4.0)
        ca, sa = math.cos(ang), math.sin(ang)
        R_rot = np.array([[1.0, 0.0, 0.0], [0.0, ca, -sa], [0.0, sa, ca]], dtype=np.float32)

        sp_path = [
            [0.0, 0.140, 0.0],
            [0.0, 0.195, 0.0],
            [0.0, 0.365, 0.0],
            [0.0, 0.412, 0.0],
        ]
        sp_radii = [
            (0.058, 0.044),
            (0.052, 0.038),
            (0.042, 0.032),
            (0.048, 0.036),
        ]
        sp_mesh = smt.make_swept_octagonal_beam(sp_path, sp_radii, UV_OAK, crease_deg=40.0)
        ferrule_base = smt.make_lathe_mesh([
            (0.148, 0.056, UV_BRASS), (0.188, 0.052, UV_BRASS)
        ], axis='y', segs=12, crease_deg=45.0)
        ferrule_rim = smt.make_lathe_mesh([
            (0.375, 0.046, UV_BRASS), (0.408, 0.050, UV_BRASS)
        ], axis='y', segs=12, crease_deg=45.0)
        cleat = smooth_box(
            [-w_half * 0.84, 0.540, -0.026],
            [+w_half * 0.84, 0.556, +0.026],
            bevel=0.007, uv_center=UV_BRASS if k % 2 == 0 else UV_IRON, crease_deg=35.0
        )
        for p_m, n_m, u_m, t_m in (sp_mesh, ferrule_base, ferrule_rim, cleat):
            parts.append((p_m @ R_rot.T, n_m @ R_rot.T, u_m, t_m))

    return mbu.concat_meshes(parts)


def make_v32_stabilizer_mesh(side_sign: float):
    """
    Builds a 100% symmetrical, articulated A-frame siege outrigger stabilizer:
      - Local origin (0, 0, 0) is the clevis hinge at [+/-1.180, 0.820, +1.050 / -1.420]
      - When planted at 0.0 deg, the broad circular bronze/iron spade foot rests flush on Y_world = 0.000 m
        (Y_local = -0.820 m at X_local = side_sign * 0.720 m).
    """
    s = float(side_sign)
    parts = [
        # Upper clevis hinge & brass pivot pin at [0, 0, 0]
        smt.make_lathe_mesh([
            (-0.14, 0.000, UV_BRASS), (-0.14, 0.068, UV_BRASS),
            (-0.11, 0.088, UV_IRON),  (+0.11, 0.088, UV_IRON),
            (+0.14, 0.068, UV_BRASS), (+0.14, 0.000, UV_BRASS),
        ], axis='z', center=(0.0, 0.0, 0.0), segs=18, crease_deg=45.0),
        # Tapered octagonal main oak outrigger beam from [0, 0, 0] to [s*0.700, -0.740, 0.0]
        smt.make_swept_octagonal_beam(
            [[0.0, 0.0, 0.0], [s * 0.24, -0.25, 0.0], [s * 0.52, -0.55, 0.0], [s * 0.70, -0.75, 0.0]],
            [(0.078, 0.068), (0.072, 0.064), (0.064, 0.056), (0.058, 0.052)],
            UV_OAK, crease_deg=40.0
        ),
        # Forged-iron reinforcement collar halfway down the leg
        smt.make_swept_octagonal_beam(
            [[s * 0.30, -0.32, 0.0], [s * 0.42, -0.44, 0.0]],
            [(0.076, 0.068), (0.072, 0.064)],
            UV_BRASS, crease_deg=40.0
        ),
        # Internal diagonal turnbuckle brace strut from [-s*0.04, -0.22, 0] to [s*0.52, -0.60, 0]
        smt.make_swept_octagonal_beam(
            [[-s * 0.04, -0.22, 0.0], [s * 0.24, -0.41, 0.0], [s * 0.52, -0.60, 0.0]],
            [(0.036, 0.036), (0.044, 0.044), (0.036, 0.036)],
            UV_IRON, crease_deg=42.0
        ),
        # Articulated ankle ball-joint & broad circular bronze/iron spade pad at [s*0.710, -0.820..0.720, 0.0]
        smt.make_lathe_mesh([
            (-0.820, 0.000, UV_IRON),
            (-0.820, 0.215, UV_IRON),
            (-0.795, 0.225, UV_BRASS),
            (-0.768, 0.195, UV_BRASS),
            (-0.745, 0.115, UV_IRON),
            (-0.710, 0.075, UV_BRASS),
            (-0.710, 0.000, UV_BRASS),
        ], axis='y', center=(s * 0.710, 0.0, 0.0), segs=24, crease_deg=45.0),
    ]
    return mbu.concat_meshes(parts)


def make_v33_damaged_siege_wheel_mesh(side_sign: float):
    """
    Builds a battle-damaged / destroyed medieval siege wheel (Nodes 39..44: Wheel_FL_Damaged .. Wheel_RR_Damaged):
      - Local origin (0, 0, 0) matches the intact wheel axle pivot [-/+1.075, 0.550, Z_axle].
      - Features a fractured 260-degree oak felloe arc (missing a 100-degree crushed lower sector around -Y),
        jagged splintered dark-oak rim break stubs, a split & peeled-back forged-iron tire strap curling outward,
        3 shattered/splintered spoke stubs in the crushed sector + 5 strained intact spokes, and an impaired
        5.5-degree canted bronze/iron nave hub that visibly wobbles when rolled or sags when collapsed.
    """
    s = float(side_sign)
    parts = []
    w_half = 0.132

    # 1. Impaired, 5.5-deg canted Nave Hub (produces visible bearing wobble when rolled!)
    hub_pts = [
        (-0.155, 0.000, UV_IRON),
        (-0.155, 0.235, UV_IRON),
        (-0.125, 0.235, UV_BRASS),
        (-0.120, 0.172, UV_BRASS),
        (-0.080, 0.172, UV_OAK),
        (+0.085, 0.172, UV_OAK),
        (+0.120, 0.158, UV_BRASS),
        (+0.155, 0.132, UV_BRASS),
        (+0.188, 0.092, UV_IRON),
        (+0.192, 0.000, UV_BRASS),
    ]
    hp, hn, hu, ht = smt.make_lathe_mesh(hub_pts, axis='x', segs=20, crease_deg=44.0)
    if s < 0:
        hp = hp.copy(); hp[:, 0] *= -1.0
        hn = hn.copy(); hn[:, 0] *= -1.0
        ht = ht[:, [0, 2, 1]].copy()
    ang_cant = math.radians(5.5 * s)
    ca_c, sa_c = math.cos(ang_cant), math.sin(ang_cant)
    R_cant = np.array([[ca_c, -sa_c, 0.0], [sa_c, ca_c, 0.0], [0.0, 0.0, 1.0]], dtype=np.float32)
    parts.append((hp @ R_cant.T, hn @ R_cant.T, hu, ht))

    # 2. Fractured 250-degree Oak Felloe & Iron Tire Arc (missing a 110-degree shattered gap on the front-lower quadrant!)
    arc_angles = np.linspace(math.radians(150.0), math.radians(400.0), 19)
    felloe_pts = [[0.0, 0.462 * math.cos(a), 0.462 * math.sin(a)] for a in arc_angles]
    felloe_rads = [(0.118, 0.052) for _ in arc_angles]
    parts.append(smt.make_swept_octagonal_beam(felloe_pts, felloe_rads, UV_OAK, crease_deg=42.0))

    # Outer forged-iron tire along the intact upper 240 deg, plus peeled-back sprung iron ends at -130 deg and +130 deg!
    tire_angles = np.linspace(math.radians(138.0), math.radians(412.0), 21)
    tire_pts = []
    tire_rads = []
    for idx_t, a in enumerate(tire_angles):
        # Flare outward at the two broken ends (idx_t <= 2 or idx_t >= 18)
        flare = 0.0
        dx_peel = 0.0
        if idx_t < 3:
            u_f = (3 - idx_t) / 3.0
            flare = 0.085 * (u_f ** 1.4)
            dx_peel = s * 0.045 * u_f
        elif idx_t > 17:
            u_f = (idx_t - 17) / 3.0
            flare = 0.095 * (u_f ** 1.4)
            dx_peel = -s * 0.038 * u_f
        r_t = 0.532 + flare
        tire_pts.append([dx_peel, r_t * math.cos(a), r_t * math.sin(a)])
        tire_rads.append((0.126 * (1.0 - 0.15 * (flare > 0)), 0.022))
    parts.append(smt.make_swept_octagonal_beam(tire_pts, tire_rads, UV_TIRE, crease_deg=42.0))

    # Jagged splintered oak fracture stubs at the two broken felloe ends (-130 deg and +130 deg)
    for a0_deg, a1_deg in ((152.0, 136.0), (398.0, 414.0)):
        a0 = math.radians(a0_deg)
        a1 = math.radians(a1_deg)
        for sp_off, r_sp in ((-0.045, 0.445), (+0.040, 0.478)):
            stub_pts = [
                [sp_off, r_sp * math.cos(a0), r_sp * math.sin(a0)],
                [sp_off * 1.2, (r_sp - 0.015) * math.cos(a1), (r_sp - 0.015) * math.sin(a1)],
            ]
            parts.append(smt.make_swept_octagonal_beam(stub_pts, [(0.038, 0.032), (0.008, 0.008)], UV_OAK, crease_deg=36.0))

    # 3. 5 Intact Strained Spokes (k = 0, 1, 2, 6, 7) + 3 Shattered Spoke Stubs (k = 3, 4, 5 in bottom sector)
    for k in range(8):
        ang = k * (math.pi / 4.0)
        ca, sa = math.cos(ang), math.sin(ang)
        R_rot = np.array([[1.0, 0.0, 0.0], [0.0, ca, -sa], [0.0, sa, ca]], dtype=np.float32)
        if k in (1, 2, 3):
            # Shattered spoke stub protruding from the hub with jagged splintered tip + bent brass ferrule
            stub_len = 0.255 if k == 4 else 0.310
            bend_x = s * (0.035 if k == 3 else -0.042)
            sp_path = [
                [0.0, 0.140, 0.0],
                [bend_x * 0.4, 0.205, 0.012],
                [bend_x, stub_len, -0.018],
            ]
            sp_radii = [(0.058, 0.044), (0.048, 0.036), (0.010, 0.008)]
            sp_mesh = smt.make_swept_octagonal_beam(sp_path, sp_radii, UV_OAK, crease_deg=38.0)
            ferrule_base = smt.make_lathe_mesh([
                (0.148, 0.056, UV_BRASS), (0.188, 0.052, UV_BRASS)
            ], axis='y', segs=12, crease_deg=45.0)
            for p_m, n_m, u_m, t_m in (sp_mesh, ferrule_base):
                parts.append((p_m @ R_rot.T, n_m @ R_rot.T, u_m, t_m))
        else:
            # Intact spoke with slight battle strain
            sp_path = [
                [0.0, 0.140, 0.0],
                [s * 0.012, 0.240, 0.0],
                [0.0, 0.418, 0.0],
            ]
            sp_radii = [(0.058, 0.044), (0.046, 0.035), (0.048, 0.036)]
            sp_mesh = smt.make_swept_octagonal_beam(sp_path, sp_radii, UV_OAK, crease_deg=40.0)
            ferrule_base = smt.make_lathe_mesh([
                (0.148, 0.056, UV_BRASS), (0.188, 0.052, UV_BRASS)
            ], axis='y', segs=12, crease_deg=45.0)
            for p_m, n_m, u_m, t_m in (sp_mesh, ferrule_base):
                parts.append((p_m @ R_rot.T, n_m @ R_rot.T, u_m, t_m))

    return mbu.concat_meshes(parts)


def make_v33_damaged_stabilizer_mesh(side_sign: float):
    """
    Builds a visibly shattered / failed siege outrigger stabilizer (Nodes 45..48: Stabilizer_FL_Damaged .. Stabilizer_RR_Damaged):
      - Local origin (0, 0, 0) is the clevis hinge at [+/-1.180, 0.820, +1.050 / -1.420].
      - Features a sheared upper oak beam stump ending in jagged dark-oak splinters, a snapped diagonal iron
        turnbuckle rod hanging down, and the broken lower leg + twisted bronze spade foot buckled upward/askew
        at Y_local = -0.58 m (Y_world = +0.24 m above the ground) so it visibly fails to touch or brace the ground!
    """
    s = float(side_sign)
    parts = [
        # Upper clevis hinge at [0, 0, 0]
        smt.make_lathe_mesh([
            (-0.14, 0.000, UV_BRASS), (-0.14, 0.068, UV_BRASS),
            (-0.11, 0.088, UV_IRON),  (+0.11, 0.088, UV_IRON),
            (+0.14, 0.068, UV_BRASS), (+0.14, 0.000, UV_BRASS),
        ], axis='z', center=(0.0, 0.0, 0.0), segs=18, crease_deg=45.0),
        # Upper sheared oak outrigger stump from [0, 0, 0] to fracture point [s*0.36, -0.37, +0.02]
        smt.make_swept_octagonal_beam(
            [[0.0, 0.0, 0.0], [s * 0.20, -0.21, +0.01], [s * 0.36, -0.37, +0.02]],
            [(0.078, 0.068), (0.072, 0.064), (0.062, 0.054)],
            UV_OAK, crease_deg=40.0
        ),
        # Jagged splintered oak spikes protruding from the fracture face
        smt.make_swept_octagonal_beam(
            [[s * 0.32, -0.33, +0.04], [s * 0.45, -0.46, +0.07]],
            [(0.032, 0.028), (0.006, 0.006)],
            UV_OAK, crease_deg=36.0
        ),
        smt.make_swept_octagonal_beam(
            [[s * 0.33, -0.35, -0.03], [s * 0.43, -0.48, -0.06]],
            [(0.028, 0.024), (0.006, 0.006)],
            UV_OAK, crease_deg=36.0
        ),
        # Twisted forged-iron collar band at the fracture
        smt.make_swept_octagonal_beam(
            [[s * 0.28, -0.30, +0.01], [s * 0.37, -0.38, +0.03]],
            [(0.078, 0.070), (0.074, 0.066)],
            UV_BRASS, crease_deg=40.0
        ),
        # Sheared diagonal iron turnbuckle strut hanging down loose
        smt.make_swept_octagonal_beam(
            [[-s * 0.04, -0.22, 0.0], [s * 0.10, -0.42, -0.04], [s * 0.22, -0.61, -0.09]],
            [(0.036, 0.036), (0.042, 0.042), (0.022, 0.022)],
            UV_IRON, crease_deg=42.0
        ),
        # Buckled lower outrigger leg & twisted bronze spade pad dangling askew (+0.23m above ground!)
        smt.make_swept_octagonal_beam(
            [[s * 0.38, -0.36, +0.05], [s * 0.52, -0.46, +0.11], [s * 0.64, -0.55, +0.16]],
            [(0.048, 0.044), (0.058, 0.052), (0.056, 0.050)],
            UV_OAK, crease_deg=40.0
        ),
        smooth_box(
            [s * 0.64 - 0.19, -0.61, +0.02],
            [s * 0.64 + 0.19, -0.53, +0.32],
            bevel=0.016, uv_center=UV_BRASS, crease_deg=38.0
        ),
    ]
    return mbu.concat_meshes(parts)


def make_v32_engineered_sword_limb_mesh(side_sign: float, limb_len: float, tip_overhang: float, base_sweep_deg: float, is_upper: bool = False):
    """
    Builds a refined, curved, multi-leaf forged spring-steel sword-limb:
      - Local origin (0, 0, 0) is the torsion drum pivot.
      - Features a cylindrical bronze torsion journal socket, a forged iron ricasso bolster,
        3 stepped spring-steel leaf laminations clamped by 2 brass keeper bands on the rear curve,
        a smoothly arching diamond-section tempered blade with recessed fuller groove and smooth
        longitudinal normals, and a forged brass recurve nock hook at s = limb_len.
    """
    s_sgn = float(side_sign)
    total_len = limb_len + tip_overhang
    ang_rad = math.radians(base_sweep_deg)
    u_x, u_z = s_sgn * math.cos(ang_rad), -math.sin(ang_rad)
    # Outward normal in XZ plane (pointing forward +Z / outward)
    f_x, f_z = s_sgn * math.sin(ang_rad), +math.cos(ang_rad)

    scale_f = 0.52 if is_upper else 1.00
    parts = []

    # 1. Cylindrical Bronze Torsion Journal Sleeve & Forged Crossguard Bolster at [0, 0, 0]
    parts.append(smt.make_lathe_mesh([
        (-0.22 * scale_f, 0.000, UV_BRASS),
        (-0.22 * scale_f, 0.135 * scale_f, UV_BRASS),
        (-0.18 * scale_f, 0.150 * scale_f, UV_IRON),
        (+0.18 * scale_f, 0.150 * scale_f, UV_IRON),
        (+0.22 * scale_f, 0.135 * scale_f, UV_BRASS),
        (+0.22 * scale_f, 0.000, UV_BRASS),
    ], axis='y', center=(0.0, 0.0, 0.0), segs=20, crease_deg=45.0))

    # Swept crossguard quillons framing the blade root
    q_p = [
        [0.08 * scale_f * u_x - 0.16 * scale_f * f_x, 0.0, 0.08 * scale_f * u_z - 0.16 * scale_f * f_z],
        [0.10 * scale_f * u_x,                        0.0, 0.10 * scale_f * u_z],
        [0.08 * scale_f * u_x + 0.18 * scale_f * f_x, 0.0, 0.08 * scale_f * u_z + 0.18 * scale_f * f_z],
    ]
    parts.append(smt.make_swept_octagonal_beam(
        q_p,
        [(0.16 * scale_f, 0.048 * scale_f), (0.20 * scale_f, 0.062 * scale_f), (0.16 * scale_f, 0.048 * scale_f)],
        UV_BRASS, crease_deg=40.0
    ))

    # 2. Continuous 14-Station Curved Diamond-Section Tempered Spring-Steel Sword Blade
    # Includes subtle natural forward arch (camber) that straightens toward the tip
    n_st = 14
    s_vals = np.linspace(0.06 * scale_f, total_len, n_st)
    pos_list = []
    uv_list  = []
    tris_list = []

    # 8-vertex cross-section per station:
    # 0: Front cutting edge (+f)
    # 1: Upper-front bevel ridge
    # 2: Upper fuller groove
    # 3: Upper-rear spine ridge
    # 4: Rear spine back (-f)
    # 5: Lower-rear spine ridge
    # 6: Lower fuller groove
    # 7: Lower-front bevel ridge
    for i, s_d in enumerate(s_vals):
        u_prog = float((s_d - s_vals[0]) / max(total_len - s_vals[0], 1e-6))
        # Graceful parabolic arch camber
        camber = (0.065 * scale_f) * math.sin(u_prog * math.pi) * (1.0 - 0.25 * u_prog)
        cx = s_d * u_x + camber * f_x
        cz = s_d * u_z + camber * f_z

        # Commanding forged greatsword-limb proportions: broad 0.42m vertical depth & 0.44m chord width at root
        if u_prog < 0.72:
            w_f = (0.225 - 0.055 * (u_prog / 0.72)) * scale_f
            h_y = (0.210 - 0.075 * (u_prog / 0.72)) * scale_f
        else:
            u_tip = (u_prog - 0.72) / 0.28
            w_f = 0.170 * scale_f * max(0.04, 1.0 - u_tip**1.35)
            h_y = 0.135 * scale_f * max(0.04, 1.0 - u_tip**1.25)

        ring_offsets = [
            (+1.00 * w_f,  0.00 * h_y, UV_BLADE), # 0: Front cutting edge
            (+0.36 * w_f, +0.85 * h_y, UV_BLADE), # 1: Upper-front bevel
            (-0.06 * w_f, +0.52 * h_y, UV_BRASS if u_prog < 0.72 else UV_BLADE), # 2: Upper fuller
            (-0.62 * w_f, +0.92 * h_y, UV_BLADE), # 3: Upper-rear spine
            (-0.95 * w_f,  0.00 * h_y, UV_IRON),  # 4: Rear spine back
            (-0.62 * w_f, -0.92 * h_y, UV_BLADE), # 5: Lower-rear spine
            (-0.06 * w_f, -0.52 * h_y, UV_BRASS if u_prog < 0.72 else UV_BLADE), # 6: Lower fuller
            (+0.32 * w_f, -0.82 * h_y, UV_BLADE), # 7: Lower-front bevel
        ]
        for k_idx, (df, dy, uv_c) in enumerate(ring_offsets):
            pos_list.append([cx + df * f_x, dy, cz + df * f_z])
            u_blade = UV_BLADE[0] + 0.038 * (u_prog - 0.5)
            v_blade = UV_BLADE[1] + 0.022 * (abs(k_idx - 4) / 4.0 - 0.5)
            uv_list.append([u_blade, v_blade])

    n_ring = 8
    for i in range(n_st - 1):
        r0 = i * n_ring
        r1 = (i + 1) * n_ring
        for k in range(n_ring):
            kn = (k + 1) % n_ring
            if s_sgn > 0:
                tris_list.append([r0 + k, r1 + k, r1 + kn])
                tris_list.append([r0 + k, r1 + kn, r0 + kn])
            else:
                tris_list.append([r0 + k, r1 + kn, r1 + k])
                tris_list.append([r0 + k, r0 + kn, r1 + kn])

    # Cap tip point with distinct longitudinal UV so tip triangles have non-zero 2D UV area
    tip_idx = len(pos_list)
    pos_list.append([total_len * u_x, 0.0, total_len * u_z])
    uv_list.append([UV_BLADE[0] + 0.024, UV_BLADE[1]])
    last_r = (n_st - 1) * n_ring
    for k in range(n_ring):
        kn = (k + 1) % n_ring
        if s_sgn > 0:
            tris_list.append([last_r + k, tip_idx, last_r + kn])
        else:
            tris_list.append([last_r + k, last_r + kn, tip_idx])

    parts.append(smt.compute_crease_normals(
        np.array(pos_list, dtype=np.float32),
        np.array(tris_list, dtype=np.int32),
        np.array(uv_list, dtype=np.float32),
        crease_deg=38.0, # Smooths longitudinal curve while keeping cutting edge & fuller ridges crisp!
    ))

    # 3. Stepped Multi-Leaf Spring-Steel Backer Laminations & Brass Keeper Straps (s = 0.14 .. 0.62 * limb_len)
    for leaf_len_frac, leaf_off_f, uv_l in [(0.58, -0.145 * scale_f, UV_IRON), (0.38, -0.180 * scale_f, UV_BRASS)]:
        s_end = limb_len * leaf_len_frac
        l_pts = []
        l_rad = []
        for u_l in np.linspace(0.10, 1.0, 5):
            sd = s_end * u_l
            u_p = float(sd / total_len)
            cam = (0.065 * scale_f) * math.sin(u_p * math.pi) * (1.0 - 0.25 * u_p) + leaf_off_f
            l_pts.append([sd * u_x + cam * f_x, 0.0, sd * u_z + cam * f_z])
            l_rad.append((0.032 * scale_f, 0.155 * scale_f * (1.0 - 0.22 * u_l)))
        parts.append(smt.make_swept_octagonal_beam(l_pts, l_rad, uv_l, crease_deg=38.0))

    # Four forged brass keeper bands & spine ribs binding the spring leaves along the blade
    for clamp_frac in (0.20, 0.36, 0.52, 0.68):
        sd = limb_len * clamp_frac
        u_p = float(sd / total_len)
        cam = (0.065 * scale_f) * math.sin(u_p * math.pi) * (1.0 - 0.25 * u_p)
        cx, cz = sd * u_x + cam * f_x, sd * u_z + cam * f_z
        tap = 1.0 - 0.28 * clamp_frac
        c_pts = [
            [cx - 0.21 * tap * scale_f * f_x, 0.0, cz - 0.21 * tap * scale_f * f_z],
            [cx + 0.10 * tap * scale_f * f_x, 0.0, cz + 0.10 * tap * scale_f * f_z],
        ]
        parts.append(smt.make_swept_octagonal_beam(
            c_pts, [(0.032 * scale_f, 0.235 * tap * scale_f), (0.028 * scale_f, 0.225 * tap * scale_f)], UV_BRASS, crease_deg=38.0
        ))

    # 4. Forged Brass Recurve Nock Hook at exact s = limb_len
    nx, nz = limb_len * u_x, limb_len * u_z
    parts.append(smt.make_lathe_mesh([
        (-0.075 * scale_f, 0.000, UV_BRASS),
        (-0.075 * scale_f, 0.048 * scale_f, UV_BRASS),
        ( 0.000,           0.056 * scale_f, UV_IRON),
        (+0.075 * scale_f, 0.048 * scale_f, UV_BRASS),
        (+0.075 * scale_f, 0.000, UV_BRASS),
    ], axis='y', center=(nx, 0.0, nz), segs=16, crease_deg=45.0))

    return mbu.concat_meshes(parts)


def make_v32_bowstring_half_mesh(side_sign: float, str_len: float, is_upper: bool = False):
    """
    Braided hemp/sinew bowstring half with leather-whipped center nock serving and forged brass tip eyelet.
    """
    s_sgn = float(side_sign)
    r_rope = 0.014 if is_upper else 0.024
    x_end = s_sgn * str_len
    pts = [
        [0.0, 0.0, 0.0],
        [s_sgn * 0.18 * str_len, 0.0, 0.0],
        [s_sgn * 0.85 * str_len, 0.0, 0.0],
        [x_end, 0.0, 0.0],
    ]
    rads = [
        (r_rope * 1.35, r_rope * 1.35),
        (r_rope,        r_rope),
        (r_rope,        r_rope),
        (r_rope * 1.30, r_rope * 1.30),
    ]
    rope_body = smt.make_swept_octagonal_beam(pts, rads, UV_ROPE, crease_deg=48.0)
    eyelet = smt.make_lathe_mesh([
        (-r_rope * 1.5, 0.000, UV_BRASS),
        (-r_rope * 1.5, r_rope * 1.9, UV_BRASS),
        (+r_rope * 1.5, r_rope * 1.9, UV_BRASS),
        (+r_rope * 1.5, 0.000, UV_BRASS),
    ], axis='y', center=(x_end, 0.0, 0.0), segs=14, crease_deg=45.0)
    return mbu.concat_meshes([rope_body, eyelet])


def make_v32_siege_bolt_mesh(is_upper: bool = False):
    """
    Lathe-turned siege projectile with unmistakable scale and purpose contrast:
      - Stage II (is_upper=False): 3.75 m heavy iron-shod ash shaft with 4-flanged armor-piercing bodkin warhead
        and crimson/bronze fletching vanes.
      - Stage I (is_upper=True): 1.65 m slender enchanted frost-conditioning dart with glowing cyan runic crystal
        warhead and brass fletching vanes.
    """
    L = UPPER_BOLT_LEN if is_upper else MAIN_BOLT_LEN
    r_sh = 0.018 if is_upper else 0.036
    uv_head = UV_CYAN if is_upper else UV_BLADE
    uv_fletch = UV_CYAN if is_upper else UV_CRIMSON

    # Lathe profile from rear nock (z = 0.0) to warhead tip (z = L)
    shaft_prof = [
        (0.000,        0.000,        UV_BRASS),
        (0.005,        r_sh * 1.25,  UV_BRASS),
        (0.065,        r_sh * 1.10,  UV_BRASS),
        (0.070,        r_sh,         UV_OAK),
        (L * 0.78,     r_sh,         UV_OAK),
        (L * 0.82,     r_sh * 1.35,  UV_BRASS),
        (L * 0.85,     r_sh * 0.95,  UV_IRON),
        (L * 0.89,     r_sh * 2.45,  uv_head),
        (L * 0.95,     r_sh * 1.15,  uv_head),
        (L,            0.000,        uv_head),
    ]
    parts = [smt.make_lathe_mesh(shaft_prof, axis='z', segs=20, crease_deg=46.0)]

    # 4 Fletching Vanes + 4 Warhead Blades
    for k in range(4):
        ang = k * (math.pi * 0.5) + (math.pi * 0.25)
        ca, sa = math.cos(ang), math.sin(ang)
        R_z = np.array([[ca, -sa, 0.0], [sa, ca, 0.0], [0.0, 0.0, 1.0]], dtype=np.float32)

        # Fletching vane near rear nock
        v_pts = [
            [0.0, r_sh * 0.9, 0.08 * L],
            [0.0, r_sh * 2.8, 0.14 * L],
            [0.0, r_sh * 1.8, 0.26 * L],
            [0.0, r_sh * 0.8, 0.30 * L],
        ]
        v_rads = [(r_sh * 0.35, 0.004), (r_sh * 1.1, 0.005), (r_sh * 0.8, 0.005), (r_sh * 0.25, 0.003)]
        vane = smt.make_swept_octagonal_beam(v_pts, v_rads, uv_fletch, crease_deg=35.0)

        # Warhead barb fin
        b_pts = [
            [0.0, r_sh * 0.8, 0.85 * L],
            [0.0, r_sh * 2.9, 0.89 * L],
            [0.0, r_sh * 1.4, 0.95 * L],
            [0.0, r_sh * 0.2, 0.99 * L],
        ]
        b_rads = [(r_sh * 0.3, 0.005), (r_sh * 1.1, 0.006), (r_sh * 0.6, 0.005), (r_sh * 0.15, 0.003)]
        barb = smt.make_swept_octagonal_beam(b_pts, b_rads, uv_head, crease_deg=35.0)

        for pm, nm, um, tm in (vane, barb):
            parts.append((pm @ R_z.T, nm @ R_z.T, um, tm))

    return mbu.concat_meshes(parts)


def make_v32_winch_drum_and_cranks_mesh():
    """
    Lathe-turned ribbed iron & rope winding drum with S-curved forged-iron crank arms and
    lathe-turned crimson hardwood handles at X = +/-0.860 m.
    """
    parts = [
        # Central lathe-turned winding drum with coiled rope layers & bronze end flanges
        smt.make_lathe_mesh([
            (-0.680, 0.000, UV_IRON),
            (-0.680, 0.055, UV_IRON),
            (-0.460, 0.055, UV_IRON),
            (-0.455, 0.220, UV_BRASS),
            (-0.410, 0.220, UV_BRASS),
            (-0.405, 0.155, UV_ROPE),
            (-0.140, 0.162, UV_ROPE),
            ( 0.000, 0.168, UV_ROPE),
            (+0.140, 0.162, UV_ROPE),
            (+0.405, 0.155, UV_ROPE),
            (+0.410, 0.220, UV_BRASS),
            (+0.455, 0.220, UV_BRASS),
            (+0.460, 0.055, UV_IRON),
            (+0.680, 0.055, UV_IRON),
            (+0.680, 0.000, UV_IRON),
        ], axis='x', segs=24, crease_deg=45.0),
    ]
    # Left & Right S-Curved Crank Arms + Turned Crimson Hardwood Grip Handles at X = +/-0.860 m
    for sgn in (-1.0, +1.0):
        arm_pts = [
            [sgn * 0.480, 0.0,           0.0],
            [sgn * 0.510, sgn * 0.100,   0.0],
            [sgn * 0.540, sgn * 0.210,   0.0],
            [sgn * 0.565, sgn * 0.260,   0.0],
        ]
        arm_rads = [(0.038, 0.028), (0.034, 0.026), (0.032, 0.024), (0.036, 0.028)]
        parts.append(smt.make_swept_octagonal_beam(arm_pts, arm_rads, UV_IRON, crease_deg=40.0))
        x0, x1 = min(sgn * 0.555, sgn * 0.805), max(sgn * 0.555, sgn * 0.805)
        parts.append(smt.make_lathe_mesh([
            (x0,         0.000, UV_BRASS),
            (x0,         0.044, UV_BRASS),
            (x0 + 0.035, 0.038, UV_CRIMSON),
            (0.5*(x0+x1),0.045, UV_CRIMSON),
            (x1 - 0.035, 0.038, UV_BRASS),
            (x1,         0.044, UV_BRASS),
            (x1,         0.000, UV_BRASS),
        ], axis='x', center=(0.0, sgn * 0.260, 0.0), segs=16, crease_deg=45.0))

    return mbu.concat_meshes(parts)


def enhance_bibyellista_pbr_textures_v32(imgs_raw):
    """
    Upgrades the 1024x1024 BaseColor, Normal, and MetallicRoughness maps with clean,
    deliberate material differentiation across our 8 canonical UV swatch zones so
    oak, forged iron, spring steel, siege brass, braided rope, crimson heraldry, and
    cyan frost runes read with unmistakable clarity under Castleward daylight.
    """
    tex_norm = Image.fromarray(np.clip(imgs_raw['texture_normal'] * 255.0, 0, 255).astype(np.uint8)).resize((1024, 1024), Image.LANCZOS).convert("RGB")
    tex_diff = Image.fromarray(np.clip(imgs_raw['texture_diffuse'] * 255.0, 0, 255).astype(np.uint8)).resize((1024, 1024), Image.LANCZOS).convert("RGB")
    tex_mr   = Image.fromarray(np.clip(imgs_raw['texture_metallic-texture_roughness'] * 255.0, 0, 255).astype(np.uint8)).resize((1024, 1024), Image.LANCZOS).convert("RGB")

    arr_d = np.array(tex_diff, dtype=np.float32)
    arr_n = np.array(tex_norm, dtype=np.float32)
    arr_m = np.array(tex_mr,   dtype=np.float32)

    H, W, _ = arr_d.shape
    yy, xx = np.mgrid[0:H, 0:W]

    def paint_swatch(uv_c, radius_px, base_rgb, rough, metal, grain_type='none'):
        uc, vc = uv_c
        cx = int(round(uc * (W - 1)))
        # Paint only at canonical glTF v_px = int(round(vc * (H - 1))) so mirror circles never bleed into other islands!
        for cy in (int(round(vc * (H - 1))),):
            y0, y1 = max(0, cy - radius_px), min(H, cy + radius_px)
            x0, x1 = max(0, cx - radius_px), min(W, cx + radius_px)
            sub_y, sub_x = yy[y0:y1, x0:x1], xx[y0:y1, x0:x1]
            dist = np.sqrt((sub_x - cx)**2 + (sub_y - cy)**2)
            mask = dist <= radius_px
            if not np.any(mask):
                continue

            # Crisp, multi-frequency procedural surface grain for 2D-unwrapped meshes
            dx_p = sub_x - cx
            dy_p = sub_y - cy
            if grain_type == 'oak':
                # Quarter-sawn oak grain + fine wood pores + subtle plank seam
                g = 0.11 * np.sin(dy_p * 0.85 + 0.25 * np.sin(dx_p * 0.22)) + 0.04 * np.cos(dx_p * 0.45)
                nx = 128.0 + 6.0 * np.sin(dx_p * 0.45)
                ny = 128.0 + 18.0 * np.cos(dy_p * 0.85 + 0.25 * np.sin(dx_p * 0.22))
            elif grain_type == 'steel':
                # Brushed tempered spring steel & turned bronze micro-grooves
                g = 0.07 * np.sin((dx_p + dy_p) * 0.95) + 0.03 * np.cos((dx_p - dy_p) * 0.50)
                nx = 128.0 + 10.0 * np.cos((dx_p + dy_p) * 0.95)
                ny = 128.0 + 8.0 * np.sin((dx_p - dy_p) * 0.50)
            elif grain_type == 'rope':
                # 3-strand twisted hemp cordage lay
                g = 0.16 * np.sin(dx_p * 1.15 + dy_p * 1.15) + 0.06 * np.cos(dx_p * 0.65 - dy_p * 0.65)
                nx = 128.0 + 26.0 * np.cos(dx_p * 1.15 + dy_p * 1.15)
                ny = 128.0 + 26.0 * np.sin(dx_p * 1.15 + dy_p * 1.15)
            elif grain_type == 'metal':
                # Hand-forged charcoal siege iron hammer-peen texture
                g = 0.06 * np.sin(dx_p * 0.70) * np.cos(dy_p * 0.70)
                nx = 128.0 + 12.0 * np.cos(dx_p * 0.70) * np.sin(dy_p * 0.70)
                ny = 128.0 + 12.0 * np.sin(dx_p * 0.70) * np.cos(dy_p * 0.70)
            else:
                g = 0.04 * np.sin(dx_p * 0.50) * np.cos(dy_p * 0.50)
                nx, ny = 128.0, 128.0

            for c_i in range(3):
                patch_d = arr_d[y0:y1, x0:x1, c_i]
                patch_d[mask] = np.clip(base_rgb[c_i] * (1.0 + g[mask]), 0, 255)

            # glTF metallicRoughness convention: G = Roughness, B = Metallic, R = AO (255)
            arr_m[y0:y1, x0:x1, 0][mask] = 245.0
            arr_m[y0:y1, x0:x1, 1][mask] = np.clip((rough - 0.04 * g[mask]) * 255.0, 15, 250)
            arr_m[y0:y1, x0:x1, 2][mask] = np.clip(metal * 255.0, 0, 255)

            if isinstance(nx, np.ndarray):
                arr_n[y0:y1, x0:x1, 0][mask] = np.clip(nx[mask], 90, 165)
            else:
                arr_n[y0:y1, x0:x1, 0][mask] = nx
            if isinstance(ny, np.ndarray):
                arr_n[y0:y1, x0:x1, 1][mask] = np.clip(ny[mask], 90, 165)
            else:
                arr_n[y0:y1, x0:x1, 1][mask] = ny
            arr_n[y0:y1, x0:x1, 2][mask] = 255.0

    paint_swatch(UV_OAK,     48, (112,  72,  42), rough=0.72, metal=0.03, grain_type='oak')
    paint_swatch(UV_IRON,    48, ( 64,  70,  78), rough=0.42, metal=0.85, grain_type='metal')
    paint_swatch(UV_TIRE,    48, ( 48,  54,  62), rough=0.50, metal=0.80, grain_type='metal')
    paint_swatch(UV_BLADE,   48, (186, 196, 210), rough=0.20, metal=0.95, grain_type='steel')
    paint_swatch(UV_BRASS,   48, (218, 170,  82), rough=0.26, metal=0.91, grain_type='steel')
    paint_swatch(UV_CRIMSON, 48, (162,  34,  36), rough=0.48, metal=0.06, grain_type='none')
    paint_swatch(UV_CYAN,    48, ( 98, 236, 250), rough=0.14, metal=0.24, grain_type='none')
    paint_swatch(UV_ROPE,    48, (160, 136,  98), rough=0.84, metal=0.00, grain_type='rope')

    return [
        Image.fromarray(arr_n.astype(np.uint8)),
        Image.fromarray(arr_d.astype(np.uint8)),
        Image.fromarray(arr_m.astype(np.uint8)),
    ]


def make_v40_cockpit_and_seat_parts():
    """
    Builds the Rear Seated Operator Station attached to Carriage_Chassis (Node 1),
    aligned to SpellbladeRig's anatomical Left (+X when facing +Z) and Right (-X when facing +Z):
      - Twin curved dark-oak cockpit extension sills (Z = -1.24..-2.32 m, X = +/-0.46 m)
      - Iron-grated & oak-planked footrest platform at Y = 0.46..0.52 m (matching SpellbladeRig LBS boot soles at Y = 0.520 m!)
      - Contoured dark-oak & crimson-leather Saddle Chair at [0.000, 0.960, -1.860] with a right-side (-X) sword-scabbard
        clearance notch (so SpellbladeRig's socket_sword at X = -0.34m hangs cleanly without clipping!)
      - High curved forged-iron & crimson-heraldic Armored Backrest (Y = 0.96..1.66 m, Z = -2.02..-2.15 m)
      - Control stanchions: Left (+0.280m) Steering Tiller (Node 49), Right (-0.280m) Traverse Wheel (Node 50),
        and Right-Inboard (-0.160m) Fire/Couple Lever (Node 51).
    """
    parts = [
        smt.make_swept_octagonal_beam(
            [[-0.48, 0.68, -1.25], [-0.48, 0.56, -1.65], [-0.46, 0.60, -2.05], [-0.42, 0.72, -2.28]],
            [(0.085, 0.095), (0.085, 0.095), (0.082, 0.092), (0.075, 0.085)],
            UV_OAK, crease_deg=38.0
        ),
        smt.make_swept_octagonal_beam(
            [[+0.48, 0.68, -1.25], [+0.48, 0.56, -1.65], [+0.46, 0.60, -2.05], [+0.42, 0.72, -2.28]],
            [(0.085, 0.095), (0.085, 0.095), (0.082, 0.092), (0.075, 0.085)],
            UV_OAK, crease_deg=38.0
        ),
        smt.make_swept_octagonal_beam(
            [[-0.46, 0.72, -2.26], [0.0, 0.74, -2.30], [+0.46, 0.72, -2.26]],
            [(0.075, 0.085), (0.085, 0.095), (0.075, 0.085)],
            UV_IRON, crease_deg=40.0
        ),
        # Stable Footrest Platform (Y = 0.46..0.52 m, Z = -1.24..-1.74 m, X = -0.44..+0.44 m)
        smooth_box([-0.44, 0.46, -1.74], [+0.44, 0.52, -1.24], bevel=0.015, uv_center=UV_OAK),
        smooth_box([-0.40, 0.50, -1.68], [+0.40, 0.53, -1.28], bevel=0.008, uv_center=UV_IRON),
        # Left (+0.210m) & Right (-0.210m) Boot Stirrups at Y = 0.520 m, Z = -1.360 m
        smooth_box([-0.285, 0.515, -1.460], [-0.135, 0.555, -1.250], bevel=0.008, uv_center=UV_BRASS),
        smooth_box([-0.275, 0.545, -1.320], [-0.145, 0.615, -1.260], bevel=0.006, uv_center=UV_IRON),
        smooth_box([+0.135, 0.515, -1.460], [+0.285, 0.555, -1.250], bevel=0.008, uv_center=UV_BRASS),
        smooth_box([+0.145, 0.545, -1.320], [+0.275, 0.615, -1.260], bevel=0.006, uv_center=UV_IRON),
        # Heavy Seat Support Pedestal Column ([0.0, 0.50..0.90, -1.86])
        smt.make_lathe_mesh([
            (0.500, 0.000, UV_IRON), (0.500, 0.195, UV_IRON),
            (0.580, 0.165, UV_BRASS), (0.860, 0.145, UV_OAK),
            (0.905, 0.210, UV_BRASS), (0.905, 0.000, UV_BRASS),
        ], axis='y', center=(0.0, 0.0, -1.860), segs=20, crease_deg=45.0),
        # Saddle-Chair Base & Crimson Padded Cushion (Y = 0.89..0.96 m, Z = -1.68..-2.02 m)
        smooth_box([-0.270, 0.885, -2.020], [+0.270, 0.940, -1.680], bevel=0.016, uv_center=UV_OAK),
        smooth_box([-0.240, 0.930, -1.990], [+0.240, 0.965, -1.700], bevel=0.014, uv_center=UV_CRIMSON),
        # Left (+X) Full Thigh Bolster & Notched Right (-X) Hip Bolster (open forward of Z=-1.86m for right-hip socket_sword!)
        smooth_box([+0.215, 0.935, -2.000], [+0.285, 1.035, -1.700], bevel=0.012, uv_center=UV_BRASS),
        smooth_box([-0.285, 0.935, -2.000], [-0.215, 1.025, -1.860], bevel=0.012, uv_center=UV_BRASS),
        # Sturdy Curved Armored Backrest & Lumbar/Thoracic Support (Y = 0.96..1.66 m, Z = -2.02..-2.15 m)
        smt.make_swept_octagonal_beam(
            [[-0.22, 0.94, -2.02], [-0.24, 1.28, -2.07], [-0.20, 1.62, -2.09]],
            [(0.045, 0.045), (0.048, 0.048), (0.042, 0.042)],
            UV_IRON, crease_deg=40.0
        ),
        smt.make_swept_octagonal_beam(
            [[+0.22, 0.94, -2.02], [+0.24, 1.28, -2.07], [+0.20, 1.62, -2.09]],
            [(0.045, 0.045), (0.048, 0.048), (0.042, 0.042)],
            UV_IRON, crease_deg=40.0
        ),
        smooth_box([-0.260, 1.020, -2.110], [+0.260, 1.580, -2.030], bevel=0.018, uv_center=UV_IRON),
        smooth_box([-0.210, 1.060, -2.045], [+0.210, 1.520, -2.005], bevel=0.014, uv_center=UV_CRIMSON),
        smooth_box([-0.280, 1.550, -2.120], [+0.280, 1.660, -2.020], bevel=0.014, uv_center=UV_BRASS),
        # Control Stanchions at Z = -1.42..-1.46 m:
        # Left (+0.280m) Steering Column, Right (-0.280m) Traverse Wheel Column & Right-Inboard (-0.160m) Fire Quadrant
        smt.make_swept_octagonal_beam(
            [[+0.280, 0.520, -1.460], [+0.280, 1.020, -1.460]],
            [(0.048, 0.048), (0.042, 0.042)],
            UV_IRON, crease_deg=40.0
        ),
        smt.make_swept_octagonal_beam(
            [[-0.280, 0.520, -1.440], [-0.280, 1.180, -1.440]],
            [(0.048, 0.048), (0.042, 0.042)],
            UV_IRON, crease_deg=40.0
        ),
        smooth_box([-0.195, 0.520, -1.480], [-0.125, 1.060, -1.360], bevel=0.010, uv_center=UV_BRASS),
        # Mechanical Bevel-Gear Conduit linking Right (-0.280m) Traverse Column forward to Turntable Pinion
        smt.make_swept_octagonal_beam(
            [[-0.280, 0.880, -1.440], [-0.480, 0.960, -0.950], [-0.680, 1.180, -0.420]],
            [(0.028, 0.028), (0.028, 0.028), (0.032, 0.032)],
            UV_BRASS, crease_deg=42.0
        ),
    ]
    return parts


def make_v40_operator_steering_tiller_mesh():
    """Node 49: Operator_Steering_Tiller (local origin at [-0.280, 1.020, -1.460], grip at [0, +0.240, 0])."""
    return mbu.concat_meshes([
        smt.make_lathe_mesh([(-0.045, 0.0, UV_BRASS), (-0.045, 0.052, UV_BRASS), (+0.045, 0.052, UV_BRASS), (+0.045, 0.0, UV_BRASS)], axis='x', segs=14),
        smt.make_swept_octagonal_beam([[0.0, 0.0, 0.0], [0.0, +0.180, -0.020], [0.0, +0.240, -0.040]], [(0.026, 0.026), (0.022, 0.022), (0.028, 0.028)], UV_IRON),
        smt.make_lathe_mesh([(-0.075, 0.0, UV_BRASS), (-0.075, 0.032, UV_CRIMSON), (+0.075, 0.032, UV_CRIMSON), (+0.075, 0.0, UV_BRASS)], axis='x', center=(0.0, +0.240, -0.040), segs=14),
    ])


def make_v40_operator_traverse_wheel_mesh():
    """Node 50: Operator_Traverse_Wheel (local origin at [+0.280, 1.180, -1.440], grip knob at [0, +0.080, 0])."""
    parts = [
        smt.make_lathe_mesh([(-0.035, 0.0, UV_BRASS), (-0.035, 0.048, UV_BRASS), (+0.035, 0.048, UV_BRASS), (+0.035, 0.0, UV_BRASS)], axis='z', segs=16),
        smt.make_lathe_mesh([(-0.018, 0.125, UV_BRASS), (-0.018, 0.150, UV_BRASS), (+0.018, 0.150, UV_BRASS), (+0.018, 0.125, UV_BRASS)], axis='z', segs=24),
        smt.make_lathe_mesh([(-0.065, 0.0, UV_BRASS), (-0.065, 0.026, UV_CRIMSON), (+0.010, 0.026, UV_CRIMSON), (+0.010, 0.0, UV_BRASS)], axis='z', center=(0.0, +0.135, -0.025), segs=12),
    ]
    for k in range(6):
        a = k * (math.pi / 3.0)
        parts.append(smt.make_swept_octagonal_beam([[0.0, 0.0, 0.0], [0.135 * math.cos(a), 0.135 * math.sin(a), 0.0]], [(0.014, 0.014), (0.012, 0.012)], UV_IRON))
    return mbu.concat_meshes(parts)


def make_v40_operator_fire_lever_mesh():
    """Node 51: Operator_Fire_And_Couple_Lever (local origin at [+0.160, 1.040, -1.420], grip at [0, +0.240, 0])."""
    return mbu.concat_meshes([
        smt.make_lathe_mesh([(-0.040, 0.0, UV_IRON), (-0.040, 0.048, UV_BRASS), (+0.040, 0.048, UV_BRASS), (+0.040, 0.0, UV_IRON)], axis='x', segs=14),
        smt.make_swept_octagonal_beam([[0.0, 0.0, 0.0], [0.0, +0.185, +0.015], [0.0, +0.245, +0.025]], [(0.024, 0.028), (0.020, 0.024), (0.026, 0.028)], UV_BRASS),
        smt.make_lathe_mesh([(-0.060, 0.0, UV_BRASS), (-0.060, 0.034, UV_CRIMSON), (+0.060, 0.034, UV_CRIMSON), (+0.060, 0.0, UV_BRASS)], axis='x', center=(0.0, +0.245, +0.025), segs=14),
    ])


def make_v40_coupling_clutch_collar_mesh():
    """
    Node 52: Coupling_Clutch_Collar (local origin at [0.000, 2.540, -0.180] on Elevation_Cradle).
    Sliding 4-lug forged-iron dog-clutch collar & locking pin that rises +0.065m and locks into
    Upper_Turret_Mount's rear dog-lug when Upper_Turret_Mount aligns at yaw = 0 deg.
    """
    parts = [
        smt.make_lathe_mesh([
            (-0.045, 0.000, UV_IRON), (-0.045, 0.095, UV_IRON),
            (+0.025, 0.095, UV_BRASS), (+0.045, 0.075, UV_BRASS),
            (+0.045, 0.000, UV_IRON),
        ], axis='y', segs=18, crease_deg=45.0),
        # 4 upstanding interlocking iron clutch dog teeth
        smooth_box([-0.085, +0.035, -0.025], [-0.042, +0.088, +0.025], bevel=0.005, uv_center=UV_IRON),
        smooth_box([+0.042, +0.035, -0.025], [+0.085, +0.088, +0.025], bevel=0.005, uv_center=UV_IRON),
        smooth_box([-0.025, +0.035, -0.085], [+0.025, +0.088, -0.042], bevel=0.005, uv_center=UV_BRASS),
        smooth_box([-0.025, +0.035, +0.042], [+0.025, +0.088, +0.085], bevel=0.005, uv_center=UV_BRASS),
        # Lateral actuator fork extending right to the sight-arch transfer linkage (X = +0.36m)
        smt.make_swept_octagonal_beam([[0.0, 0.0, 0.0], [+0.18, 0.0, +0.01], [+0.34, -0.04, +0.02]], [(0.024, 0.024), (0.022, 0.022), (0.026, 0.026)], UV_BRASS),
    ]
    return mbu.concat_meshes(parts)


def make_v40_coupling_transfer_linkage_mesh():
    """
    Node 53: Coupling_Transfer_Linkage (local origin at [+0.360, 2.180, -0.160] on Elevation_Cradle).
    Articulated forged-iron bell-crank rocker arm & vertical drop-rod connecting the upper trigger release
    down to the 0.200s geared delay escapement (Node 54).
    """
    return mbu.concat_meshes([
        # Bell-crank pivot hub at [0, 0, 0]
        smt.make_lathe_mesh([(-0.045, 0.0, UV_BRASS), (-0.045, 0.055, UV_BRASS), (+0.045, 0.055, UV_BRASS), (+0.045, 0.0, UV_BRASS)], axis='x', segs=16),
        # Upper push-rod rising toward Coupling_Clutch_Collar (+0.32m up)
        smt.make_swept_octagonal_beam([[0.0, 0.0, 0.0], [0.0, +0.18, -0.01], [-0.02, +0.34, -0.02]], [(0.022, 0.022), (0.020, 0.020), (0.024, 0.024)], UV_IRON),
        # Forward trip-arm & lower drop-link descending to Delay_Escapement_Gear ([0, -0.34, -0.36])
        smt.make_swept_octagonal_beam([[0.0, 0.0, 0.0], [0.0, -0.16, -0.18], [-0.02, -0.32, -0.34]], [(0.026, 0.026), (0.022, 0.022), (0.026, 0.026)], UV_BRASS),
        smooth_box([-0.032, -0.045, -0.045], [+0.032, +0.045, +0.145], bevel=0.008, uv_center=UV_CRIMSON),
    ])


def make_v40_delay_escapement_gear_mesh():
    """
    Node 54: Delay_Escapement_Gear (local origin at [+0.340, 1.840, -0.520] on Elevation_Cradle).
    12-tooth cast-bronze 0.200s delay escapement wheel (R = 0.165m) with weighted pendulum vane and
    eccentric cam striker that rotates +240 deg over t = 0.450..0.650s to trip Heavy_Sear_Trip_Bar (Node 55).
    """
    gear_base = bhg.shift_mesh_to_pivot(
        smt.compute_crease_normals(
            *bhg.make_toothed_gear([0.0, 0.0, 0.0], r_root=0.125, r_tip=0.168, half_thick=0.032, n_teeth=12, uv_body=UV_BRASS, uv_rim=UV_IRON)[:4:3],
            bhg.make_toothed_gear([0.0, 0.0, 0.0], r_root=0.125, r_tip=0.168, half_thick=0.032, n_teeth=12, uv_body=UV_BRASS, uv_rim=UV_IRON)[2],
            crease_deg=40.0
        ),
        [0.0, 0.0, 0.0]
    )
    cam_and_vane = mbu.concat_meshes([
        # Eccentric cam striker lobe extending toward -Z/-Y
        smt.make_swept_octagonal_beam([[0.0, 0.0, 0.0], [-0.035, -0.085, -0.185]], [(0.032, 0.032), (0.038, 0.028)], UV_CRIMSON),
        # Weighted bronze pendulum governor arm
        smt.make_swept_octagonal_beam([[0.0, 0.0, 0.0], [+0.035, +0.195, +0.065]], [(0.024, 0.024), (0.045, 0.045)], UV_BRASS),
    ])
    return mbu.concat_meshes([gear_base, cam_and_vane])


def make_v40_heavy_sear_trip_bar_mesh():
    """
    Node 55: Heavy_Sear_Trip_Bar (local origin at [+0.180, 1.765, -0.780] on Elevation_Cradle).
    Forged-iron transverse sear-trip bar struck by Delay_Escapement_Gear at t = 0.650s to knock open
    Main_Draw_Catch (Node 18).
    """
    return mbu.concat_meshes([
        smt.make_swept_octagonal_beam([[-0.180, 0.0, -0.060], [0.0, 0.0, 0.0], [+0.160, +0.045, +0.120]], [(0.028, 0.028), (0.032, 0.032), (0.028, 0.028)], UV_IRON),
        smooth_box([-0.205, -0.035, -0.095], [-0.135, +0.045, -0.025], bevel=0.006, uv_center=UV_BRASS),
        smooth_box([+0.125, +0.015, +0.085], [+0.185, +0.085, +0.155], bevel=0.006, uv_center=UV_CRIMSON),
    ])


def build_bibyellista_v32_meshes_and_textures():
    in_glb = Path(os.environ['BIBYE_BASE_GLB']) if 'BIBYE_BASE_GLB' in os.environ else ((SCRIPT_DIR / 'bibye_base_basic_pbr.glb') if (SCRIPT_DIR / 'bibye_base_basic_pbr.glb').exists() else ((SCRIPT_DIR / 'base_basic_pbr.glb') if (SCRIPT_DIR / 'base_basic_pbr.glb').exists() else (BIBYE_DIR / 'base_basic_pbr.glb')))
    _, _, pos_raw, norm_raw, uv_raw, tris_raw, imgs_raw = bhg.load_glb_any(str(in_glb))

    # Extract ONLY the iconic sculpted front Roman Numeral II shield pair from the Rodin mesh
    # and smooth their vertex normals, while rebuilding all structural/mechanical tiers cleanly!
    mesh0 = bhg.compact_mesh((pos_raw, norm_raw, uv_raw, tris_raw))
    p, n, u, t = mesh0
    xc = p[:, 0] - X0_RAW
    yr = p[:, 1]
    zr = p[:, 2]
    tc_x = xc[t].mean(axis=1)
    tc_y = yr[t].mean(axis=1)
    tc_z = zr[t].mean(axis=1)

    shield_II_mask = (np.abs(tc_x) >= 0.24) & (np.abs(tc_x) <= 0.405) & (tc_y >= 0.52) & (tc_y <= 0.75) & (tc_z >= 0.50)
    pw_sh = np.column_stack([xc * SCALE, (yr * SCALE) + 0.060, zr * SCALE]).astype(np.float32)
    shield_II_raw = bhg.compact_mesh((pw_sh, n, u, t[shield_II_mask]))
    shield_II_smooth = smt.compute_crease_normals(shield_II_raw[0], shield_II_raw[3], shield_II_raw[2], crease_deg=42.0)

    # Extract the sculpted lower wagon body & Front Crimson Trident Banner (Y_world <= 1.15m),
    # excising the 6 wheel wells and 4 outrigger mounts, and smooth its normals to eliminate marching-cubes facets!
    pw0 = np.column_stack([xc * SCALE, yr * SCALE, zr * SCALE]).astype(np.float32)
    tc_xw, tc_yw, tc_zw = tc_x * SCALE, tc_y * SCALE, tc_z * SCALE
    in_wheel = np.zeros(len(t), dtype=bool)
    for wz in (AXLE_Z_FRONT, AXLE_Z_MID, AXLE_Z_REAR):
        in_wheel |= (np.abs(tc_xw) >= 0.86) & (np.hypot(tc_yw - WHEEL_RADIUS, tc_zw - wz) <= 0.59)
    in_stab = (np.abs(tc_xw) >= 1.12) & (tc_yw <= 0.96) & ((tc_zw >= 0.65) | (tc_zw <= -0.95))
    # Keep the intact Front Crimson Trident Banner (Z >= 1.24m, |X| <= 0.48m, Y <= 1.30m)
    # plus the lower sculpted wagon skirt (Y <= 0.94m, |Z| <= 1.55m, |X| <= 0.84m) — ZERO vertex squashing!
    is_front_banner = (tc_zw >= 1.32) & (np.abs(tc_xw) <= 0.44) & (tc_yw >= 0.16) & (tc_yw <= 0.96)
    hull_mask = is_front_banner
    pw_banner = pw0.copy()
    pw_banner[:, 1] = np.minimum(pw_banner[:, 1], 0.980)
    hull_raw = bhg.compact_mesh((pw_banner, n, u, t[hull_mask]))
    hull_smooth = smt.compute_crease_normals(hull_raw[0], hull_raw[3], hull_raw[2], crease_deg=48.0)

    # -------------------------------------------------------------------------
    # TIER 1: Carriage_Chassis (Node 1, Y <= 1.140 m outside turntable!)
    # -------------------------------------------------------------------------
    carriage_parts = [
        hull_smooth,
        # Twin massive chamfered longitudinal dark-oak main sill beams (X = +/-0.62 m)
        smt.make_swept_octagonal_beam(
            [[-0.62, 0.72, -2.06], [-0.62, 0.74, -1.60], [-0.62, 0.74, +1.25], [-0.56, 0.78, +1.44]],
            [(0.125, 0.145), (0.135, 0.155), (0.135, 0.155), (0.095, 0.115)],
            UV_OAK, crease_deg=38.0
        ),
        smt.make_swept_octagonal_beam(
            [[+0.62, 0.72, -2.06], [+0.62, 0.74, -1.60], [+0.62, 0.74, +1.25], [+0.56, 0.78, +1.44]],
            [(0.125, 0.145), (0.135, 0.155), (0.135, 0.155), (0.095, 0.115)],
            UV_OAK, crease_deg=38.0
        ),
        # Recessed planked center wagon deck (Y = 0.76..0.92 m, Z = -1.96..+1.52 m)
        smooth_box([-0.54, 0.76, -1.96], [+0.54, 0.92, +1.34], bevel=0.025, uv_center=UV_OAK),
        # Front Banner-Hanger Cross-Beam (set at Z = +1.44m, Y = 0.96m right at the top of the Crimson Trident Banner!)
        smt.make_swept_octagonal_beam(
            [[-0.64, 0.88, +1.32], [0.0, 0.92, +1.34], [+0.64, 0.88, +1.32]],
            [(0.085, 0.095), (0.095, 0.105), (0.085, 0.095)],
            UV_BRASS, crease_deg=40.0
        ),
        smt.make_swept_octagonal_beam(
            [[-0.68, 0.70, -2.04], [0.0, 0.70, -2.10], [+0.68, 0.70, -2.04]],
            [(0.090, 0.105), (0.105, 0.115), (0.090, 0.105)],
            UV_IRON, crease_deg=40.0
        ),
        # Crimson Heraldic Side-Escutcheon Panels with Brass Framing between Front & Rear Outriggers (Z = -1.10..+0.75 m)
        smooth_box([-0.75, 0.72, -1.12], [-0.68, 1.02, +0.76], bevel=0.018, uv_center=UV_BRASS),
        smooth_box([-0.77, 0.76, -1.04], [-0.73, 0.98, +0.68], bevel=0.012, uv_center=UV_CRIMSON),
        smooth_box([+0.68, 0.72, -1.12], [+0.75, 1.02, +0.76], bevel=0.018, uv_center=UV_BRASS),
        smooth_box([+0.73, 0.76, -1.04], [+0.77, 0.98, +0.68], bevel=0.012, uv_center=UV_CRIMSON),
        # Machined Cast-Iron & Burnished-Bronze Lower Turntable Race (Y = 0.90..1.235 m, R = 0.88 m)
        smt.make_lathe_mesh([
            (0.900, 0.000, UV_IRON),
            (0.900, 0.855, UV_IRON),
            (1.040, 0.850, UV_OAK),
            (1.160, 0.845, UV_IRON),
            (1.215, 0.840, UV_BRASS),
            (1.238, 0.825, UV_BRASS),
            (1.238, 0.000, UV_BRASS),
        ], axis='y', center=(0.0, 0.0, 0.0), segs=32, crease_deg=45.0),
    ]

    # Three Sculpted Axle-Trees & Lathe-Turned Bronze Axle Journals at Z = +1.200, -0.340, -1.715 m
    for az in (AXLE_Z_FRONT, AXLE_Z_MID, AXLE_Z_REAR):
        carriage_parts.append(smt.make_lathe_mesh([
            (-0.960, 0.000, UV_IRON),
            (-0.960, 0.072, UV_BRASS),
            (-0.840, 0.088, UV_BRASS),
            (-0.820, 0.076, UV_IRON),
            (+0.820, 0.076, UV_IRON),
            (+0.840, 0.088, UV_BRASS),
            (+0.960, 0.072, UV_BRASS),
            (+0.960, 0.000, UV_IRON),
        ], axis='x', center=(0.0, WHEEL_RADIUS, az), segs=18, crease_deg=45.0))
        # Arched oak axle bolster connecting axle to main sill beams
        carriage_parts.append(smt.make_swept_octagonal_beam(
            [[-0.82, 0.55, az], [-0.58, 0.66, az], [0.0, 0.70, az], [+0.58, 0.66, az], [+0.82, 0.55, az]],
            [(0.085, 0.095), (0.105, 0.115), (0.115, 0.125), (0.105, 0.115), (0.085, 0.095)],
            UV_OAK, crease_deg=40.0
        ))

    # Four Flared Forged-Iron Outrigger Clevis Mount Arms at [+/-1.180, 0.820, +1.050 / -1.420]
    for sx in (-1.0, +1.0):
        for sz in (+1.050, -1.420):
            carriage_parts.append(smt.make_swept_octagonal_beam(
                [[sx * 0.62, 0.78, sz], [sx * 0.92, 0.80, sz], [sx * 1.18, 0.82, sz]],
                [(0.095, 0.110), (0.088, 0.100), (0.080, 0.090)],
                UV_IRON, crease_deg=40.0
            ))
        # Sculpted Ackermann Steering Kingpin Yokes & Vertical Pivot Pins on Front (+1.200m) and Rear (-1.715m) Axles
        for az_steer in (AXLE_Z_FRONT, AXLE_Z_REAR):
            carriage_parts.append(smt.make_lathe_mesh([
                (0.435, 0.000, UV_BRASS), (0.435, 0.058, UV_BRASS),
                (0.665, 0.058, UV_IRON),  (0.665, 0.000, UV_BRASS),
            ], axis='y', center=(sx * 0.910, 0.0, az_steer), segs=14, crease_deg=45.0))
    # Turntable Worm-Gear Drive Pinion Housing on Carriage_Chassis engaging Traverse_Mount ring
    carriage_parts.append(smt.make_lathe_mesh([
        (-0.22, 0.000, UV_BRASS), (-0.22, 0.075, UV_BRASS),
        (+0.22, 0.075, UV_IRON),  (+0.22, 0.000, UV_BRASS),
    ], axis='z', center=(+0.78, 1.22, -0.42), segs=16, crease_deg=45.0))
    carriage_parts.extend(make_v40_cockpit_and_seat_parts())

    # -------------------------------------------------------------------------
    # TIER 2: Traverse_Mount (Node 12, pivot [0.000, 1.240, 0.000])
    # -------------------------------------------------------------------------
    traverse_parts = [
        # Lathe-turned upper geared bronze turntable ring & oak base platform (Y_world = 1.235..1.335 m)
        smt.make_lathe_mesh([
            (1.235, 0.000, UV_BRASS),
            (1.235, 0.855, UV_BRASS),
            (1.275, 0.865, UV_BRASS),
            (1.300, 0.780, UV_IRON),
            (1.335, 0.680, UV_OAK),
            (1.335, 0.000, UV_OAK),
        ], axis='y', center=(0.0, 0.0, 0.0), segs=32, crease_deg=45.0),
    ]
    # 24 Sculpted External Bronze Gear Teeth around the Traverse_Mount Turntable Ring (for crisp visual rotation feedback!)
    for kt in range(24):
        ang_t = kt * (2.0 * math.pi / 24.0)
        ct, st = math.cos(ang_t), math.sin(ang_t)
        R_yt = np.array([[ct, 0.0, st], [0.0, 1.0, 0.0], [-st, 0.0, ct]], dtype=np.float32)
        tp, tn, tu, tt = smooth_box([-0.032, 1.240, 0.845], [+0.032, 1.276, 0.884], bevel=0.006, uv_center=UV_BRASS)
        traverse_parts.append((tp @ R_yt.T, tn @ R_yt.T, tu, tt))
    # Left & Right Swept-Back Curved Trunnion Cheek A-Frames rising to exact trunnion pivot [+/-0.45, 1.620, -0.120]
    # plus Cantilevered Rear Winch Support Arms extending to [+/-0.42, 1.420, -1.380]
    for sx in (-1.0, +1.0):
        # Front leg of trunnion A-frame
        traverse_parts.append(smt.make_swept_octagonal_beam(
            [[sx * 0.52, 1.31, +0.46], [sx * 0.48, 1.49, +0.17], [sx * 0.45, 1.62, -0.12]],
            [(0.085, 0.105), (0.082, 0.098), (0.092, 0.110)],
            UV_IRON, crease_deg=40.0
        ))
        # Rear leg of trunnion A-frame continuing seamlessly into the compacted rear winch arm (Z = -0.98m, clear of seated operator!)
        traverse_parts.append(smt.make_swept_octagonal_beam(
            [[sx * 0.45, 1.62, -0.12], [sx * 0.43, 1.48, -0.52], [sx * 0.42, 1.44, -0.98]],
            [(0.092, 0.110), (0.082, 0.096), (0.078, 0.088)],
            UV_OAK, crease_deg=40.0
        ))
        # Lower horizontal tie-beam of the compacted rear winch frame (Y = 1.32..1.44 m, Z = -0.40..-0.92 m)
        traverse_parts.append(smt.make_swept_octagonal_beam(
            [[sx * 0.50, 1.31, -0.40], [sx * 0.42, 1.38, -0.68], [sx * 0.42, 1.44, -0.92]],
            [(0.068, 0.068), (0.064, 0.064), (0.068, 0.068)],
            UV_IRON, crease_deg=40.0
        ))

    # Heavy Bronze Main Elevation Trunnion Axle Shaft concentric with Elevation_Cradle pivot [0.000, 1.620, -0.120]
    traverse_parts.append(smt.make_lathe_mesh([
        (-0.560, 0.000, UV_BRASS),
        (-0.560, 0.095, UV_BRASS),
        (-0.380, 0.108, UV_IRON),
        (+0.380, 0.108, UV_IRON),
        (+0.560, 0.095, UV_BRASS),
        (+0.560, 0.000, UV_BRASS),
    ], axis='x', center=(0.0, 1.620, -0.120), segs=20, crease_deg=45.0))

    # Smooth 12-Station Catenary Oak-and-Brass Gunner Sight Arch (Clear inner window X in [-0.35, +0.35m], Y in [1.85, 2.50m])!
    for sx in (-1.0, +1.0):
        arch_pts = []
        arch_rads = []
        for u_a in np.linspace(0.0, 1.0, 12):
            ya = 1.62 + (2.495 - 1.62) * u_a
            # Smooth outward flare peaking at u_a = 0.45, then curving gracefully into the upper bronze turret collar (Y <= 2.540m)
            xa = sx * (0.35 + 0.085 * math.sin(u_a * math.pi) - 0.145 * (u_a ** 2.2))
            za = +0.08 + 0.03 * math.sin(u_a * math.pi)
            arch_pts.append([xa, ya, za])
            arch_rads.append((0.052 - 0.008 * u_a, 0.105 - 0.025 * u_a))
        traverse_parts.append(smt.make_swept_octagonal_beam(arch_pts, arch_rads, UV_OAK, crease_deg=46.0))
        # Forged brass arch collar bands at base & mid-arch
        for u_b in (0.18, 0.68):
            yb = 1.74 + (2.53 - 1.74) * u_b
            xb = sx * (0.35 + 0.085 * math.sin(u_b * math.pi) - 0.13 * (u_b ** 2.2))
            traverse_parts.append(smooth_box([xb - 0.072, yb - 0.035, -0.05], [xb + 0.072, yb + 0.035, +0.22], bevel=0.010, uv_center=UV_BRASS))
        # Swept diagonal forward brace from mid-arch down to main torsion crossbeam
        traverse_parts.append(smt.make_swept_octagonal_beam(
            [[sx * 0.41, 2.08, +0.10], [sx * 0.44, 1.82, +0.28], [sx * 0.48, 1.49, +0.42]],
            [(0.052, 0.058), (0.048, 0.052), (0.058, 0.064)],
            UV_BRASS, crease_deg=44.0
        ))


    # Upper Arch Crown & Stationary 360-Deg Bronze Ring-Gear Turret Pedestal at [0.000, 2.495..2.635, +0.080]
    traverse_parts.append(smt.make_lathe_mesh([
        (2.495, 0.000, UV_BRASS),
        (2.495, 0.285, UV_BRASS),
        (2.545, 0.305, UV_IRON),
        (2.595, 0.285, UV_BRASS),
        (2.635, 0.255, UV_BRASS),
        (2.635, 0.000, UV_BRASS),
    ], axis='y', center=(0.0, 0.0, +0.080), segs=28, crease_deg=45.0))
    # 18 Sculpted Bronze Ring-Gear Teeth around the Upper Turret Pedestal (Y = 2.55..2.595 m, R = 0.280..0.312 m)
    for kt_u in range(18):
        ang_u = kt_u * (2.0 * math.pi / 18.0)
        cu, su = math.cos(ang_u), math.sin(ang_u)
        R_yu = np.array([[cu, 0.0, su], [0.0, 1.0, 0.0], [-su, 0.0, cu]], dtype=np.float32)
        tp, tn, tu, tt = smooth_box([-0.022, 2.550, 0.275], [+0.022, 2.595, 0.312], bevel=0.005, uv_center=UV_BRASS)
        tp = (tp @ R_yu.T) + np.array([[0.0, 0.0, +0.080]], dtype=np.float32)
        traverse_parts.append((tp, tn @ R_yu.T, tu, tt))

    # Embossed Burnished-Bronze "I -> II" Coupled-Release Instruction Plaque on the Right Sight-Arch Housing (X = +0.415m)
    traverse_parts.extend([
        # Dark-iron & crimson backing plaque at X = +0.395..+0.422 m, Y = 1.94..2.12 m, Z = -0.26..+0.04 m
        smooth_box([+0.385, 1.940, -0.260], [+0.418, 2.120, +0.040], bevel=0.008, uv_center=UV_IRON),
        smooth_box([+0.412, 1.955, -0.245], [+0.424, 2.105, +0.025], bevel=0.005, uv_center=UV_CRIMSON),
        # Embossed Brass Roman Numeral "I" (rear/top side, Z = +0.00..-0.03 m)
        smooth_box([+0.420, 1.980, -0.025], [+0.432, 2.080, +0.005], bevel=0.003, uv_center=UV_BRASS),
        # Embossed Brass Arrow "->" shaft & arrowhead pointing from I toward II (Z = -0.045..-0.135 m)
        smooth_box([+0.420, 2.022, -0.125], [+0.432, 2.038, -0.045], bevel=0.003, uv_center=UV_BRASS),
        smt.make_swept_octagonal_beam([[+0.426, 2.055, -0.105], [+0.426, 2.030, -0.140], [+0.426, 2.005, -0.105]], [(0.006, 0.008), (0.006, 0.010), (0.006, 0.008)], UV_BRASS),
        # Embossed Brass Roman Numeral "II" (main launcher side, Z = -0.160..-0.225 m)
        smooth_box([+0.420, 1.980, -0.185], [+0.432, 2.080, -0.160], bevel=0.003, uv_center=UV_BRASS),
        smooth_box([+0.420, 1.980, -0.225], [+0.432, 2.080, -0.200], bevel=0.003, uv_center=UV_BRASS),
    ])


    # -------------------------------------------------------------------------
    # TIER 3: Elevation_Cradle (Node 13, pivot [0.000, 1.600, -0.140])
    # Includes Primary Launcher II Stock, Torsion Drums, II Shields, AND the
    # Wide-Framing Curved Siege-Iron Gunner Sight Arch!
    # -------------------------------------------------------------------------
    elev_parts = [
        shield_II_smooth,
        # Main Chamfered Dark-Oak Ballista Stock with upswept rear tail (Y_bottom >= 1.623m at Z = -1.04m)
        smt.make_swept_octagonal_beam(
            [[0.0, 1.705, -1.04], [0.0, 1.700, -0.45], [0.0, 1.685, +0.65], [0.0, 1.685, +1.54]],
            [(0.155, 0.082), (0.195, 0.108), (0.205, 0.135), (0.175, 0.120)],
            UV_OAK, crease_deg=38.0
        ),
        # Precision Iron Dovetail Bolt Guide Runners along top of stock (Y = 1.78..1.835 m)
        smooth_box([-0.155, 1.775, -1.02], [-0.058, 1.835, +1.52], bevel=0.010, uv_center=UV_IRON),
        smooth_box([+0.058, 1.775, -1.02], [+0.155, 1.835, +1.52], bevel=0.010, uv_center=UV_IRON),
        smooth_box([-0.060, 1.770, -1.02], [+0.060, 1.798, +1.52], bevel=0.006, uv_center=UV_BRASS),
        # Swept Forward Forged-Iron & Bronze Torsion Crossbeam connecting Stock to Main Limb Drums (Z = +0.72..+1.12 m)
        smt.make_swept_octagonal_beam(
            [[-0.96, 1.76, +0.92], [-0.48, 1.72, +0.96], [0.0, 1.70, +1.00], [+0.48, 1.72, +0.96], [+0.96, 0.0 + 1.76, +0.92]],
            [(0.185, 0.165), (0.165, 0.155), (0.175, 0.160), (0.165, 0.155), (0.185, 0.165)],
            UV_IRON, crease_deg=40.0
        ),
        # Bold Embossed Brass Roman Numeral II Plaques on Front Mantlet Shields
        smooth_box([-0.875, 1.54, +1.36], [-0.835, 1.78, +1.415], bevel=0.006, uv_center=UV_BRASS),
        smooth_box([-0.795, 1.54, +1.36], [-0.755, 1.78, +1.415], bevel=0.006, uv_center=UV_BRASS),
        smooth_box([+0.755, 1.54, +1.36], [+0.795, 1.78, +1.415], bevel=0.006, uv_center=UV_BRASS),
        smooth_box([+0.835, 1.54, +1.36], [+0.875, 1.78, +1.415], bevel=0.006, uv_center=UV_BRASS),
    ]

    # Twin Lathe-Turned Cylindrical Bronze Torsion Drums housing Main_Limb_L/R at [+/-0.880, 1.800, +0.920]
    for sx in (-1.0, +1.0):
        elev_parts.append(smt.make_lathe_mesh([
            (1.480, 0.000, UV_BRASS),
            (1.480, 0.235, UV_BRASS),
            (1.535, 0.250, UV_BRASS),
            (1.560, 0.215, UV_IRON),
            (1.660, 0.205, UV_ROPE),
            (1.940, 0.205, UV_ROPE),
            (2.040, 0.215, UV_IRON),
            (2.065, 0.250, UV_BRASS),
            (2.120, 0.235, UV_BRASS),
            (2.120, 0.000, UV_BRASS),
        ], axis='y', center=(sx * MAIN_LIMB_ROOT_X, 0.0, MAIN_LIMB_ROOT_Z), segs=24, crease_deg=45.0))

    for sx in (-1.0, +1.0):
        # Substantial sculpted side cheek plates on Elevation_Cradle bridging down to the trunnion axle [+/-0.38, 1.62, -0.12]
        elev_parts.append(smt.make_swept_octagonal_beam(
            [[sx * 0.34, 1.62, -0.52], [sx * 0.35, 1.62, -0.12], [sx * 0.35, 1.68, +0.48], [sx * 0.40, 1.74, +0.88]],
            [(0.060, 0.105), (0.068, 0.135), (0.068, 0.130), (0.072, 0.125)],
            UV_OAK, crease_deg=42.0
        ))

    # -------------------------------------------------------------------------
    # TIER 4: Upper_Turret_Mount (Node 23, pivot [0.000, 2.780, +0.080])
    # True 360-Degree Conditioning Arbalest Turret I with -14..+25 deg Elevation/Convergence
    # and Rear Coupling Dog-Lug that engages Coupling_Clutch_Collar (Node 52)!
    # -------------------------------------------------------------------------
    upper_turret_parts = [
        # Rotating Bronze Kingpin Collar & Swivel Base at Y = 2.635..2.705 m
        smt.make_lathe_mesh([
            (2.635, 0.000, UV_BRASS),
            (2.635, 0.255, UV_BRASS),
            (2.675, 0.240, UV_IRON),
            (2.705, 0.195, UV_OAK),
            (2.705, 0.000, UV_OAK),
        ], axis='y', center=(0.0, 0.0, +0.080), segs=24, crease_deg=45.0),
        # Twin Swept Bronze Trunnion Yoke Arms rising from Swivel Base (Y=2.68m) to Trunnion Pivot (Y=2.780m, Z=+0.080m)
        smt.make_swept_octagonal_beam(
            [[-0.145, 2.680, +0.060], [-0.135, 2.780, +0.080], [-0.115, 2.855, +0.100]],
            [(0.036, 0.048), (0.042, 0.055), (0.035, 0.045)],
            UV_BRASS, crease_deg=40.0
        ),
        smt.make_swept_octagonal_beam(
            [[+0.145, 2.680, +0.060], [+0.135, 2.780, +0.080], [+0.115, 2.855, +0.100]],
            [(0.036, 0.048), (0.042, 0.055), (0.035, 0.045)],
            UV_BRASS, crease_deg=40.0
        ),
        # Rear Mechanical Coupling Dog-Lug & Upper Sear Trip-Finger at [0.000, 2.605..2.860, -0.180]
        # (Rotates freely above Coupling_Clutch_Collar when uncoupled; locks into Node 52 when aligned at yaw=0!)
        smooth_box([-0.055, 2.605, -0.225], [+0.055, 2.675, -0.135], bevel=0.008, uv_center=UV_IRON),
        smt.make_swept_octagonal_beam(
            [[0.0, 2.860, -0.520], [0.0, 2.740, -0.320], [0.0, 2.625, -0.180]],
            [(0.022, 0.022), (0.024, 0.024), (0.028, 0.028)],
            UV_BRASS, crease_deg=40.0
        ),
        # Sleek Chamfered Dark-Oak Conditioning Arbalest Stock (Y = 2.81..2.91 m, Z = -0.66..+0.92 m)
        smt.make_swept_octagonal_beam(
            [[0.0, 2.845, -0.66], [0.0, 2.855, +0.10], [0.0, 2.855, +0.92]],
            [(0.085, 0.058), (0.105, 0.065), (0.088, 0.058)],
            UV_OAK, crease_deg=38.0
        ),
        # Upper Iron Dovetail Track Runners (Y = 2.90..2.945 m)
        smooth_box([-0.085, 2.900, -0.64], [-0.032, 2.945, +0.90], bevel=0.006, uv_center=UV_IRON),
        smooth_box([+0.032, 2.900, -0.64], [+0.085, 2.945, +0.90], bevel=0.006, uv_center=UV_IRON),
        # Swept Upper Crossbeam & Twin Compact Bronze Torsion Drums at [+/-0.300, 2.920, +0.340]
        smt.make_swept_octagonal_beam(
            [[-0.34, 2.88, +0.34], [0.0, 2.87, +0.38], [+0.34, 2.88, +0.34]],
            [(0.085, 0.075), (0.095, 0.082), (0.085, 0.075)],
            UV_BRASS, crease_deg=40.0
        ),
        # Front Heraldic Crest Shield & Roman Numeral I Plaque (Y = 2.745..2.905 m, Z = +0.50..+0.575 m)
        smooth_box([-0.14, 2.745, +0.50], [+0.14, 2.905, +0.55], bevel=0.012, uv_center=UV_CRIMSON),
        smooth_box([-0.024, 2.760, +0.54], [+0.024, 2.890, +0.575], bevel=0.005, uv_center=UV_BRASS),
    ]
    for sx in (-1.0, +1.0):
        upper_turret_parts.append(smt.make_lathe_mesh([
            (2.780, 0.000, UV_BRASS),
            (2.780, 0.115, UV_BRASS),
            (2.820, 0.102, UV_ROPE),
            (3.020, 0.102, UV_ROPE),
            (3.060, 0.115, UV_BRASS),
            (3.060, 0.000, UV_BRASS),
        ], axis='y', center=(sx * UPPER_LIMB_ROOT_X, 0.0, UPPER_LIMB_ROOT_Z), segs=18, crease_deg=45.0))

    wheel_L     = make_v32_siege_wheel_mesh(-1.0)
    wheel_R     = make_v32_siege_wheel_mesh(+1.0)
    stab_L      = make_v32_stabilizer_mesh(-1.0)
    stab_R      = make_v32_stabilizer_mesh(+1.0)
    wheel_dmg_L = make_v33_damaged_siege_wheel_mesh(-1.0)
    wheel_dmg_R = make_v33_damaged_siege_wheel_mesh(+1.0)
    stab_dmg_L  = make_v33_damaged_stabilizer_mesh(-1.0)
    stab_dmg_R  = make_v33_damaged_stabilizer_mesh(+1.0)

    meshes_dict = {
        "Carriage_Chassis":        bhg.shift_mesh_to_pivot(mbu.concat_meshes(carriage_parts), PIVOTS["Carriage_Chassis"]),
        "Wheel_FL":                wheel_L,
        "Wheel_FR":                wheel_R,
        "Wheel_ML":                wheel_L,
        "Wheel_MR":                wheel_R,
        "Wheel_RL":                wheel_L,
        "Wheel_RR":                wheel_R,
        "Stabilizer_FL":           stab_L,
        "Stabilizer_FR":           stab_R,
        "Stabilizer_RL":           stab_L,
        "Stabilizer_RR":           stab_R,
        "Traverse_Mount":          bhg.shift_mesh_to_pivot(mbu.concat_meshes(traverse_parts), PIVOTS["Traverse_Mount"]),
        "Elevation_Cradle":        bhg.shift_mesh_to_pivot(mbu.concat_meshes(elev_parts), PIVOTS["Elevation_Cradle"]),
        "Main_Limb_L":             make_v32_engineered_sword_limb_mesh(-1.0, MAIN_LIMB_LEN, MAIN_TIP_OVERHANG, MAIN_BASE_SWEEP, is_upper=False),
        "Main_Limb_R":             make_v32_engineered_sword_limb_mesh(+1.0, MAIN_LIMB_LEN, MAIN_TIP_OVERHANG, MAIN_BASE_SWEEP, is_upper=False),
        "Main_String_L":           make_v32_bowstring_half_mesh(-1.0, MAIN_STR_LEN, is_upper=False),
        "Main_String_R":           make_v32_bowstring_half_mesh(+1.0, MAIN_STR_LEN, is_upper=False),
        "Main_Draw_Catch":         bb2_make_catch(is_upper=False),
        "Main_Siege_Bolt":         make_v32_siege_bolt_mesh(is_upper=False),
        "Winch_Drum_And_Cranks":   make_v32_winch_drum_and_cranks_mesh(),
        "Winch_Ratchet_Gear":      bhg.shift_mesh_to_pivot(
            smt.compute_crease_normals(*bhg.make_toothed_gear(PIVOTS["Winch_Ratchet_Gear"], r_root=0.19, r_tip=0.25, half_thick=0.045, n_teeth=12, uv_body=UV_IRON, uv_rim=UV_BRASS)[:4:3], bhg.make_toothed_gear(PIVOTS["Winch_Ratchet_Gear"], r_root=0.19, r_tip=0.25, half_thick=0.045, n_teeth=12, uv_body=UV_IRON, uv_rim=UV_BRASS)[2], crease_deg=40.0),
            PIVOTS["Winch_Ratchet_Gear"]
        ),
        "Winch_Pawl_And_Lever":    mbu.concat_meshes([
            smooth_box([-0.035, -0.04, -0.04], [+0.035, +0.42, +0.04], bevel=0.008, uv_center=UV_BRASS),
            smt.make_lathe_mesh([(-0.055, 0.0, UV_CRIMSON), (-0.055, 0.046, UV_CRIMSON), (+0.055, 0.046, UV_CRIMSON), (+0.055, 0.0, UV_CRIMSON)], axis='x', center=(0.0, +0.42, 0.0), segs=14),
        ]),
        "Upper_Turret_Mount":      bhg.shift_mesh_to_pivot(mbu.concat_meshes(upper_turret_parts), PIVOTS["Upper_Turret_Mount"]),
        "Upper_Limb_L":            make_v32_engineered_sword_limb_mesh(-1.0, UPPER_LIMB_LEN, UPPER_TIP_OVERHANG, UPPER_BASE_SWEEP, is_upper=True),
        "Upper_Limb_R":            make_v32_engineered_sword_limb_mesh(+1.0, UPPER_LIMB_LEN, UPPER_TIP_OVERHANG, UPPER_BASE_SWEEP, is_upper=True),
        "Upper_String_L":          make_v32_bowstring_half_mesh(-1.0, UPPER_STR_LEN, is_upper=True),
        "Upper_String_R":          make_v32_bowstring_half_mesh(+1.0, UPPER_STR_LEN, is_upper=True),
        "Upper_Catch_And_Trigger": bb2_make_catch(is_upper=True),
        "Upper_Conditioning_Bolt": make_v32_siege_bolt_mesh(is_upper=True),
        "Wheel_FL_Damaged":        wheel_dmg_L,
        "Wheel_FR_Damaged":        wheel_dmg_R,
        "Wheel_ML_Damaged":        wheel_dmg_L,
        "Wheel_MR_Damaged":        wheel_dmg_R,
        "Wheel_RL_Damaged":        wheel_dmg_L,
        "Wheel_RR_Damaged":        wheel_dmg_R,
        "Stabilizer_FL_Damaged":   stab_dmg_L,
        "Stabilizer_FR_Damaged":   stab_dmg_R,
        "Stabilizer_RL_Damaged":   stab_dmg_L,
        "Stabilizer_RR_Damaged":   stab_dmg_R,
        "Operator_Steering_Tiller":       make_v40_operator_steering_tiller_mesh(),
        "Operator_Traverse_Wheel":        make_v40_operator_traverse_wheel_mesh(),
        "Operator_Fire_And_Couple_Lever": make_v40_operator_fire_lever_mesh(),
        "Coupling_Clutch_Collar":         make_v40_coupling_clutch_collar_mesh(),
        "Coupling_Transfer_Linkage":      make_v40_coupling_transfer_linkage_mesh(),
        "Delay_Escapement_Gear":          make_v40_delay_escapement_gear_mesh(),
        "Heavy_Sear_Trip_Bar":            make_v40_heavy_sear_trip_bar_mesh(),
    }

    total_v, total_t = 0, 0
    for name, m in meshes_dict.items():
        total_v += len(m[0])
        total_t += len(m[3])
        print(f"  v3.2 Mesh [{name:24s}]: {len(m[0]):6d} verts, {len(m[3]):6d} tris")
    print(f"  Total v3.2 Geometry: {total_v:,} verts, {total_t:,} tris")

    pil_imgs = enhance_bibyellista_pbr_textures_v32(imgs_raw)
    return meshes_dict, pil_imgs


def bb2_make_catch(is_upper: bool = False):
    s = 0.55 if is_upper else 1.00
    parts = [
        smooth_box([-0.13 * s, -0.05 * s, -0.20 * s], [+0.13 * s, +0.06 * s, +0.10 * s], bevel=0.012 * s, uv_center=UV_BRASS),
        smooth_box([-0.09 * s, +0.05 * s, -0.06 * s], [-0.03 * s, +0.13 * s, +0.04 * s], bevel=0.008 * s, uv_center=UV_IRON),
        smooth_box([+0.03 * s, +0.05 * s, -0.06 * s], [+0.09 * s, +0.13 * s, +0.04 * s], bevel=0.008 * s, uv_center=UV_IRON),
    ]
    return mbu.concat_meshes(parts)


# =============================================================================
# 2. KINEMATICS, POSE SOLVER & V3.2 MECHANICAL ANIMATION NATURALISM (12 CLIPS)
# =============================================================================

LOCOMOTION_SPEC = {
    "wheelRadiusMeters": WHEEL_RADIUS,
    "wheelCircumferenceMeters": WHEEL_CIRCUMF,
    "wheelWidthMeters": round(2.0 * WHEEL_HALF_W, 3),
    "trackWidthMeters": round(2.0 * WHEEL_X_OFFSET, 3),
    "axlePositionsZ": {
        "front": AXLE_Z_FRONT,
        "middle": AXLE_Z_MID,
        "rear": AXLE_Z_REAR,
    },
    "wheelbaseTotalMeters": round(AXLE_Z_FRONT - AXLE_Z_REAR, 3),
    "rollingSignConvention": (
        "Each wheel node (Nodes 2..7: Wheel_FL, Wheel_FR, Wheel_ML, Wheel_MR, Wheel_RL, Wheel_RR) "
        "rolls around its local +X axis: delta_theta_x_rad = +delta_distance_z / 0.550 (i.e. +1.8182 rad or +104.175 deg "
        "per meter of forward +Z travel; negative for reverse -Z travel)."
    ),
    "steeringSpec": {
        "frontAxleMaxSteerDeg": 18.0,
        "middleAxleMaxSteerDeg": 0.0,
        "rearAxleCounterSteerDeg": -10.0,
        "minimumTurnRadiusMeters": 4.25,
        "steeringAxisLocal": [0.0, 1.0, 0.0],
    },
    "stabilizerFootprint": {
        "travelReadyFoldDeg": STAB_FOLD_TRAVEL_DEG,
        "travelGroundClearanceMeters": 0.520,
        "travelCollisionWidthMeters": 2.460,
        "deployedPlantedDeg": STAB_PLANTED_DEG,
        "deployedOutriggerSpanWidthMeters": 4.380,
        "deployedCollisionLengthMeters": 4.035,
    },
}

DAMAGED_SUBSYSTEM_NODES = [
    ("Wheel_FL_Damaged",      "Wheel_FL",      2,  39, [-WHEEL_X_OFFSET, WHEEL_RADIUS, AXLE_Z_FRONT]),
    ("Wheel_FR_Damaged",      "Wheel_FR",      3,  40, [+WHEEL_X_OFFSET, WHEEL_RADIUS, AXLE_Z_FRONT]),
    ("Wheel_ML_Damaged",      "Wheel_ML",      4,  41, [-WHEEL_X_OFFSET, WHEEL_RADIUS, AXLE_Z_MID]),
    ("Wheel_MR_Damaged",      "Wheel_MR",      5,  42, [+WHEEL_X_OFFSET, WHEEL_RADIUS, AXLE_Z_MID]),
    ("Wheel_RL_Damaged",      "Wheel_RL",      6,  43, [-WHEEL_X_OFFSET, WHEEL_RADIUS, AXLE_Z_REAR]),
    ("Wheel_RR_Damaged",      "Wheel_RR",      7,  44, [+WHEEL_X_OFFSET, WHEEL_RADIUS, AXLE_Z_REAR]),
    ("Stabilizer_FL_Damaged", "Stabilizer_FL", 8,  45, [-1.180, 0.820, +1.050]),
    ("Stabilizer_FR_Damaged", "Stabilizer_FR", 9,  46, [+1.180, 0.820, +1.050]),
    ("Stabilizer_RL_Damaged", "Stabilizer_RL", 10, 47, [-1.180, 0.820, -1.420]),
    ("Stabilizer_RR_Damaged", "Stabilizer_RR", 11, 48, [+1.180, 0.820, -1.420]),
]

AIMING_SPEC = {
    "traverseNodeIndex": 12,
    "traverseNodeName": "Traverse_Mount",
    "traversePivotCarriageSpace": PIVOTS["Traverse_Mount"],
    "traverseAxisLocal": [0.0, 1.0, 0.0],
    "traverseYawRangeDeg": [-45.0, +45.0],
    "verifiedMaxPracticalTraverseDeg": [-60.0, +60.0],
    "elevationNodeIndex": 13,
    "elevationNodeName": "Elevation_Cradle",
    "elevationPivotCarriageSpace": PIVOTS["Elevation_Cradle"],
    "elevationPivotLocalToTraverse": [0.000, +0.380, -0.120],
    "elevationAxisLocal": [1.0, 0.0, 0.0],
    "elevationPitchRangeDeg": {
        "maxDepressionDownhillDeg": -8.0,
        "maxElevationUphillDeg": +20.0,
        "rearDeckPhysicalClearanceAtPos20DegMeters": 0.2879,
        "rearCenterPlankDeckClearanceAtPos20DegMeters": 0.3879,
        "rearTurntablePlatformClearanceAtPos20DegMeters": 0.0665,
        "seatedOperatorKneeClearanceAtPos20DegRecoilMeters": 0.3450,
        "quatXSignNote": "In right-handed (+X right, +Y up, +Z forward) coordinates, quat_x(-elev_deg) tilts the +Z nose UP by +elev_deg."
    },
    "upperTurretNodeIndex": 23,
    "upperTurretNodeName": "Upper_Turret_Mount",
    "upperTurretPivotCarriageSpace": PIVOTS["Upper_Turret_Mount"],
    "upperTurretParentNodeIndex": 12,
    "upperTurretParentNodeName": "Traverse_Mount",
    "upperTurretPivotLocalToTraverse": [0.000, +1.540, +0.080],
    "upperTurretFullCircleYawRangeDeg": [-180.0, +180.0],
    "upperTurretContinuous360Supported": True,
    "upperTurretPitchRangeDeg": [-14.0, +25.0],
    "muzzleHeightDifferenceMeters": 1.110,
    "convergencePitchFormula": "delta_pitch_rad = -atan2(1.110, target_distance_m) (e.g. -4.23 deg at 15m, -2.54 deg at 25m, -1.59 deg at 40m)",
}

COUPLED_FIRING_SPEC = {
    "designPhilosophy": (
        "Main Launcher II (Main_Draw_Catch Node 18) deliberately lacks an independent manual firing trigger. "
        "To discharge the heavy siege bolt, Upper_Turret_Mount (Node 23) rotates into alignment (yaw = 0 deg) with "
        "Elevation_Cradle (Node 13) and Coupling_Clutch_Collar (Node 52) engages the upper turret's rear dog-lug. "
        "When Upper_Catch_And_Trigger (Node 28) releases Shot I at t = 0.450 s, its trip-finger drives "
        "Coupling_Transfer_Linkage (Node 53, beside the engraved I -> II plaque), releasing the 12-tooth "
        "Delay_Escapement_Gear (Node 54). Over the exact 0.200 s interval (0.450 s -> 0.650 s), Node 54 spins +240 deg "
        "until its eccentric cam strikes Heavy_Sear_Trip_Bar (Node 55) at t = 0.650 s, tripping Main_Draw_Catch (Node 18) "
        "to unleash Shot II."
    ),
    "clutchNodeName": "Coupling_Clutch_Collar",
    "clutchNodeIndex": 52,
    "clutchParentNodeName": "Traverse_Mount",
    "clutchParentNodeIndex": 12,
    "clutchNominalUncoupledPivotCarriageSpace": [0.000, +2.540, -0.180],
    "clutchNominalUncoupledLocalToTraverse": [0.000, +1.300, -0.180],
    "clutchExportedBindPoseEngagedCarriageSpace": [0.000, +2.605, -0.180],
    "clutchExportedBindPoseEngagedLocalToTraverse": [0.000, +1.365, -0.180],
    "clutchEngagedLiftOffsetMeters": +0.065,
    "clutchEngagedTwistYawDeg": +35.0,
    "clutchPoseNote": (
        "IMPORTANT: Node 52 (Coupling_Clutch_Collar) default exported GLB bind pose is the ENGAGED pose "
        "(local translation [0.000, +1.365, -0.180] on Traverse_Mount, +65 mm above its nominal uncoupled pivot "
        "[0.000, +1.300, -0.180] used in 06_BiBye_Travel_Ready and 18_BiBye_Upper_Uncouple_Release)."
    ),
    "transferLinkageNodeName": "Coupling_Transfer_Linkage",
    "transferLinkageNodeIndex": 53,
    "delayEscapementNodeName": "Delay_Escapement_Gear",
    "delayEscapementNodeIndex": 54,
    "heavySearTripBarNodeName": "Heavy_Sear_Trip_Bar",
    "heavySearTripBarNodeIndex": 55,
    "coupledShot1ReleaseSec": 0.450,
    "coupledShot1HandoffSec": 0.485,
    "mechanicalDelayDurationSec": 0.200,
    "delayedShot2ReleaseSec": 0.650,
    "delayedShot2HandoffSec": 0.705,
    "recoilPeakSec": 0.850,
}

SEATED_OPERATOR_SPEC = {
    "seatAttachedToNode": "Carriage_Chassis",
    "seatAttachedToNodeIndex": 1,
    "rotatesWithUpperTurret": False,
    "locators": V4_SEATED_OPERATOR_LOCATORS,
    "controlNodes": {
        "steeringTiller": {"nodeName": "Operator_Steering_Tiller", "nodeIndex": 49, "gripLocator": "hand_L_steering_grip", "gripNodeIndex": 61},
        "traverseWheel":  {"nodeName": "Operator_Traverse_Wheel",  "nodeIndex": 50, "gripLocator": "hand_R_traverse_grip", "gripNodeIndex": 62},
        "fireCoupleLever":{"nodeName": "Operator_Fire_And_Couple_Lever", "nodeIndex": 51, "gripLocator": "hand_R_fire_lever_grip", "gripNodeIndex": 63},
    },
    "spellbladeSeatedClearancesMeters": {
        "helmetCrestTopY": 1.853,
        "upperTurretRearwardFireClearanceAboveHelmetMeters": 0.662,
        "winchSweepClearanceToSeatedKneesMeters": 0.306,
        "winchSweepClearanceToSeatedTorsoMeters": 0.696,
        "rightHipSwordNotchClearance": "Open right bolster forward of Z = -1.860 m provides unobstructed clearance for ARSpellbladeRig socket_sword / OBHeroSword.",
    },
}

PROJECTILE_HANDOFF = {
    "stage1_conditioning_bolt": {
        "nodeIndex": 29,
        "nodeName": "Upper_Conditioning_Bolt",
        "parentNodeName": "Upper_Turret_Mount",
        "muzzleLocator": "small_bolt_muzzle",
        "muzzleLocatorNodeIndex": 34,
        "deployedFireEvent": "small_bolt_fire",
        "deployedFireTimeSec": 0.450,
        "deployedHandoffEvent": "small_bolt_handoff",
        "deployedHandoffTimeSec": 0.485,
        "mobileFireClip": "09_BiBye_Mobile_Shot1_Fire",
        "mobileFireEvent": "mobile_small_bolt_fire",
        "mobileFireTimeSec": 0.200,
        "mobileHandoffEvent": "mobile_small_bolt_handoff",
        "mobileHandoffTimeSec": 0.235,
        "boltLengthMeters": UPPER_BOLT_LEN,
        "launchDirectionLocal": [0.0, 0.0, +1.0],
    },
    "stage2_main_siege_bolt": {
        "nodeIndex": 19,
        "nodeName": "Main_Siege_Bolt",
        "parentNodeName": "Elevation_Cradle",
        "muzzleLocator": "main_bolt_muzzle",
        "muzzleLocatorNodeIndex": 30,
        "deployedOnly": True,
        "fireEvent": "main_bolt_fire",
        "fireTimeSec": 0.650,
        "interShotIntervalSec": 0.200,
        "handoffEvent": "main_bolt_handoff",
        "handoffTimeSec": 0.705,
        "boltLengthMeters": MAIN_BOLT_LEN,
        "launchDirectionLocal": [0.0, 0.0, +1.0],
    },
}

SUBSYSTEM_DAMAGE_SPEC = {
    "designSummary": (
        "Nodes 0..48 preserve all v3.3 indices and names. Ten dedicated damaged subsystem mesh nodes (Nodes 39..44: "
        "Wheel_FL_Damaged..Wheel_RR_Damaged; Nodes 45..48: Stabilizer_FL_Damaged..Stabilizer_RR_Damaged) are parented "
        "to Carriage_Chassis (Node 1) at the exact same pivots as their intact counterparts (Nodes 2..11), initialized "
        "with scale=[0,0,0] in healthy states."
    ),
    "wheels": {
        "Wheel_FL": {"subsystemId": "wheel_fl", "intactNode": "Wheel_FL", "intactNodeIndex": 2, "damagedNode": "Wheel_FL_Damaged", "damagedNodeIndex": 39, "pivotCarriageSpace": [-1.075, 0.550, +1.200], "hitboxAABB_CarriageSpace": {"min": [-1.225, 0.000, +0.650], "max": [-0.925, 1.100, +1.750]}, "impairedWobbleCamberDeg": 8.5, "destroyedCollapseCamberDeg": -22.0, "destroyedAxleDropMeters": -0.048},
        "Wheel_FR": {"subsystemId": "wheel_fr", "intactNode": "Wheel_FR", "intactNodeIndex": 3, "damagedNode": "Wheel_FR_Damaged", "damagedNodeIndex": 40, "pivotCarriageSpace": [+1.075, 0.550, +1.200], "hitboxAABB_CarriageSpace": {"min": [+0.925, 0.000, +0.650], "max": [+1.225, 1.100, +1.750]}, "impairedWobbleCamberDeg": 8.5, "destroyedCollapseCamberDeg": +22.0, "destroyedAxleDropMeters": -0.048},
        "Wheel_ML": {"subsystemId": "wheel_ml", "intactNode": "Wheel_ML", "intactNodeIndex": 4, "damagedNode": "Wheel_ML_Damaged", "damagedNodeIndex": 41, "pivotCarriageSpace": [-1.075, 0.550, -0.340], "hitboxAABB_CarriageSpace": {"min": [-1.225, 0.000, -0.890], "max": [-0.925, 1.100, +0.210]}, "impairedWobbleCamberDeg": 8.5, "destroyedCollapseCamberDeg": -20.0, "destroyedAxleDropMeters": -0.042},
        "Wheel_MR": {"subsystemId": "wheel_mr", "intactNode": "Wheel_MR", "intactNodeIndex": 5, "damagedNode": "Wheel_MR_Damaged", "damagedNodeIndex": 42, "pivotCarriageSpace": [+1.075, 0.550, -0.340], "hitboxAABB_CarriageSpace": {"min": [+0.925, 0.000, -0.890], "max": [+1.225, 1.100, +0.210]}, "impairedWobbleCamberDeg": 8.5, "destroyedCollapseCamberDeg": +20.0, "destroyedAxleDropMeters": -0.042},
        "Wheel_RL": {"subsystemId": "wheel_rl", "intactNode": "Wheel_RL", "intactNodeIndex": 6, "damagedNode": "Wheel_RL_Damaged", "damagedNodeIndex": 43, "pivotCarriageSpace": [-1.075, 0.550, -1.715], "hitboxAABB_CarriageSpace": {"min": [-1.225, 0.000, -2.265], "max": [-0.925, 1.100, -1.165]}, "impairedWobbleCamberDeg": 8.5, "destroyedCollapseCamberDeg": -22.0, "destroyedAxleDropMeters": -0.048},
        "Wheel_RR": {"subsystemId": "wheel_rr", "intactNode": "Wheel_RR", "intactNodeIndex": 7, "damagedNode": "Wheel_RR_Damaged", "damagedNodeIndex": 44, "pivotCarriageSpace": [+1.075, 0.550, -1.715], "hitboxAABB_CarriageSpace": {"min": [+0.925, 0.000, -2.265], "max": [+1.225, 1.100, -1.165]}, "impairedWobbleCamberDeg": 8.5, "destroyedCollapseCamberDeg": +22.0, "destroyedAxleDropMeters": -0.048},
    },
    "stabilizers": {
        "Stabilizer_FL": {"subsystemId": "stabilizer_fl", "intactNode": "Stabilizer_FL", "intactNodeIndex": 8,  "damagedNode": "Stabilizer_FL_Damaged", "damagedNodeIndex": 45, "pivotCarriageSpace": [-1.180, 0.820, +1.050], "hitboxAABB_Deployed": {"min": [-2.120, 0.000, +0.820], "max": [-1.100, 0.920, +1.280]}, "hitboxAABB_Travel": {"min": [-1.420, 0.480, +0.820], "max": [-1.050, 1.580, +1.280]}, "destroyedBlocksDeployment": True},
        "Stabilizer_FR": {"subsystemId": "stabilizer_fr", "intactNode": "Stabilizer_FR", "intactNodeIndex": 9,  "damagedNode": "Stabilizer_FR_Damaged", "damagedNodeIndex": 46, "pivotCarriageSpace": [+1.180, 0.820, +1.050], "hitboxAABB_Deployed": {"min": [+1.100, 0.000, +0.820], "max": [+2.120, 0.920, +1.280]}, "hitboxAABB_Travel": {"min": [+1.050, 0.480, +0.820], "max": [+1.420, 1.580, +1.280]}, "destroyedBlocksDeployment": True},
        "Stabilizer_RL": {"subsystemId": "stabilizer_rl", "intactNode": "Stabilizer_RL", "intactNodeIndex": 10, "damagedNode": "Stabilizer_RL_Damaged", "damagedNodeIndex": 47, "pivotCarriageSpace": [-1.180, 0.820, -1.420], "hitboxAABB_Deployed": {"min": [-2.120, 0.000, -1.650], "max": [-1.100, 0.920, -1.190]}, "hitboxAABB_Travel": {"min": [-1.420, 0.480, -1.650], "max": [-1.050, 1.580, -1.190]}, "destroyedBlocksDeployment": True},
        "Stabilizer_RR": {"subsystemId": "stabilizer_rr", "intactNode": "Stabilizer_RR", "intactNodeIndex": 11, "damagedNode": "Stabilizer_RR_Damaged", "damagedNodeIndex": 48, "pivotCarriageSpace": [+1.180, 0.820, -1.420], "hitboxAABB_Deployed": {"min": [+1.100, 0.000, -1.650], "max": [+2.120, 0.920, -1.190]}, "hitboxAABB_Travel": {"min": [+1.050, 0.480, -1.650], "max": [+1.420, 1.580, -1.190]}, "destroyedBlocksDeployment": True},
    },
}

DAMAGE_STATES_SPEC = {
    "provisionalMaxHP": 300,
    "destroyedClipName": "12_BiBye_Damaged_Destroyed",
    "partialWheelDamageClipName": "13_BiBye_Partial_Wheel_Damage_Limp",
    "stabilizerFailureClipName": "14_BiBye_Stabilizer_Failure_Abort",
    "destroyedHoldMode": "ClampWhenFinished",
    "subsystemDamageSpec": SUBSYSTEM_DAMAGE_SPEC,
}

ANIMATION_EVENTS = {
    "01_BiBye_LoadedIdle": {
        "duration_sec": 1.20, "loop": True, "state_role": "DEPLOYED_COUPLED_READY",
        "events": {"loaded_idle_ready": 0.000, "deployed_coupled_ready": 0.000},
    },
    "02_BiBye_TwoStage_Fire": {
        "duration_sec": 3.20, "loop": False, "state_role": "COUPLED_TWO_STAGE_VOLLEY",
        "target_subassembly": "Launchers_And_Coupling_Linkage_Only (Nodes 13..29, 50..55)",
        "events": {
            "aim_committed": 0.000,
            "final_short_draw_start": 0.100,
            "small_bolt_fire": 0.450,
            "coupling_linkage_trip": 0.450,
            "delay_escapement_start": 0.450,
            "small_bolt_handoff": 0.485,
            "delay_escapement_trip_main_sear": 0.650,
            "main_bolt_fire": 0.650,
            "main_bolt_handoff": 0.705,
            "recoil_peak": 0.850,
            "recovery_complete": 2.200,
        },
        "inter_shot_interval_sec": 0.200,
    },
    "03_BiBye_Spent_Recovery": {
        "duration_sec": 1.20, "loop": True, "state_role": "DEPLOYED_SPENT",
        "events": {"spent_recovery_idle": 0.000},
    },
    "04_BiBye_Mechanical_Reload": {
        "duration_sec": 6.00, "loop": False, "state_role": "FULL_TWO_LAUNCHER_RELOAD",
        "target_subassembly": "Launchers_And_Winch_Only (Nodes 13..29, 50..55)",
        "events": {
            "main_catch_slide_forward": 0.000,
            "main_winch_draw_start": 0.750,
            "main_catch_lock": 2.850,
            "main_bolt_place_on_rail": 3.100,
            "upper_cock_and_load": 4.100,
            "reload_ready_state": 5.350,
        },
    },
    "05_BiBye_Stabilizer_Deploy": {
        "duration_sec": 1.60, "loop": False, "state_role": "DEPLOYING_SUBASSEMBLY",
        "target_subassembly": "Stabilizers_And_Chassis_Lift_Only (Nodes 1, 8..11)",
        "events": {
            "deploy_halt_start": 0.000,
            "stabilizers_plant_down_start": 0.100,
            "stabilizers_planted_lock": 1.050,
            "stabilizers_deploy_complete": 1.350,
        },
    },
    "06_BiBye_Travel_Ready": {
        "duration_sec": 1.20, "loop": True, "state_role": "TRAVEL_UNCOUPLED_READY",
        "events": {"travel_ready_idle": 0.000},
    },
    "07_BiBye_Stabilizer_Retract": {
        "duration_sec": 1.60, "loop": False, "state_role": "RETRACTING_SUBASSEMBLY",
        "target_subassembly": "Stabilizers_And_Chassis_Lift_Only (Nodes 1, 8..11)",
        "events": {
            "bracing_unlock_start": 0.000,
            "stabilizers_fold_up_start": 0.200,
            "stabilizers_folded_travel_lock": 1.250,
            "retract_to_travel_complete": 1.450,
        },
    },
    "08_BiBye_Wheel_Roll_Forward": {
        "duration_sec": 1.60, "loop": True, "state_role": "LOCOMOTION_SUBASSEMBLY",
        "target_subassembly": "Wheels_Only (Nodes 2..7)",
        "events": {"wheel_cycle_start": 0.000, "wheel_half_turn": 0.800, "wheel_full_turn": 1.600},
    },
    "09_BiBye_Mobile_Shot1_Fire": {
        "duration_sec": 1.60, "loop": False, "state_role": "INDEPENDENT_SHOT1_FIRE_SUBASSEMBLY",
        "target_subassembly": "Upper_Conditioning_Ballista_Only (Nodes 23..29)",
        "events": {
            "mobile_aim_committed": 0.000,
            "mobile_small_bolt_fire": 0.200,
            "mobile_small_bolt_handoff": 0.235,
            "mobile_recoil_peak": 0.310,
            "mobile_recovery_complete": 0.850,
        },
    },
    "10_BiBye_Mobile_Shot1_Reload": {
        "duration_sec": 2.50, "loop": False, "state_role": "INDEPENDENT_SHOT1_RELOAD_SUBASSEMBLY",
        "target_subassembly": "Upper_Conditioning_Ballista_Only (Nodes 23..29)",
        "events": {
            "mobile_upper_catch_forward": 0.000,
            "mobile_upper_draw_start": 0.450,
            "mobile_upper_catch_lock": 1.450,
            "mobile_upper_bolt_place": 1.550,
            "mobile_reload_ready": 2.500,
        },
    },
    "11_BiBye_Aim_Traverse_Elevation_Sweep": {
        "duration_sec": 4.00, "loop": False, "state_role": "AIMING_SUBASSEMBLY_DEMO",
        "target_subassembly": "Traverse_Elevation_And_Wheel_Control (Nodes 12, 13, 50)",
        "events": {
            "aim_sweep_start": 0.000,
            "traverse_left_max_neg45deg": 0.800,
            "traverse_right_max_pos45deg": 2.000,
            "elevation_up_pos20deg": 2.800,
            "elevation_down_neg8deg": 3.400,
            "aim_sweep_center_return": 4.000,
        },
    },
    "12_BiBye_Damaged_Destroyed": {
        "duration_sec": 1.80, "loop": False, "state_role": "DESTROYED_WRECK_STATE",
        "events": {
            "structural_collapse_impact": 0.150,
            "limbs_shatter_slack": 0.350,
            "wreck_settle_complete": 0.850,
            "destroyed_persistent_hold": 1.800,
        },
    },
    "13_BiBye_Partial_Wheel_Damage_Limp": {
        "duration_sec": 2.40, "loop": True, "state_role": "PARTIAL_WHEEL_DAMAGE_SUBASSEMBLY",
        "target_subassembly": "Chassis_And_Wheels_Only (Nodes 1..7, 39..44, 49)",
        "events": {
            "limp_cycle_start": 0.000,
            "damaged_fl_spoke_gap_drop": 0.600,
            "damaged_mr_bearing_wobble": 1.200,
            "limp_cycle_complete": 2.400,
        },
    },
    "14_BiBye_Stabilizer_Failure_Abort": {
        "duration_sec": 2.20, "loop": False, "state_role": "STABILIZER_FAILURE_SUBASSEMBLY",
        "target_subassembly": "Chassis_And_Stabilizers_Only (Nodes 1, 8..11, 45..48)",
        "events": {
            "deploy_attempt_start": 0.000,
            "sheared_outriggers_fail_contact": 0.750,
            "carriage_unsupported_list_peak": 1.050,
            "emergency_retract_abort": 1.350,
            "abort_return_travel_ready": 2.000,
        },
    },
    "15_BiBye_Wide_Traverse_60_Turret_70_Sweep": {
        "duration_sec": 4.80, "loop": False, "state_role": "WIDE_TRAVERSE_EXPLORATION_DEMO",
        "target_subassembly": "Traverse_Elevation_And_Upper_Turret (Nodes 12, 13, 23, 50)",
        "events": {
            "wide_sweep_start": 0.000,
            "main_traverse_neg60_up20": 1.000,
            "main_traverse_pos60_down8": 2.400,
            "upper_turret_neg70_sweep": 3.300,
            "upper_turret_pos70_sweep": 4.100,
            "wide_sweep_center_return": 4.800,
        },
    },
    "16_BiBye_Upper_Turret_360_And_Pitch_Sweep": {
        "duration_sec": 4.80, "loop": True, "state_role": "UPPER_TURRET_360_ROTATION_SUBASSEMBLY",
        "target_subassembly": "Upper_Turret_Mount_Only (Node 23)",
        "events": {
            "turret_360_start_0deg": 0.000,
            "turret_left_90deg_pitch_up25": 1.200,
            "turret_rearward_180deg_over_operator": 2.400,
            "turret_right_270deg_pitch_down14": 3.600,
            "turret_full_360_complete": 4.800,
        },
    },
    "17_BiBye_Upper_Align_And_Couple": {
        "duration_sec": 0.60, "loop": False, "state_role": "MECHANICAL_COUPLING_ENGAGE",
        "target_subassembly": "Clutch_And_Couple_Lever_Only (Nodes 51, 52 — Runtime owns Node 23 yaw alignment!)",
        "events": {
            "clutch_collar_slide_up_start": 0.000,
            "dog_teeth_engaged": 0.350,
            "coupling_lock_complete": 0.550,
        },
    },
    "18_BiBye_Upper_Uncouple_Release": {
        "duration_sec": 0.60, "loop": False, "state_role": "MECHANICAL_COUPLING_RELEASE",
        "target_subassembly": "Clutch_And_Couple_Lever_Only (Nodes 51, 52 — Runtime owns Node 23 yaw!)",
        "events": {
            "uncouple_lever_release_start": 0.000,
            "clutch_collar_disengaged": 0.450,
            "independent_360_freedom_restored": 0.600,
        },
    },
    "19_BiBye_Main_Winch_Reload_Only": {
        "duration_sec": 4.50, "loop": False, "state_role": "MAIN_LAUNCHER_WINCH_RELOAD_SUBASSEMBLY",
        "target_subassembly": "Main_Launcher_And_Winch_Only (Nodes 14..22, 50, 53..55 — Composable with Upper 360 Fire/Reload!)",
        "events": {
            "main_catch_slide_forward": 0.000,
            "main_winch_draw_start": 0.600,
            "main_catch_lock": 2.550,
            "main_bolt_place_on_rail": 2.750,
            "main_reload_complete": 4.500,
        },
    },
    "20_BiBye_Coupled_Shot1_Trigger_And_Delay": {
        "duration_sec": 0.70, "loop": False, "state_role": "COUPLED_STAGE1_AND_0P2S_DELAY_SUBASSEMBLY",
        "target_subassembly": "Upper_Launcher_And_Delay_Escapement (Nodes 23..29, 51..54)",
        "events": {
            "coupled_trigger_pull": 0.100,
            "small_bolt_fire": 0.450,
            "transfer_linkage_drop": 0.450,
            "small_bolt_handoff": 0.485,
            "delay_escapement_200ms_complete": 0.650,
        },
    },
    "21_BiBye_Delayed_Shot2_Release_And_Recoil": {
        "duration_sec": 2.55, "loop": False, "state_role": "DELAYED_STAGE2_RELEASE_AND_RECOIL_SUBASSEMBLY",
        "target_subassembly": "Main_Launcher_And_Sear_Trip (Nodes 13..22, 50, 55)",
        "events": {
            "sear_trip_bar_strike": 0.000,
            "main_bolt_fire": 0.000,
            "main_bolt_handoff": 0.055,
            "heavy_recoil_peak": 0.200,
            "battery_recovery_complete": 1.550,
        },
    },
}


def quat_x(deg):
    return bhg.quat_from_axis_angle([1.0, 0.0, 0.0], deg)


def quat_y(deg):
    return bhg.quat_from_axis_angle([0.0, 1.0, 0.0], deg)


def quat_z(deg):
    return bhg.quat_from_axis_angle([0.0, 0.0, 1.0], deg)


def quat_mul(q1, q2):
    x1, y1, z1, w1 = q1
    x2, y2, z2, w2 = q2
    q = np.array([
        w1*x2 + x1*w2 + y1*z2 - z1*y2,
        w1*y2 - x1*z2 + y1*w2 + z1*x2,
        w1*z2 + x1*y2 - y1*x2 + z1*w2,
        w1*w2 - x1*x2 - y1*y2 - z1*z2,
    ], dtype=np.float64)
    n = np.linalg.norm(q)
    if n < 1e-12:
        return [0.0, 0.0, 0.0, 1.0]
    q /= n
    return [float(q[0]), float(q[1]), float(q[2]), float(q[3])]


def quat_yxz(yaw_deg, pitch_deg, roll_deg=0.0):
    return quat_mul(quat_y(yaw_deg), quat_mul(quat_x(pitch_deg), quat_z(roll_deg)))


def parent_rel_pos(child_carriage_xyz, parent_name):
    if parent_name == "BiBye_Root" or parent_name == "Carriage_Chassis":
        return [round(float(child_carriage_xyz[i]), 5) for i in range(3)]
    p_piv = PIVOTS[parent_name]
    return [round(float(child_carriage_xyz[i] - p_piv[i]), 5) for i in range(3)]


def build_bibye_v3_pose(
    chassis_dy=0.0,
    chassis_dz=0.0,
    chassis_pitch_deg=0.0,
    chassis_roll_deg=0.0,
    wheel_roll_deg=0.0,
    wheel_steer_front_deg=0.0,
    wheel_steer_rear_deg=0.0,
    wheel_camber_fl_deg=0.0,
    wheel_camber_fr_deg=0.0,
    wheel_camber_ml_deg=0.0,
    wheel_camber_mr_deg=0.0,
    wheel_camber_rl_deg=0.0,
    wheel_camber_rr_deg=0.0,
    wheel_dy_fl=0.0,
    wheel_dy_fr=0.0,
    wheel_dy_ml=0.0,
    wheel_dy_mr=0.0,
    wheel_dy_rl=0.0,
    wheel_dy_rr=0.0,
    damaged_wheels_active=(),
    stab_fold_fl_deg=0.0,
    stab_fold_fr_deg=0.0,
    stab_fold_rl_deg=0.0,
    stab_fold_rr_deg=0.0,
    damaged_stabs_active=(),
    traverse_yaw_deg=0.0,
    elev_pitch_deg=0.0,
    elev_roll_deg=0.0,
    elev_recoil_dz=0.0,
    main_flex_deg=MAIN_FLEX_LOADED,
    main_limb_roll_l_deg=0.0,
    main_limb_roll_r_deg=0.0,
    main_catch_z=None,
    main_catch_pitch_deg=0.0,
    main_bolt_z=None,
    main_bolt_dy=0.0,
    main_bolt_visible=True,
    winch_deg=0.0,
    gear_deg=0.0,
    pawl_deg=0.0,
    upper_turret_yaw_deg=0.0,
    upper_turret_pitch_deg=0.0,
    upper_turret_roll_deg=0.0,
    upper_turret_recoil_dz=0.0,
    upper_flex_deg=UPPER_FLEX_LOADED,
    upper_catch_z=None,
    upper_catch_pitch_deg=0.0,
    upper_bolt_z=None,
    upper_bolt_dy=0.0,
    upper_bolt_visible=True,
    # v4.0 Seated Controls & Visible Coupling / 0.200s Delay Linkage States:
    steering_tiller_roll_deg=None,
    traverse_wheel_deg=None,
    fire_lever_pitch_deg=0.0,
    clutch_engaged=True,
    clutch_dy=None,
    clutch_yaw_deg=None,
    transfer_linkage_pitch_deg=0.0,
    transfer_linkage_dy=0.0,
    delay_escapement_deg=0.0,
    sear_trip_bar_deg=0.0,
    sear_trip_bar_dx=0.0,
):
    _, _, m_znock, m_str_yaw = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, main_flex_deg)
    _, _, u_znock, u_str_yaw = solve_bow_linkage(UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Z, UPPER_LIMB_LEN, UPPER_BASE_SWEEP, UPPER_STR_LEN, upper_flex_deg)

    m_cz = m_znock if main_catch_z is None else float(main_catch_z)
    m_bz = m_znock if main_bolt_z  is None else float(main_bolt_z)
    u_cz = u_znock if upper_catch_z is None else float(upper_catch_z)
    u_bz = u_znock if upper_bolt_z  is None else float(upper_bolt_z)

    m_scale = [1.0, 1.0, 1.0] if main_bolt_visible else [0.0, 0.0, 0.0]
    u_scale = [1.0, 1.0, 1.0] if upper_bolt_visible else [0.0, 0.0, 0.0]

    def w_quat(steer_y, roll_x, camber_z):
        return quat_mul(quat_y(steer_y), quat_mul(quat_z(camber_z), quat_x(roll_x)))

    e_piv = PIVOTS["Elevation_Cradle"]
    u_piv = PIVOTS["Upper_Turret_Mount"]

    dmg_w_set = set(damaged_wheels_active)
    dmg_s_set = set(damaged_stabs_active)

    def sc_intact(name, s_set):
        return [0.0, 0.0, 0.0] if name in s_set else [1.0, 1.0, 1.0]

    def sc_dmg(name, s_set):
        return [1.0, 1.0, 1.0] if name in s_set else [0.0, 0.0, 0.0]

    p_fl = [PIVOTS["Wheel_FL"][0], PIVOTS["Wheel_FL"][1] + wheel_dy_fl, PIVOTS["Wheel_FL"][2]]
    p_fr = [PIVOTS["Wheel_FR"][0], PIVOTS["Wheel_FR"][1] + wheel_dy_fr, PIVOTS["Wheel_FR"][2]]
    p_ml = [PIVOTS["Wheel_ML"][0], PIVOTS["Wheel_ML"][1] + wheel_dy_ml, PIVOTS["Wheel_ML"][2]]
    p_mr = [PIVOTS["Wheel_MR"][0], PIVOTS["Wheel_MR"][1] + wheel_dy_mr, PIVOTS["Wheel_MR"][2]]
    p_rl = [PIVOTS["Wheel_RL"][0], PIVOTS["Wheel_RL"][1] + wheel_dy_rl, PIVOTS["Wheel_RL"][2]]
    p_rr = [PIVOTS["Wheel_RR"][0], PIVOTS["Wheel_RR"][1] + wheel_dy_rr, PIVOTS["Wheel_RR"][2]]

    q_fl = w_quat(wheel_steer_front_deg, wheel_roll_deg, wheel_camber_fl_deg)
    q_fr = w_quat(wheel_steer_front_deg, wheel_roll_deg, wheel_camber_fr_deg)
    q_ml = w_quat(0.0,                   wheel_roll_deg, wheel_camber_ml_deg)
    q_mr = w_quat(0.0,                   wheel_roll_deg, wheel_camber_mr_deg)
    q_rl = w_quat(wheel_steer_rear_deg,  wheel_roll_deg, wheel_camber_rl_deg)
    q_rr = w_quat(wheel_steer_rear_deg,  wheel_roll_deg, wheel_camber_rr_deg)

    q_sfl = quat_z(-stab_fold_fl_deg)
    q_sfr = quat_z(+stab_fold_fr_deg)
    q_srl = quat_z(-stab_fold_rl_deg)
    q_srr = quat_z(+stab_fold_rr_deg)

    tiller_deg = (-wheel_steer_front_deg * 1.15) if steering_tiller_roll_deg is None else float(steering_tiller_roll_deg)
    twheel_deg = (traverse_yaw_deg * 4.0 - winch_deg * 0.35) if traverse_wheel_deg is None else float(traverse_wheel_deg)
    c_dy  = (+0.065 if clutch_engaged else 0.000) if clutch_dy is None else float(clutch_dy)
    c_yaw = (+35.0  if clutch_engaged else 0.000) if clutch_yaw_deg is None else float(clutch_yaw_deg)

    p52_base = parent_rel_pos(PIVOTS["Coupling_Clutch_Collar"], "Traverse_Mount")
    p53_base = parent_rel_pos(PIVOTS["Coupling_Transfer_Linkage"], "Elevation_Cradle")
    p54_base = parent_rel_pos(PIVOTS["Delay_Escapement_Gear"], "Elevation_Cradle")
    p55_base = parent_rel_pos(PIVOTS["Heavy_Sear_Trip_Bar"], "Elevation_Cradle")

    return {
        1:  ([0.000, chassis_dy, chassis_dz], quat_yxz(0.0, chassis_pitch_deg, chassis_roll_deg), [1.0, 1.0, 1.0]),
        2:  (p_fl, q_fl, sc_intact("Wheel_FL", dmg_w_set)),
        3:  (p_fr, q_fr, sc_intact("Wheel_FR", dmg_w_set)),
        4:  (p_ml, q_ml, sc_intact("Wheel_ML", dmg_w_set)),
        5:  (p_mr, q_mr, sc_intact("Wheel_MR", dmg_w_set)),
        6:  (p_rl, q_rl, sc_intact("Wheel_RL", dmg_w_set)),
        7:  (p_rr, q_rr, sc_intact("Wheel_RR", dmg_w_set)),
        8:  (parent_rel_pos(PIVOTS["Stabilizer_FL"], "Carriage_Chassis"), q_sfl, sc_intact("Stabilizer_FL", dmg_s_set)),
        9:  (parent_rel_pos(PIVOTS["Stabilizer_FR"], "Carriage_Chassis"), q_sfr, sc_intact("Stabilizer_FR", dmg_s_set)),
        10: (parent_rel_pos(PIVOTS["Stabilizer_RL"], "Carriage_Chassis"), q_srl, sc_intact("Stabilizer_RL", dmg_s_set)),
        11: (parent_rel_pos(PIVOTS["Stabilizer_RR"], "Carriage_Chassis"), q_srr, sc_intact("Stabilizer_RR", dmg_s_set)),
        12: (parent_rel_pos(PIVOTS["Traverse_Mount"], "Carriage_Chassis"), quat_y(traverse_yaw_deg), [1.0, 1.0, 1.0]),
        13: (parent_rel_pos([e_piv[0], e_piv[1], e_piv[2] + elev_recoil_dz], "Traverse_Mount"), quat_yxz(0.0, elev_pitch_deg, elev_roll_deg), [1.0, 1.0, 1.0]),
        14: (parent_rel_pos(PIVOTS["Main_Limb_L"], "Elevation_Cradle"), quat_yxz(-main_flex_deg, 0.0, main_limb_roll_l_deg), [1.0, 1.0, 1.0]),
        15: (parent_rel_pos(PIVOTS["Main_Limb_R"], "Elevation_Cradle"), quat_yxz(+main_flex_deg, 0.0, main_limb_roll_r_deg), [1.0, 1.0, 1.0]),
        16: (parent_rel_pos([0.000, MAIN_LIMB_ROOT_Y, m_znock], "Elevation_Cradle"), quat_y(+m_str_yaw), [1.0, 1.0, 1.0]),
        17: (parent_rel_pos([0.000, MAIN_LIMB_ROOT_Y, m_znock], "Elevation_Cradle"), quat_y(-m_str_yaw), [1.0, 1.0, 1.0]),
        18: (parent_rel_pos([0.000, MAIN_LIMB_ROOT_Y - 0.035, m_cz], "Elevation_Cradle"), quat_x(main_catch_pitch_deg), [1.0, 1.0, 1.0]),
        19: (parent_rel_pos([0.000, MAIN_LIMB_ROOT_Y + 0.035 + main_bolt_dy, m_bz], "Elevation_Cradle"), [0.0, 0.0, 0.0, 1.0], m_scale),
        20: (parent_rel_pos(PIVOTS["Winch_Drum_And_Cranks"], "Traverse_Mount"), quat_x(winch_deg), [1.0, 1.0, 1.0]),
        21: (parent_rel_pos(PIVOTS["Winch_Ratchet_Gear"], "Traverse_Mount"), quat_x(gear_deg), [1.0, 1.0, 1.0]),
        22: (parent_rel_pos(PIVOTS["Winch_Pawl_And_Lever"], "Traverse_Mount"), quat_x(pawl_deg), [1.0, 1.0, 1.0]),
        23: (parent_rel_pos([u_piv[0], u_piv[1], u_piv[2] + upper_turret_recoil_dz], "Traverse_Mount"), quat_yxz(upper_turret_yaw_deg, upper_turret_pitch_deg, upper_turret_roll_deg), [1.0, 1.0, 1.0]),
        24: (parent_rel_pos(PIVOTS["Upper_Limb_L"], "Upper_Turret_Mount"), quat_y(-upper_flex_deg), [1.0, 1.0, 1.0]),
        25: (parent_rel_pos(PIVOTS["Upper_Limb_R"], "Upper_Turret_Mount"), quat_y(+upper_flex_deg), [1.0, 1.0, 1.0]),
        26: (parent_rel_pos([0.000, UPPER_LIMB_ROOT_Y, u_znock], "Upper_Turret_Mount"), quat_y(+u_str_yaw), [1.0, 1.0, 1.0]),
        27: (parent_rel_pos([0.000, UPPER_LIMB_ROOT_Y, u_znock], "Upper_Turret_Mount"), quat_y(-u_str_yaw), [1.0, 1.0, 1.0]),
        28: (parent_rel_pos([0.000, UPPER_LIMB_ROOT_Y - 0.028, u_cz], "Upper_Turret_Mount"), quat_x(upper_catch_pitch_deg), [1.0, 1.0, 1.0]),
        29: (parent_rel_pos([0.000, UPPER_LIMB_ROOT_Y + 0.025 + upper_bolt_dy, u_bz], "Upper_Turret_Mount"), [0.0, 0.0, 0.0, 1.0], u_scale),
        # Nodes 39..44: Individual Damaged Wheel Nodes
        39: (p_fl, q_fl, sc_dmg("Wheel_FL", dmg_w_set)),
        40: (p_fr, q_fr, sc_dmg("Wheel_FR", dmg_w_set)),
        41: (p_ml, q_ml, sc_dmg("Wheel_ML", dmg_w_set)),
        42: (p_mr, q_mr, sc_dmg("Wheel_MR", dmg_w_set)),
        43: (p_rl, q_rl, sc_dmg("Wheel_RL", dmg_w_set)),
        44: (p_rr, q_rr, sc_dmg("Wheel_RR", dmg_w_set)),
        # Nodes 45..48: Individual Damaged Stabilizer Nodes
        45: (parent_rel_pos(PIVOTS["Stabilizer_FL"], "Carriage_Chassis"), q_sfl, sc_dmg("Stabilizer_FL", dmg_s_set)),
        46: (parent_rel_pos(PIVOTS["Stabilizer_FR"], "Carriage_Chassis"), q_sfr, sc_dmg("Stabilizer_FR", dmg_s_set)),
        47: (parent_rel_pos(PIVOTS["Stabilizer_RL"], "Carriage_Chassis"), q_srl, sc_dmg("Stabilizer_RL", dmg_s_set)),
        48: (parent_rel_pos(PIVOTS["Stabilizer_RR"], "Carriage_Chassis"), q_srr, sc_dmg("Stabilizer_RR", dmg_s_set)),
        # Nodes 49..51: Seated Operator Controls
        49: (parent_rel_pos(PIVOTS["Operator_Steering_Tiller"], "Carriage_Chassis"), quat_z(tiller_deg), [1.0, 1.0, 1.0]),
        50: (parent_rel_pos(PIVOTS["Operator_Traverse_Wheel"], "Carriage_Chassis"), quat_z(twheel_deg), [1.0, 1.0, 1.0]),
        51: (parent_rel_pos(PIVOTS["Operator_Fire_And_Couple_Lever"], "Carriage_Chassis"), quat_x(fire_lever_pitch_deg), [1.0, 1.0, 1.0]),
        # Nodes 52..55: Visible I -> II Coupled Delayed-Release Mechanism
        52: ([p52_base[0], round(p52_base[1] + c_dy, 5), p52_base[2]], quat_y(c_yaw), [1.0, 1.0, 1.0]),
        53: ([p53_base[0], round(p53_base[1] + transfer_linkage_dy, 5), p53_base[2]], quat_x(transfer_linkage_pitch_deg), [1.0, 1.0, 1.0]),
        54: (p54_base, quat_x(delay_escapement_deg), [1.0, 1.0, 1.0]),
        55: ([round(p55_base[0] + sear_trip_bar_dx, 5), p55_base[1], p55_base[2]], quat_z(sear_trip_bar_deg), [1.0, 1.0, 1.0]),
    }


def smoothstep(u):
    u = max(0.0, min(1.0, float(u)))
    return u * u * (3.0 - 2.0 * u)


def smootherstep(u):
    u = max(0.0, min(1.0, float(u)))
    return u * u * u * (u * (u * 6.0 - 15.0) + 10.0)


def build_12_animation_clips():
    ALL_MESH_NODES     = list(range(1, 30)) + list(range(39, 56))
    WHEELS_ONLY        = [2, 3, 4, 5, 6, 7]
    STABS_AND_CHASSIS  = [1, 8, 9, 10, 11]
    UPPER_ONLY         = [23, 24, 25, 26, 27, 28, 29]
    AIM_ONLY           = [12, 13, 50]
    WIDE_AIM_NODES     = [12, 13, 23, 50]
    VOLLEY_NODES       = list(range(13, 30)) + [50, 51, 52, 53, 54, 55]
    MAIN_RELOAD_NODES  = list(range(14, 23)) + [50, 53, 54, 55]
    COUPLE_NODES       = [51, 52]
    STAGE1_DELAY_NODES = list(range(23, 30)) + [51, 52, 53, 54]
    STAGE2_REC_NODES   = list(range(13, 23)) + [50, 55]

    pose_deployed_loaded = build_bibye_v3_pose(
        stab_fold_fl_deg=0.0, stab_fold_fr_deg=0.0, stab_fold_rl_deg=0.0, stab_fold_rr_deg=0.0,
        main_flex_deg=MAIN_FLEX_LOADED, upper_flex_deg=UPPER_FLEX_LOADED,
        main_bolt_visible=True, upper_bolt_visible=True,
        clutch_engaged=True, fire_lever_pitch_deg=0.0
    )
    pose_travel_loaded = build_bibye_v3_pose(
        stab_fold_fl_deg=STAB_FOLD_TRAVEL_DEG, stab_fold_fr_deg=STAB_FOLD_TRAVEL_DEG,
        stab_fold_rl_deg=STAB_FOLD_TRAVEL_DEG, stab_fold_rr_deg=STAB_FOLD_TRAVEL_DEG,
        main_flex_deg=MAIN_FLEX_LOADED, upper_flex_deg=UPPER_FLEX_LOADED,
        main_bolt_visible=True, upper_bolt_visible=True,
        clutch_engaged=False, fire_lever_pitch_deg=-18.0
    )
    pose_deployed_spent = build_bibye_v3_pose(
        main_flex_deg=0.0,
        main_catch_z=MAIN_Z_NOCK_PEAK,
        main_bolt_z=MAIN_Z_NOCK_SPENT,
        main_bolt_visible=False,
        upper_flex_deg=0.0,
        upper_catch_z=UPPER_Z_NOCK_LOADED,
        upper_bolt_z=UPPER_Z_NOCK_SPENT,
        upper_bolt_visible=False,
        winch_deg=-95.0, gear_deg=+142.5, pawl_deg=0.0,
        clutch_engaged=True,
        transfer_linkage_pitch_deg=0.0,
        delay_escapement_deg=+240.0,
        sear_trip_bar_deg=0.0,
    )

    # 1. 01_BiBye_LoadedIdle (DEPLOYED_COUPLED_READY, 1.20 s)
    clip_01_loaded_idle = [(0.00, pose_deployed_loaded), (1.20, pose_deployed_loaded)]

    # 2. 02_BiBye_TwoStage_Fire (COUPLED_TWO_STAGE_VOLLEY, 3.20 s — Visible I -> II Coupled Linkage & 0.200s Geared Escapement Delay!)
    fire_times = [
        0.000, 0.100, 0.250, 0.400, 0.450, 0.468, 0.485, 0.540, 0.600,
        0.650, 0.678, 0.705, 0.735, 0.785, 0.850, 0.980, 1.150, 1.400, 1.750, 2.200, 3.200
    ]
    clip_02_fire = []
    for t in fire_times:
        if t <= 0.001:
            clip_02_fire.append((t, pose_deployed_loaded))
            continue
        if t >= 2.200:
            clip_02_fire.append((t, pose_deployed_spent))
            continue

        # Upper Launcher I release at 0.450s -> 0.485s
        if t < 0.450:
            u_flex, u_cz, u_cpitch, u_bz, u_vis = UPPER_FLEX_LOADED, UPPER_Z_NOCK_LOADED, 0.0, UPPER_Z_NOCK_LOADED, True
        elif t < 0.485:
            u_s = smootherstep((t - 0.450) / 0.035)
            u_flex = UPPER_FLEX_LOADED * (1.0 - u_s)
            _, _, u_zn, _ = solve_bow_linkage(UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Z, UPPER_LIMB_LEN, UPPER_BASE_SWEEP, UPPER_STR_LEN, u_flex)
            u_cz, u_cpitch, u_bz, u_vis = UPPER_Z_NOCK_LOADED, -28.0, u_zn, True
        else:
            dt_u = t - 0.485
            u_flex = max(0.0, 3.2 * math.exp(-5.5 * dt_u) * math.sin(26.0 * dt_u))
            u_cz = UPPER_Z_NOCK_LOADED
            u_cpitch = -28.0 * max(0.0, 1.0 - dt_u * 2.8)
            u_bz, u_vis = UPPER_Z_NOCK_SPENT, False

        # Coupled I -> II Transfer Linkage (Node 53), 0.200s Geared Escapement Delay (Node 54), and Heavy Sear Trip-Bar (Node 55):
        f_lev = +26.0 * smootherstep(min(1.0, max(0.0, (t - 0.350) / 0.100))) * max(0.0, 1.0 - max(0.0, (t - 0.900) / 0.600))
        if t < 0.450:
            tl_pitch, tl_dy = 0.0, 0.0
            esc_deg = 0.0
            trip_deg, trip_dx = 0.0, 0.0
        elif t < 0.650:
            u_delay = (t - 0.450) / 0.200
            tl_pitch = +28.0 * smootherstep(min(1.0, u_delay * 3.5))
            tl_dy    = -0.055 * smootherstep(min(1.0, u_delay * 3.5))
            esc_deg  = +240.0 * (u_delay ** 1.15)
            trip_u   = smootherstep(max(0.0, (u_delay - 0.75) / 0.25))
            trip_deg = +32.0 * trip_u
            trip_dx  = -0.055 * trip_u
        else:
            u_ret = smootherstep(min(1.0, (t - 0.650) / 0.850))
            tl_pitch = +28.0 * (1.0 - u_ret)
            tl_dy    = -0.055 * (1.0 - u_ret)
            esc_deg  = +240.0
            trip_deg = +32.0 * (1.0 - u_ret)
            trip_dx  = -0.055 * (1.0 - u_ret)

        # Main Launcher II over-draw (0.100..0.450s) and delayed release at 0.650s -> 0.705s
        if t < 0.100:
            m_flex, m_cz, m_cpitch, m_bz, m_vis = MAIN_FLEX_LOADED, MAIN_Z_NOCK_LOADED, 0.0, MAIN_Z_NOCK_LOADED, True
            w_deg, g_deg, p_deg = 0.0, 0.0, 0.0
        elif t <= 0.450:
            u_d = smootherstep((t - 0.100) / 0.350)
            m_flex = MAIN_FLEX_LOADED + (MAIN_FLEX_PEAK - MAIN_FLEX_LOADED) * u_d
            _, _, m_zn, _ = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, m_flex)
            m_cz, m_cpitch, m_bz, m_vis = m_zn, 0.0, m_zn, True
            w_deg, g_deg, p_deg = -95.0 * u_d, +142.5 * u_d, +12.0 * math.sin(u_d * math.pi * 2.0)
        elif t < 0.650:
            m_flex, m_cz, m_bz, m_vis = MAIN_FLEX_PEAK, MAIN_Z_NOCK_PEAK, MAIN_Z_NOCK_PEAK, True
            m_cpitch = -12.0 * smoothstep((t - 0.600) / 0.050) if t > 0.600 else 0.0
            w_deg, g_deg = -95.0, +142.5
            p_deg = -32.0 * smoothstep((t - 0.600) / 0.050) if t > 0.600 else 0.0
        elif t < 0.705:
            u_m = smootherstep((t - 0.650) / 0.055)
            m_flex = MAIN_FLEX_PEAK * (1.0 - u_m)
            _, _, m_zn, _ = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, m_flex)
            m_cz, m_cpitch, m_bz, m_vis = MAIN_Z_NOCK_PEAK, -34.0, m_zn, True
            w_deg, g_deg, p_deg = -95.0, +142.5, -34.0
        else:
            dt_m = t - 0.705
            m_flex = max(0.0, 4.8 * math.exp(-4.2 * dt_m) * math.sin(22.0 * dt_m))
            m_cz = MAIN_Z_NOCK_PEAK
            m_cpitch = -34.0 * max(0.0, 1.0 - dt_m * 2.0)
            m_bz, m_vis = MAIN_Z_NOCK_SPENT, False
            w_deg, g_deg = -95.0, +142.5
            p_deg = -34.0 * max(0.0, 1.0 - dt_m * 2.0)

        if t < 0.450:
            e_dz, e_pitch, u_rec_dz, u_rec_pitch = 0.0, 0.0, 0.0, 0.0
        elif t < 0.650:
            u_r1 = (t - 0.450) / 0.200
            e_dz        = -0.024 * math.sin(u_r1 * math.pi)
            e_pitch     = -0.45 * math.sin(u_r1 * math.pi)
            u_rec_dz    = -0.045 * math.sin(u_r1 * math.pi)
            u_rec_pitch = -1.35 * math.sin(u_r1 * math.pi)
        elif t < 0.850:
            u_r2 = smootherstep((t - 0.650) / 0.200)
            e_dz        = -0.155 * u_r2
            e_pitch     = -2.85 * math.sin(u_r2 * math.pi)
            u_rec_dz    = -0.020 * math.sin(u_r2 * math.pi)
            u_rec_pitch = -0.60 * math.sin(u_r2 * math.pi)
        else:
            u_rec = smootherstep((t - 0.850) / (2.200 - 0.850))
            e_dz        = -0.155 * (1.0 - u_rec)
            e_pitch     = +0.65 * math.sin(u_rec * math.pi) * (1.0 - u_rec)
            u_rec_dz    = 0.0
            u_rec_pitch = 0.0

        clip_02_fire.append((t, build_bibye_v3_pose(
            elev_recoil_dz=e_dz, elev_pitch_deg=e_pitch,
            upper_turret_recoil_dz=u_rec_dz, upper_turret_pitch_deg=u_rec_pitch,
            main_flex_deg=m_flex, main_catch_z=m_cz, main_catch_pitch_deg=m_cpitch,
            main_bolt_z=m_bz, main_bolt_dy=0.0, main_bolt_visible=m_vis,
            upper_flex_deg=u_flex, upper_catch_z=u_cz, upper_catch_pitch_deg=u_cpitch,
            upper_bolt_z=u_bz, upper_bolt_dy=0.0, upper_bolt_visible=u_vis,
            winch_deg=w_deg, gear_deg=g_deg, pawl_deg=p_deg,
            fire_lever_pitch_deg=f_lev,
            clutch_engaged=True,
            transfer_linkage_pitch_deg=tl_pitch,
            transfer_linkage_dy=tl_dy,
            delay_escapement_deg=esc_deg,
            sear_trip_bar_deg=trip_deg,
            sear_trip_bar_dx=trip_dx,
        )))

    # 3. 03_BiBye_Spent_Recovery (1.20 s)
    clip_03_spent = [(0.00, pose_deployed_spent), (1.20, pose_deployed_spent)]

    # 4. 04_BiBye_Mechanical_Reload (6.00 s — Full reload) & 19_BiBye_Main_Winch_Reload_Only (5.00 s — Main-only subassembly reload!)
    reload_times = [
        0.00, 0.35, 0.60, 0.75, 1.15, 1.55, 1.95, 2.35, 2.85, 3.10,
        3.45, 3.80, 4.10, 4.35, 4.65, 4.95, 5.35, 5.65, 6.00
    ]
    clip_04_reload = []
    for t in reload_times:
        if t <= 0.001:
            clip_04_reload.append((t, pose_deployed_spent))
            continue
        if t >= 5.65:
            clip_04_reload.append((t, pose_deployed_loaded))
            continue

        if t < 0.60:
            u_fwd = smootherstep(t / 0.60)
            m_flex = 0.0
            m_cz = MAIN_Z_NOCK_PEAK * (1.0 - u_fwd) + MAIN_Z_NOCK_SPENT * u_fwd
            m_cpitch = -24.0 * math.sin(u_fwd * math.pi)
            w_deg = -95.0 * (1.0 - u_fwd) + 260.0 * u_fwd
            g_deg = +142.5 * (1.0 - u_fwd) - 390.0 * u_fwd
            p_deg = -18.0
            esc_deg = 240.0 * (1.0 - u_fwd)
        elif t < 0.75:
            m_flex, m_cz, m_cpitch = 0.0, MAIN_Z_NOCK_SPENT, 0.0
            w_deg, g_deg, p_deg, esc_deg = 260.0, -390.0, 0.0, 0.0
        elif t < 2.85:
            u_raw = (t - 0.75) / (2.85 - 0.75)
            u_wind = max(0.0, min(1.0, smoothstep(u_raw) + 0.018 * math.sin(u_raw * math.pi * 8.0)))
            m_flex = MAIN_FLEX_LOADED * u_wind
            _, _, m_zn, _ = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, m_flex)
            m_cz, m_cpitch = m_zn, 0.0
            w_deg = 260.0 * (1.0 - u_wind) + (-720.0) * u_wind
            g_deg = -390.0 * (1.0 - u_wind) + (+1080.0) * u_wind
            p_deg = +16.0 * abs(math.sin(u_raw * math.pi * 8.0))
            esc_deg = 0.0
        else:
            m_flex, m_cz, m_cpitch = MAIN_FLEX_LOADED, MAIN_Z_NOCK_LOADED, 0.0
            u_wset = smootherstep(min(1.0, (t - 2.85) / 2.50))
            w_deg = -720.0 * (1.0 - u_wset)
            g_deg = +1080.0 * (1.0 - u_wset)
            p_deg, esc_deg = 0.0, 0.0

        if t < 3.10:
            m_bz, m_bdy, m_vis = MAIN_Z_NOCK_SPENT, 0.0, False
        elif t < 3.80:
            u_mb = smootherstep((t - 3.10) / 0.70)
            m_bz = (MAIN_Z_NOCK_LOADED + 0.42) * (1.0 - u_mb) + MAIN_Z_NOCK_LOADED * u_mb
            m_bdy = +0.48 * (1.0 - u_mb) * (1.0 - 0.35 * u_mb)
            m_vis = True
        else:
            m_bz, m_bdy, m_vis = MAIN_Z_NOCK_LOADED, 0.0, True

        if t < 4.10:
            u_flex, u_cz, u_cpitch, u_bz, u_bdy, u_vis = 0.0, UPPER_Z_NOCK_LOADED, 0.0, UPPER_Z_NOCK_SPENT, 0.0, False
        elif t < 4.35:
            u_ufwd = smootherstep((t - 4.10) / 0.25)
            u_flex = 0.0
            u_cz = UPPER_Z_NOCK_LOADED * (1.0 - u_ufwd) + UPPER_Z_NOCK_SPENT * u_ufwd
            u_cpitch = -20.0 * math.sin(u_ufwd * math.pi)
            u_bz, u_bdy, u_vis = UPPER_Z_NOCK_SPENT, 0.0, False
        elif t < 4.95:
            u_udraw = smootherstep((t - 4.35) / 0.60)
            u_flex = UPPER_FLEX_LOADED * u_udraw
            _, _, u_zn, _ = solve_bow_linkage(UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Z, UPPER_LIMB_LEN, UPPER_BASE_SWEEP, UPPER_STR_LEN, u_flex)
            u_cz, u_cpitch, u_bz, u_bdy, u_vis = u_zn, 0.0, UPPER_Z_NOCK_SPENT, 0.0, False
        else:
            u_flex, u_cz, u_cpitch = UPPER_FLEX_LOADED, UPPER_Z_NOCK_LOADED, 0.0
            u_ub = smootherstep(min(1.0, (t - 4.95) / 0.40))
            u_bz = (UPPER_Z_NOCK_LOADED + 0.26) * (1.0 - u_ub) + UPPER_Z_NOCK_LOADED * u_ub
            u_bdy = +0.28 * (1.0 - u_ub)
            u_vis = True

        clip_04_reload.append((t, build_bibye_v3_pose(
            main_flex_deg=m_flex, main_catch_z=m_cz, main_catch_pitch_deg=m_cpitch,
            main_bolt_z=m_bz, main_bolt_dy=m_bdy, main_bolt_visible=m_vis,
            upper_flex_deg=u_flex, upper_catch_z=u_cz, upper_catch_pitch_deg=u_cpitch,
            upper_bolt_z=u_bz, upper_bolt_dy=u_bdy, upper_bolt_visible=u_vis,
            winch_deg=w_deg, gear_deg=g_deg, pawl_deg=p_deg,
            delay_escapement_deg=esc_deg,
        )))

    # 5. 05_BiBye_Stabilizer_Deploy (1.60 s — Scoped to STABS_AND_CHASSIS)
    deploy_times = [0.00, 0.10, 0.35, 0.65, 0.90, 1.05, 1.20, 1.35, 1.60]
    clip_05_deploy = []
    for t in deploy_times:
        if t <= 0.001:
            clip_05_deploy.append((t, pose_travel_loaded))
        elif t >= 1.35:
            clip_05_deploy.append((t, pose_deployed_loaded))
        elif t < 0.10:
            u_halt = t / 0.10
            clip_05_deploy.append((t, build_bibye_v3_pose(
                chassis_pitch_deg=+0.75 * math.sin(u_halt * math.pi),
                stab_fold_fl_deg=STAB_FOLD_TRAVEL_DEG, stab_fold_fr_deg=STAB_FOLD_TRAVEL_DEG,
                stab_fold_rl_deg=STAB_FOLD_TRAVEL_DEG, stab_fold_rr_deg=STAB_FOLD_TRAVEL_DEG
            )))
        elif t < 1.05:
            u_dn = smootherstep((t - 0.10) / (1.05 - 0.10))
            s_deg = STAB_FOLD_TRAVEL_DEG * (1.0 - u_dn)
            lift_y = +0.022 * math.sin(max(0.0, (u_dn - 0.70) / 0.30) * math.pi) if u_dn > 0.70 else 0.0
            clip_05_deploy.append((t, build_bibye_v3_pose(
                chassis_dy=lift_y,
                stab_fold_fl_deg=s_deg, stab_fold_fr_deg=s_deg, stab_fold_rl_deg=s_deg, stab_fold_rr_deg=s_deg
            )))
        else:
            u_sh = (t - 1.05) / (1.35 - 1.05)
            ch_dy = +0.012 * math.sin(u_sh * math.pi) * (1.0 - u_sh)
            clip_05_deploy.append((t, build_bibye_v3_pose(chassis_dy=ch_dy)))

    # 6. 06_BiBye_Travel_Ready (1.20 s)
    clip_06_travel_ready = [(0.00, pose_travel_loaded), (1.20, pose_travel_loaded)]

    # 7. 07_BiBye_Stabilizer_Retract (1.60 s — Scoped to STABS_AND_CHASSIS)
    retract_times = [0.00, 0.20, 0.50, 0.85, 1.10, 1.25, 1.45, 1.60]
    clip_07_retract = []
    for t in retract_times:
        if t <= 0.001:
            clip_07_retract.append((t, pose_deployed_loaded))
        elif t >= 1.45:
            clip_07_retract.append((t, pose_travel_loaded))
        elif t < 0.20:
            u_un = t / 0.20
            ch_dy = -0.016 * math.sin(u_un * math.pi)
            clip_07_retract.append((t, build_bibye_v3_pose(chassis_dy=ch_dy)))
        elif t < 1.25:
            u_up = smootherstep((t - 0.20) / (1.25 - 0.20))
            s_deg = STAB_FOLD_TRAVEL_DEG * u_up
            clip_07_retract.append((t, build_bibye_v3_pose(
                stab_fold_fl_deg=s_deg, stab_fold_fr_deg=s_deg, stab_fold_rl_deg=s_deg, stab_fold_rr_deg=s_deg
            )))
        else:
            clip_07_retract.append((t, pose_travel_loaded))

    # 8. 08_BiBye_Wheel_Roll_Forward (1.60 s loop — Scoped to WHEELS_ONLY)
    wheel_times = [0.00, 0.20, 0.40, 0.60, 0.80, 1.00, 1.20, 1.40, 1.60]
    clip_08_wheels = [(t, build_bibye_v3_pose(wheel_roll_deg=360.0 * (t / 1.60))) for t in wheel_times]

    # 9. 09_BiBye_Mobile_Shot1_Fire (1.60 s — Scoped to UPPER_ONLY, composable while main launcher reloads!)
    mob_fire_times = [0.000, 0.100, 0.200, 0.218, 0.235, 0.270, 0.310, 0.420, 0.580, 0.850, 1.600]
    clip_09_mob_fire = []
    for t in mob_fire_times:
        if t < 0.200:
            u_flex, u_cz, u_cpitch, u_bz, u_vis = UPPER_FLEX_LOADED, UPPER_Z_NOCK_LOADED, 0.0, UPPER_Z_NOCK_LOADED, True
            u_tdz, u_tpitch = 0.0, 0.0
        elif t < 0.235:
            u_s = smootherstep((t - 0.200) / 0.035)
            u_flex = UPPER_FLEX_LOADED * (1.0 - u_s)
            _, _, u_zn, _ = solve_bow_linkage(UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Z, UPPER_LIMB_LEN, UPPER_BASE_SWEEP, UPPER_STR_LEN, u_flex)
            u_cz, u_cpitch, u_bz, u_vis = UPPER_Z_NOCK_LOADED, -28.0, u_zn, True
            u_tdz, u_tpitch = -0.018 * u_s, -0.45 * u_s
        elif t < 0.850:
            dt_u = t - 0.235
            u_flex = max(0.0, 3.0 * math.exp(-5.8 * dt_u) * math.sin(28.0 * dt_u))
            u_cz = UPPER_Z_NOCK_LOADED
            u_cpitch = -28.0 * max(0.0, 1.0 - dt_u * 3.0)
            u_bz, u_vis = UPPER_Z_NOCK_SPENT, False
            if t <= 0.310:
                u_k = smootherstep((t - 0.200) / (0.310 - 0.200))
                u_tdz, u_tpitch = -0.048 * u_k, -1.25 * u_k
            else:
                u_r = smootherstep((t - 0.310) / (0.850 - 0.310))
                u_tdz, u_tpitch = -0.048 * (1.0 - u_r), -1.25 * (1.0 - u_r)
        else:
            u_flex, u_cz, u_cpitch, u_bz, u_vis = 0.0, UPPER_Z_NOCK_LOADED, 0.0, UPPER_Z_NOCK_SPENT, False
            u_tdz, u_tpitch = 0.0, 0.0

        clip_09_mob_fire.append((t, build_bibye_v3_pose(
            upper_turret_recoil_dz=u_tdz, upper_turret_pitch_deg=u_tpitch,
            upper_flex_deg=u_flex, upper_catch_z=u_cz, upper_catch_pitch_deg=u_cpitch,
            upper_bolt_z=u_bz, upper_bolt_dy=0.0, upper_bolt_visible=u_vis
        )))

    # 10. 10_BiBye_Mobile_Shot1_Reload (2.50 s — Exact 2.5s Shot I recock duration, scoped strictly to UPPER_ONLY!)
    mob_rel_times = [0.00, 0.22, 0.45, 0.80, 1.15, 1.45, 1.55, 1.95, 2.25, 2.50]
    clip_10_mob_reload = []
    for t in mob_rel_times:
        if t < 0.45:
            u_ufwd = smootherstep(t / 0.45)
            u_flex = 0.0
            u_cz = UPPER_Z_NOCK_LOADED * (1.0 - u_ufwd) + UPPER_Z_NOCK_SPENT * u_ufwd
            u_cpitch = -20.0 * math.sin(u_ufwd * math.pi)
            u_bz, u_bdy, u_vis = UPPER_Z_NOCK_SPENT, 0.0, False
        elif t < 1.45:
            u_udraw = smootherstep((t - 0.45) / (1.45 - 0.45))
            u_flex = UPPER_FLEX_LOADED * u_udraw
            _, _, u_zn, _ = solve_bow_linkage(UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Z, UPPER_LIMB_LEN, UPPER_BASE_SWEEP, UPPER_STR_LEN, u_flex)
            u_cz, u_cpitch, u_bz, u_bdy, u_vis = u_zn, 0.0, UPPER_Z_NOCK_SPENT, 0.0, False
        elif t < 1.55:
            u_flex, u_cz, u_cpitch, u_bz, u_bdy, u_vis = UPPER_FLEX_LOADED, UPPER_Z_NOCK_LOADED, 0.0, UPPER_Z_NOCK_SPENT, 0.0, False
        elif t < 2.25:
            u_flex, u_cz, u_cpitch = UPPER_FLEX_LOADED, UPPER_Z_NOCK_LOADED, 0.0
            u_ub = smootherstep((t - 1.55) / (2.25 - 1.55))
            u_bz = (UPPER_Z_NOCK_LOADED + 0.28) * (1.0 - u_ub) + UPPER_Z_NOCK_LOADED * u_ub
            u_bdy = +0.30 * (1.0 - u_ub)
            u_vis = True
        else:
            u_flex, u_cz, u_cpitch, u_bz, u_bdy, u_vis = UPPER_FLEX_LOADED, UPPER_Z_NOCK_LOADED, 0.0, UPPER_Z_NOCK_LOADED, 0.0, True

        clip_10_mob_reload.append((t, build_bibye_v3_pose(
            upper_flex_deg=u_flex, upper_catch_z=u_cz, upper_catch_pitch_deg=u_cpitch,
            upper_bolt_z=u_bz, upper_bolt_dy=u_bdy, upper_bolt_visible=u_vis
        )))

    # 11. 11_BiBye_Aim_Traverse_Elevation_Sweep (4.00 s)
    aim_keyframes = [
        (0.00,   0.0,   0.0),
        (0.80, -45.0,  -6.0),
        (1.40,   0.0, -14.0),
        (2.00, +45.0,  -6.0),
        (2.80, +15.0, -20.0),
        (3.40, -15.0,  +8.0),
        (4.00,   0.0,   0.0),
    ]
    clip_11_aim = [
        (t, build_bibye_v3_pose(traverse_yaw_deg=yaw, elev_pitch_deg=pitch))
        for (t, yaw, pitch) in aim_keyframes
    ]

    # 12. 12_BiBye_Damaged_Destroyed (1.80 s)
    destroy_times = [0.00, 0.15, 0.35, 0.60, 0.85, 1.15, 1.80]
    clip_12_destroy = []
    for t in destroy_times:
        if t <= 0.001:
            clip_12_destroy.append((t, pose_deployed_loaded))
            continue
        u_col = smootherstep(min(1.0, (t - 0.10) / 0.75)) if t > 0.10 else 0.0
        u_shk = math.sin(((t - 0.15) / 0.70) * math.pi * 3.0) * (1.0 - u_col) if 0.15 <= t <= 0.85 else 0.0
        bolts_vis = (t < 0.35)
        dmg_w = ("Wheel_FL", "Wheel_MR", "Wheel_RL") if t >= 0.35 else ()
        dmg_s = ("Stabilizer_FL", "Stabilizer_RR") if t >= 0.35 else ()
        m_flex = MAIN_FLEX_LOADED * max(0.0, 1.0 - (t - 0.15) / 0.20) if t < 0.35 else 0.0
        u_flex = UPPER_FLEX_LOADED * max(0.0, 1.0 - (t - 0.15) / 0.20) if t < 0.35 else 0.0

        clip_12_destroy.append((t, build_bibye_v3_pose(
            chassis_dy=-0.145 * u_col,
            chassis_dz=-0.065 * u_col,
            chassis_pitch_deg=+3.4 * u_col + 1.2 * u_shk,
            chassis_roll_deg=+6.8 * u_col + 1.8 * u_shk,
            wheel_camber_fl_deg=-26.0 * u_col,
            wheel_camber_fr_deg=+14.0 * u_col,
            wheel_camber_ml_deg=-11.0 * u_col,
            wheel_camber_mr_deg=+24.0 * u_col,
            wheel_camber_rl_deg=-19.0 * u_col,
            wheel_camber_rr_deg=+12.0 * u_col,
            wheel_dy_fl=-0.048 * u_col,
            wheel_dy_mr=-0.042 * u_col,
            wheel_dy_rl=-0.045 * u_col,
            damaged_wheels_active=dmg_w,
            wheel_steer_front_deg=-16.0 * u_col,
            wheel_steer_rear_deg=+11.0 * u_col,
            stab_fold_fl_deg=18.0 * u_col,
            stab_fold_fr_deg=28.0 * u_col,
            stab_fold_rl_deg=12.0 * u_col,
            stab_fold_rr_deg=22.0 * u_col,
            damaged_stabs_active=dmg_s,
            traverse_yaw_deg=-14.5 * u_col,
            elev_pitch_deg=+6.8 * u_col,
            elev_roll_deg=-5.2 * u_col,
            elev_recoil_dz=-0.08 * u_col,
            main_flex_deg=m_flex,
            main_limb_roll_l_deg=-9.5 * u_col,
            main_limb_roll_r_deg=+12.0 * u_col,
            main_catch_pitch_deg=-28.0 * u_col,
            main_bolt_visible=bolts_vis,
            winch_deg=140.0 * u_col,
            gear_deg=-210.0 * u_col,
            pawl_deg=-35.0 * u_col,
            upper_turret_yaw_deg=+16.5 * u_col,
            upper_turret_pitch_deg=+9.2 * u_col,
            upper_turret_roll_deg=-11.5 * u_col,
            upper_flex_deg=u_flex,
            upper_catch_pitch_deg=-25.0 * u_col,
            upper_bolt_visible=bolts_vis,
            clutch_engaged=False,
        )))

    # 13. 13_BiBye_Partial_Wheel_Damage_Limp (2.40 s loop)
    limp_times = np.linspace(0.0, 2.40, 17)
    clip_13_limp = []
    for t in limp_times:
        u = t / 2.40
        r_deg = 360.0 * u
        r_rad = math.radians(r_deg)
        wob_fl = -10.5 - 7.5 * math.sin(r_rad)
        wob_mr = +9.5  + 6.8 * math.cos(r_rad)
        ch_dy  = -0.028 - 0.016 * abs(math.sin(r_rad))
        ch_roll  = +2.2 + 1.1 * math.sin(r_rad)
        ch_pitch = +1.2 + 0.8 * math.cos(r_rad)
        clip_13_limp.append((float(t), build_bibye_v3_pose(
            chassis_dy=ch_dy,
            chassis_pitch_deg=ch_pitch,
            chassis_roll_deg=ch_roll,
            wheel_roll_deg=r_deg,
            wheel_steer_front_deg=+8.0 * math.sin(u * 2.0 * math.pi),
            wheel_steer_rear_deg=-4.4 * math.sin(u * 2.0 * math.pi),
            wheel_camber_fl_deg=wob_fl,
            wheel_camber_mr_deg=wob_mr,
            wheel_dy_fl=-0.042,
            wheel_dy_mr=-0.036,
            damaged_wheels_active=("Wheel_FL", "Wheel_MR"),
            stab_fold_fl_deg=STAB_FOLD_TRAVEL_DEG,
            stab_fold_fr_deg=STAB_FOLD_TRAVEL_DEG,
            stab_fold_rl_deg=STAB_FOLD_TRAVEL_DEG,
            stab_fold_rr_deg=STAB_FOLD_TRAVEL_DEG,
            clutch_engaged=False,
        )))

    # 14. 14_BiBye_Stabilizer_Failure_Abort (2.20 s)
    fail_times = [0.00, 0.25, 0.55, 0.75, 0.90, 1.05, 1.25, 1.55, 1.85, 2.05, 2.20]
    clip_14_stab_fail = []
    for t in fail_times:
        if t <= 0.75:
            u_dn = smootherstep(t / 0.75)
            s_ok = STAB_FOLD_TRAVEL_DEG * (1.0 - u_dn)
            s_br = STAB_FOLD_TRAVEL_DEG * (1.0 - 0.65 * u_dn)
            ch_r, ch_p, ch_y = 0.0, 0.0, 0.0
        elif t <= 1.25:
            u_lurch = math.sin(((t - 0.75) / 0.50) * math.pi)
            s_ok = 0.0
            s_br = 18.0 + 14.0 * u_lurch
            ch_r = +5.4 * u_lurch
            ch_p = +2.2 * u_lurch
            ch_y = -0.045 * u_lurch
        elif t <= 2.00:
            u_up = smootherstep((t - 1.25) / 0.75)
            s_ok = STAB_FOLD_TRAVEL_DEG * u_up
            s_br = 18.0 + (STAB_FOLD_TRAVEL_DEG - 18.0) * u_up
            ch_r, ch_p, ch_y = 0.0, 0.0, 0.0
        else:
            s_ok = STAB_FOLD_TRAVEL_DEG
            s_br = STAB_FOLD_TRAVEL_DEG
            ch_r, ch_p, ch_y = 0.0, 0.0, 0.0

        clip_14_stab_fail.append((t, build_bibye_v3_pose(
            chassis_dy=ch_y,
            chassis_pitch_deg=ch_p,
            chassis_roll_deg=ch_r,
            stab_fold_fl_deg=s_br,
            stab_fold_fr_deg=s_ok,
            stab_fold_rl_deg=s_ok,
            stab_fold_rr_deg=s_br,
            damaged_stabs_active=("Stabilizer_FL", "Stabilizer_RR"),
            clutch_engaged=False,
        )))

    # 15. 15_BiBye_Wide_Traverse_60_Turret_70_Sweep (4.80 s)
    wide_kfs = [
        (0.00,   0.0,   0.0,   0.0,   0.0),
        (1.00, -60.0, -20.0, -15.0,  -6.0),
        (1.70,   0.0, -10.0,   0.0,   0.0),
        (2.40, +60.0,  +8.0, +15.0,  +5.0),
        (3.00,   0.0,   0.0,   0.0,   0.0),
        (3.55,   0.0,   0.0, -70.0, -12.0),
        (4.20,   0.0,   0.0, +70.0,  +9.0),
        (4.80,   0.0,   0.0,   0.0,   0.0),
    ]
    clip_15_wide = [
        (t, build_bibye_v3_pose(
            traverse_yaw_deg=m_yaw,
            elev_pitch_deg=m_pitch,
            upper_turret_yaw_deg=u_yaw,
            upper_turret_pitch_deg=u_pitch
        ))
        for (t, m_yaw, m_pitch, u_yaw, u_pitch) in wide_kfs
    ]

    # 16. 16_BiBye_Upper_Turret_360_And_Pitch_Sweep (4.80 s — Full 360-deg rotation including 180-deg rearward over seated Spellblade!)
    # Note: in glTF quaternion nlerp, step by 45-deg increments so 0 -> 90 -> 180 -> 270 -> 360 rotates smoothly in one continuous direction!
    rot360_times = np.linspace(0.0, 4.80, 17)
    clip_16_360 = []
    for t in rot360_times:
        u = float(t / 4.80)
        u_yaw = 360.0 * u
        # Pitch sweeps between -25 deg (uphill +25 deg) and +14 deg (downhill -14 deg) across the 360 turn
        u_pitch = -18.0 * math.sin(u * 2.0 * math.pi)
        clip_16_360.append((float(t), build_bibye_v3_pose(
            upper_turret_yaw_deg=u_yaw,
            upper_turret_pitch_deg=u_pitch,
            clutch_engaged=False,
        )))

    # 17. 17_BiBye_Upper_Align_And_Couple (0.60 s — Animates ONLY Nodes 51 & 52 so runtime controls Node 23 yaw alignment!)
    couple_times = [0.00, 0.15, 0.35, 0.55, 0.60]
    clip_17_couple = []
    for t in couple_times:
        u_lk = smootherstep(min(1.0, t / 0.55))
        clip_17_couple.append((t, build_bibye_v3_pose(
            clutch_dy=+0.065 * u_lk,
            clutch_yaw_deg=+35.0 * u_lk,
            fire_lever_pitch_deg=-18.0 * (1.0 - u_lk),
        )))

    # 18. 18_BiBye_Upper_Uncouple_Release (0.60 s — Animates ONLY Nodes 51 & 52 to disengage clutch!)
    uncouple_times = [0.00, 0.15, 0.35, 0.45, 0.60]
    clip_18_uncouple = []
    for t in uncouple_times:
        u_un = smootherstep(min(1.0, t / 0.45))
        clip_18_uncouple.append((t, build_bibye_v3_pose(
            clutch_dy=+0.065 * (1.0 - u_un),
            clutch_yaw_deg=+35.0 * (1.0 - u_un),
            fire_lever_pitch_deg=-18.0 * u_un,
        )))

    # 19. 19_BiBye_Main_Winch_Reload_Only (4.50 s — Exact 4.5s Main Mechanical Reload, scoped strictly to Nodes 14..22, 50, 53..55!)
    main_rel_45_times = [0.00, 0.30, 0.50, 0.60, 1.05, 1.50, 1.95, 2.55, 2.75, 3.20, 3.65, 4.10, 4.50]
    clip_19_main_reload = []
    for t in main_rel_45_times:
        if t <= 0.001:
            clip_19_main_reload.append((t, pose_deployed_spent))
            continue
        if t >= 4.10:
            clip_19_main_reload.append((t, pose_deployed_loaded))
            continue
        if t < 0.50:
            u_fwd = smootherstep(t / 0.50)
            m_flex, m_cz, m_cpitch = 0.0, MAIN_Z_NOCK_PEAK * (1.0 - u_fwd) + MAIN_Z_NOCK_SPENT * u_fwd, -24.0 * math.sin(u_fwd * math.pi)
            w_deg, g_deg, p_deg, esc_deg = -95.0 * (1.0 - u_fwd) + 260.0 * u_fwd, +142.5 * (1.0 - u_fwd) - 390.0 * u_fwd, -18.0, 240.0 * (1.0 - u_fwd)
        elif t < 0.60:
            m_flex, m_cz, m_cpitch = 0.0, MAIN_Z_NOCK_SPENT, 0.0
            w_deg, g_deg, p_deg, esc_deg = 260.0, -390.0, 0.0, 0.0
        elif t < 2.55:
            u_raw = (t - 0.60) / (2.55 - 0.60)
            u_wind = max(0.0, min(1.0, smoothstep(u_raw) + 0.018 * math.sin(u_raw * math.pi * 8.0)))
            m_flex = MAIN_FLEX_LOADED * u_wind
            _, _, m_zn, _ = solve_bow_linkage(MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_BASE_SWEEP, MAIN_STR_LEN, m_flex)
            m_cz, m_cpitch = m_zn, 0.0
            w_deg = 260.0 * (1.0 - u_wind) + (-720.0) * u_wind
            g_deg = -390.0 * (1.0 - u_wind) + (+1080.0) * u_wind
            p_deg = +16.0 * abs(math.sin(u_raw * math.pi * 8.0))
            esc_deg = 0.0
        else:
            m_flex, m_cz, m_cpitch = MAIN_FLEX_LOADED, MAIN_Z_NOCK_LOADED, 0.0
            u_wset = smootherstep(min(1.0, (t - 2.55) / 1.55))
            w_deg, g_deg, p_deg, esc_deg = -720.0 * (1.0 - u_wset), +1080.0 * (1.0 - u_wset), 0.0, 0.0

        if t < 2.75:
            m_bz, m_bdy, m_vis = MAIN_Z_NOCK_SPENT, 0.0, False
        elif t < 3.65:
            u_mb = smootherstep((t - 2.75) / 0.90)
            m_bz = (MAIN_Z_NOCK_LOADED + 0.42) * (1.0 - u_mb) + MAIN_Z_NOCK_LOADED * u_mb
            m_bdy = +0.48 * (1.0 - u_mb) * (1.0 - 0.35 * u_mb)
            m_vis = True
        else:
            m_bz, m_bdy, m_vis = MAIN_Z_NOCK_LOADED, 0.0, True

        clip_19_main_reload.append((float(t), build_bibye_v3_pose(
            main_flex_deg=m_flex, main_catch_z=m_cz, main_catch_pitch_deg=m_cpitch,
            main_bolt_z=m_bz, main_bolt_dy=m_bdy, main_bolt_visible=m_vis,
            winch_deg=w_deg, gear_deg=g_deg, pawl_deg=p_deg,
            delay_escapement_deg=esc_deg,
        )))

    # 20. 20_BiBye_Coupled_Shot1_Trigger_And_Delay (0.70 s — Composable Coupled Shot I + 0.200s Escapement Run)
    clip_20_s1_delay = [(t, p) for (t, p) in clip_02_fire if t <= 0.655] + [(0.700, dict(clip_02_fire[9][1]))]

    # 21. 21_BiBye_Delayed_Shot2_Release_And_Recoil (2.55 s — Composable Delayed Shot II Release & Heavy Recoil)
    clip_21_s2_recoil = [(round(t - 0.650, 4), p) for (t, p) in clip_02_fire if t >= 0.650]

    return [
        ("01_BiBye_LoadedIdle",                       clip_01_loaded_idle, ALL_MESH_NODES),
        ("02_BiBye_TwoStage_Fire",                    clip_02_fire,        VOLLEY_NODES),
        ("03_BiBye_Spent_Recovery",                   clip_03_spent,       ALL_MESH_NODES),
        ("04_BiBye_Mechanical_Reload",                clip_04_reload,      VOLLEY_NODES),
        ("05_BiBye_Stabilizer_Deploy",                clip_05_deploy,      STABS_AND_CHASSIS),
        ("06_BiBye_Travel_Ready",                     clip_06_travel_ready,ALL_MESH_NODES),
        ("07_BiBye_Stabilizer_Retract",               clip_07_retract,     STABS_AND_CHASSIS),
        ("08_BiBye_Wheel_Roll_Forward",               clip_08_wheels,      WHEELS_ONLY),
        ("09_BiBye_Mobile_Shot1_Fire",                clip_09_mob_fire,    UPPER_ONLY),
        ("10_BiBye_Mobile_Shot1_Reload",              clip_10_mob_reload,  UPPER_ONLY),
        ("11_BiBye_Aim_Traverse_Elevation_Sweep",     clip_11_aim,         AIM_ONLY),
        ("12_BiBye_Damaged_Destroyed",                clip_12_destroy,     ALL_MESH_NODES),
        ("13_BiBye_Partial_Wheel_Damage_Limp",        clip_13_limp,        [1, 2, 3, 4, 5, 6, 7, 39, 40, 41, 42, 43, 44, 49]),
        ("14_BiBye_Stabilizer_Failure_Abort",         clip_14_stab_fail,   [1, 8, 9, 10, 11, 45, 46, 47, 48]),
        ("15_BiBye_Wide_Traverse_60_Turret_70_Sweep", clip_15_wide,        WIDE_AIM_NODES),
        ("16_BiBye_Upper_Turret_360_And_Pitch_Sweep", clip_16_360,         [23]),
        ("17_BiBye_Upper_Align_And_Couple",           clip_17_couple,      COUPLE_NODES),
        ("18_BiBye_Upper_Uncouple_Release",          clip_18_uncouple,    COUPLE_NODES),
        ("19_BiBye_Main_Winch_Reload_Only",           clip_19_main_reload, MAIN_RELOAD_NODES),
        ("20_BiBye_Coupled_Shot1_Trigger_And_Delay",  clip_20_s1_delay,    STAGE1_DELAY_NODES),
        ("21_BiBye_Delayed_Shot2_Release_And_Recoil", clip_21_s2_recoil,   STAGE2_REC_NODES),
    ]


import build_bibyellista_v2 as bb2


class BiByellistaV32GLBBuilder(bb2.BiByellistaGLBBuilder):
    def add_image_pil_hq(self, pil_img: Image.Image, name: str, quality=96):
        buf = io.BytesIO()
        pil_img.convert("RGB").save(buf, format="JPEG", quality=quality, subsampling=0, optimize=True)
        bv_idx = self._append_bytes(buf.getvalue())
        img_idx = len(self.images)
        self.images.append({"name": name, "bufferView": bv_idx, "mimeType": "image/jpeg"})
        tex_idx = len(self.textures)
        self.textures.append({"source": img_idx, "sampler": 0})
        return tex_idx

    def build_bibye_v32_glb_bytes(self, extras: dict = None):
        while len(self.bin_buf) % 4 != 0:
            self.bin_buf.append(0)
        j = {
            "asset": {"version": "2.0", "generator": "Castleward Bi-Bye-llista Mobile Siege Engine Builder v4.0"},
            "scene": 0,
            "scenes": [{"name": "BiByellistaMobileSiegeScene", "nodes": [0]}],
            "nodes": self.nodes,
            "meshes": self.meshes,
            "materials": self.materials,
            "samplers": [{
                "magFilter": 9729,
                "minFilter": 9987,
                "wrapS": 10497,
                "wrapT": 10497,
            }],
            "textures": self.textures,
            "images": self.images,
            "accessors": self.accessors,
            "bufferViews": self.buffer_views,
            "buffers": [{"byteLength": len(self.bin_buf)}],
            "animations": self.animations,
        }
        if extras:
            j["extras"] = extras
            j["scenes"][0]["extras"] = extras
            self.nodes[0]["extras"] = extras
        json_bytes = bytearray(json.dumps(j, separators=(',', ':')).encode('utf-8'))
        while len(json_bytes) % 4 != 0:
            json_bytes.append(0x20)
        total_len = 12 + 8 + len(json_bytes) + 8 + len(self.bin_buf)
        out = bytearray()
        out.extend(struct.pack('<4sII', b'glTF', 2, total_len))
        out.extend(struct.pack('<I4s', len(json_bytes), b'JSON'))
        out.extend(json_bytes)
        out.extend(struct.pack('<I4s', len(self.bin_buf), b'BIN\x00'))
        out.extend(self.bin_buf)
        return bytes(out)


def export_bibyellista_v32_glb(meshes_dict, imgs, clips, out_glb_path: Path):
    builder = BiByellistaV32GLBBuilder()

    idx_diff = builder.add_image_pil_hq(imgs[1], "bibye_diffuse", quality=96)
    idx_norm = builder.add_image_pil_hq(imgs[0], "bibye_normal",  quality=96)
    idx_mr   = builder.add_image_pil_hq(imgs[2], "bibye_mr",      quality=96)

    builder.materials.append({
        "name": "Castleward_BiByellista_PBR",
        "pbrMetallicRoughness": {
            "baseColorTexture": {"index": idx_diff},
            "metallicRoughnessTexture": {"index": idx_mr},
            "metallicFactor": 1.0,
            "roughnessFactor": 1.0,
        },
        "normalTexture": {"index": idx_norm, "scale": 1.0},
        "doubleSided": True,
    })

    mesh_indices = {}
    for name in ORDERED_NODES[:29]:
        p, n, u, t = meshes_dict[name]
        mesh_indices[name] = builder.add_mesh(f"{name}_Mesh", p, n, u, t, mat_idx=0)
    for dmg_name, _, _, _, _ in DAMAGED_SUBSYSTEM_NODES:
        p, n, u, t = meshes_dict[dmg_name]
        mesh_indices[dmg_name] = builder.add_mesh(f"{dmg_name}_Mesh", p, n, u, t, mat_idx=0)
    for v4_name, _, _, _, _ in V4_MECHANISM_NODES:
        p, n, u, t = meshes_dict[v4_name]
        mesh_indices[v4_name] = builder.add_mesh(f"{v4_name}_Mesh", p, n, u, t, mat_idx=0)

    # Children lists by node index (0..64):
    # Nodes 0..48 preserve exact v3.3 indices!
    # Nodes 49..51: Seated Operator Controls on Carriage_Chassis (Node 1) -> children 61, 62, 63 (hand grip locators)
    # Nodes 52..55: Coupled I -> II Delayed-Release Mechanism on Elevation_Cradle (Node 13)
    # Nodes 56..60: Seated Spellblade Seat, Pelvis, Backrest, Footrest L/R Locators on Carriage_Chassis (Node 1)
    # Node 64: mounted_camera_upper_360 on Upper_Turret_Mount (Node 23)
    children_map = {
        0:  [1, 35, 36],
        1:  [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 56, 57, 58, 59, 60],
        12: [13, 20, 21, 22, 23, 32, 33, 37, 52],
        13: [14, 15, 16, 17, 18, 19, 30, 31, 38, 53, 54, 55],
        23: [24, 25, 26, 27, 28, 29, 34, 64],
        49: [61],
        50: [62],
        51: [63],
    }

    builder.add_node("BiBye_Root", translation=[0.0, 0.0, 0.0], rotation=[0.0, 0.0, 0.0, 1.0], children=children_map[0])

    pose0 = build_bibye_v3_pose()
    for idx_off, name in enumerate(ORDERED_NODES[:29]):
        n_idx = idx_off + 1
        tr0, rt0, sc0 = pose0[n_idx]
        ch = children_map.get(n_idx, None)
        builder.add_node(name, mesh_idx=mesh_indices[name], translation=tr0, rotation=rt0, children=ch)
        builder.nodes[n_idx]["scale"] = [float(x) for x in sc0]

    for loc_name, loc_info in LOCATORS.items():
        n_idx = builder.add_node(loc_name, translation=loc_info["translation"], rotation=loc_info["rotation"])
        builder.nodes[n_idx]["extras"] = {
            "role": "castleward_bibyellista_locator",
            "parent": loc_info["parent"],
            "worldTranslationAtRest": loc_info["world_translation"],
            "description": loc_info["description"]
        }

    for dmg_name, intact_name, intact_idx, dmg_idx, piv_xyz in DAMAGED_SUBSYSTEM_NODES:
        tr0, rt0, sc0 = pose0[dmg_idx]
        n_idx = builder.add_node(dmg_name, mesh_idx=mesh_indices[dmg_name], translation=tr0, rotation=rt0)
        assert n_idx == dmg_idx, f"Expected node index {dmg_idx} for {dmg_name}, got {n_idx}"
        builder.nodes[n_idx]["scale"] = [float(x) for x in sc0]
        builder.nodes[n_idx]["extras"] = {
            "role": "castleward_bibyellista_damaged_subsystem",
            "intactCounterpartNode": intact_name,
            "intactCounterpartNodeIndex": intact_idx,
            "parent": "Carriage_Chassis",
            "pivotCarriageSpace": piv_xyz,
        }

    # Add Nodes 49..55: v4.0 Controls & Coupled Delay Mechanism Nodes
    for v4_name, v4_parent, v4_pidx, v4_idx, v4_piv in V4_MECHANISM_NODES:
        tr0, rt0, sc0 = pose0[v4_idx]
        ch = children_map.get(v4_idx, None)
        n_idx = builder.add_node(v4_name, mesh_idx=mesh_indices[v4_name], translation=tr0, rotation=rt0, children=ch)
        assert n_idx == v4_idx, f"Expected node index {v4_idx} for {v4_name}, got {n_idx}"
        builder.nodes[n_idx]["scale"] = [float(x) for x in sc0]
        builder.nodes[n_idx]["extras"] = {
            "role": "castleward_bibyellista_v4_mechanism",
            "parent": v4_parent,
            "parentNodeIndex": v4_pidx,
            "pivotCarriageSpace": v4_piv,
        }

    # Add Nodes 56..64: Seated Operator & 360-Deg Upper Camera Locators
    for loc_name, loc_info in V4_SEATED_OPERATOR_LOCATORS.items():
        n_idx = builder.add_node(loc_name, translation=loc_info["translation"], rotation=loc_info["rotation"])
        assert n_idx == loc_info["node_index"], f"Expected locator index {loc_info['node_index']}, got {n_idx}"
        builder.nodes[n_idx]["extras"] = {
            "role": "castleward_bibyellista_seated_operator_locator",
            "parent": loc_info["parent"],
            "parentNodeIndex": loc_info["parent_idx"],
            "spellbladeRigBone": loc_info["spellblade_bone"],
            "worldTranslationAtRest": loc_info["world_translation"],
            "description": loc_info["description"],
        }

    scale_nodes = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 19, 29, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48}
    for clip_name, kf_list, target_nodes in clips:
        times = [t for (t, _) in kf_list]
        tracks = {}
        for n_idx in target_nodes:
            tr_dict = {
                "translation": [pose[n_idx][0] for (_, pose) in kf_list],
                "rotation":    [pose[n_idx][1] for (_, pose) in kf_list],
            }
            if n_idx in scale_nodes:
                tr_dict["scale"] = [pose[n_idx][2] for (_, pose) in kf_list]
            tracks[n_idx] = tr_dict
        builder.add_animation_with_scale(clip_name, times, tracks, extras=ANIMATION_EVENTS[clip_name])

    extras = {
        "assetId": "bi-bye-llista",
        "version": "4.1",
        "scaleFactor": SCALE,
        "symmetryCenterOffsetRawX": X0_RAW,
        "pivotsCarriageSpace": PIVOTS,
        "nodeParentMap": NODE_PARENT_NAME,
        "locators": LOCATORS,
        "seatedOperatorSpec": SEATED_OPERATOR_SPEC,
        "coupledFiringSpec": COUPLED_FIRING_SPEC,
        "locomotionSpec": LOCOMOTION_SPEC,
        "aimingSpec": AIMING_SPEC,
        "animationEvents": ANIMATION_EVENTS,
        "projectileHandoff": PROJECTILE_HANDOFF,
        "damageStatesSpec": DAMAGE_STATES_SPEC,
        "subsystemDamageSpec": SUBSYSTEM_DAMAGE_SPEC,
    }
    out_bytes = builder.build_bibye_v32_glb_bytes(extras=extras)
    out_glb_path.write_bytes(out_bytes)
    sha256 = hashlib.sha256(out_bytes).hexdigest()
    print(f"[OK] Exported v4.0 GLB: {out_glb_path} ({len(out_bytes):,} bytes / {len(out_bytes)/1048576:.2f} MB, SHA-256: {sha256})")
    return sha256


def export_bibyellista_v32_blend(meshes_dict, imgs, out_blend_path: Path):
    template_blend = Path(os.environ['SPELLBLADE_TEMPLATE_BLEND']) if 'SPELLBLADE_TEMPLATE_BLEND' in os.environ else ((SCRIPT_DIR / 'Spellblade-production-third-person.blend') if (SCRIPT_DIR / 'Spellblade-production-third-person.blend').exists() else (SCRIPT_DIR / 'Bi_Bye_llista_v4_1_Candidate.blend'))
    bf = blend_io.BlendFile(str(template_blend))

    wheels_left_mesh = mbu.concat_meshes([
        bhg.shift_mesh_to_pivot(meshes_dict[w], [-x for x in PIVOTS[w]]) for w in ("Wheel_FL", "Wheel_ML", "Wheel_RL")
    ])
    wheels_right_mesh = mbu.concat_meshes([
        bhg.shift_mesh_to_pivot(meshes_dict[w], [-x for x in PIVOTS[w]]) for w in ("Wheel_FR", "Wheel_MR", "Wheel_RR")
    ])
    stabs_all_mesh = mbu.concat_meshes([
        bhg.shift_mesh_to_pivot(meshes_dict[s], [-x for x in PIVOTS[s]]) for s in ("Stabilizer_FL", "Stabilizer_FR", "Stabilizer_RL", "Stabilizer_RR")
    ])
    main_strings_and_catch = mbu.concat_meshes([
        meshes_dict["Main_String_L"],
        meshes_dict["Main_String_R"],
        bhg.shift_mesh_to_pivot(meshes_dict["Main_Draw_Catch"], [0.0, +0.035, 0.0]),
    ])
    upper_strings_and_catch = mbu.concat_meshes([
        meshes_dict["Upper_String_L"],
        meshes_dict["Upper_String_R"],
        bhg.shift_mesh_to_pivot(meshes_dict["Upper_Catch_And_Trigger"], [0.0, +0.028, 0.0]),
    ])

    blend_slots = [
        ("OBBreastplate",          "MEBreastplate",          "Carriage_Chassis",        meshes_dict["Carriage_Chassis"],        PIVOTS["Carriage_Chassis"]),
        ("OBBoot.L",               "MEBoot.L",               "Wheels_Left_FL_ML_RL",    wheels_left_mesh,                       [0.0, 0.0, 0.0]),
        ("OBBoot.R",               "MEBoot.R",               "Wheels_Right_FR_MR_RR",   wheels_right_mesh,                      [0.0, 0.0, 0.0]),
        ("OBGreave.L",             "MEGreave.L",             "Stabilizers_FL_FR_RL_RR", stabs_all_mesh,                         [0.0, 0.0, 0.0]),
        ("OBTabardFront",          "METabardFront",          "Traverse_Mount",          meshes_dict["Traverse_Mount"],          PIVOTS["Traverse_Mount"]),
        ("OBTabardBack",           "METabardBack",           "Elevation_Cradle",        meshes_dict["Elevation_Cradle"],        PIVOTS["Elevation_Cradle"]),
        ("OBHeroSword",            "MEHeroSword",            "Main_Limb_L",             meshes_dict["Main_Limb_L"],             PIVOTS["Main_Limb_L"]),
        ("OBHelmetShell",          "MEHelmetShellCanonical", "Main_Limb_R",             meshes_dict["Main_Limb_R"],             PIVOTS["Main_Limb_R"]),
        ("OBPauldron.L",           "MEPauldron.L",           "Main_Strings_And_Catch",  main_strings_and_catch,                 PIVOTS["Main_String_L"]),
        ("OBGreave.R",             "MEGreave.R",             "Main_Siege_Bolt",         meshes_dict["Main_Siege_Bolt"],         PIVOTS["Main_Siege_Bolt"]),
        ("OBPauldron.R",           "MEPauldron.R",           "Winch_Drum_And_Cranks",   meshes_dict["Winch_Drum_And_Cranks"],   PIVOTS["Winch_Drum_And_Cranks"]),
        ("OBSpellbladeReviewFloor","MEPlane",                "Winch_Ratchet_And_Pawl",  meshes_dict["Winch_Ratchet_Gear"],      PIVOTS["Winch_Ratchet_Gear"]),
        ("OBCrest",                "MECrestCanonical",       "Upper_Turret_Mount",      meshes_dict["Upper_Turret_Mount"],      PIVOTS["Upper_Turret_Mount"]),
        ("OBGauntlet.L",           "MEGauntlet.L.001",       "Upper_Limb_L",            meshes_dict["Upper_Limb_L"],            PIVOTS["Upper_Limb_L"]),
        ("OBGauntlet.R",           "MEGauntlet.R.001",       "Upper_Limb_R",            meshes_dict["Upper_Limb_R"],            PIVOTS["Upper_Limb_R"]),
        ("OBHelmetJaw",            "MEHelmetJawCanonical",   "Upper_Strings_And_Catch", upper_strings_and_catch,                PIVOTS["Upper_String_L"]),
        ("OBPalmRune",             "MEPalmRune.001",         "Upper_Conditioning_Bolt", meshes_dict["Upper_Conditioning_Bolt"], PIVOTS["Upper_Conditioning_Bolt"]),
        ("OBVisor",                "MEVisorCanonical",       "Winch_Pawl_And_Lever",    meshes_dict["Winch_Pawl_And_Lever"],    PIVOTS["Winch_Pawl_And_Lever"]),
    ]
    ob_layout = bf.get_layout("Object")
    existing_me_names = {bf.get_id_name(b) for b in bf.blocks if b["code"] == "ME"}
    for old_ob, old_me, new_name, m_tup, pv in blend_slots:
        target_me = old_me if old_me in existing_me_names else f"ME{new_name}"
        target_ob = old_ob if old_me in existing_me_names else f"OB{new_name}"
        bf.replace_mesh(target_me, bhg.TriangleMeshAdapter(m_tup))
        old_me, old_ob = target_me, target_ob
        for b in bf.blocks:
            if b["code"] == "ME" and bf.get_id_name(b) == old_me:
                bhg.set_id_name(b, f"ME{new_name}")
            elif b["code"] == "OB" and bf.get_id_name(b) == old_ob:
                bhg.set_id_name(b, f"OB{new_name}")
                struct.pack_into("<3f", b["payload"], ob_layout["loc"][0], float(pv[0]), float(pv[1]), float(pv[2]))

    ac_blocks = [b for b in bf.blocks if b["code"] == "AC"]
    clip_names = [
        "AC01_BiBye_LoadedIdle",
        "AC02_BiBye_TwoStage_Fire",
        "AC03_BiBye_Spent_Recovery",
        "AC04_BiBye_Mechanical_Reload",
        "AC05_BiBye_Stabilizer_Deploy",
        "AC06_BiBye_Travel_Ready",
        "AC07_BiBye_Stabilizer_Retract",
        "AC08_BiBye_Wheel_Roll_Forward",
        "AC09_BiBye_Mobile_Shot1_Fire",
    ]
    for ac_b, cname in zip(ac_blocks, clip_names):
        bhg.set_id_name(ac_b, cname)

    bf.update_packed_image("IMSpellbladeBanner", imgs[1].resize((512, 512), Image.LANCZOS))
    bf.update_packed_image("IMKitMetalWear",     imgs[0].resize((512, 512), Image.LANCZOS))
    bf.update_packed_image("IMKitMatteWear",     imgs[2].resize((512, 512), Image.LANCZOS))

    n_bytes = bf.save(str(out_blend_path))
    sha256 = hashlib.sha256(out_blend_path.read_bytes()).hexdigest()
    print(f"[OK] Exported v3.2 Blend: {out_blend_path} ({n_bytes:,} bytes / {n_bytes/1048576:.2f} MB, SHA-256: {sha256})")
    return sha256


if __name__ == '__main__':
    import shutil
    meshes_v33, imgs_v33 = build_bibyellista_v32_meshes_and_textures()
    clips_v33 = build_12_animation_clips()
    out_glb   = OUT_DIR / 'Bi_Bye_llista_GameReady_PBR.glb'
    out_blend = OUT_DIR / 'Bi_Bye_llista.blend'
    export_bibyellista_v32_glb(meshes_v33, imgs_v33, clips_v33, out_glb)
    export_bibyellista_v32_blend(meshes_v33, imgs_v33, out_blend)
    shutil.copy2(out_glb,   OUT_DIR / 'Bi_Bye_llista_v4_1_Candidate_PBR.glb')
    shutil.copy2(out_blend, OUT_DIR / 'Bi_Bye_llista_v4_1_Candidate.blend')