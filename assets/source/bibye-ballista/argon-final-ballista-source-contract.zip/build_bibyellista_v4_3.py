#!/usr/bin/env python3
"""
Bi-Bye-llista v4.3 (Substantive v2.5 Whole-Machine Visual Hierarchy Redesign)
=============================================================================
Builds on `build_bibyellista_v4_1.py` (and v4.2's clean low-poly shields/banner & crisp crease normals)
while re-architecting the whole-machine visual hierarchy so the two independent launchers are immediately
distinct and mechanically comprehensible at normal gameplay distance:
  1. Strict Material & Value Discipline Across the 4 Vertical Tiers:
     - Tier 1 (`Carriage_Chassis`, `Wheels`, `Stabilizers`, `Traverse_Mount` Base): Shifted to deep Quarter-Sawn
       Dark Oak (`UV_OAK`) and Blackened Forged Iron (`UV_IRON` / `UV_TIRE`), removing competing bright gold
       (`UV_BRASS`) from wheel cleats, inner rim bands, stabilizer collars/spades, front crossbeams, and side rails.
     - Tier 2 (`Main Launcher II` — `Elevation_Cradle`, `Main_Limb_L/R`, `Main_String_L/R`, `Main_Siege_Bolt`):
       Dominant wide horizontal silhouette with gleaming Honed Silver-Steel Greatsword prods (`UV_BLADE`), swept
       iron-and-brass crossguards, darkened cast-iron torsion drums (`UV_IRON` + `UV_ROPE`), crimson `II` mantlet
       shields, a cantilevered forward heavy-bolt roller trough, a thick 56mm double-ply primary bowstring, and a
       colossal 3.75m barbed steel siege spear-bolt.
     - Open Daylight Sight Window (`Y = 1.88..2.58m`): Removes the diagonal brass clutter struts above the main
       torsion frame so clear daylight separates Launcher II below from Launcher I above!
     - Tier 3 (`Upper Conditioning Launcher I` — `Upper_Turret_Mount`, `Upper_Limb_L/R`, `Upper_String_L/R`,
       `Upper_Conditioning_Bolt`): Distinct Forward-Swept Recurve / Dihedral Arbalest silhouette with Royal
       Crimson limb shrouds (`UV_CRIMSON`), Glowing Arcane-Cyan fuller channels (`UV_CYAN`), upturned brass
       recurve tips (`+55mm` dihedral), an open front Arcane Focusing Fork, and a vivid 1.65m Cyan Conditioning Dart.
     - Tier 4 (`Winch, Reload Tackle & Coupled I -> II Release Train`): Twin haul-back ropes connecting the rear
       windlass drum to the main draw catch, and a high-contrast crimson-and-brass coupled trigger train (`Nodes 52..55`)
       mounted against the dark-iron right sight-arch column.
"""
import sys, os, math, gzip, shutil, hashlib
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
WORK_DIR = HERE
OUT_DIR  = Path(os.environ.get("CASTLEWARD_OUT_DIR", str(HERE)))
sys.path.insert(0, str(WORK_DIR))
sys.path.insert(0, str(OUT_DIR))

os.environ["BIBYE_BASE_GLB"] = str(HERE / "bibye_base_basic_pbr.glb")
os.environ["SPELLBLADE_TEMPLATE_BLEND"] = str(OUT_DIR / "Spellblade-production-third-person.blend")

import build_bibyellista_v4_1 as bb
from build_bibyellista_v4_1 import (
    smt, mbu, bhg,
    UV_OAK, UV_IRON, UV_TIRE, UV_BLADE, UV_BRASS, UV_CRIMSON, UV_CYAN, UV_ROPE,
    WHEEL_RADIUS, WHEEL_HALF_W, WHEEL_X_OFFSET, AXLE_Z_FRONT, AXLE_Z_MID, AXLE_Z_REAR,
    MAIN_LIMB_ROOT_X, MAIN_LIMB_ROOT_Y, MAIN_LIMB_ROOT_Z, MAIN_LIMB_LEN, MAIN_TIP_OVERHANG, MAIN_BASE_SWEEP, MAIN_STR_LEN, MAIN_BOLT_LEN,
    UPPER_LIMB_ROOT_X, UPPER_LIMB_ROOT_Y, UPPER_LIMB_ROOT_Z, UPPER_LIMB_LEN, UPPER_TIP_OVERHANG, UPPER_BASE_SWEEP, UPPER_STR_LEN, UPPER_BOLT_LEN,
    PIVOTS,
)

_orig_smooth_box = bb.smooth_box
def smooth_box_crisp(bmin, bmax, bevel=0.014, uv_center=UV_OAK, crease_deg=16.0):
    return _orig_smooth_box(bmin, bmax, bevel=bevel, uv_center=uv_center, crease_deg=crease_deg)

bb.smooth_box = smooth_box_crisp

# 1. Grounded Dark-Oak & Blackened-Iron Siege Wheel (`make_v32_siege_wheel_mesh`)
#    Removes bright gold from the inner rim band and tire cleats so the wheels ground the lower carriage!
def make_v43_siege_wheel_mesh(side_sign: float):
    parts = []
    w_half = 0.132
    rim_profile = [
        (-w_half * 0.88, 0.402, UV_IRON),
        (-w_half * 0.96, 0.418, UV_OAK),
        (-w_half * 0.98, 0.512, UV_OAK),
        (-w_half * 1.00, 0.518, UV_TIRE),
        (-w_half * 0.86, 0.545, UV_TIRE),
        ( 0.000,         0.550, UV_TIRE),
        (+w_half * 0.86, 0.545, UV_TIRE),
        (+w_half * 1.00, 0.518, UV_TIRE),
        (+w_half * 0.98, 0.512, UV_OAK),
        (+w_half * 0.96, 0.418, UV_OAK),
        (+w_half * 0.88, 0.402, UV_IRON),
    ]
    parts.append(smt.make_lathe_mesh(rim_profile, axis='x', segs=24, crease_deg=23.5))

    hub_pts = [
        (-0.155, 0.000, UV_IRON),
        (-0.155, 0.235, UV_IRON),
        (-0.125, 0.235, UV_IRON),
        (-0.120, 0.172, UV_BRASS),
        (-0.080, 0.172, UV_OAK),
        (+0.085, 0.172, UV_OAK),
        (+0.120, 0.158, UV_BRASS),
        (+0.155, 0.132, UV_IRON),
        (+0.188, 0.092, UV_IRON),
        (+0.192, 0.000, UV_BRASS),
    ]
    hp, hn, hu, ht = smt.make_lathe_mesh(hub_pts, axis='x', segs=18, crease_deg=23.5)
    if side_sign < 0:
        hp = hp.copy(); hp[:, 0] *= -1.0
        hn = hn.copy(); hn[:, 0] *= -1.0
        ht = ht[:, [0, 2, 1]].copy()
    parts.append((hp, hn, hu, ht))

    for k in range(8):
        ang = k * (math.pi / 4.0)
        ca, sa = math.cos(ang), math.sin(ang)
        R_rot = np.array([[1.0, 0.0, 0.0], [0.0, ca, -sa], [0.0, sa, ca]], dtype=np.float32)
        sp_path  = [[0.0, 0.140, 0.0], [0.0, 0.195, 0.0], [0.0, 0.365, 0.0], [0.0, 0.412, 0.0]]
        sp_radii = [(0.058, 0.044), (0.052, 0.038), (0.040, 0.030), (0.048, 0.036)]
        sp_mesh  = smt.make_swept_octagonal_beam(sp_path, sp_radii, UV_OAK, crease_deg=16.0)
        ferrule_base = smt.make_lathe_mesh([(0.148, 0.056, UV_IRON), (0.188, 0.052, UV_IRON)], axis='y', segs=12, crease_deg=23.5)
        ferrule_rim  = smt.make_lathe_mesh([(0.375, 0.046, UV_IRON), (0.408, 0.050, UV_IRON)], axis='y', segs=12, crease_deg=23.5)
        cleat = smooth_box_crisp([-w_half * 0.86, 0.538, -0.026], [+w_half * 0.86, 0.556, +0.026], bevel=0.006, uv_center=UV_TIRE, crease_deg=16.0)
        for p_m, n_m, u_m, t_m in (sp_mesh, ferrule_base, ferrule_rim, cleat):
            parts.append((p_m @ R_rot.T, n_m @ R_rot.T, u_m, t_m))

    return mbu.concat_meshes(parts)


# 2. Grounded Dark-Oak & Blackened-Iron Outrigger Stabilizer (`make_v32_stabilizer_mesh`)
def make_v43_stabilizer_mesh(side_sign: float):
    s = float(side_sign)
    parts = [
        smt.make_lathe_mesh([
            (-0.14, 0.000, UV_IRON), (-0.14, 0.068, UV_IRON),
            (-0.11, 0.088, UV_IRON), (+0.11, 0.088, UV_IRON),
            (+0.14, 0.068, UV_IRON), (+0.14, 0.000, UV_IRON),
        ], axis='z', center=(0.0, 0.0, 0.0), segs=16, crease_deg=23.5),
        smt.make_swept_octagonal_beam(
            [[0.0, 0.0, 0.0], [s * 0.24, -0.25, 0.0], [s * 0.52, -0.55, 0.0], [s * 0.70, -0.75, 0.0]],
            [(0.078, 0.068), (0.072, 0.064), (0.064, 0.056), (0.058, 0.052)],
            UV_OAK, crease_deg=16.0
        ),
        smt.make_swept_octagonal_beam(
            [[s * 0.30, -0.32, 0.0], [s * 0.42, -0.44, 0.0]],
            [(0.078, 0.070), (0.074, 0.066)],
            UV_IRON, crease_deg=16.0
        ),
        smt.make_swept_octagonal_beam(
            [[-s * 0.04, -0.22, 0.0], [s * 0.24, -0.41, 0.0], [s * 0.52, -0.60, 0.0]],
            [(0.036, 0.036), (0.044, 0.044), (0.036, 0.036)],
            UV_IRON, crease_deg=16.0
        ),
        smt.make_lathe_mesh([
            (-0.820, 0.000, UV_TIRE),
            (-0.820, 0.215, UV_TIRE),
            (-0.795, 0.225, UV_IRON),
            (-0.768, 0.195, UV_IRON),
            (-0.745, 0.115, UV_BRASS),
            (-0.710, 0.075, UV_IRON),
            (-0.710, 0.000, UV_IRON),
        ], axis='y', center=(s * 0.710, 0.0, 0.0), segs=18, crease_deg=23.5),
    ]
    return mbu.concat_meshes(parts)


# 3. Distinct Sword-Limb Builders for Main Heavy Launcher II vs. Upper Conditioning Launcher I!
def make_v43_distinct_sword_limb_mesh(side_sign: float, limb_len: float, tip_overhang: float, base_sweep_deg: float, is_upper: bool = False):
    """
    Substantive v2.5 Visual Hierarchy Differentiation between Launcher II and Launcher I:
      - `is_upper = False` (`Main_Limb_L/R`, Stage II Heavy Siege Launcher):
        * Colossal, broad, horizontal Double-Edged Greatsword Prod (`0.48 m` root chord, `0.42 m` vertical depth)
          dominated by gleaming Honed Silver-Steel (`UV_BLADE`) cutting bevels and a deep Blackened-Iron Blood-Fuller
          (`UV_IRON`) with a narrow brass fuller inlay.
        * Massive Swept Forged-Iron & Brass Greatsword Crossguard (`Quillons`) at the torsion root (`X = ±0.88 m`).
        * Darkened Spring-Steel Backer Leaves (`UV_IRON`) clamped by only 2 heavy iron-and-brass keeper collars so
          the gleaming silver-steel greatsword silhouette dominates without golden block clutter!
      - `is_upper = True` (`Upper_Limb_L/R`, Stage I Conditioning Arbalest):
        * Distinct Forward-Swept Recurve / Dihedral Arcane Arbalest Limb (`+0.058 m` upward dihedral curve toward the tip!)
          with a Royal Crimson Enamel Root Shroud (`UV_CRIMSON`), a Glowing Arcane-Cyan Runic Fuller Channel (`UV_CYAN`),
          sleek honed steel bevels (`UV_BLADE`), and an upturned Burnished-Brass Recurve Nock Finial (`UV_BRASS`).
        * Immediately reads from side, front, and 3/4 gameplay views as a lighter, high-velocity arcane conditioning
          launcher rather than a miniature clone of the lower heavy greatsword prod!
    """
    s_sgn = float(side_sign)
    total_len = limb_len + tip_overhang
    ang_rad = math.radians(base_sweep_deg)
    u_x, u_z = s_sgn * math.cos(ang_rad), -math.sin(ang_rad)
    f_x, f_z = s_sgn * math.sin(ang_rad), +math.cos(ang_rad)

    parts = []

    if not is_upper:
        # === PRIMARY HEAVY GREATSWORD PROD (STAGE II) ===
        # 1. Forged-Iron Torsion Socket & Bold Swept Greatsword Crossguard Quillons (`UV_IRON` + `UV_BRASS`)
        parts.append(smt.make_lathe_mesh([
            (-0.23, 0.000, UV_IRON),
            (-0.23, 0.145, UV_IRON),
            (-0.18, 0.162, UV_BRASS),
            (+0.18, 0.162, UV_BRASS),
            (+0.23, 0.145, UV_IRON),
            (+0.23, 0.000, UV_IRON),
        ], axis='y', center=(0.0, 0.0, 0.0), segs=18, crease_deg=23.5))

        # Wide 0.62m Swept Greatsword Crossguard Quillons framing the blade root
        q_p = [
            [0.08 * u_x - 0.28 * f_x, 0.0, 0.08 * u_z - 0.28 * f_z],
            [0.12 * u_x,              0.0, 0.12 * u_z],
            [0.10 * u_x + 0.32 * f_x, 0.0, 0.10 * u_z + 0.32 * f_z],
        ]
        parts.append(smt.make_swept_octagonal_beam(
            q_p, [(0.14, 0.058), (0.22, 0.082), (0.14, 0.058)], UV_BRASS, crease_deg=16.0
        ))
        # Narrowed Forged-Iron Ricasso Bolster (`s = 0.08..0.28m`)
        parts.append(smt.make_swept_octagonal_beam(
            [[0.08 * u_x, 0.0, 0.08 * u_z], [0.28 * u_x, 0.0, 0.28 * u_z]],
            [(0.165, 0.145), (0.155, 0.135)], UV_IRON, crease_deg=16.0
        ))

        # 2. 14-Station Broad Honed Silver-Steel Greatsword Blade (`crease_deg = 14.0`)
        n_st = 14
        s_vals = np.linspace(0.06, total_len, n_st)
        pos_list, uv_list, tris_list = [], [], []

        for i, s_d in enumerate(s_vals):
            u_prog = float((s_d - s_vals[0]) / max(total_len - s_vals[0], 1e-6))
            camber = 0.068 * math.sin(u_prog * math.pi) * (1.0 - 0.22 * u_prog)
            cx = s_d * u_x + camber * f_x
            cz = s_d * u_z + camber * f_z

            if u_prog < 0.74:
                w_f = 0.255 - 0.052 * (u_prog / 0.74)
                h_y = 0.225 - 0.072 * (u_prog / 0.74)
            else:
                u_tip = (u_prog - 0.74) / 0.26
                w_f = 0.203 * max(0.04, 1.0 - u_tip**1.30)
                h_y = 0.153 * max(0.04, 1.0 - u_tip**1.20)

            ring_offsets = [
                (+1.00 * w_f,  0.00 * h_y, UV_BLADE), # 0: Front razor cutting edge (Bright Silver Steel!)
                (+0.34 * w_f, +0.88 * h_y, UV_BLADE), # 1: Upper-front bevel ridge (Bright Silver Steel!)
                (-0.08 * w_f, +0.46 * h_y, UV_IRON if u_prog < 0.74 else UV_BLADE), # 2: Deep dark-iron blood fuller
                (-0.58 * w_f, +0.94 * h_y, UV_BRASS if u_prog < 0.68 else UV_BLADE),# 3: Upper-rear brass fuller rib
                (-0.96 * w_f,  0.00 * h_y, UV_IRON),  # 4: Rear spine back (Dark Forged Iron)
                (-0.58 * w_f, -0.94 * h_y, UV_BRASS if u_prog < 0.68 else UV_BLADE),# 5: Lower-rear brass fuller rib
                (-0.08 * w_f, -0.46 * h_y, UV_IRON if u_prog < 0.74 else UV_BLADE), # 6: Lower dark-iron blood fuller
                (+0.34 * w_f, -0.88 * h_y, UV_BLADE), # 7: Lower-front bevel ridge (Bright Silver Steel!)
            ]
            for k_idx, (df, dy, uv_c) in enumerate(ring_offsets):
                pos_list.append([cx + df * f_x, dy, cz + df * f_z])
                uv_list.append([uv_c[0] + 0.024 * (u_prog - 0.5), uv_c[1] + 0.016 * ((k_idx % 2) - 0.5)])

        n_ring = 8
        for i in range(n_st - 1):
            r0 = i * n_ring
            r1 = (i + 1) * n_ring
            for k in range(n_ring):
                kn = (k + 1) % n_ring
                if s_sgn > 0:
                    tris_list.append([r0 + k, r1 + k, r1 + kn])
                    tris_list.append([r0 + k, r1 + kn, r0 + kn])
                else:
                    tris_list.append([r0 + k, r1 + kn, r1 + k])
                    tris_list.append([r0 + k, r0 + kn, r1 + kn])

        tip_idx = len(pos_list)
        pos_list.append([total_len * u_x, 0.0, total_len * u_z])
        uv_list.append([UV_BLADE[0] + 0.020, UV_BLADE[1]])
        last_r = (n_st - 1) * n_ring
        for k in range(n_ring):
            kn = (k + 1) % n_ring
            if s_sgn > 0:
                tris_list.append([last_r + k, tip_idx, last_r + kn])
            else:
                tris_list.append([last_r + k, last_r + kn, tip_idx])

        parts.append(smt.compute_crease_normals(
            np.array(pos_list, dtype=np.float32),
            np.array(tris_list, dtype=np.int32),
            np.array(uv_list, dtype=np.float32),
            crease_deg=14.0,
        ))

        # 3. Darkened Spring-Steel Backer Leaves (`UV_IRON`) & 2 Restrained Keeper Collars (at 0.28 and 0.56)
        for leaf_len_frac, leaf_off_f in [(0.56, -0.155), (0.36, -0.195)]:
            s_end = limb_len * leaf_len_frac
            l_pts, l_rad = [], []
            for u_l in np.linspace(0.10, 1.0, 5):
                sd = s_end * u_l
                u_p = float(sd / total_len)
                cam = 0.068 * math.sin(u_p * math.pi) * (1.0 - 0.22 * u_p) + leaf_off_f
                l_pts.append([sd * u_x + cam * f_x, 0.0, sd * u_z + cam * f_z])
                l_rad.append((0.034, 0.148 * (1.0 - 0.22 * u_l)))
            parts.append(smt.make_swept_octagonal_beam(l_pts, l_rad, UV_IRON, crease_deg=16.0))

        for clamp_frac, uv_cl in ((0.28, UV_IRON), (0.56, UV_BRASS)):
            sd = limb_len * clamp_frac
            u_p = float(sd / total_len)
            cam = 0.068 * math.sin(u_p * math.pi) * (1.0 - 0.22 * u_p)
            cx, cz = sd * u_x + cam * f_x, sd * u_z + cam * f_z
            tap = 1.0 - 0.26 * clamp_frac
            c_pts = [
                [cx - 0.21 * tap * f_x, 0.0, cz - 0.21 * tap * f_z],
                [cx + 0.08 * tap * f_x, 0.0, cz + 0.08 * tap * f_z],
            ]
            parts.append(smt.make_swept_octagonal_beam(
                c_pts, [(0.032, 0.235 * tap), (0.028, 0.225 * tap)], uv_cl, crease_deg=16.0
            ))

        # 4. Heavy Forged-Iron & Brass Nock Shackle at exact `s = limb_len` (`Y = 0.0`)
        nx, nz = limb_len * u_x, limb_len * u_z
        parts.append(smt.make_lathe_mesh([
            (-0.085, 0.000, UV_IRON),
            (-0.085, 0.056, UV_IRON),
            ( 0.000, 0.066, UV_BRASS),
            (+0.085, 0.056, UV_IRON),
            (+0.085, 0.000, UV_IRON),
        ], axis='y', center=(nx, 0.0, nz), segs=14, crease_deg=23.5))

    else:
        # === UPPER CONDITIONING LAUNCHER LIMB (STAGE I — SWEPT RECURVE ARCANE ARBALEST) ===
        # Visually distinct from the lower straight greatsword prods:
        #   - Royal Crimson Enamel Root Shroud (`UV_CRIMSON`) & Swept Wing-Guard (`s = 0.0..0.28m`)
        #   - Graceful Forward-Swept Recurve S-Curve in XZ with Glowing Arcane-Cyan Fuller (`UV_CYAN`)
        #   - Upturned Brass Recurve Tip Finial while keeping the string nock at exact `(limb_len * u_x, 0.0, limb_len * u_z)`!
        parts.append(smt.make_lathe_mesh([
            (-0.115, 0.000, UV_CRIMSON),
            (-0.115, 0.078, UV_CRIMSON),
            (-0.085, 0.086, UV_BRASS),
            (+0.085, 0.086, UV_BRASS),
            (+0.115, 0.078, UV_CRIMSON),
            (+0.115, 0.000, UV_CRIMSON),
        ], axis='y', center=(0.0, 0.0, 0.0), segs=16, crease_deg=23.5))

        # Crimson & Brass Swept Winged Limb Shroud at the root (`s = 0.04..0.32m`)
        shroud_pts = [
            [0.04 * u_x,               0.0, 0.04 * u_z],
            [0.18 * u_x + 0.065 * f_x, 0.0, 0.18 * u_z + 0.065 * f_z],
            [0.32 * u_x + 0.035 * f_x, 0.0, 0.32 * u_z + 0.035 * f_z],
        ]
        parts.append(smt.make_swept_octagonal_beam(
            shroud_pts, [(0.085, 0.095), (0.072, 0.082), (0.048, 0.056)], UV_CRIMSON, crease_deg=16.0
        ))

        n_st = 14
        s_vals = np.linspace(0.04, total_len, n_st)
        pos_list, uv_list, tris_list = [], [], []
        for i, s_d in enumerate(s_vals):
            u_prog = float((s_d - s_vals[0]) / max(total_len - s_vals[0], 1e-6))
            # S-shaped recurve camber: arches forward (+f) in inner half, sweeps forward again at recurve tip,
            # while passing through 0.0 camber at `s_d = limb_len` so the string nock aligns with `solve_bow_linkage`!
            u_nock = float((limb_len - s_vals[0]) / max(total_len - s_vals[0], 1e-6))
            camber = 0.052 * math.sin(math.pi * (u_prog / u_nock))
            # Slight upward dihedral flair on the outer overhang (`s_d > limb_len`)
            y_dihedral = 0.048 * max(0.0, (u_prog - u_nock) / (1.0 - u_nock)) ** 1.3
            cx = s_d * u_x + camber * f_x
            cz = s_d * u_z + camber * f_z

            w_f = (0.118 - 0.045 * u_prog) if u_prog < 0.78 else 0.073 * max(0.05, 1.0 - ((u_prog - 0.78)/0.22)**1.2)
            h_y = (0.096 - 0.036 * u_prog) if u_prog < 0.78 else 0.060 * max(0.05, 1.0 - ((u_prog - 0.78)/0.22)**1.2)

            ring_offsets = [
                (+1.00 * w_f, y_dihedral + 0.00 * h_y, UV_BLADE),
                (+0.32 * w_f, y_dihedral + 0.85 * h_y, UV_BLADE),
                (-0.08 * w_f, y_dihedral + 0.45 * h_y, UV_CYAN if u_prog < 0.78 else UV_BRASS),
                (-0.60 * w_f, y_dihedral + 0.90 * h_y, UV_CRIMSON if u_prog < 0.55 else UV_BRASS),
                (-0.95 * w_f, y_dihedral + 0.00 * h_y, UV_IRON),
                (-0.60 * w_f, y_dihedral - 0.90 * h_y, UV_CRIMSON if u_prog < 0.55 else UV_BRASS),
                (-0.08 * w_f, y_dihedral - 0.45 * h_y, UV_CYAN if u_prog < 0.78 else UV_BRASS),
                (+0.32 * w_f, y_dihedral - 0.85 * h_y, UV_BLADE),
            ]
            for k_idx, (df, dy, uv_c) in enumerate(ring_offsets):
                pos_list.append([cx + df * f_x, dy, cz + df * f_z])
                uv_list.append([uv_c[0] + 0.020 * (u_prog - 0.5), uv_c[1] + 0.014 * ((k_idx % 2) - 0.5)])

        n_ring = 8
        for i in range(n_st - 1):
            r0 = i * n_ring
            r1 = (i + 1) * n_ring
            for k in range(n_ring):
                kn = (k + 1) % n_ring
                if s_sgn > 0:
                    tris_list.append([r0 + k, r1 + k, r1 + kn])
                    tris_list.append([r0 + k, r1 + kn, r0 + kn])
                else:
                    tris_list.append([r0 + k, r1 + kn, r1 + k])
                    tris_list.append([r0 + k, r0 + kn, r1 + kn])

        tip_idx = len(pos_list)
        pos_list.append([total_len * u_x + 0.035 * f_x, +0.052, total_len * u_z + 0.035 * f_z])
        uv_list.append([UV_BRASS[0], UV_BRASS[1]])
        last_r = (n_st - 1) * n_ring
        for k in range(n_ring):
            kn = (k + 1) % n_ring
            if s_sgn > 0:
                tris_list.append([last_r + k, tip_idx, last_r + kn])
            else:
                tris_list.append([last_r + k, last_r + kn, tip_idx])

        parts.append(smt.compute_crease_normals(
            np.array(pos_list, dtype=np.float32),
            np.array(tris_list, dtype=np.int32),
            np.array(uv_list, dtype=np.float32),
            crease_deg=14.0,
        ))

        nx, nz = limb_len * u_x, limb_len * u_z
        parts.append(smt.make_lathe_mesh([
            (-0.045, 0.000, UV_BRASS),
            (-0.045, 0.032, UV_BRASS),
            ( 0.000, 0.038, UV_CYAN),
            (+0.045, 0.032, UV_BRASS),
            (+0.045, 0.000, UV_BRASS),
        ], axis='y', center=(nx, 0.0, nz), segs=14, crease_deg=23.5))

    return mbu.concat_meshes(parts)


# 4. Higher-Contrast Bowstrings & Bolts (`make_v32_bowstring_half_mesh`, `make_v32_siege_bolt_mesh`, `bb2_make_catch`)
def make_v43_bowstring_half_mesh(side_sign: float, str_len: float, is_upper: bool = False):
    s_sgn = float(side_sign)
    r_rope = 0.016 if is_upper else 0.030  # Thicker, unmistakable siege cable on Main Launcher II!
    x_end = s_sgn * str_len
    pts = [
        [0.0, 0.0, 0.0],
        [s_sgn * 0.16 * str_len, 0.0, 0.0],
        [s_sgn * 0.84 * str_len, 0.0, 0.0],
        [x_end, 0.0, 0.0],
    ]
    rads = [
        (r_rope * 1.45, r_rope * 1.45),
        (r_rope,        r_rope),
        (r_rope,        r_rope),
        (r_rope * 1.40, r_rope * 1.40),
    ]
    rope_body = smt.make_swept_octagonal_beam(pts, rads, UV_ROPE, crease_deg=28.0)
    # Center leather/crimson whipping collar & outer forged-iron/brass nock shackle
    serving = smt.make_swept_octagonal_beam(
        [[0.0, 0.0, 0.0], [s_sgn * 0.14 * str_len, 0.0, 0.0]],
        [(r_rope * 1.55, r_rope * 1.55), (r_rope * 1.35, r_rope * 1.35)],
        UV_CRIMSON if is_upper else UV_IRON, crease_deg=22.0
    )
    eyelet = smt.make_lathe_mesh([
        (-r_rope * 1.6, 0.000, UV_BRASS),
        (-r_rope * 1.6, r_rope * 2.1, UV_BRASS),
        (+r_rope * 1.6, r_rope * 2.1, UV_BRASS),
        (+r_rope * 1.6, 0.000, UV_BRASS),
    ], axis='y', center=(x_end, 0.0, 0.0), segs=14, crease_deg=23.5)
    return mbu.concat_meshes([rope_body, serving, eyelet])


def make_v43_siege_bolt_mesh(is_upper: bool = False):
    L = UPPER_BOLT_LEN if is_upper else MAIN_BOLT_LEN
    r_sh = 0.022 if is_upper else 0.044
    uv_head   = UV_CYAN if is_upper else UV_BLADE
    uv_fletch = UV_CYAN if is_upper else UV_CRIMSON
    uv_shaft  = UV_CRIMSON if is_upper else UV_OAK

    shaft_prof = [
        (0.000,        0.000,        UV_BRASS),
        (0.005,        r_sh * 1.35,  UV_BRASS),
        (0.075,        r_sh * 1.15,  UV_BRASS),
        (0.080,        r_sh,         uv_shaft),
        (L * 0.76,     r_sh,         uv_shaft),
        (L * 0.80,     r_sh * 1.45,  UV_BRASS if is_upper else UV_IRON),
        (L * 0.83,     r_sh * 1.05,  UV_IRON),
        (L * 0.88,     r_sh * 2.85,  uv_head),
        (L * 0.95,     r_sh * 1.30,  uv_head),
        (L,            0.000,        uv_head),
    ]
    parts = [smt.make_lathe_mesh(shaft_prof, axis='z', segs=18, crease_deg=23.5)]

    for k in range(4):
        ang = k * (math.pi * 0.5) + (math.pi * 0.25)
        ca, sa = math.cos(ang), math.sin(ang)
        R_z = np.array([[ca, -sa, 0.0], [sa, ca, 0.0], [0.0, 0.0, 1.0]], dtype=np.float32)

        v_pts = [
            [0.0, r_sh * 0.9, 0.07 * L],
            [0.0, r_sh * 3.4, 0.13 * L],
            [0.0, r_sh * 2.4, 0.27 * L],
            [0.0, r_sh * 0.8, 0.31 * L],
        ]
        v_rads = [(r_sh * 0.4, 0.006), (r_sh * 1.2, 0.008), (r_sh * 0.9, 0.008), (r_sh * 0.3, 0.005)]
        vane = smt.make_swept_octagonal_beam(v_pts, v_rads, uv_fletch, crease_deg=16.0)

        b_pts = [
            [0.0, r_sh * 0.8, 0.82 * L],
            [0.0, r_sh * 3.5, 0.88 * L],
            [0.0, r_sh * 1.6, 0.95 * L],
            [0.0, r_sh * 0.2, 0.99 * L],
        ]
        b_rads = [(r_sh * 0.35, 0.007), (r_sh * 1.25, 0.009), (r_sh * 0.7, 0.007), (r_sh * 0.2, 0.004)]
        barb = smt.make_swept_octagonal_beam(b_pts, b_rads, uv_head, crease_deg=16.0)

        for pm, nm, um, tm in (vane, barb):
            parts.append((pm @ R_z.T, nm @ R_z.T, um, tm))

    return mbu.concat_meshes(parts)


def make_v43_catch(is_upper: bool = False):
    s = 0.62 if is_upper else 1.15
    parts = [
        # Heavy bronze & crimson housing block with twin forged-steel claw jaws gripping the string!
        smooth_box_crisp([-0.15 * s, -0.06 * s, -0.22 * s], [+0.15 * s, +0.06 * s, +0.12 * s], bevel=0.012 * s, uv_center=UV_CRIMSON if is_upper else UV_IRON),
        smooth_box_crisp([-0.16 * s, -0.02 * s, -0.14 * s], [+0.16 * s, +0.08 * s, +0.06 * s], bevel=0.010 * s, uv_center=UV_BRASS),
        smooth_box_crisp([-0.10 * s, +0.05 * s, -0.07 * s], [-0.03 * s, +0.16 * s, +0.05 * s], bevel=0.008 * s, uv_center=UV_BLADE),
        smooth_box_crisp([+0.03 * s, +0.05 * s, -0.07 * s], [+0.10 * s, +0.16 * s, +0.05 * s], bevel=0.008 * s, uv_center=UV_BLADE),
    ]
    return mbu.concat_meshes(parts)


# 5. Upgraded PBR Texture Swatches for Clear Tier Value Separation
def enhance_bibyellista_pbr_textures_v43(imgs_raw):
    pil_list = bb._orig_enhance_textures(imgs_raw)
    # Darken UV_OAK and UV_IRON slightly and boost UV_BLADE & UV_CYAN contrast on diffuse image (pil_list[1])
    arr_d = np.array(pil_list[1], dtype=np.float32)
    H, W, _ = arr_d.shape
    yy, xx = np.mgrid[0:H, 0:W]

    def tint_swatch(uv_c, radius_px, scale_rgb):
        cx, cy = int(round(uv_c[0]*(W-1))), int(round(uv_c[1]*(H-1)))
        mask = (xx - cx)**2 + (yy - cy)**2 <= radius_px**2
        for c in range(3):
            arr_d[:, :, c][mask] = np.clip(arr_d[:, :, c][mask] * scale_rgb[c], 0, 255)

    tint_swatch(UV_OAK,   50, (0.86, 0.84, 0.82)) # Richer dark seasoned siege oak
    tint_swatch(UV_IRON,  50, (0.82, 0.84, 0.86)) # Deeper blackened charcoal iron
    tint_swatch(UV_BLADE, 50, (1.12, 1.12, 1.14)) # Brighter gleaming honed silver-steel sword limbs
    pil_list[1] = bb.Image.fromarray(arr_d.astype(np.uint8))
    return pil_list


# 6. Full Whole-Machine Hierarchy Assembly (`build_bibyellista_v43_meshes_and_textures`)
def build_bibyellista_v43_meshes_and_textures():
    in_glb = OUT_DIR / "bibye_base_basic_pbr.glb"
    _, _, _, _, _, _, imgs_raw = bhg.load_glb_any(str(in_glb))

    # A. Clean Architectural 3D Front Mantlet Shields (`II`) and Prow Trident Banner (Zero Marching Cubes!)
    def make_crisp_front_mantlet_shields():
        sh_parts = []
        for sx in (-1.0, +1.0):
            cx = sx * 0.815
            # Outer angled forged-iron backing plate (`Y = 1.44..1.86m`, `Z = +1.30..+1.38m`)
            sh_parts.append(smooth_box_crisp([cx - 0.195, 1.44, +1.30], [cx + 0.195, 1.86, +1.36], bevel=0.012, uv_center=UV_IRON))
            # Crimson heraldic shield field (`Y = 1.47..1.83m`, `Z = +1.33..+1.385m`)
            sh_parts.append(smooth_box_crisp([cx - 0.165, 1.47, +1.335], [cx + 0.165, 1.83, +1.385], bevel=0.010, uv_center=UV_CRIMSON))
            # Restrained brass top & bottom shield borders
            sh_parts.append(smooth_box_crisp([cx - 0.185, 1.81, +1.33], [cx + 0.185, 1.86, +1.395], bevel=0.006, uv_center=UV_BRASS))
            sh_parts.append(smooth_box_crisp([cx - 0.175, 1.44, +1.33], [cx + 0.175, 1.49, +1.395], bevel=0.006, uv_center=UV_BRASS))
            # Lower V-point of heater shield (`Y = 1.32..1.46m`)
            sh_parts.append(smt.make_swept_octagonal_beam(
                [[cx - 0.155, 1.46, +1.35], [cx, 1.32, +1.36], [cx + 0.155, 1.46, +1.35]],
                [(0.028, 0.035), (0.036, 0.045), (0.028, 0.035)], UV_BRASS, crease_deg=16.0
            ))
        return mbu.concat_meshes(sh_parts)

    def make_crisp_chassis_prow_banner():
        b_parts = [
            # Crimson cloth banner panel (`X = -0.36..+0.36m, Y = 0.24..0.92m, Z = +1.34..+1.39m`)
            smooth_box_crisp([-0.36, 0.26, +1.34], [+0.36, 0.92, +1.39], bevel=0.010, uv_center=UV_CRIMSON),
            smooth_box_crisp([-0.39, 0.24, +1.33], [-0.34, 0.92, +1.40], bevel=0.006, uv_center=UV_BRASS),
            smooth_box_crisp([+0.34, 0.24, +1.33], [+0.39, 0.92, +1.40], bevel=0.006, uv_center=UV_BRASS),
            # 3D Golden Trident Relief on the front prow banner
            smooth_box_crisp([-0.022, 0.34, +1.375], [+0.022, 0.82, +1.415], bevel=0.004, uv_center=UV_BRASS),
            smooth_box_crisp([-0.145, 0.56, +1.375], [+0.145, 0.60, +1.415], bevel=0.004, uv_center=UV_BRASS),
            smooth_box_crisp([-0.145, 0.58, +1.375], [-0.105, 0.78, +1.415], bevel=0.004, uv_center=UV_BRASS),
            smooth_box_crisp([+0.105, 0.58, +1.375], [+0.145, 0.78, +1.415], bevel=0.004, uv_center=UV_BRASS),
        ]
        return mbu.concat_meshes(b_parts)

    # -------------------------------------------------------------------------
    # TIER 1: Carriage_Chassis (Node 1 — Grounded Dark Oak & Blackened Wrought Iron)
    # -------------------------------------------------------------------------
    carriage_parts = [
        make_crisp_chassis_prow_banner(),
        smt.make_swept_octagonal_beam(
            [[-0.62, 0.72, -2.06], [-0.62, 0.74, -1.60], [-0.62, 0.74, +1.25], [-0.56, 0.78, +1.44]],
            [(0.125, 0.145), (0.135, 0.155), (0.135, 0.155), (0.095, 0.115)],
            UV_OAK, crease_deg=16.0
        ),
        smt.make_swept_octagonal_beam(
            [[+0.62, 0.72, -2.06], [+0.62, 0.74, -1.60], [+0.62, 0.74, +1.25], [+0.56, 0.78, +1.44]],
            [(0.125, 0.145), (0.135, 0.155), (0.135, 0.155), (0.095, 0.115)],
            UV_OAK, crease_deg=16.0
        ),
        smooth_box_crisp([-0.54, 0.76, -1.96], [+0.54, 0.92, +1.34], bevel=0.022, uv_center=UV_OAK),
        # Front & Rear Cross-Beams in Dark Forged Iron (`UV_IRON` instead of noisy gold!)
        smt.make_swept_octagonal_beam(
            [[-0.64, 0.88, +1.32], [0.0, 0.92, +1.34], [+0.64, 0.88, +1.32]],
            [(0.085, 0.095), (0.095, 0.105), (0.085, 0.095)],
            UV_IRON, crease_deg=16.0
        ),
        smt.make_swept_octagonal_beam(
            [[-0.68, 0.70, -2.04], [0.0, 0.70, -2.10], [+0.68, 0.70, -2.04]],
            [(0.090, 0.105), (0.105, 0.115), (0.090, 0.105)],
            UV_IRON, crease_deg=16.0
        ),
        # Side Escutcheon Panels framed in Blackened Forged Iron (`UV_IRON`) with recessed Crimson Heraldry (`UV_CRIMSON`)
        smooth_box_crisp([-0.75, 0.72, -1.12], [-0.68, 1.02, +0.76], bevel=0.016, uv_center=UV_IRON),
        smooth_box_crisp([-0.77, 0.76, -1.04], [-0.73, 0.98, +0.68], bevel=0.010, uv_center=UV_CRIMSON),
        smooth_box_crisp([+0.68, 0.72, -1.12], [+0.75, 1.02, +0.76], bevel=0.016, uv_center=UV_IRON),
        smooth_box_crisp([+0.73, 0.76, -1.04], [+0.77, 0.98, +0.68], bevel=0.010, uv_center=UV_CRIMSON),
        # Lower Turntable Base in Dark Oak & Blackened Iron (`UV_IRON` + `UV_OAK`)
        smt.make_lathe_mesh([
            (0.900, 0.000, UV_IRON),
            (0.900, 0.855, UV_IRON),
            (1.040, 0.850, UV_OAK),
            (1.160, 0.845, UV_IRON),
            (1.215, 0.840, UV_IRON),
            (1.238, 0.825, UV_BRASS),
            (1.238, 0.000, UV_IRON),
        ], axis='y', center=(0.0, 0.0, 0.0), segs=24, crease_deg=23.5),
    ]

    for az in (AXLE_Z_FRONT, AXLE_Z_MID, AXLE_Z_REAR):
        carriage_parts.append(smt.make_lathe_mesh([
            (-0.960, 0.000, UV_IRON),
            (-0.960, 0.072, UV_IRON),
            (-0.840, 0.088, UV_BRASS),
            (-0.820, 0.076, UV_IRON),
            (+0.820, 0.076, UV_IRON),
            (+0.840, 0.088, UV_BRASS),
            (+0.960, 0.072, UV_IRON),
            (+0.960, 0.000, UV_IRON),
        ], axis='x', center=(0.0, WHEEL_RADIUS, az), segs=16, crease_deg=23.5))
        carriage_parts.append(smt.make_swept_octagonal_beam(
            [[-0.82, 0.55, az], [-0.58, 0.66, az], [0.0, 0.70, az], [+0.58, 0.66, az], [+0.82, 0.55, az]],
            [(0.085, 0.095), (0.105, 0.115), (0.115, 0.125), (0.105, 0.115), (0.085, 0.095)],
            UV_OAK, crease_deg=16.0
        ))

    for sx in (-1.0, +1.0):
        for sz in (+1.050, -1.420):
            carriage_parts.append(smt.make_swept_octagonal_beam(
                [[sx * 0.62, 0.78, sz], [sx * 0.92, 0.80, sz], [sx * 1.18, 0.82, sz]],
                [(0.095, 0.110), (0.088, 0.100), (0.080, 0.090)],
                UV_IRON, crease_deg=16.0
            ))
        for az_steer in (AXLE_Z_FRONT, AXLE_Z_REAR):
            carriage_parts.append(smt.make_lathe_mesh([
                (0.435, 0.000, UV_IRON), (0.435, 0.058, UV_IRON),
                (0.665, 0.058, UV_IRON), (0.665, 0.000, UV_IRON),
            ], axis='y', center=(sx * 0.910, 0.0, az_steer), segs=14, crease_deg=23.5))
    carriage_parts.extend(bb.make_v40_cockpit_and_seat_parts())

    # -------------------------------------------------------------------------
    # TIER 2: Traverse_Mount (Node 12 — Clean Open Gothic Sight Portal & Turntable)
    # -------------------------------------------------------------------------
    traverse_parts = [
        # Dark-Iron & Oak Turntable Platform with Restrained Bronze Gear Ring
        smt.make_lathe_mesh([
            (1.235, 0.000, UV_IRON),
            (1.235, 0.855, UV_IRON),
            (1.275, 0.865, UV_BRASS),
            (1.300, 0.780, UV_IRON),
            (1.335, 0.680, UV_OAK),
            (1.335, 0.000, UV_OAK),
        ], axis='y', center=(0.0, 0.0, 0.0), segs=24, crease_deg=23.5),
    ]
    for kt in range(24):
        ang_t = kt * (2.0 * math.pi / 24.0)
        ct, st = math.cos(ang_t), math.sin(ang_t)
        R_yt = np.array([[ct, 0.0, st], [0.0, 1.0, 0.0], [-st, 0.0, ct]], dtype=np.float32)
        tp, tn, tu, tt = smooth_box_crisp([-0.030, 1.240, 0.845], [+0.030, 1.276, 0.884], bevel=0.005, uv_center=UV_BRASS)
        traverse_parts.append((tp @ R_yt.T, tn @ R_yt.T, tu, tt))

    for sx in (-1.0, +1.0):
        traverse_parts.append(smt.make_swept_octagonal_beam(
            [[sx * 0.52, 1.31, +0.46], [sx * 0.48, 1.49, +0.17], [sx * 0.45, 1.62, -0.12]],
            [(0.085, 0.105), (0.082, 0.098), (0.092, 0.110)],
            UV_IRON, crease_deg=16.0
        ))
        traverse_parts.append(smt.make_swept_octagonal_beam(
            [[sx * 0.45, 1.62, -0.12], [sx * 0.43, 1.48, -0.52], [sx * 0.42, 1.44, -0.98]],
            [(0.092, 0.110), (0.082, 0.096), (0.078, 0.088)],
            UV_OAK, crease_deg=16.0
        ))
        traverse_parts.append(smt.make_swept_octagonal_beam(
            [[sx * 0.50, 1.31, -0.40], [sx * 0.42, 1.38, -0.68], [sx * 0.42, 1.44, -0.92]],
            [(0.068, 0.068), (0.064, 0.064), (0.068, 0.068)],
            UV_IRON, crease_deg=16.0
        ))

    traverse_parts.append(smt.make_lathe_mesh([
        (-0.560, 0.000, UV_BRASS),
        (-0.560, 0.095, UV_BRASS),
        (-0.380, 0.108, UV_IRON),
        (+0.380, 0.108, UV_IRON),
        (+0.560, 0.095, UV_BRASS),
        (+0.560, 0.000, UV_BRASS),
    ], axis='x', center=(0.0, 1.620, -0.120), segs=18, crease_deg=23.5))

    # Open, Slender Dark-Iron Gothic Sight Arch (`|X| = 0.38..0.44m`, `UV_IRON`)
    # REMOVES the noisy diagonal forward brass struts so a clean DAYLIGHT WINDOW separates Launcher II and Launcher I!
    for sx in (-1.0, +1.0):
        arch_pts, arch_rads = [], []
        for u_a in np.linspace(0.0, 1.0, 12):
            ya = 1.62 + (2.525 - 1.62) * u_a
            xa = sx * (0.38 + 0.065 * math.sin(u_a * math.pi) - 0.185 * (u_a ** 2.4))
            za = +0.08 + 0.02 * math.sin(u_a * math.pi)
            arch_pts.append([xa, ya, za])
            arch_rads.append((0.044 - 0.006 * u_a, 0.082 - 0.018 * u_a))
        traverse_parts.append(smt.make_swept_octagonal_beam(arch_pts, arch_rads, UV_IRON, crease_deg=16.0))

    # Compact Dark-Iron & Bronze Turret Pedestal Ring at `[0.000, 2.515..2.635, +0.080]`
    traverse_parts.append(smt.make_lathe_mesh([
        (2.515, 0.000, UV_IRON),
        (2.515, 0.255, UV_IRON),
        (2.555, 0.275, UV_BRASS),
        (2.595, 0.255, UV_IRON),
        (2.635, 0.235, UV_BRASS),
        (2.635, 0.000, UV_BRASS),
    ], axis='y', center=(0.0, 0.0, +0.080), segs=22, crease_deg=23.5))

    # Embossed "I -> II" Coupled-Release Instruction Plaque on Right Sight-Arch Column (`X = +0.415m`)
    traverse_parts.extend([
        smooth_box_crisp([+0.385, 1.940, -0.260], [+0.418, 2.120, +0.040], bevel=0.008, uv_center=UV_IRON),
        smooth_box_crisp([+0.412, 1.955, -0.245], [+0.424, 2.105, +0.025], bevel=0.005, uv_center=UV_CRIMSON),
        smooth_box_crisp([+0.420, 1.980, -0.025], [+0.432, 2.080, +0.005], bevel=0.003, uv_center=UV_BRASS),
        smooth_box_crisp([+0.420, 2.022, -0.125], [+0.432, 2.038, -0.045], bevel=0.003, uv_center=UV_BRASS),
        smt.make_swept_octagonal_beam([[+0.426, 2.055, -0.105], [+0.426, 2.030, -0.140], [+0.426, 2.005, -0.105]], [(0.006, 0.008), (0.006, 0.010), (0.006, 0.008)], UV_BRASS, crease_deg=16.0),
        smooth_box_crisp([+0.420, 1.980, -0.185], [+0.432, 2.080, -0.160], bevel=0.003, uv_center=UV_BRASS),
        smooth_box_crisp([+0.420, 1.980, -0.225], [+0.432, 2.080, -0.200], bevel=0.003, uv_center=UV_BRASS),
    ])

    # -------------------------------------------------------------------------
    # TIER 3: Elevation_Cradle (Node 13 — Primary Heavy Siege Launcher II)
    # -------------------------------------------------------------------------
    elev_parts = [
        make_crisp_front_mantlet_shields(),
        # Extended Heavy Dark-Oak Stock (`Z = -1.04..+1.66m`) with Cantilevered Forward Heavy-Bolt Support Trough!
        smt.make_swept_octagonal_beam(
            [[0.0, 1.705, -1.04], [0.0, 1.700, -0.45], [0.0, 1.685, +0.65], [0.0, 1.685, +1.66]],
            [(0.160, 0.085), (0.205, 0.112), (0.215, 0.140), (0.185, 0.125)],
            UV_OAK, crease_deg=16.0
        ),
        # Deep Forged-Iron Heavy-Bolt Guide Channel & Forward Nose Stirrup (`Z = -1.02..+1.64m`)
        smooth_box_crisp([-0.165, 1.775, -1.02], [-0.062, 1.848, +1.64], bevel=0.010, uv_center=UV_IRON),
        smooth_box_crisp([+0.062, 1.775, -1.02], [+0.165, 1.848, +1.64], bevel=0.010, uv_center=UV_IRON),
        smooth_box_crisp([-0.064, 1.768, -1.02], [+0.064, 1.796, +1.64], bevel=0.006, uv_center=UV_IRON),
        # 4 Bronze Heavy-Bolt Support Roller-Saddles along the trough (`Z = -0.35, +0.25, +0.85, +1.48m`)
        smt.make_lathe_mesh([(-0.14, 0.0, UV_BRASS), (-0.14, 0.032, UV_BRASS), (+0.14, 0.032, UV_BRASS), (+0.14, 0.0, UV_BRASS)], axis='x', center=(0.0, 1.798, -0.35), segs=12, crease_deg=23.5),
        smt.make_lathe_mesh([(-0.14, 0.0, UV_BRASS), (-0.14, 0.032, UV_BRASS), (+0.14, 0.032, UV_BRASS), (+0.14, 0.0, UV_BRASS)], axis='x', center=(0.0, 1.798, +0.25), segs=12, crease_deg=23.5),
        smt.make_lathe_mesh([(-0.14, 0.0, UV_BRASS), (-0.14, 0.032, UV_BRASS), (+0.14, 0.032, UV_BRASS), (+0.14, 0.0, UV_BRASS)], axis='x', center=(0.0, 1.798, +0.85), segs=12, crease_deg=23.5),
        smt.make_lathe_mesh([(-0.16, 0.0, UV_BRASS), (-0.16, 0.038, UV_BRASS), (+0.16, 0.038, UV_BRASS), (+0.16, 0.0, UV_BRASS)], axis='x', center=(0.0, 1.798, +1.52), segs=12, crease_deg=23.5),
        # Forward Armored Muzzle Stirrup Clevis (`Z = +1.50..+1.66m`) cradling the heavy siege bolt shaft
        smooth_box_crisp([-0.205, 1.62, +1.48], [+0.205, 1.855, +1.64], bevel=0.012, uv_center=UV_IRON),
        # Twin Haul-Back Winch Tackle Ropes (`UV_ROPE`) running from the rear winch drum along the stock to Main_Draw_Catch!
        smt.make_swept_octagonal_beam([[-0.185, 1.64, -0.92], [-0.125, 1.78, -0.74]], [(0.020, 0.020), (0.020, 0.020)], UV_ROPE, crease_deg=24.0),
        smt.make_swept_octagonal_beam([[+0.185, 1.64, -0.92], [+0.125, 1.78, -0.74]], [(0.020, 0.020), (0.020, 0.020)], UV_ROPE, crease_deg=24.0),
        # Massive Blackened Cast-Iron Torsion Crossbeam (`UV_IRON`) connecting Stock to Main Limb Drums
        smt.make_swept_octagonal_beam(
            [[-0.96, 1.76, +0.92], [-0.48, 1.72, +0.96], [0.0, 1.70, +1.00], [+0.48, 1.72, +0.96], [+0.96, 1.76, +0.92]],
            [(0.195, 0.175), (0.175, 0.162), (0.185, 0.168), (0.175, 0.162), (0.195, 0.175)],
            UV_IRON, crease_deg=16.0
        ),
        # Embossed Brass Roman Numeral II Plaques on Front Crimson Mantlet Shields
        smooth_box_crisp([-0.875, 1.54, +1.365], [-0.835, 1.78, +1.420], bevel=0.006, uv_center=UV_BRASS),
        smooth_box_crisp([-0.795, 1.54, +1.365], [-0.755, 1.78, +1.420], bevel=0.006, uv_center=UV_BRASS),
        smooth_box_crisp([+0.755, 1.54, +1.365], [+0.795, 1.78, +1.420], bevel=0.006, uv_center=UV_BRASS),
        smooth_box_crisp([+0.835, 1.54, +1.365], [+0.875, 1.78, +1.420], bevel=0.006, uv_center=UV_BRASS),
    ]

    # Blackened Cast-Iron Torsion Drums with Wound Hemp Rope Skeins & Narrow Bronze End Caps (instead of all-gold drums!)
    for sx in (-1.0, +1.0):
        elev_parts.append(smt.make_lathe_mesh([
            (1.470, 0.000, UV_IRON),
            (1.470, 0.245, UV_IRON),
            (1.520, 0.260, UV_BRASS),
            (1.550, 0.225, UV_IRON),
            (1.650, 0.215, UV_ROPE),
            (1.950, 0.215, UV_ROPE),
            (2.050, 0.225, UV_IRON),
            (2.080, 0.260, UV_BRASS),
            (2.130, 0.245, UV_IRON),
            (2.130, 0.000, UV_IRON),
        ], axis='y', center=(sx * MAIN_LIMB_ROOT_X, 0.0, MAIN_LIMB_ROOT_Z), segs=20, crease_deg=23.5))
        elev_parts.append(smt.make_swept_octagonal_beam(
            [[sx * 0.34, 1.62, -0.52], [sx * 0.35, 1.62, -0.12], [sx * 0.35, 1.68, +0.48], [sx * 0.40, 1.74, +0.88]],
            [(0.060, 0.105), (0.068, 0.135), (0.068, 0.130), (0.072, 0.125)],
            UV_OAK, crease_deg=16.0
        ))

    # -------------------------------------------------------------------------
    # TIER 4: Upper_Turret_Mount (Node 23 — Distinct Crimson & Arcane-Cyan Conditioning Launcher I)
    # -------------------------------------------------------------------------
    upper_turret_parts = [
        # Sleek Blackened-Iron & Crimson Swivel Pedestal (`Y = 2.635..2.715m`)
        smt.make_lathe_mesh([
            (2.635, 0.000, UV_IRON),
            (2.635, 0.235, UV_IRON),
            (2.675, 0.215, UV_CRIMSON),
            (2.715, 0.175, UV_IRON),
            (2.715, 0.000, UV_IRON),
        ], axis='y', center=(0.0, 0.0, +0.080), segs=20, crease_deg=23.5),
        # Open Swan-Neck Trunnion Yoke Arms rising to `Y = 2.780..2.860m`
        smt.make_swept_octagonal_beam(
            [[-0.145, 2.680, +0.060], [-0.135, 2.780, +0.080], [-0.115, 2.855, +0.100]],
            [(0.034, 0.045), (0.040, 0.052), (0.032, 0.042)],
            UV_IRON, crease_deg=16.0
        ),
        smt.make_swept_octagonal_beam(
            [[+0.145, 2.680, +0.060], [+0.135, 2.780, +0.080], [+0.115, 2.855, +0.100]],
            [(0.034, 0.045), (0.040, 0.052), (0.032, 0.042)],
            UV_IRON, crease_deg=16.0
        ),
        # Rear Mechanical Coupling Dog-Lug & Crimson/Brass Upper Sear Trip-Finger (`Z = -0.180..-0.620m`)
        smooth_box_crisp([-0.058, 2.605, -0.228], [+0.058, 2.680, -0.132], bevel=0.008, uv_center=UV_CRIMSON),
        smt.make_swept_octagonal_beam(
            [[0.0, 2.885, -0.620], [0.0, 2.755, -0.350], [0.0, 2.625, -0.180]],
            [(0.024, 0.024), (0.026, 0.026), (0.030, 0.030)],
            UV_BRASS, crease_deg=16.0
        ),
        # Crimson-Lacquered & Dark-Iron Conditioning Arbalest Stock (`Y = 2.82..2.91m, Z = -0.68..+0.96m`)
        smt.make_swept_octagonal_beam(
            [[0.0, 2.845, -0.68], [0.0, 2.855, +0.10], [0.0, 2.855, +0.96]],
            [(0.082, 0.054), (0.098, 0.062), (0.082, 0.054)],
            UV_CRIMSON, crease_deg=16.0
        ),
        smooth_box_crisp([-0.088, 2.898, -0.66], [-0.032, 2.948, +0.94], bevel=0.006, uv_center=UV_IRON),
        smooth_box_crisp([+0.032, 2.898, -0.66], [+0.088, 2.948, +0.94], bevel=0.006, uv_center=UV_IRON),
        # Glowing Cyan Runic Guide Strip down the center of the Upper Conditioning Trough (`Z = -0.64..+0.92m`)
        smooth_box_crisp([-0.024, 2.895, -0.64], [+0.024, 2.918, +0.92], bevel=0.004, uv_center=UV_CYAN),
        # Forward Arcane Focusing Fork at the Upper Muzzle (`Z = +0.84..+0.96m`)
        smt.make_swept_octagonal_beam([[-0.085, 2.91, +0.88], [-0.125, 2.99, +0.96]], [(0.022, 0.022), (0.016, 0.016)], UV_BRASS, crease_deg=16.0),
        smt.make_swept_octagonal_beam([[+0.085, 2.91, +0.88], [+0.125, 2.99, +0.96]], [(0.022, 0.022), (0.016, 0.016)], UV_BRASS, crease_deg=16.0),
        # Swept Crimson & Iron Upper Crossbeam (`Z = +0.34m`)
        smt.make_swept_octagonal_beam(
            [[-0.34, 2.88, +0.34], [0.0, 2.87, +0.38], [+0.34, 2.88, +0.34]],
            [(0.078, 0.068), (0.088, 0.076), (0.078, 0.068)],
            UV_IRON, crease_deg=16.0
        ),
        # Front Heraldic Crest Shield & Roman Numeral I Plaque (`Y = 2.740..2.910m, Z = +0.50..+0.58m`)
        smooth_box_crisp([-0.145, 2.740, +0.50], [+0.145, 2.910, +0.555], bevel=0.012, uv_center=UV_CRIMSON),
        smooth_box_crisp([-0.155, 2.735, +0.495], [+0.155, 2.765, +0.560], bevel=0.005, uv_center=UV_BRASS),
        smooth_box_crisp([-0.026, 2.765, +0.545], [+0.026, 2.895, +0.582], bevel=0.005, uv_center=UV_BRASS),
    ]
    for sx in (-1.0, +1.0):
        upper_turret_parts.append(smt.make_lathe_mesh([
            (2.785, 0.000, UV_IRON),
            (2.785, 0.112, UV_BRASS),
            (2.820, 0.098, UV_CRIMSON),
            (3.015, 0.098, UV_CRIMSON),
            (3.050, 0.112, UV_BRASS),
            (3.050, 0.000, UV_IRON),
        ], axis='y', center=(sx * UPPER_LIMB_ROOT_X, 0.0, UPPER_LIMB_ROOT_Z), segs=16, crease_deg=23.5))

    wheel_L     = make_v43_siege_wheel_mesh(-1.0)
    wheel_R     = make_v43_siege_wheel_mesh(+1.0)
    stab_L      = make_v43_stabilizer_mesh(-1.0)
    stab_R      = make_v43_stabilizer_mesh(+1.0)
    wheel_dmg_L = bb.make_v33_damaged_siege_wheel_mesh(-1.0)
    wheel_dmg_R = bb.make_v33_damaged_siege_wheel_mesh(+1.0)
    stab_dmg_L  = bb.make_v33_damaged_stabilizer_mesh(-1.0)
    stab_dmg_R  = bb.make_v33_damaged_stabilizer_mesh(+1.0)

    meshes_dict = {
        "Carriage_Chassis":        bhg.shift_mesh_to_pivot(mbu.concat_meshes(carriage_parts), PIVOTS["Carriage_Chassis"]),
        "Wheel_FL":                wheel_L,
        "Wheel_FR":                wheel_R,
        "Wheel_ML":                wheel_L,
        "Wheel_MR":                wheel_R,
        "Wheel_RL":                wheel_L,
        "Wheel_RR":                wheel_R,
        "Stabilizer_FL":           stab_L,
        "Stabilizer_FR":           stab_R,
        "Stabilizer_RL":           stab_L,
        "Stabilizer_RR":           stab_R,
        "Traverse_Mount":          bhg.shift_mesh_to_pivot(mbu.concat_meshes(traverse_parts), PIVOTS["Traverse_Mount"]),
        "Elevation_Cradle":        bhg.shift_mesh_to_pivot(mbu.concat_meshes(elev_parts), PIVOTS["Elevation_Cradle"]),
        "Main_Limb_L":             make_v43_distinct_sword_limb_mesh(-1.0, MAIN_LIMB_LEN, MAIN_TIP_OVERHANG, MAIN_BASE_SWEEP, is_upper=False),
        "Main_Limb_R":             make_v43_distinct_sword_limb_mesh(+1.0, MAIN_LIMB_LEN, MAIN_TIP_OVERHANG, MAIN_BASE_SWEEP, is_upper=False),
        "Main_String_L":           make_v43_bowstring_half_mesh(-1.0, MAIN_STR_LEN, is_upper=False),
        "Main_String_R":           make_v43_bowstring_half_mesh(+1.0, MAIN_STR_LEN, is_upper=False),
        "Main_Draw_Catch":         make_v43_catch(is_upper=False),
        "Main_Siege_Bolt":         make_v43_siege_bolt_mesh(is_upper=False),
        "Winch_Drum_And_Cranks":   bb.make_v32_winch_drum_and_cranks_mesh(),
        "Winch_Ratchet_Gear":      bhg.shift_mesh_to_pivot(
            smt.compute_crease_normals(*bhg.make_toothed_gear(PIVOTS["Winch_Ratchet_Gear"], r_root=0.19, r_tip=0.25, half_thick=0.045, n_teeth=12, uv_body=UV_IRON, uv_rim=UV_BRASS)[:4:3], bhg.make_toothed_gear(PIVOTS["Winch_Ratchet_Gear"], r_root=0.19, r_tip=0.25, half_thick=0.045, n_teeth=12, uv_body=UV_IRON, uv_rim=UV_BRASS)[2], crease_deg=18.0),
            PIVOTS["Winch_Ratchet_Gear"]
        ),
        "Winch_Pawl_And_Lever":    mbu.concat_meshes([
            smooth_box_crisp([-0.035, -0.04, -0.04], [+0.035, +0.42, +0.04], bevel=0.008, uv_center=UV_BRASS),
            smt.make_lathe_mesh([(-0.055, 0.0, UV_CRIMSON), (-0.055, 0.046, UV_CRIMSON), (+0.055, 0.046, UV_CRIMSON), (+0.055, 0.0, UV_CRIMSON)], axis='x', center=(0.0, +0.42, 0.0), segs=14, crease_deg=23.5),
        ]),
        "Upper_Turret_Mount":      bhg.shift_mesh_to_pivot(mbu.concat_meshes(upper_turret_parts), PIVOTS["Upper_Turret_Mount"]),
        "Upper_Limb_L":            make_v43_distinct_sword_limb_mesh(-1.0, UPPER_LIMB_LEN, UPPER_TIP_OVERHANG, UPPER_BASE_SWEEP, is_upper=True),
        "Upper_Limb_R":            make_v43_distinct_sword_limb_mesh(+1.0, UPPER_LIMB_LEN, UPPER_TIP_OVERHANG, UPPER_BASE_SWEEP, is_upper=True),
        "Upper_String_L":          make_v43_bowstring_half_mesh(-1.0, UPPER_STR_LEN, is_upper=True),
        "Upper_String_R":          make_v43_bowstring_half_mesh(+1.0, UPPER_STR_LEN, is_upper=True),
        "Upper_Catch_And_Trigger": make_v43_catch(is_upper=True),
        "Upper_Conditioning_Bolt": make_v43_siege_bolt_mesh(is_upper=True),
        "Wheel_FL_Damaged":        wheel_dmg_L,
        "Wheel_FR_Damaged":        wheel_dmg_R,
        "Wheel_ML_Damaged":        wheel_dmg_L,
        "Wheel_MR_Damaged":        wheel_dmg_R,
        "Wheel_RL_Damaged":        wheel_dmg_L,
        "Wheel_RR_Damaged":        wheel_dmg_R,
        "Stabilizer_FL_Damaged":   stab_dmg_L,
        "Stabilizer_FR_Damaged":   stab_dmg_R,
        "Stabilizer_RL_Damaged":   stab_dmg_L,
        "Stabilizer_RR_Damaged":   stab_dmg_R,
        "Operator_Steering_Tiller":       bb.make_v40_operator_steering_tiller_mesh(),
        "Operator_Traverse_Wheel":        bb.make_v40_operator_traverse_wheel_mesh(),
        "Operator_Fire_And_Couple_Lever": bb.make_v40_operator_fire_lever_mesh(),
        "Coupling_Clutch_Collar":         bb.make_v40_coupling_clutch_collar_mesh(),
        "Coupling_Transfer_Linkage":      bb.make_v40_coupling_transfer_linkage_mesh(),
        "Delay_Escapement_Gear":          bb.make_v40_delay_escapement_gear_mesh(),
        "Heavy_Sear_Trip_Bar":            bb.make_v40_heavy_sear_trip_bar_mesh(),
    }

    total_v = sum(len(m[0]) for m in meshes_dict.values())
    total_t = sum(len(m[3]) for m in meshes_dict.values())
    print(f"[Bi-Bye-llista v4.3] Total Geometry: {total_v:,} welded verts, {total_t:,} tris")

    pil_imgs = enhance_bibyellista_pbr_textures_v43(imgs_raw)
    return meshes_dict, pil_imgs


bb._orig_enhance_textures = bb.enhance_bibyellista_pbr_textures_v32
bb.build_bibyellista_v32_meshes_and_textures = build_bibyellista_v43_meshes_and_textures

if __name__ == "__main__":
    meshes_v43, imgs_v43 = build_bibyellista_v43_meshes_and_textures()
    clips_v43 = bb.build_12_animation_clips()
    out_glb   = OUT_DIR / "bi-bye-llista-v4_3-review.glb"
    out_blend = OUT_DIR / "Bi_Bye_llista_v4_3_Review.blend"
    glb_sha   = bb.export_bibyellista_v32_glb(meshes_v43, imgs_v43, clips_v43, out_glb)
    if (HERE / "Spellblade-production-third-person.blend").exists():
        bb.export_bibyellista_v32_blend(meshes_v43, imgs_v43, out_blend)
        raw_b = out_blend.read_bytes()
        if raw_b[:2] != bytes([0x1f, 0x8b]):
            out_blend.write_bytes(gzip.compress(raw_b, compresslevel=6))
