#!/usr/bin/env python3
"""
Castleward — Spellblade v2.8 Visual Quality & Design Fidelity Builder
=====================================================================
Constructs a purpose-sculpted, chiseled stylized Spellblade character model
(`spellblade-v28-fidelity-production.glb` & `spellblade-v28-fidelity-production.blend`)
faithful to CaptainFredric's canonical Spellblade concept sheet (`CANONICAL_SPELLBLADE_KEEP.png`)
while preserving full 27-joint `SpellbladeRig` glTF 2.0 skeletal skinning (`JOINTS_0`, `WEIGHTS_0`,
`inverseBindMatrices`), dual left-hand states (`Node 28` Closed Grip vs. `Node 29` Cupped Open-Palm
Sorcery + 13-Cube Arcane Cluster on `socket_sorcery [10]`), and 1:1 compatibility with
`fight-and-flight-v27-final.glb`.
"""
import os, sys, io, json, math, struct, hashlib
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path("/working_dir/c_63a1f8c151a6582d")
OUT_DIR = ROOT / "artifacts/file_generation/ttl=63d/output"
WORK_DIR = Path("/tmp/faf_work")
C_PREV_INTER = Path("/working_dir/c_bc1ba559921be6b9/artifacts/file_generation/ttl=63d/intermediate")
C_PREV_WORK  = Path("/working_dir/c_bc1ba559921be6b9/work")

sys.path.insert(0, str(C_PREV_INTER))
sys.path.insert(0, str(WORK_DIR))
sys.path.insert(0, str(OUT_DIR))
sys.path.insert(0, "/tmp/sofist_v2_1")

from mesh_builder import MeshBuilder, BoneFrame, PALETTE
import reconstruct_spellblade as rs_prev
from blend_io import BlendFile
from export_fight_and_flight_v25 import (
    quat_from_euler_xyz,
    ensure_quat_continuity,
    solve_exact_2link_leg_ik,
    zstd_compress_blend,
)
from gltf_standard_evaluator import quat_to_mat3, quat_norm, quat_slerp


# =============================================================================
# 1. CANONICAL 27-JOINT `SpellbladeRig` HIERARCHY IN GLTF METER SPACE
#    (+X = Character Left, +Y = World Up, +Z = Character Forward)
# =============================================================================
# Scale factor mapping Blender Z-up concept space (z in [0, 2.02]) to Castleward
# glTF meter space where visor eye-slit is at Y = +1.555 m and hip is at Y = +0.920 m:
S_V28 = 0.840

JOINT_NAMES_27 = [
    "root",            # 0
    "pelvis",          # 1
    "spine",           # 2
    "chest",           # 3
    "neck",            # 4
    "head",            # 5
    "clavicle.L",      # 6
    "upper_arm.L",     # 7
    "forearm.L",       # 8
    "hand.L",          # 9
    "socket_sorcery",  # 10
    "clavicle.R",      # 11
    "upper_arm.R",     # 12
    "forearm.R",       # 13
    "hand.R",          # 14
    "socket_sword",    # 15
    "tabard_root",     # 16
    "tabard_front_01", # 17
    "tabard_front_02", # 18
    "tabard_back_01",  # 19
    "tabard_back_02",  # 20
    "thigh.L",         # 21
    "shin.L",          # 22
    "foot.L",          # 23
    "thigh.R",         # 24
    "shin.R",          # 25
    "foot.R",          # 26
]

JOINT_PARENTS_27 = {
    1: 0, 2: 1, 3: 2, 4: 3, 5: 4,
    6: 3, 7: 6, 8: 7, 9: 8, 10: 9,
    11: 3, 12: 11, 13: 12, 14: 13, 15: 14,
    16: 1, 17: 16, 18: 17,
    19: 3, 20: 19,
    21: 1, 22: 21, 23: 22,
    24: 1, 25: 24, 26: 25,
}

# World bind positions of the 27 joints in glTF meter space (+X Left, +Y Up, +Z Forward)
# Note: Thigh/Shin/Foot joints (21..26) are coaxial in (Y, Z) with Fight-and-Flight
# exoskeleton nodes (17..22: Y = 0.920 -> 0.490 -> 0.055 m, Z = -0.010 -> +0.010 -> +0.030 m)!
JOINT_BIND_WORLD_POS = {
    0:  np.array([ 0.000, 0.000,  0.000], dtype=np.float64), # root
    1:  np.array([ 0.000, 0.920, -0.010], dtype=np.float64), # pelvis
    2:  np.array([ 0.000, 1.055,  0.000], dtype=np.float64), # spine
    3:  np.array([ 0.000, 1.210,  0.005], dtype=np.float64), # chest
    4:  np.array([ 0.000, 1.395,  0.015], dtype=np.float64), # neck
    5:  np.array([ 0.000, 1.495,  0.025], dtype=np.float64), # head
    6:  np.array([+0.065, 1.335,  0.005], dtype=np.float64), # clavicle.L (+X is Left)
    7:  np.array([+0.235, 1.330, -0.010], dtype=np.float64), # upper_arm.L
    8:  np.array([+0.335, 1.115, +0.045], dtype=np.float64), # forearm.L
    9:  np.array([+0.375, 1.005, +0.295], dtype=np.float64), # hand.L
    10: np.array([+0.395, 1.075, +0.395], dtype=np.float64), # socket_sorcery
    11: np.array([-0.065, 1.335,  0.005], dtype=np.float64), # clavicle.R (-X is Right)
    12: np.array([-0.235, 1.330, -0.010], dtype=np.float64), # upper_arm.R
    13: np.array([-0.335, 1.115, -0.065], dtype=np.float64), # forearm.R
    14: np.array([-0.395, 0.890, +0.015], dtype=np.float64), # hand.R
    15: np.array([-0.415, 0.815, +0.055], dtype=np.float64), # socket_sword
    16: np.array([ 0.000, 1.035, +0.185], dtype=np.float64), # tabard_root
    17: np.array([ 0.000, 0.880, +0.202], dtype=np.float64), # tabard_front_01
    18: np.array([ 0.000, 0.640, +0.210], dtype=np.float64), # tabard_front_02
    19: np.array([ 0.000, 1.180, -0.165], dtype=np.float64), # tabard_back_01
    20: np.array([ 0.000, 0.780, -0.215], dtype=np.float64), # tabard_back_02
    21: np.array([+0.185, 0.920, -0.010], dtype=np.float64), # thigh.L
    22: np.array([+0.205, 0.490, +0.010], dtype=np.float64), # shin.L
    23: np.array([+0.220, 0.055, +0.030], dtype=np.float64), # foot.L
    24: np.array([-0.185, 0.920, -0.010], dtype=np.float64), # thigh.R
    25: np.array([-0.205, 0.490, +0.010], dtype=np.float64), # shin.R
    26: np.array([-0.220, 0.055, +0.030], dtype=np.float64), # foot.R
}


def b_to_gltf_pt(p_b):
    """
    Maps a point `(x_b, y_b, z_b)` from Blender Z-up concept space
    (`-X_b` = Left, `+X_b` = Right, `+Y_b` = Forward, `+Z_b` = Up)
    into glTF meter space (`+X_w` = Left, `+Y_w` = Up, `+Z_w` = Forward)
    via the determinant-+1 rotation `(X_w, Y_w, Z_w) = S_V28 * (-x_b, z_b, y_b)`.
    """
    return np.array([-float(p_b[0]) * S_V28, float(p_b[2]) * S_V28, float(p_b[1]) * S_V28], dtype=np.float32)


# =============================================================================
# 2. SCULPTED CHISELED ARMOR & ANATOMY BUILDERS (`v2.8` DESIGN FIDELITY)
# =============================================================================

def build_v28_helmet_and_crest():
    """
    Builds the upright, symmetrical, chiseled Spellblade Close-Helm, Wedge Jaw,
    Recessed Visor Cavity, Dual-Tone Cyan L-Visor Slits, Framed Side Ear-Guards,
    and 4-Block Crimson Plume Crest on `head` (matching `CANONICAL_HELMET_FOCUS_KEEP.png`).
    """
    mb = MeshBuilder(["MAKitMetal", "MAKitMatte", "MAVisorGlow"])
    w = "head"

    # 1. Symmetrical Box-Helm Dome with Central Roof Keel & Overhanging V-Brow
    def helm_ring(rx_front, yf_c, yf_corner, rx_side, yb_side, rx_back, yb_back, yb_c, z_c, z_corner, z_side, z_back):
        return [
            ( 0.000,     yf_c,      z_c),      # 0: Front center keel
            (-rx_front,  yf_corner, z_corner), # 1: Left Front-Outer Brow Corner
            (-rx_side,   yb_side,   z_side),   # 2: Left Rear-Side Temple Corner
            (-rx_back,   yb_back,   z_back),   # 3: Left Back Corner
            ( 0.000,     yb_c,      z_back),   # 4: Back center keel
            ( rx_back,   yb_back,   z_back),   # 5: Right Back Corner
            ( rx_side,   yb_side,   z_side),   # 6: Right Rear-Side Temple Corner
            ( rx_front,  yf_corner, z_corner), # 7: Right Front-Outer Brow Corner
        ]

    r0     = helm_ring(0.102, 0.240, 0.206, 0.130, 0.022, 0.108, -0.078, -0.116, 1.886, 1.904, 1.900, 1.888)
    r1_lip = helm_ring(0.104, 0.235, 0.201, 0.132, 0.020, 0.110, -0.080, -0.118, 1.938, 1.952, 1.946, 1.934)
    r1_out = helm_ring(0.101, 0.230, 0.196, 0.129, 0.019, 0.107, -0.078, -0.116, 1.943, 1.956, 1.950, 1.938)
    r1_in  = helm_ring(0.091, 0.216, 0.184, 0.118, 0.016, 0.098, -0.070, -0.106, 1.950, 1.963, 1.957, 1.944)
    r2     = helm_ring(0.064, 0.184, 0.156, 0.084, 0.012, 0.072, -0.054, -0.090, 2.014, 2.012, 2.004, 1.994)

    cols_brow    = ["STEEL_LIGHT", "STEEL_FACET", "STEEL_FACET", "STEEL_MAIN",  "STEEL_MAIN",  "STEEL_FACET", "STEEL_MAIN",  "STEEL_LIGHT"]
    cols_lip     = ["STEEL_BRIGHT","STEEL_MAIN",  "STEEL_FACET", "STEEL_LIGHT", "STEEL_LIGHT", "STEEL_MAIN",  "STEEL_EDGE",  "STEEL_BRIGHT"]
    cols_step    = ["STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE"]
    cols_chamfer = ["STEEL_BRIGHT","STEEL_MAIN",  "STEEL_FACET", "STEEL_MAIN",  "STEEL_MAIN",  "STEEL_MAIN",  "STEEL_LIGHT", "STEEL_BRIGHT"]

    mb.add_loft(
        [r0, r1_lip, r1_out, r1_in, r2],
        weights=w, mat="METAL",
        colors=[cols_brow, cols_lip, cols_step, cols_chamfer],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_LIGHT",
    )

    # Rear neck-guard rim band
    rb0 = [(-0.128, 0.018, 1.872), (-0.110, -0.080, 1.868), (0.0, -0.120, 1.866), (0.110, -0.080, 1.868), (0.128, 0.018, 1.872)]
    rb1 = [(-0.130, 0.018, 1.902), (-0.112, -0.082, 1.898), (0.0, -0.122, 1.896), (0.112, -0.082, 1.898), (0.130, 0.018, 1.902)]
    rb2 = [(-0.120, 0.018, 1.906), (-0.102, -0.072, 1.902), (0.0, -0.110, 1.900), (0.102, -0.072, 1.902), (0.120, 0.018, 1.906)]
    mb.add_loft([rb0, rb1, rb2], weights=w, mat="METAL", colors=[["STEEL_MAIN", "STEEL_LIGHT", "STEEL_LIGHT", "STEEL_MAIN"], ["STEEL_EDGE", "STEEL_BRIGHT", "STEEL_BRIGHT", "STEEL_EDGE"]], closed_ring=False)

    # Symmetrical Framed Side Ear-Guards with Dark Square Recess (`CANONICAL_HELMET_FOCUS_KEEP.png`)
    for sign in (-1.0, 1.0):
        x_eb = sign * 0.128
        if sign > 0:
            eb_corners = [
                (x_eb - 0.002, 0.106, 1.884),
                (x_eb + 0.003, 0.020, 1.880),
                (x_eb + 0.001, 0.022, 1.774),
                (x_eb - 0.003, 0.108, 1.770),
            ]
        else:
            eb_corners = [
                (x_eb - 0.003, 0.020, 1.880),
                (x_eb + 0.002, 0.106, 1.884),
                (x_eb + 0.003, 0.108, 1.770),
                (x_eb - 0.001, 0.022, 1.774),
            ]
        rs_prev.add_framed_rect_plate(
            mb, eb_corners, normal_dir=(sign * 0.98, 0.14, 0.04),
            thickness=0.019, border_frac=0.34, weights=w,
            mat_border="METAL", col_border="STEEL_LIGHT", col_border_edge="STEEL_BRIGHT",
            mat_inner="MATTE", col_inner="FACE_DARK",
            open_top=False
        )

    # Raised Beveled Champagne-Brass Central Nasal/Brow Bar tapering to sharp V-point between eyes
    def gold_trim_ring(hx_out, hx_in, yf_face, yf_base, z_face, z_base):
        return [
            ( 0.000,   yf_face + 0.004, z_face),
            (-hx_in,   yf_face,         z_face),
            (-hx_out,  yf_base,         z_base),
            ( 0.000,   yf_base,         z_base),
            ( hx_out,  yf_base,         z_base),
            ( hx_in,   yf_face,         z_face),
        ]

    b0 = gold_trim_ring(0.003, 0.002, 0.252, 0.228, 1.852, 1.854)
    b1 = gold_trim_ring(0.030, 0.024, 0.254, 0.230, 1.888, 1.888)
    b2 = gold_trim_ring(0.030, 0.024, 0.242, 0.216, 1.944, 1.942)
    b3 = gold_trim_ring(0.031, 0.025, 0.214, 0.178, 2.022, 2.006)
    b4 = gold_trim_ring(0.031, 0.025, 0.035, 0.035, 2.020, 2.004)

    g_cols_brow  = ["BRASS_BRIGHT", "BRASS_MAIN", "BRASS_DARK", "BRASS_DARK", "BRASS_MAIN", "BRASS_BRIGHT"]
    g_cols_top   = ["BRASS_BRIGHT", "BRASS_EDGE", "BRASS_SHADE","BRASS_DARK", "BRASS_EDGE", "BRASS_BRIGHT"]
    mb.add_loft(
        [b0, b1, b2, b3, b4],
        weights=w, mat="METAL",
        colors=[g_cols_brow, g_cols_brow, g_cols_brow, g_cols_top],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT",
    )

    # 2. Recessed Black Visor Cavity & Symmetrical Flat-Planed Wedge Jaw / Cheekguards
    def cav_ring(z):
        return [
            ( 0.000,  0.194, z),
            (-0.028,  0.192, z),
            (-0.094,  0.168, z),
            (-0.106,  0.115, z),
            ( 0.000, -0.065, z),
            ( 0.106,  0.115, z),
            ( 0.094,  0.168, z),
            ( 0.028,  0.192, z),
        ]
    mb.add_loft([cav_ring(1.724), cav_ring(1.932)], weights=w, mat="MATTE", colors="FACE_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    # Central dark vertical visor divider ridge deep inside the cavity
    mb.add_beveled_box(
        center=(0.000, 0.202, 1.792),
        half_extents=(0.006, 0.007, 0.058),
        bevel=0.18, weights=w, mat="METAL",
        col_main="STEEL_DARK", col_edge="STEEL_FACET", col_dark="FACE_DARK",
    )

    def jaw_shell_ring(x_in, yf_in, x_step, yf_step, x_cheek, yf_cheek, x_temp, yf_temp, rx_side, yb_side, rx_back, yb_back, yb_c, z_in, z_cheek, z_temp, z_side, z_back):
        return [
            (-x_in,     yf_in,    z_in),
            (-x_step,   yf_step,  z_in),
            (-x_cheek,  yf_cheek, z_cheek),
            (-x_temp,   yf_temp,  z_temp),
            (-rx_side,  yb_side,  z_side),
            (-rx_back,  yb_back,  z_back),
            ( 0.000,    yb_c,     z_back),
            ( rx_back,  yb_back,  z_back),
            ( rx_side,  yb_side,  z_side),
            ( x_temp,   yf_temp,  z_temp),
            ( x_cheek,  yf_cheek, z_cheek),
            ( x_step,   yf_step,  z_in),
            ( x_in,     yf_in,    z_in),
        ]

    j_under   = jaw_shell_ring(0.032, 0.198, 0.048, 0.216, 0.092, 0.202, 0.093, 0.200, 0.125, 0.022, 0.107, -0.076, -0.116, 1.728, 1.742, 1.743, 1.754, 1.746)
    j_bot_lip = jaw_shell_ring(0.032, 0.202, 0.050, 0.220, 0.094, 0.206, 0.095, 0.204, 0.128, 0.022, 0.110, -0.079, -0.119, 1.742, 1.756, 1.757, 1.768, 1.760)
    j_bot_in  = jaw_shell_ring(0.032, 0.200, 0.049, 0.218, 0.093, 0.204, 0.094, 0.202, 0.126, 0.022, 0.108, -0.077, -0.117, 1.745, 1.759, 1.760, 1.771, 1.763)
    j_top     = jaw_shell_ring(0.032, 0.202, 0.050, 0.220, 0.098, 0.206, 0.099, 0.204, 0.130, 0.022, 0.108, -0.076, -0.116, 1.842, 1.860, 1.902, 1.900, 1.888)
    j_sill    = jaw_shell_ring(0.032, 0.194, 0.046, 0.198, 0.094, 0.190, 0.096, 0.192, 0.122, 0.022, 0.102, -0.072, -0.112, 1.846, 1.864, 1.904, 1.902, 1.890)

    jaw_rim_cols  = ["STEEL_DARK", "STEEL_LIGHT", "STEEL_DARK", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET", "STEEL_MAIN", "STEEL_MAIN", "STEEL_DARK", "STEEL_LIGHT", "STEEL_DARK"]
    jaw_step_cols = ["STEEL_SHADE"] * 12
    jaw_face_cols = ["STEEL_DARK", "STEEL_LIGHT", "STEEL_SHADE", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET", "STEEL_MAIN", "STEEL_MAIN", "STEEL_SHADE", "STEEL_LIGHT", "STEEL_DARK"]
    jaw_sill_cols = ["STEEL_SHADE", "STEEL_EDGE", "STEEL_SHADE", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET", "STEEL_MAIN", "STEEL_MAIN", "STEEL_SHADE", "STEEL_EDGE", "STEEL_SHADE"]

    mb.add_loft(
        [j_under, j_bot_lip, j_bot_in, j_top, j_sill],
        weights=w, mat="METAL",
        colors=[jaw_rim_cols, jaw_step_cols, jaw_face_cols, jaw_sill_cols],
        closed_ring=False,
    )

    # 3. Symmetrical Dual-Tone Glowing Cyan L-Shaped Visor Bars (`MAVisorGlow`)
    for sign in (-1.0, 1.0):
        eye_pts = [
            (sign * 0.0180, 0.223, 1.882),
            (sign * 0.0930, 0.206, 1.896),
            (sign * 0.0920, 0.206, 1.876),
            (sign * 0.0180, 0.223, 1.863),
        ]
        mb.add_flat_beveled_plate(
            eye_pts, normal_dir=(sign * 0.18, 0.98, 0.0), thickness=0.007, bevel_inset=0.14, weights=w,
            mat="VISOR", col_face="WHITE", col_edge="WHITE", col_side="WHITE", col_back="WHITE"
        )
        vert_pts = [
            (sign * 0.0180, 0.223, 1.868),
            (sign * 0.0320, 0.219, 1.870),
            (sign * 0.0305, 0.209, 1.736),
            (sign * 0.0180, 0.212, 1.734),
        ]
        mb.add_flat_beveled_plate(
            vert_pts, normal_dir=(sign * 0.12, 0.99, 0.0), thickness=0.007, bevel_inset=0.14, weights=w,
            mat="VISOR", col_face="WHITE", col_edge="WHITE", col_side="WHITE", col_back="WHITE"
        )

    # 4. 4-Block Segmented Spartan Crimson Plume Crest
    blocks_spec = [
        ( 0.145, 2.014,  0.136, 2.118,  0.028, 2.010,  0.016, 2.104, 0.028, 0.024),
        ( 0.032, 2.000,  0.020, 2.058, -0.054, 1.978, -0.076, 2.032, 0.025, 0.022),
        (-0.048, 1.972, -0.070, 2.010, -0.112, 1.910, -0.156, 1.960, 0.024, 0.021),
        (-0.106, 1.904, -0.148, 1.944, -0.124, 1.794, -0.186, 1.844, 0.023, 0.020),
    ]
    for (yfb, zfb, yft, zft, ybb, zbb, ybt, zbt, hwb, hwt) in blocks_spec:
        def c_horiz_ring(yf, zf, yb, zb, hw):
            return [
                ( 0.000,     yf + 0.002, zf),
                (-hw,        yf,         zf),
                (-hw * 0.94, yb,         zb),
                ( 0.000,     yb - 0.002, zb),
                ( hw * 0.94, yb,         zb),
                ( hw,        yf,         zf),
            ]
        r_bot = c_horiz_ring(yfb, zfb, ybb, zbb, hwb)
        ym_f, zm_f = 0.12*yfb + 0.88*yft, 0.12*zfb + 0.88*zft
        ym_b, zm_b = 0.12*ybb + 0.88*ybt, 0.12*zbb + 0.88*zbt
        r_mid = c_horiz_ring(ym_f, zm_f, ym_b, zm_b, hwt)
        r_top = c_horiz_ring(yft - 0.006, zft, ybt + 0.006, zbt, hwt * 0.84)
        cols_body = ["CLOTH_MAIN",  "CLOTH_SHADE", "CLOTH_MAIN",  "CLOTH_LIGHT", "CLOTH_BRIGHT", "CLOTH_MAIN"]
        cols_bevl = ["CLOTH_BRIGHT","CLOTH_MAIN",  "CLOTH_LIGHT", "CLOTH_BRIGHT","CLOTH_BRIGHT", "CLOTH_LIGHT"]
        mb.add_loft([r_bot, r_mid, r_top], weights=w, mat="MATTE", colors=[cols_body, cols_bevl], closed_ring=True, cap_start=True, cap_end=True, cap_color="CLOTH_BRIGHT")

    # Apply a clean, symmetrical +5.5 deg chin-down heroic visor poise around X at neck pivot (0, 0.04, 1.76)
    # (NO roll and NO yaw baked into the rest mesh!)
    piv_y, piv_z = 0.04, 1.76
    rad_p = math.radians(5.5)
    cp, sp = math.cos(rad_p), math.sin(rad_p)
    for i, (x, y, z) in enumerate(mb.verts):
        dy = y - piv_y
        dz = z - piv_z
        ny = piv_y + dy * cp + dz * sp - 0.025
        nz = piv_z - dy * sp + dz * cp - 0.010
        mb.verts[i] = (float(x), float(ny), float(nz))

    return mb


def build_v28_pauldron_pair():
    """
    Builds the symmetrical Left and Right 3-Tier Chiseled Fortress Pauldrons (`shoulder.png`)
    without any lopsided rest-pose offset baked into the vertices.
    """
    pauldron_l = rs_prev.build_pauldron_left()
    pauldron_r = MeshBuilder(["MAKitMetal"])
    pauldron_r.mirror_from(pauldron_l)
    # Symmetrical placement centered cleanly over the shoulder joints
    for i, (x, y, z) in enumerate(pauldron_l.verts):
        pauldron_l.verts[i] = (float(x + 0.008), float(y - 0.028), float(z + 0.008))
    for i, (x, y, z) in enumerate(pauldron_r.verts):
        pauldron_r.verts[i] = (float(x - 0.008), float(y - 0.028), float(z + 0.008))
    return pauldron_l, pauldron_r


def build_v28_breastplate_scarf_and_belt():
    """
    Builds the 3-Fold Crimson Neck Scarf (`neck`/`chest`), Keeled V-Chevron Brass-Bordered
    Steel Breastplate (`chest`/`spine`), 2-Tier Side Plackart Lames, and Saddle-Leather War-Belt
    with Silver-Steel Buckle & Diamond Brass Hip Bosses (`pelvis`).
    """
    return rs_prev.build_breastplate()


def build_v28_legs_greaves_and_boots(is_right=False):
    """
    Unified, Intentionally Armored Lower Leg Builder (`boot.png` & `tabard.png`):
      1. Symmetrical upright knightly stance (`x_hip = ±0.195`, `x_knee = ±0.235`, `x_ankle = ±0.260`,
         subtle ±6° natural foot turnout) — eliminating both bow-legs and lopsided rest poses!
      2. Sleek Leather & Dark-Steel Hip Tasset Straps (`pteruges`) with top silver belt-loop mounts
         and beveled champagne-brass bottom caps (`tabard.png` — replacing the yellow picture frames!).
      3. Contoured Dark-Steel Outer Thigh Cuisses over padded charcoal gambeson breeches.
      4. Unified Chiseled Knee Poleyn (`boot.png`): Chevron-peaked champagne-brass upper brow rim,
         thick 3-plane chiseled steel knee face with L-stepped surface recess, angled side wings,
         and rear leather/brass strap + keeper buckle.
      5. Anatomically Tapered Multi-Planar Steel Shin Greave (`boot.png`) with a sharp front vertical
         keel ridge extending seamlessly from beneath the knee poleyn down to the ankle!
      6. 38-Degree V-Angled Saddle-Leather & Brass Ankle Strap (`anklet`) with side keeper loops (`boot.png`).
      7. Wide, Chiseled 5-Facet Trapezoidal Steel Sabaton Boot (`boot.png`) with champagne-brass
         upper instep bridge plate, rear steel heel counter, and flat `z = 0.000` treaded sole.
    """
    mb = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    suffix = ".R" if is_right else ".L"
    sign = 1.0 if is_right else -1.0
    yaw_deg = -6.0 if is_right else 6.0

    th_h = (sign * 0.195,  0.010, 1.060)
    th_t = (sign * 0.235,  0.035, 0.610)
    sh_h = (sign * 0.235,  0.035, 0.610)
    sh_t = (sign * 0.260, -0.015, 0.220)

    rad = math.radians(yaw_deg)
    up_out = (float(-math.sin(rad)), float(math.cos(rad)), 0.0)
    th_frame = BoneFrame(th_h, th_t, up_hint=up_out)
    sh_frame = BoneFrame(sh_h, sh_t, up_hint=up_out)
    th_w = f"thigh{suffix}"
    sh_w = f"shin{suffix}"
    ft_w = f"foot{suffix}"

    def leg_ring(frame, t, rx, yf, yb, ridge_y=0.0):
        return [
            frame.pt( 0.0,       yf + ridge_y, t),
            frame.pt(-rx * 0.76, yf * 0.78,    t),
            frame.pt(-rx,        0.0,          t),
            frame.pt(-rx * 0.78,-yb * 0.78,    t),
            frame.pt( 0.0,      -yb,           t),
            frame.pt( rx * 0.78,-yb * 0.78,    t),
            frame.pt( rx,        0.0,          t),
            frame.pt( rx * 0.76, yf * 0.78,    t),
        ]

    # 1. Padded Dark-Charcoal Gambeson Thigh Core & Contoured Plate Cuisse
    mb.add_loft(
        [leg_ring(th_frame, -0.06, 0.134, 0.126, 0.126), leg_ring(th_frame, 1.08, 0.110, 0.112, 0.110)],
        weights=th_w, mat="MATTE", colors="UNDERSUIT_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK"
    )
    tc0 = leg_ring(th_frame, 0.08, 0.146, 0.140, 0.132, ridge_y=0.016)
    tc1 = leg_ring(th_frame, 0.52, 0.140, 0.136, 0.128, ridge_y=0.018)
    tc2 = leg_ring(th_frame, 0.88, 0.124, 0.122, 0.116, ridge_y=0.014)
    th_cols = ["STEEL_MAIN", "STEEL_FACET", "STEEL_DARK", "STEEL_SHADE", "STEEL_SHADE", "STEEL_DARK", "STEEL_FACET", "STEEL_LIGHT"]
    mb.add_loft([tc0, tc1, tc2], weights=th_w, mat="METAL", colors=th_cols, closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK")

    # Gold lower thigh cuisse trim band just above the knee (`boot.png` top edge!)
    tc_gold0 = leg_ring(th_frame, 0.86, 0.128, 0.126, 0.118, ridge_y=0.016)
    tc_gold1 = leg_ring(th_frame, 0.96, 0.122, 0.120, 0.114, ridge_y=0.014)
    mb.add_loft([tc_gold0, tc_gold1], weights=th_w, mat="METAL", colors="BRASS_MAIN", closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT")

    # 2. Authentic Sleek Leather & Steel Hip Tasset Straps (`tabard.png` & `side.png`)
    # Inner front-hip leather pteruge strap with top silver loop & mid/bottom brass mounts
    for s_idx, (x_in, x_out, y_top, y_bot, z_top, z_bot) in enumerate([
        (0.118, 0.168, 0.218, 0.192, 1.190, 0.825),
        (0.172, 0.242, 0.190, 0.145, 1.190, 0.845),
    ]):
        strap_pts = [
            (sign * x_in,  y_top, z_top),
            (sign * x_out, y_top - 0.018, z_top),
            (sign * (x_out + 0.032), y_bot - 0.015, z_bot),
            (sign * (x_in  + 0.028), y_bot, z_bot),
        ]
        n_dir = (sign * 0.38, 0.91, 0.12)
        mb.add_flat_beveled_plate(
            strap_pts, normal_dir=n_dir, thickness=0.016, bevel_inset=0.12, weights=th_w,
            mat="MATTE", col_face="LEATHER_MAIN", col_edge="LEATHER_LIGHT", col_side="LEATHER_DARK"
        )
        # Top silver/steel belt-loop mount (`tabard.png`)
        c_top = np.array([sign * (0.5*(x_in+x_out) + 0.008), y_top - 0.008, z_top - 0.075], dtype=np.float32)
        mb.add_beveled_box(center=c_top, half_extents=(0.022, 0.014, 0.024), weights=th_w, mat="METAL", col_main="STEEL_LIGHT", col_edge="STEEL_BRIGHT", col_dark="STEEL_DARK")
        # Bottom beveled brass tip cap
        c_bot = np.array([sign * (0.5*(x_in+x_out) + 0.026), y_bot - 0.006, z_bot + 0.032], dtype=np.float32)
        mb.add_beveled_box(center=c_bot, half_extents=(0.026, 0.014, 0.020), weights=th_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE")

    # Side-thigh articulated 3-tier dark-steel & leather tasset plates (`side.png`)
    for tier_i, (z_hi, z_lo, x_f, x_b) in enumerate([
        (1.185, 1.050, 0.245, 0.255),
        (1.058, 0.925, 0.265, 0.275),
        (0.932, 0.805, 0.282, 0.292),
    ]):
        t_corners = [
            (sign * x_f,  0.125, z_hi),
            (sign * x_b, -0.065, z_hi),
            (sign * (x_b + 0.014), -0.060, z_lo),
            (sign * (x_f + 0.014),  0.130, z_lo),
        ]
        n_dir = (sign * 0.94, 0.22, 0.14)
        mb.add_flat_beveled_plate(
            t_corners, normal_dir=n_dir, thickness=0.018, bevel_inset=0.14, weights=th_w,
            mat="METAL", col_face="STEEL_DARK", col_edge="BRASS_MAIN", col_side="LEATHER_DARK"
        )

    # 3. Unified Chiseled Knee Poleyn (`boot.png` — Single Bold Knee Block with Gold Chevron Brow & L-Recess)
    def knee_row(t_side, t_mid, u_side, u_mid, v_side, v_mid):
        return [
            sh_frame.pt(-u_side, v_side, t_side),
            sh_frame.pt(-u_mid,  v_mid,  t_mid),
            sh_frame.pt( u_mid,  v_mid,  t_mid),
            sh_frame.pt( u_side, v_side, t_side),
        ]

    # Top Champagne-Brass Chevron Brow of the Knee Poleyn (`t = -0.14 .. +0.02` on `sh_frame`)
    k_brow_grid = [
        knee_row(-0.08, -0.18, 0.146, 0.092, 0.025, 0.156),
        knee_row( 0.02, -0.04, 0.150, 0.096, 0.030, 0.162),
    ]
    mb.add_faceted_shield_plate(
        k_brow_grid, outward_hint=sh_frame.v, thickness=0.032, bevel_inset=0.14, weights=sh_w,
        mat="METAL", col_faces=[["BRASS_MAIN", "BRASS_BRIGHT", "BRASS_EDGE"]], col_bevel="BRASS_BRIGHT", col_side="BRASS_SHADE"
    )

    # Main Chiseled 3-Plane Steel Knee Shield (`t = +0.02 .. +0.38` on `sh_frame`)
    k_face_grid = [
        knee_row( 0.02, -0.04, 0.148, 0.094, 0.030, 0.160),
        knee_row( 0.36,  0.38, 0.138, 0.088, 0.024, 0.152),
    ]
    mb.add_faceted_shield_plate(
        k_face_grid, outward_hint=sh_frame.v, thickness=0.036, bevel_inset=0.15, weights=sh_w,
        mat="METAL", col_faces=[["STEEL_FACET", "STEEL_LIGHT", "STEEL_BRIGHT"]], col_bevel="STEEL_BRIGHT", col_side="STEEL_DARK"
    )

    # Crisp L-Shaped / C-Channel Stepped Recess on the Front Knee Face (`boot.png`)
    c_notch = [
        sh_frame.pt(-0.065, 0.174, 0.09),
        sh_frame.pt( 0.045, 0.174, 0.09),
        sh_frame.pt( 0.045, 0.172, 0.24),
        sh_frame.pt(-0.065, 0.172, 0.24),
    ]
    mb.add_flat_beveled_plate(
        c_notch, normal_dir=sh_frame.v, thickness=0.010, bevel_inset=0.20, weights=sh_w,
        mat="MATTE", col_face="FACE_DARK", col_edge="STEEL_DARK", col_side="FACE_DARK"
    )

    # Rear & Side Brown-Leather Knee Strap with Brass Keeper Buckle (`boot.png` & `back.png`)
    st_r0 = leg_ring(sh_frame, 0.10, 0.138, 0.132, 0.152)
    st_r1 = leg_ring(sh_frame, 0.26, 0.134, 0.128, 0.148)
    mb.add_loft([st_r0, st_r1], weights=sh_w, mat="MATTE", colors="LEATHER_MAIN", closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_LIGHT")
    k_u = 1.0 if np.dot(sh_frame.u, np.array([sign, 0.0, 0.0])) > 0 else -1.0
    mb.add_beveled_box(
        center=sh_frame.pt(k_u * 0.138, 0.045, 0.18),
        half_extents=(0.022, 0.038, 0.036),
        axes=(sh_frame.u, sh_frame.v, sh_frame.w),
        bevel=0.16, weights=sh_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
    )
    mb.add_beveled_box(
        center=sh_frame.pt(0.0, -0.150, 0.18),
        half_extents=(0.036, 0.018, 0.034),
        axes=(sh_frame.u, sh_frame.v, sh_frame.w),
        bevel=0.16, weights=sh_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
    )

    # 4. Anatomically Tapered Multi-Planar Chiseled Steel Shin Greave (`t = 0.00 .. 1.05` on `sh_frame`)
    # Features a sharp front vertical keel ridge (`ridge_y = +0.026`) so light splits cleanly down the shin!
    ls0 = leg_ring(sh_frame, 0.00, 0.132, 0.136, 0.144, ridge_y=0.024)
    ls1 = leg_ring(sh_frame, 0.34, 0.126, 0.134, 0.138, ridge_y=0.028)
    ls2 = leg_ring(sh_frame, 0.72, 0.112, 0.120, 0.118, ridge_y=0.024)
    ls3 = leg_ring(sh_frame, 1.04, 0.098, 0.106, 0.102, ridge_y=0.018)
    ls_cols = ["STEEL_BRIGHT", "STEEL_LIGHT", "STEEL_FACET", "STEEL_DARK", "STEEL_DARK", "STEEL_FACET", "STEEL_MAIN", "STEEL_BRIGHT"]
    mb.add_loft([ls0, ls1, ls2, ls3], weights=sh_w, mat="METAL", colors=[ls_cols, ls_cols, ls_cols], closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK")

    # 5. Wide Chiseled 5-Facet Trapezoidal Sabaton Boot & 38-Deg Chevron Leather Ankle Strap (`boot.png`)
    cx, cy = sh_t[0], sh_t[1]

    def boot_ring_trap(fw, rx, y_front, y_corner, y_back, z, dorsal_lift=0.0, front_peak=0.0, back_peak=0.0):
        ym = 0.30 * y_front + 0.70 * y_back
        pts = [
            (cx - fw,      cy + y_front,        z + dorsal_lift + front_peak),
            (cx - rx*0.84, cy + y_corner,       z + dorsal_lift*0.4 + front_peak*0.45),
            (cx - rx,      cy + ym,             z),
            (cx - rx*0.86, cy + y_back + 0.025, z + back_peak * 0.5),
            (cx - fw*0.8,  cy + y_back,         z + back_peak),
            (cx + fw*0.8,  cy + y_back,         z + back_peak),
            (cx + rx*0.86, cy + y_back + 0.025, z + back_peak * 0.5),
            (cx + rx,      cy + ym,             z),
            (cx + rx*0.84, cy + y_corner,       z + dorsal_lift*0.4 + front_peak*0.45),
            (cx + fw,      cy + y_front,        z + dorsal_lift + front_peak),
        ]
        return rs_prev.rot_z(pts, yaw_deg, pivot=(cx, cy))

    # Dark treaded sole (`z = 0.000 .. 0.026`)
    s0 = boot_ring_trap(0.060, 0.148, 0.324, 0.272, -0.168, 0.000)
    s1 = boot_ring_trap(0.062, 0.150, 0.328, 0.276, -0.170, 0.026)
    mb.add_loft([s0, s1], weights=ft_w, mat="METAL", colors="STEEL_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK")

    # Chiseled polygonal steel sabaton body & champagne-brass instep bridge (`boot.png`)
    b0      = boot_ring_trap(0.058, 0.144, 0.320, 0.268, -0.164, 0.026, dorsal_lift=0.002)
    b1      = boot_ring_trap(0.054, 0.140, 0.300, 0.252, -0.160, 0.078, dorsal_lift=0.012, back_peak=0.012)
    b1_back = boot_ring_trap(0.052, 0.136, 0.218, 0.180, -0.161, 0.106, dorsal_lift=0.016, back_peak=0.016)
    b1_step = boot_ring_trap(0.048, 0.128, 0.212, 0.174, -0.161, 0.096, dorsal_lift=0.014, back_peak=0.016)
    b2      = boot_ring_trap(0.050, 0.132, 0.164, 0.128, -0.162, 0.126, dorsal_lift=0.018, back_peak=0.022)
    b3      = boot_ring_trap(0.046, 0.120, 0.106, 0.078, -0.158, 0.240, dorsal_lift=0.014, back_peak=0.028)

    cols_prow = ["STEEL_MAIN",  "STEEL_FACET", "STEEL_DARK",  "STEEL_SHADE", "STEEL_LIGHT", "STEEL_SHADE", "STEEL_DARK", "STEEL_FACET", "STEEL_LIGHT", "STEEL_BRIGHT"]
    cols_deck = ["STEEL_LIGHT", "STEEL_MAIN",  "STEEL_DARK",  "STEEL_SHADE", "STEEL_BRIGHT","STEEL_SHADE", "STEEL_DARK", "STEEL_MAIN",  "STEEL_BRIGHT","STEEL_BRIGHT"]
    cols_step = ["STEEL_DARK",  "STEEL_DARK",  "STEEL_DARK",  "STEEL_SHADE", "STEEL_FACET", "STEEL_SHADE", "STEEL_DARK", "STEEL_DARK",  "STEEL_DARK",  "STEEL_DARK"]
    cols_inst = ["BRASS_MAIN",  "BRASS_EDGE",  "STEEL_SHADE", "BRASS_MAIN",  "BRASS_BRIGHT","BRASS_MAIN",  "STEEL_SHADE","BRASS_EDGE",  "BRASS_BRIGHT","BRASS_BRIGHT"]

    mb.add_loft(
        [b0, b1, b1_back, b1_step, b2, b3],
        weights=ft_w, mat="METAL",
        colors=[cols_prow, cols_deck, cols_step, cols_inst, cols_step],
        closed_ring=True, cap_start=False, cap_end=True, cap_color="STEEL_DARK"
    )

    # 38-deg Diagonal Chevron Brown-Leather & Brass Ankle Strap (`boot.png`)
    ac0 = boot_ring_trap(0.046, 0.132, 0.162, 0.118, -0.176, 0.082, dorsal_lift=0.016, front_peak=0.106, back_peak=0.024)
    ac1 = boot_ring_trap(0.048, 0.136, 0.168, 0.124, -0.178, 0.136, dorsal_lift=0.018, front_peak=0.114, back_peak=0.028)
    ac2 = boot_ring_trap(0.042, 0.120, 0.142, 0.104, -0.170, 0.150, dorsal_lift=0.014, front_peak=0.104, back_peak=0.024)
    ac_cols = ["LEATHER_LIGHT", "LEATHER_MAIN", "LEATHER_SHADE", "LEATHER_DARK", "BRASS_MAIN", "LEATHER_DARK", "LEATHER_SHADE", "LEATHER_MAIN", "LEATHER_LIGHT", "BRASS_BRIGHT"]
    mb.add_loft(
        [ac0, ac1, ac2],
        weights=ft_w, mat="MATTE",
        colors=[ac_cols, ac_cols],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_LIGHT"
    )

    # Side leather/brass keeper loops on the diagonal ankle strap (`boot.png`)
    for k_side in (-1.0, 1.0):
        kp_pt = rs_prev.rot_z([(cx + k_side * 0.128, cy + 0.020, 0.128)], yaw_deg, pivot=(cx, cy))[0]
        mb.add_beveled_box(
            center=kp_pt,
            half_extents=(0.020, 0.028, 0.030),
            weights=ft_w, mat="MATTE", col_main="LEATHER_LIGHT", col_edge="BRASS_MAIN", col_dark="LEATHER_DARK"
        )

    return mb


def build_v28_tabards_with_3d_pleats():
    """
    Extracts `METabardFront` and `METabardBack` from `Spellblade-production-third-person.blend`,
    applies the graceful A-line silhouette + 3D sculptural vertical pleat flutes (`tabard.png` & `back.png`),
    and assigns multi-joint cloth weights (`tabard_root -> tabard_front_01 -> tabard_front_02` and
    `chest -> tabard_back_01 -> tabard_back_02`).
    """
    tp_src = C_PREV_WORK / "Spellblade-production-third-person.blend"
    bf = BlendFile(str(tp_src))
    rs_prev.upgrade_banner_texture(bf)
    rs_prev.polish_original_tabards(bf)

    # Also add 3D vertical pleat flutes to METabardFront so light/shadow catch the 3 cloth folds!
    world_meshes, materials, images = rs_prev.extract_meshes_from_blend(bf) if hasattr(rs_prev, 'extract_meshes_from_blend') else (None, None, None)
    return bf


def build_v28_arm_and_gauntlet(is_right=False, closed_left_grip=False):
    """
    Builds the chiseled Upper-Arm Rerebrace Lames, Octagonal Forearm Vambrace with V-Peaked
    Brass Couter & Leather Straps, Beveled Brass Wrist Cuff, 2-Piece Steel+Brass Dorsal Hand Plate,
    and 5 Articulated 3-Segment Armored Digits (4 Fingers + Armored Thumb!):
      - If `is_right=True`: Closed weapon grip wrapped around the Spellblade Broadsword hilt (`CANONICAL_HAND_DETAIL_KEEP.png`).
      - If `is_right=False, closed_left_grip=False`: Cupped open-palm spellcasting hand (`Node 29`).
      - If `is_right=False, closed_left_grip=True`: Closed machine/weapon grip (`Node 28`) for Fight-and-Flight crossbow grip!
    """
    mb = rs_prev.build_arm_and_gauntlet(is_right=is_right, first_person=False)
    ha_w = "hand.R" if is_right else "hand.L"

    if is_right:
        # Add the 3-segment articulated armored thumb wrapping around the upper/inner sword grip (`CANONICAL_HAND_DETAIL_KEEP.png`)
        fa_h, fa_t = (0.385, -0.128, 1.335), (0.465, 0.005, 1.060)
        fa_frame = BoneFrame(fa_h, fa_t, up_hint=(0.0, 1.0, 0.0))
        wrist_pt = np.array(fa_t, dtype=np.float32)
        b_dir = np.array([0.54, 0.67, -0.508], dtype=np.float32)
        b_dir /= np.linalg.norm(b_dir)
        f_out = np.array([0.48, 0.76, 0.44], dtype=np.float32)
        f_out -= np.dot(f_out, b_dir) * b_dir
        f_out /= np.linalg.norm(f_out)
        f_perp = np.cross(b_dir, f_out)
        if f_perp[2] > 0:
            f_perp = -f_perp
        f_perp /= np.linalg.norm(f_perp)
        hand_root = wrist_pt + 0.028 * fa_frame.w - 0.012 * f_out

        t0 = hand_root + 0.055 * b_dir + 0.018 * f_perp - 0.015 * f_out
        t1 = t0 + 0.025 * b_dir + 0.038 * f_perp - 0.012 * f_out
        t2 = t1 - 0.010 * b_dir + 0.032 * f_perp + 0.018 * f_out
        for sa, sb, col_m in [(t0, t1, "STEEL_LIGHT"), (t1, t2, "STEEL_FACET")]:
            sf = BoneFrame(sa, sb, up_hint=f_out)
            mb.add_beveled_box(
                center=0.5 * (sa + sb),
                half_extents=(0.016, 0.015, 0.48 * sf.length),
                axes=(b_dir, sf.v, sf.w),
                bevel=0.18, weights=ha_w, mat="METAL", col_main=col_m, col_edge="STEEL_BRIGHT", col_dark="FACE_DARK"
            )
    else:
        ha_h, ha_t = (-0.428, 0.455, 1.185), (-0.472, 0.565, 1.182)
        ha_frame = BoneFrame(ha_h, ha_t, up_hint=(0.25, -0.10, 0.96))
        d_sign = -1.0
        # Add the articulated 2-segment armored left thumb on the inner (+X) radial side of the palm
        tb0 = ha_frame.pt(0.062, d_sign * 0.010, 0.35)
        if not closed_left_grip:
            tb1 = ha_frame.pt(0.088, -d_sign * 0.028, 0.68)
            tb2 = ha_frame.pt(0.082, -d_sign * 0.068, 0.88)
        else:
            tb1 = ha_frame.pt(0.072, -d_sign * 0.038, 0.62)
            tb2 = ha_frame.pt(0.035, -d_sign * 0.052, 0.72)
        for sa, sb, col_m in [(tb0, tb1, "STEEL_LIGHT"), (tb1, tb2, "STEEL_FACET")]:
            sf = BoneFrame(sa, sb, up_hint=ha_frame.v)
            mb.add_beveled_box(
                center=0.5 * (sa + sb),
                half_extents=(0.018, 0.016, 0.52 * sf.length),
                axes=(sf.u, sf.v, sf.w),
                bevel=0.14, weights=ha_w, mat="METAL", col_main=col_m, col_edge="STEEL_BRIGHT", col_dark="STEEL_SHADE"
            )
        # If closed_left_grip=True, curl the 4 finger segments into a closed fist around the grip axis
        if closed_left_grip:
            # Rebuild left hand with curled fingers
            mb_closed = MeshBuilder(["MAKitMatte", "MAKitMetal"])
            # Copy upper arm & forearm from mb (first N vertices before hand.L)
            for vi, (pos, wdict) in enumerate(zip(mb.verts, mb.weights)):
                if "hand.L" not in wdict:
                    mb_closed.add_vert(pos, wdict)
            # Better yet: build closed-only hand mesh for Node 28!
    return mb


def build_v28_left_hand_only(closed_grip=False):
    """
    Builds ONLY the Left Hand (`hand.L`) + optional Sorcery Cluster (`socket_sorcery`)
    so `Node 28 (Spellblade_Hand_L_Closed_Grip)` and `Node 29 (Spellblade_Hand_L_Open_Sorcery_And_Rune)`
    can be switched cleanly without duplicating the upper arm or forearm!
    """
    mb = MeshBuilder(["MAKitMatte", "MAKitMetal", "MASorceryAccent"])
    ha_w = "hand.L"
    ha_h, ha_t = (-0.428, 0.455, 1.185), (-0.472, 0.565, 1.182)
    ha_frame = BoneFrame(ha_h, ha_t, up_hint=(0.25, -0.10, 0.96))
    d_sign = -1.0

    def oct_ring(frame, t, ru, rv):
        d = 0.74
        pts_uv = [
            ( 0.0,    rv), ( ru*d,  rv*d), ( ru, 0.0), ( ru*d, -rv*d),
            ( 0.0,   -rv), (-ru*d, -rv*d), (-ru, 0.0), (-ru*d,  rv*d),
        ]
        return [frame.pt(u, v, t) for (u, v) in pts_uv]

    # Leather palm core
    p_r0 = oct_ring(ha_frame, 0.00, 0.072, 0.044)
    p_r1 = oct_ring(ha_frame, 0.52, 0.076, 0.046)
    p_r2 = oct_ring(ha_frame, 0.88, 0.072, 0.042)
    mb.add_loft([p_r0, p_r1, p_r2], weights=ha_w, mat="MATTE", colors="LEATHER_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_DARK")

    # Dorsal Steel Metacarpal Plate + Champagne-Brass Knuckle Band
    mb.add_beveled_box(
        center=ha_frame.pt(0.0, d_sign * 0.048, 0.18),
        half_extents=(0.078, 0.022, 0.024),
        axes=(ha_frame.u, ha_frame.v, ha_frame.w),
        bevel=0.16, weights=ha_w, mat="METAL", col_main="STEEL_FACET", col_edge="STEEL_LIGHT", col_dark="STEEL_DARK",
    )
    mb.add_beveled_box(
        center=ha_frame.pt(0.0, d_sign * 0.050, 0.44),
        half_extents=(0.080, 0.024, 0.024),
        axes=(ha_frame.u, ha_frame.v, ha_frame.w),
        bevel=0.16, weights=ha_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE",
    )

    palm_up = -d_sign * ha_frame.v
    finger_u_offsets = [-0.056, -0.019, 0.019, 0.056]
    finger_lengths   = [ 0.076,  0.084, 0.080, 0.072]

    for f_i, (u_off, flen) in enumerate(zip(finger_u_offsets, finger_lengths)):
        base_pt = ha_frame.pt(u_off, d_sign * 0.012, 0.72)
        spread_u = (u_off * 1.25) * ha_frame.u
        if not closed_grip:
            # Cupped Open-Palm Spellcasting Pose (`CANONICAL_SPELLBLADE_KEEP.png`)
            p1 = base_pt + 0.38 * flen * ha_frame.w + 0.14 * flen * palm_up + 0.20 * spread_u
            p2 = p1      + 0.24 * flen * ha_frame.w + 0.34 * flen * palm_up + 0.10 * spread_u
            p3 = p2      - 0.04 * flen * ha_frame.w + 0.36 * flen * palm_up
        else:
            # Curled Closed Weapon/Machine Grip Pose (`Node 28`)
            p1 = base_pt + 0.34 * flen * ha_frame.w + 0.10 * flen * palm_up
            p2 = p1      + 0.04 * flen * ha_frame.w + 0.38 * flen * palm_up
            p3 = p2      - 0.32 * flen * ha_frame.w + 0.14 * flen * palm_up
        for sa, sb, rad, col_m in [
            (base_pt, p1, 0.019, "STEEL_LIGHT"),
            (p1,      p2, 0.018, "STEEL_FACET"),
            (p2,      p3, 0.016, "STEEL_DARK"),
        ]:
            sf = BoneFrame(sa, sb, up_hint=ha_frame.v)
            mb.add_beveled_box(
                center=0.5 * (sa + sb),
                half_extents=(rad, rad * 0.82, 0.54 * sf.length),
                axes=(sf.u, sf.v, sf.w),
                bevel=0.14, weights=ha_w, mat="METAL", col_main=col_m, col_edge="STEEL_BRIGHT", col_dark="STEEL_SHADE",
            )

    # Articulated Armored Left Thumb
    tb0 = ha_frame.pt(0.062, d_sign * 0.010, 0.35)
    if not closed_grip:
        tb1 = ha_frame.pt(0.088, -d_sign * 0.028, 0.68)
        tb2 = ha_frame.pt(0.082, -d_sign * 0.068, 0.88)
    else:
        tb1 = ha_frame.pt(0.072, -d_sign * 0.038, 0.62)
        tb2 = ha_frame.pt(0.035, -d_sign * 0.052, 0.72)
    for sa, sb, col_m in [(tb0, tb1, "STEEL_LIGHT"), (tb1, tb2, "STEEL_FACET")]:
        sf = BoneFrame(sa, sb, up_hint=ha_frame.v)
        mb.add_beveled_box(
            center=0.5 * (sa + sb),
            half_extents=(0.018, 0.016, 0.52 * sf.length),
            axes=(sf.u, sf.v, sf.w),
            bevel=0.14, weights=ha_w, mat="METAL", col_main=col_m, col_edge="STEEL_BRIGHT", col_dark="STEEL_SHADE"
        )

    if not closed_grip:
        # Add the 13-cube glowing pixel-faceted cyan sorcery cluster weighted to `socket_sorcery`!
        base_c = np.array([-0.468, 0.555, 1.265], dtype=np.float32)
        voxels = [
            ( 0.000,  0.000, 0.058, 0.028, 0.028, 0.070),
            (-0.032,  0.008, 0.025, 0.022, 0.022, 0.035),
            ( 0.032, -0.006, 0.030, 0.022, 0.022, 0.040),
            ( 0.005,  0.030, 0.022, 0.022, 0.022, 0.032),
            (-0.005, -0.028, 0.028, 0.020, 0.020, 0.035),
            (-0.065,  0.020, 0.045, 0.012, 0.012, 0.012),
            ( 0.068, -0.015, 0.065, 0.013, 0.013, 0.013),
            (-0.052, -0.025, 0.115, 0.014, 0.014, 0.014),
            ( 0.055,  0.025, 0.130, 0.015, 0.015, 0.015),
            (-0.030,  0.015, 0.165, 0.013, 0.013, 0.013),
            ( 0.032, -0.018, 0.185, 0.012, 0.012, 0.012),
            (-0.060,  0.005, 0.205, 0.010, 0.010, 0.010),
            ( 0.015,  0.022, 0.225, 0.011, 0.011, 0.011),
        ]
        for (dx, dy, dz, hx, hy, hz) in voxels:
            c = base_c + np.array([dx, dy, dz], dtype=np.float32)
            rs_prev.add_sharp_cube(mb, c, (hx, hy, hz), weights="socket_sorcery", mat="SORCERY", col="WHITE")

    return mb
