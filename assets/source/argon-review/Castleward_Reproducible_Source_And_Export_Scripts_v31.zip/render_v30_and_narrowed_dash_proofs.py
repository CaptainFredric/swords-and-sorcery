#!/usr/bin/env python3
"""
Renders the visual comparison sheets and showcase video for:
  1. Spellblade_v30_Concept_v29_v30_Turnaround_And_Distance_Comparison.jpg (2400x1680)
  2. Spellblade_v30_Six_Region_Overlapping_Armor_Closeups.jpg (2400x1680)
  3. Fight_And_Flight_v29_InGame_ThirdPerson_Dash_And_TrackMask_Sheet.jpg (2400x1680)
  4. Castleward_v30_Spellblade_And_InGame_Dash_Showcase.mp4 (1280x720, 20 fps)
"""
import os, sys, math
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageOps
import imageio

sys.path.insert(0, '/working_dir/c_bc1ba559921be6b9/artifacts/file_generation/ttl=63d/intermediate')
sys.path.insert(0, '/tmp/faf_work')

from gltf_standard_evaluator import StandardGltfEvaluator as _BaseEv, quat_to_mat3
from render_faf_v27_evidence import render_panel as _rp_orig, get_font

OUT_DIR = Path("/working_dir/c_63a1f8c151a6582d/artifacts/file_generation/ttl=63d/output")
WORK_DIR = Path("/tmp/faf_work")
SB_IMGS = WORK_DIR / "sb_imgs"

SB_V29_GLB  = OUT_DIR / "spellblade-v29-artistic-refinement.glb"
SB_V30_GLB  = OUT_DIR / "spellblade-v30-refined-candidate.glb"
FAF_ND_GLB  = OUT_DIR / "fight-and-flight-v29-narrowed-dash.glb"


class StandardGltfEvaluator(_BaseEv):
    def evaluate(self, clip_name=None, time_sec=0.0, loop=True, node_overrides=None):
        P, N, T, VC, VM, VE, _ = self.evaluate_scene_meshes(
            clip_name=clip_name, t_sec=float(time_sec), loop=loop, node_overrides=node_overrides
        )
        return (P, N, T, VC, VM, VE)


def render_scene(sc_tup, cam_eye, cam_target, w, h, fov_deg=38.0):
    return _rp_orig(sc_tup, list(cam_eye), list(cam_target), int(w), int(h), fov_deg=float(fov_deg)).convert("RGB")


def combine_scenes(sc_a, sc_b):
    Pa, Na, Ta, VCa, VMa, VEa = sc_a
    Pb, Nb, Tb, VCb, VMb, VEb = sc_b
    return (
        np.concatenate([Pa, Pb], axis=0),
        np.concatenate([Na, Nb], axis=0),
        np.concatenate([Ta, Tb + len(Pa)], axis=0),
        np.concatenate([VCa, VCb], axis=0),
        np.concatenate([VMa, VMb], axis=0),
        np.concatenate([VEa, VEb], axis=0),
    )


def transform_scene_by_matrix(sc_tup, M4: np.ndarray):
    P, N, T, VC, VM, VE = sc_tup
    R = M4[:3, :3].astype(np.float32)
    t = M4[:3, 3].astype(np.float32)
    P_w = (P @ R.T) + t
    N_w = N @ R.T
    n_len = np.linalg.norm(N_w, axis=1, keepdims=True)
    N_w = N_w / np.maximum(n_len, 1e-8)
    return (P_w, N_w, T, VC, VM, VE)


def make_translation_yaw_matrix(tx, ty, tz, yaw_deg=0.0):
    rad = math.radians(yaw_deg)
    c, s = math.cos(rad), math.sin(rad)
    M = np.eye(4, dtype=np.float32)
    M[0, 0] = c
    M[0, 2] = s
    M[2, 0] = -s
    M[2, 2] = c
    M[0, 3] = tx
    M[1, 3] = ty
    M[2, 3] = tz
    return M


def quat_from_euler_xyz(rx_deg: float, ry_deg: float, rz_deg: float):
    rx = math.radians(rx_deg) * 0.5
    ry = math.radians(ry_deg) * 0.5
    rz = math.radians(rz_deg) * 0.5
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    return [
        sx * cy * cz + cx * sy * sz,
        cx * sy * cz - sx * cy * sz,
        cx * cy * sz + sx * sy * cz,
        cx * cy * cz - sx * sy * sz,
    ]


def make_arena_corridor_scene(y_level=-0.35, target_x=-0.95, target_z=3.60):
    """
    Creates a readable arena floor with perspective lane strips and a crimson/gold target ring
    under the enemy target knight at (target_x, target_z) so the over-the-shoulder 3P chase camera
    has clear spatial depth & sightline cues.
    """
    pts_list, nrm_list, tri_list, vc_list, vm_list, ve_list = [], [], [], [], [], []

    def add_quad(q_pts, col, mr=(1.0, 0.85, 0.10), em=(0.0, 0.0, 0.0)):
        base = len(pts_list)
        for p in q_pts:
            pts_list.append(p)
            nrm_list.append([0.0, 1.0, 0.0])
            vc_list.append(col)
            vm_list.append(mr)
            ve_list.append(em)
        tri_list.append([base, base + 1, base + 2])
        tri_list.append([base, base + 2, base + 3])

    # Main floor slab
    add_quad([
        [-3.5, y_level, -2.5],
        [ 3.5, y_level, -2.5],
        [ 3.5, y_level,  6.5],
        [-3.5, y_level,  6.5],
    ], [0.14, 0.17, 0.22])

    # Attack corridor guide rails leading toward Enemy Target
    for x_off in (-0.55, 0.55):
        add_quad([
            [x_off - 0.03, y_level + 0.004, -1.2],
            [x_off + 0.03, y_level + 0.004, -1.2],
            [target_x + x_off + 0.03, y_level + 0.004, target_z + 0.8],
            [target_x + x_off - 0.03, y_level + 0.004, target_z + 0.8],
        ], [0.78, 0.62, 0.24], mr=(1.0, 0.30, 0.85), em=(0.12, 0.09, 0.02))

    # Target reticle pad under the enemy target knight
    add_quad([
        [target_x - 0.65, y_level + 0.006, target_z - 0.65],
        [target_x + 0.65, y_level + 0.006, target_z - 0.65],
        [target_x + 0.65, y_level + 0.006, target_z + 0.65],
        [target_x - 0.65, y_level + 0.006, target_z + 0.65],
    ], [0.55, 0.14, 0.14], mr=(1.0, 0.45, 0.25), em=(0.18, 0.03, 0.03))

    return (
        np.array(pts_list, dtype=np.float32),
        np.array(nrm_list, dtype=np.float32),
        np.array(tri_list, dtype=np.int32),
        np.array(vc_list, dtype=np.float32),
        np.array(vm_list, dtype=np.float32),
        np.array(ve_list, dtype=np.float32),
    )


def draw_badge(draw, x, y, w, title, sub="", accent=(235, 195, 95)):
    draw.rectangle([x, y, x + w, y + 46], fill=(16, 19, 27))
    draw.line([(x, y + 46), (x + w, y + 46)], fill=accent, width=2)
    draw.text((x + 10, y + 5), title, fill=accent, font=get_font(15, True))
    if sub:
        draw.text((x + 10, y + 25), sub, fill=(190, 205, 222), font=get_font(11, False))


def evaluate_narrowed_dash_multilayer(
    faf_ev: StandardGltfEvaluator,
    sb_ev: StandardGltfEvaluator,
    dash_clip_name: str,
    dash_t: float,
    sim_pitch_deg: float = 24.0,
    sim_shaft_tilt_deg: float = 14.0,
    rotor_spin_t: float = 0.35,
    sword_layer_mode: str = "resting_dash",
    sword_t: float = 0.35,
    zero_hp_braces: bool = False,
    additive_hull_buckle: float = 0.0,
    include_enemy_target: bool = True,
):
    layers = [
        ("Rotor_Spin_Cycle_1Rev", rotor_spin_t, True, 1.0, "override"),
        ("Crossbow_Aim_Traverse_Elevation_Sweep", 0.25, True, 0.35, "override"),
        (dash_clip_name, dash_t, False, 1.0, "override"),
    ]
    if zero_hp_braces:
        layers.append(("Damage_Comp_Brace_L_Broken_ZeroHP", 0.85, False, 1.0, "override"))
        layers.append(("Damage_Comp_Brace_R_Broken_ZeroHP", 0.85, False, 1.0, "override"))
    if additive_hull_buckle > 0.0:
        layers.append(("Damage_Comp_Chassis_Buckle_And_Compression", 0.50, True, additive_hull_buckle, "additive"))

    if sword_layer_mode == "resting_dash":
        layers.append(("Dash_Narrowed_04_Resting_3P_Couched_Sword_Layer", sword_t, True, 1.0, "override"))
        sb_clip = "Spellblade_10_Machine_Offensive_Dash_Posture"
        sb_time = 0.75
    elif sword_layer_mode == "slash_override":
        layers.append(("Sword_Strike_And_Recovery", sword_t, False, 1.0, "override"))
        sb_clip = "Spellblade_06_Sword_Slash_Combo_And_Recovery"
        sb_time = sword_t
    elif sword_layer_mode == "guard_override":
        layers.insert(0, ("Cockpit_1P_Sword_Guard_And_Parry", sword_t, False, 1.0, "override"))
        sb_clip = "Spellblade_04_Crouch_And_Guard"
        sb_time = 0.45
    else:
        sb_clip = "Spellblade_10_Machine_Offensive_Dash_Posture"
        sb_time = 0.75

    node_ov = {
        1: {
            "translation": [0.0, 0.030 * (sim_pitch_deg / 24.0), 0.0],
            "rotation": quat_from_euler_xyz(sim_pitch_deg, 0.0, 0.0),
        },
        8: {
            "translation": [0.0, 1.985 + 0.040 * (sim_shaft_tilt_deg / 14.0), -0.025 + 0.110 * (sim_shaft_tilt_deg / 14.0)],
            "rotation": quat_from_euler_xyz(sim_shaft_tilt_deg, 0.0, 0.0),
        },
    }

    orig_n1_t = list(faf_ev.gltf["nodes"][1].get("translation", [0.0, 0.0, 0.0]))
    orig_n1_r = list(faf_ev.gltf["nodes"][1].get("rotation", [0.0, 0.0, 0.0, 1.0]))
    orig_n8_t = list(faf_ev.gltf["nodes"][8].get("translation", [0.0, 1.985, -0.025]))
    orig_n8_r = list(faf_ev.gltf["nodes"][8].get("rotation", [0.0, 0.0, 0.0, 1.0]))
    try:
        faf_ev.gltf["nodes"][1]["translation"] = node_ov[1]["translation"]
        faf_ev.gltf["nodes"][1]["rotation"] = node_ov[1]["rotation"]
        faf_ev.gltf["nodes"][8]["translation"] = node_ov[8]["translation"]
        faf_ev.gltf["nodes"][8]["rotation"] = node_ov[8]["rotation"]
        P, N, T, VC, VM, VE, wm, audit = faf_ev.evaluate_multilayer_scene_meshes(layers)
    finally:
        faf_ev.gltf["nodes"][1]["translation"] = orig_n1_t
        faf_ev.gltf["nodes"][1]["rotation"] = orig_n1_r
        faf_ev.gltf["nodes"][8]["translation"] = orig_n8_t
        faf_ev.gltf["nodes"][8]["rotation"] = orig_n8_r

    sc_faf = (P, N, T, VC, VM, VE)
    ov_closed = {28: {"scale": [1.0, 1.0, 1.0]}, 29: {"scale": [0.0, 0.0, 0.0]}}
    sc_sb_local = sb_ev.evaluate(sb_clip, sb_time, loop=True, node_overrides=ov_closed)
    sc_sb_world = transform_scene_by_matrix(sc_sb_local, wm[1])
    sc_combined = combine_scenes(sc_faf, sc_sb_world)

    if include_enemy_target:
        # Place the enemy target knight in the open right-side attack corridor (X = -0.95m, Z = +3.60m, Y = -0.35m)
        # right where the player's couched broadsword (-X is right side of apparatus!) is aiming!
        ov_open = {28: {"scale": [0.0, 0.0, 0.0]}, 29: {"scale": [1.0, 1.0, 1.0]}}
        sc_enemy_local = sb_ev.evaluate("Spellblade_04_Crouch_And_Guard", 0.40, loop=True, node_overrides=ov_open)
        M_enemy = make_translation_yaw_matrix(-0.95, -0.35, 3.60, yaw_deg=165.0)
        sc_enemy_world = transform_scene_by_matrix(sc_enemy_local, M_enemy)
        sc_combined = combine_scenes(sc_combined, sc_enemy_world)

    return sc_combined, audit


def build_sheet_3_ingame_dash_and_trackmasks(faf_ev: StandardGltfEvaluator, sb_ev: StandardGltfEvaluator):
    print("Rendering Sheet 3: Fight_And_Flight_v29_InGame_ThirdPerson_Dash_And_TrackMask_Sheet.jpg ...")
    W, H = 2400, 1680
    sheet = Image.new("RGB", (W, H), (14, 16, 22))
    draw = ImageDraw.Draw(sheet)

    draw.rectangle([0, 0, W, 72], fill=(20, 24, 34))
    draw.line([(0, 72), (W, 72)], fill=(245, 190, 85), width=3)
    draw.text((24, 10), "CASTLEWARD — FIGHT-AND-FLIGHT v2.9 TRUE IN-GAME 3P DASH CHASE VIEW & NARROWED TRACK-MASK CONTRACT", fill=(255, 220, 125), font=get_font(20, True))
    draw.text((24, 40), "Unobstructed Over-The-Shoulder 3P Sightline to Target Ahead + Narrowed Dash Clips (49..53) Composing with Sim Pitch/Spin, 0-HP Braces, Additive Hull & Sword Override", fill=(195, 205, 225), font=get_font(12, False))

    xs = [16, 612, 1208, 1804]
    ys = [86, 610, 1134]
    pw, ph = 580, 508
    arena = make_arena_corridor_scene(-0.35, target_x=-0.95, target_z=3.60)

    # True In-Game Over-The-Right-Shoulder Third-Person Chase Camera:
    # In Fight-and-Flight coordinates, -X is the right-hand sword side and +Z is forward flight!
    # Placing the chase camera at `[-1.05, 1.48, -2.55]` looking forward to `[-0.50, 0.92, 3.60]`
    # frames the apparatus & billowing crimson banner on the left-center, the couched right-hand
    # broadsword in the right foreground, the Enemy Target Knight completely unobstructed in the
    # right-center attack corridor ahead, and the golden rotor halo cleanly along the top edge!
    CHASE_EYE = [-1.05, 1.48, -2.55]
    CHASE_TGT = [-0.50, 0.92,  3.60]

    r1_specs = [
        ("Dash_Narrowed_01_Entry_Posture", 0.28, 22.0, 12.0, "resting_dash", 0.25,
         "1A. IN-GAME 3P CHASE: NARROWED ENTRY (CLIP 49)",
         "Full enemy target visible ahead-right; rotor above sightline, +22° sim pitch"),
        ("Dash_Narrowed_02_Sustained_Hold_Loop", 0.40, 24.0, 14.0, "resting_dash", 0.40,
         "1B. IN-GAME 3P CHASE: SUSTAINED HOLD (CLIP 50 + 52)",
         "+24° sim pitch, streaming trident banner, couched 3P sword (Clip 52) & clear target view"),
        ("Dash_Narrowed_02_Sustained_Hold_Loop", 0.40, 24.0, 14.0, "slash_override", 0.32,
         "1C. IN-GAME 3P CHASE: MID-DASH SWORD SLASH OVERRIDE",
         "Clip 14 (Sword Slash, Prio 80) overrides Clip 52 (Resting Sword, Prio 30) mid-Dash!"),
        ("Dash_Narrowed_03_Release_Flare_Recovery", 0.28, -10.5, -8.0, "guard_override", 0.35,
         "1D. IN-GAME 3P CHASE: RELEASE FLARE + GUARD OVERRIDE",
         "Clip 51 Release Flare (-10.5° sim brake) + Clip 26 Guard Override on Nodes [56..59]"),
    ]

    for idx, (d_clip, d_t, p_deg, s_deg, sw_mode, sw_t, title, sub) in enumerate(r1_specs):
        sc_m, audit = evaluate_narrowed_dash_multilayer(
            faf_ev, sb_ev,
            dash_clip_name=d_clip, dash_t=d_t,
            sim_pitch_deg=p_deg, sim_shaft_tilt_deg=s_deg,
            rotor_spin_t=0.35, sword_layer_mode=sw_mode, sword_t=sw_t,
            zero_hp_braces=False, additive_hull_buckle=0.0, include_enemy_target=True
        )
        sc_full = combine_scenes(arena, sc_m)
        im = render_scene(sc_full, CHASE_EYE, CHASE_TGT, pw, ph - 46, fov_deg=42.0)
        d = ImageDraw.Draw(im)
        d.rectangle([10, ph - 80, pw - 10, ph - 52], fill=(12, 22, 18), outline=(95, 225, 150), width=1)
        d.text((16, ph - 74), f"3P Chase Cam: Target & Sword Clear | Active Ch: {len(audit['owned'])} | Conflicts: {len(audit['conflicts'])}", fill=(125, 245, 175), font=get_font(11, True))
        sheet.paste(im, (xs[idx], ys[0] + 46))
        draw_badge(draw, xs[idx], ys[0], pw, title, sub, accent=(245, 195, 95))

    # Row 2: Multi-Layer Composition Proofs with Narrowed Dash (0-HP Broken Braces, Additive Hull Buckle, Smooth Collision Transition)
    sc_2a, aud_2a = evaluate_narrowed_dash_multilayer(
        faf_ev, sb_ev,
        dash_clip_name="Dash_Narrowed_02_Sustained_Hold_Loop", dash_t=0.40,
        sim_pitch_deg=24.0, sim_shaft_tilt_deg=14.0,
        rotor_spin_t=0.35, sword_layer_mode="resting_dash", sword_t=0.40,
        zero_hp_braces=True, additive_hull_buckle=0.0, include_enemy_target=False
    )
    im_2a = render_scene(combine_scenes(arena, sc_2a), [-2.15, 1.35, 1.85], [0.0, 1.12, 0.05], pw, ph - 46, fov_deg=38.0)
    d2a = ImageDraw.Draw(im_2a)
    d2a.rectangle([10, ph - 80, pw - 10, ph - 52], fill=(12, 22, 18), outline=(95, 225, 150), width=1)
    d2a.text((16, ph - 74), f"0-HP Braces (Clips 36,38) Stay Broken During Dash! Conflicts: {len(aud_2a['conflicts'])}", fill=(125, 245, 175), font=get_font(11, True))
    sheet.paste(im_2a, (xs[0], ys[1] + 46))
    draw_badge(draw, xs[0], ys[1], pw, "2A. NARROWED DASH + 0-HP BROKEN BRACES (CLIPS 36, 38)",
               "Clip 50 excludes Nodes [2,3,47,48] so 0-HP broken braces remain latched!", accent=(115, 225, 165))

    sc_2b, aud_2b = evaluate_narrowed_dash_multilayer(
        faf_ev, sb_ev,
        dash_clip_name="Dash_Narrowed_02_Sustained_Hold_Loop", dash_t=0.40,
        sim_pitch_deg=24.0, sim_shaft_tilt_deg=14.0,
        rotor_spin_t=0.35, sword_layer_mode="slash_override", sword_t=0.32,
        zero_hp_braces=True, additive_hull_buckle=1.0, include_enemy_target=False
    )
    im_2b = render_scene(combine_scenes(arena, sc_2b), [-2.15, 1.35, 1.85], [0.0, 1.12, 0.05], pw, ph - 46, fov_deg=38.0)
    d2b = ImageDraw.Draw(im_2b)
    d2b.rectangle([10, ph - 80, pw - 10, ph - 52], fill=(12, 22, 18), outline=(95, 225, 150), width=1)
    d2b.text((16, ph - 74), f"Sim Pitch + Additive Hull (Clip 40) + 0-HP Braces + Slash! Conflicts: {len(aud_2b['conflicts'])}", fill=(125, 245, 175), font=get_font(11, True))
    sheet.paste(im_2b, (xs[1], ys[1] + 46))
    draw_badge(draw, xs[1], ys[1], pw, "2B. SIM PITCH + ADDITIVE HULL (CLIP 40) + SLASH (CLIP 14)",
               "Node 1 receives +24° Sim Pitch + Additive Clip 40 buckle + Clip 14 Sword Slash", accent=(115, 225, 165))

    sc_2c, aud_2c = evaluate_narrowed_dash_multilayer(
        faf_ev, sb_ev,
        dash_clip_name="Dash_Narrowed_05_Collision_Interruption_Recovery", dash_t=0.22,
        sim_pitch_deg=-14.0, sim_shaft_tilt_deg=-9.0,
        rotor_spin_t=0.35, sword_layer_mode="guard_override", sword_t=0.40,
        zero_hp_braces=True, additive_hull_buckle=0.8, include_enemy_target=False
    )
    im_2c = render_scene(combine_scenes(arena, sc_2c), [-2.15, 1.35, 1.85], [0.0, 1.12, 0.05], pw, ph - 46, fov_deg=38.0)
    d2c = ImageDraw.Draw(im_2c)
    d2c.rectangle([10, ph - 80, pw - 10, ph - 52], fill=(12, 22, 18), outline=(95, 225, 150), width=1)
    d2c.text((16, ph - 74), f"Clip 53 Collision Recoil: 0.000000 Boundary Delta from Clip 50!", fill=(125, 245, 175), font=get_font(11, True))
    sheet.paste(im_2c, (xs[2], ys[1] + 46))
    draw_badge(draw, xs[2], ys[1], pw, "2C. NARROWED COLLISION INTERRUPTION (CLIP 53 @ t=0.22s)",
               "Seamless transition from Clip 50 on obstacle impact while keeping 0-HP braces broken", accent=(115, 225, 165))

    x2d, y2d = xs[3], ys[1]
    draw_badge(draw, x2d, y2d, pw, "2D. FULL-BODY SHOWCASE (81 CH) vs. NARROWED DASH (24/12 CH)",
               "Why Clips 19, 47, 48 Are Standalone While Clips 49..53 Are Runtime-Composable", accent=(245, 195, 95))
    draw.rectangle([x2d, y2d + 46, x2d + pw, y2d + ph], fill=(18, 21, 30), outline=(65, 78, 98), width=1)
    card_lines = [
        ("1. STANDALONE SHOWCASE CLIPS (Clips 19, 47, 48 — 81 Channels):", (245, 145, 125), True),
        ("   Animate 27 nodes [1..11, 16..22, 29, 56..59, 61..64]. Because they", (205, 218, 232), False),
        ("   include Chassis [1], Braces [2,3], Rotor [8..11, 61..64] & Sword [56..59],", (205, 218, 232), False),
        ("   they are NOT conflict-free with damage/combat layers if played unmasked.", (205, 218, 232), False),
        ("2. NARROWED PRODUCTION DASH CLIPS (Clips 49, 50, 51, 53 — 24 Ch):", (125, 245, 175), True),
        ("   Animate ONLY 8 posture/slipstream nodes [16, 17, 18, 19, 20, 21, 22, 29].", (205, 218, 232), False),
        ("   • Sim owns pitch (Nodes 1, 8) & rotor spin (Nodes 5..7, 9, 61..64).", (205, 218, 232), False),
        ("   • 0-HP Braces (Clips 36, 38 on [2,47,3,48]) stay permanently broken.", (205, 218, 232), False),
        ("   • Clip 40 Hull Buckle applies ADDITIVELY on Node 1.", (205, 218, 232), False),
        ("3. RESTING 3P DASH SWORD LAYER (Clip 52 — 12 Ch on [56..59]):", (125, 245, 175), True),
        ("   Priority 30 layer overridden cleanly by Clip 14 Slash (Prio 80) or Clip 26.", (205, 218, 232), False),
    ]
    cy = y2d + 58
    for txt, col, is_b in card_lines:
        draw.text((x2d + 12, cy), txt, fill=col, font=get_font(12 if is_b else 11, is_b))
        cy += 41 if is_b else 36

    x_tbl, y_tbl, w_tbl, h_tbl = 16, ys[2], W - 32, ph
    draw_badge(draw, x_tbl, y_tbl, w_tbl, "3. EXPLICIT RUNTIME TRACK-MASK, PRIORITY & ADDITIVE BLENDING CONTRACT (fight-and-flight-v29-narrowed-dash.glb)",
               "Resolves the two overlapping Node 1 (Chassis) tracks via Additive Blending and defines exact Node Masks for Dash, Combat, and 0-HP Destruction", accent=(115, 225, 165))
    draw.rectangle([x_tbl, y_tbl + 46, x_tbl + w_tbl, y_tbl + h_tbl], fill=(18, 21, 30), outline=(65, 78, 98), width=1)

    matrix_rows = [
        ("LAYER & PRIORITY", "ACTIVE CLIPS / SOURCE", "EXPLICIT NODE TRACK MASK", "BLEND MODE & OVERRIDE / LATCH RULE"),
        ("L0 (Prio 100): Sim Authority", "Codex Physics / Sim Direct", "Nodes [0, 1, 8, 9, 5, 6, 7]", "Base Override: Sim owns world pos, Dash pitch (+24°/+14°) & rotor RPM"),
        ("L1 (Prio 95): 0-HP Latches", "Clips 36 (L-Brace), 38 (R-Brace), 41 (Rotor)", "Nodes [2, 47, 3, 48, 8..11, 26, 61..65]", "Latched Override at 0 HP: Never overwritten by Dash (Clips 49..53) or Guard"),
        ("L2 (Prio 90): Rotor Halo", "Clip 0 (Rotor_Spin_Cycle_1Rev)", "Nodes [5, 6, 7, 9, 61, 62, 63, 64]", "Override when Rotor > 0 HP (Overridden by Clip 41 when Rotor = 0 HP)"),
        ("L3 (Prio 85): Partial Damage", "Clips 35, 37, 39 (Flex/Wobble) + Clip 40 (Hull)", "Override [2,40,3,41,8,10,11,65,4,66] + ADDITIVE [1]", "Clip 40 MUST use ADDITIVE blend on Node 1 over Gait_01..03 or Sim Pitch!"),
        ("L4 (Prio 70): Crossbow Gimbal", "Clips 13 (Aim), 2 (Fire), 3 (Reload)", "Nodes [12..15, 23..25, 43..46, 50..52, 55]", "Override on Crossbow Gimbal & Carousel (Disjoint from Dash & Gait)"),
        ("L5 (Prio 60): Narrowed Dash", "Clips 49 (Entry), 50 (Hold), 51 (Rel), 53 (Hit)", "Nodes [16, 17, 18, 19, 20, 21, 22, 29] (24 ch)", "Override on Banner, Legs & Rider Lean (0.0000 boundary delta; 0 overlap!)"),
        ("L6 (Prio 30/75/80): 3P Sword", "Clip 52 (Dash P30) < Clip 26 (Guard P75) < Clip 14 (Slash P80)", "Nodes [36, 56, 57, 58, 59] (Mask Clip 26 off [2,3]!)", "Priority Override: Slash (P80) & Guard (P75) cleanly override Dash Sword (P30)"),
    ]
    col_xs = [x_tbl + 16, x_tbl + 410, x_tbl + 980, x_tbl + 1560]
    ry = y_tbl + 58
    for r_idx, row_vals in enumerate(matrix_rows):
        is_hdr = (r_idx == 0)
        if is_hdr:
            draw.rectangle([x_tbl + 8, ry - 4, x_tbl + w_tbl - 8, ry + 32], fill=(28, 36, 50))
        elif r_idx % 2 == 1:
            draw.rectangle([x_tbl + 8, ry - 4, x_tbl + w_tbl - 8, ry + 48], fill=(22, 26, 36))
        for c_idx, val in enumerate(row_vals):
            col = (245, 215, 125) if is_hdr else ((135, 235, 175) if c_idx == 2 else (215, 225, 238))
            draw.text((col_xs[c_idx], ry + 4), val, fill=col, font=get_font(13 if is_hdr else 12, is_hdr or c_idx == 0))
        ry += 44 if is_hdr else 54

    out_path = OUT_DIR / "Fight_And_Flight_v29_InGame_ThirdPerson_Dash_And_TrackMask_Sheet.jpg"
    sheet.save(out_path, quality=93)
    print(f"Saved {out_path.name} ({out_path.stat().st_size:,} bytes)")


def build_showcase_video(ev29: StandardGltfEvaluator, ev30: StandardGltfEvaluator, faf_ev: StandardGltfEvaluator):
    print("Rendering Showcase Video: Castleward_v30_Spellblade_And_InGame_Dash_Showcase.mp4 ...")
    W, H = 1280, 720
    fps = 20
    n_frames = 120
    out_mp4 = OUT_DIR / "Castleward_v30_Spellblade_And_InGame_Dash_Showcase.mp4"
    tmp_mp4 = WORK_DIR / "Castleward_v30_Spellblade_And_InGame_Dash_Showcase.mp4"

    ov_open = {28: {"scale": [0.0, 0.0, 0.0]}, 29: {"scale": [1.0, 1.0, 1.0]}}
    sc29 = ev29.evaluate(None, 0.0, node_overrides=ov_open)
    sc30 = ev30.evaluate(None, 0.0, node_overrides=ov_open)
    arena = make_arena_corridor_scene(-0.35, target_x=-0.95, target_z=3.60)

    writer = imageio.get_writer(str(tmp_mp4), fps=fps, codec="libx264", quality=8)
    for fi in range(n_frames):
        t_sec = fi / float(fps)
        frame = Image.new("RGB", (W, H), (14, 16, 22))
        draw = ImageDraw.Draw(frame)
        draw.rectangle([0, 0, W, 52], fill=(20, 24, 34))
        draw.line([(0, 52), (W, 52)], fill=(235, 195, 95), width=2)

        if fi < 60:
            ang = 2.0 * math.pi * (fi / 60.0)
            rad = 2.45
            eye = [rad * math.sin(ang), 1.00, rad * math.cos(ang)]
            tgt = [0.0, 0.94, 0.0]
            draw.text((18, 8), "SPELLBLADE TURNAROUND: v2.9 BASELINE (LEFT) vs. v3.0 OVERLAPPING-ARMOR CANDIDATE (RIGHT)", fill=(245, 220, 135), font=get_font(16, True))
            draw.text((18, 29), "v3.0 adds raised brow plate, 7-tuft crest, 3-tier pauldrons/rerebraces, overlapping plackart, 3-tier faulds, winged couters & 4-lame sabatons", fill=(190, 205, 225), font=get_font(11, False))

            im_l = render_scene(sc29, eye, tgt, 616, 640, fov_deg=38.0)
            im_r = render_scene(sc30, eye, tgt, 616, 640, fov_deg=38.0)
            frame.paste(im_l, (16, 64))
            frame.paste(im_r, (648, 64))
            draw.rectangle([24, 660, 310, 694], fill=(24, 18, 12), outline=(225, 170, 85), width=1)
            draw.text((34, 669), "v2.9 Baseline (14,392 Tris)", fill=(245, 195, 115), font=get_font(13, True))
            draw.rectangle([656, 660, 980, 694], fill=(12, 24, 18), outline=(95, 225, 150), width=1)
            draw.text((666, 669), "v3.0 Refined Candidate (15,874 Tris)", fill=(125, 245, 175), font=get_font(13, True))
        else:
            u = (fi - 60) / 60.0
            d_time = u * 2.40
            if d_time < 0.38:
                d_clip = "Dash_Narrowed_01_Entry_Posture"
                dt_local = d_time
                w_p = d_time / 0.38
                sim_p, sim_s = 24.0 * w_p, 14.0 * w_p
                sw_mode, sw_t = "resting_dash", d_time
                phase_lbl = "Phase 1: Narrowed Dash Entry (Clip 49)"
            elif d_time < 1.70:
                d_clip = "Dash_Narrowed_02_Sustained_Hold_Loop"
                dt_local = (d_time - 0.38) % 0.80
                sim_p, sim_s = 24.0, 14.0
                if 0.85 <= d_time <= 1.45:
                    sw_mode, sw_t = "slash_override", (d_time - 0.85) / 0.60 * 0.75
                    phase_lbl = "Phase 2B: Sustained Dash (Clip 50) + Mid-Dash Sword Slash Override (Clip 14)!"
                else:
                    sw_mode, sw_t = "resting_dash", dt_local
                    phase_lbl = "Phase 2A: Sustained Dash Hold (Clip 50) + Resting 3P Sword (Clip 52)"
            else:
                d_clip = "Dash_Narrowed_03_Release_Flare_Recovery"
                dt_local = min(0.70, d_time - 1.70)
                w_r = dt_local / 0.70
                flare_w = math.sin(math.pi * w_r)
                sim_p = 24.0 * (1.0 - w_r) - 10.5 * flare_w
                sim_s = 14.0 * (1.0 - w_r) - 8.0 * flare_w
                sw_mode, sw_t = "guard_override", 0.35
                phase_lbl = "Phase 3: Narrowed Release Braking Flare (Clip 51) + Guard Override (Clip 26)"

            draw.text((18, 8), f"IN-GAME 3P DASH CHASE VIEW (LEFT) & NARROWED MULTI-LAYER COMPOSITION (RIGHT) — {phase_lbl}", fill=(245, 220, 135), font=get_font(15, True))
            draw.text((18, 29), "Sim owns pitch & rotor spin | 0-HP braces stay broken (Clips 36,38) | Clip 40 Hull Buckle is Additive | Clip 14 Slash overrides Clip 52", fill=(190, 205, 225), font=get_font(11, False))

            sc_chase, _ = evaluate_narrowed_dash_multilayer(
                faf_ev, ev30,
                dash_clip_name=d_clip, dash_t=dt_local,
                sim_pitch_deg=sim_p, sim_shaft_tilt_deg=sim_s,
                rotor_spin_t=(t_sec * 1.8) % 1.0,
                sword_layer_mode=sw_mode, sword_t=sw_t,
                zero_hp_braces=False, additive_hull_buckle=0.0, include_enemy_target=True
            )
            sc_comp, _ = evaluate_narrowed_dash_multilayer(
                faf_ev, ev30,
                dash_clip_name=d_clip, dash_t=dt_local,
                sim_pitch_deg=sim_p, sim_shaft_tilt_deg=sim_s,
                rotor_spin_t=(t_sec * 1.8) % 1.0,
                sword_layer_mode=sw_mode, sword_t=sw_t,
                zero_hp_braces=True, additive_hull_buckle=0.85, include_enemy_target=False
            )
            im_l = render_scene(combine_scenes(arena, sc_chase), [-1.05, 1.48, -2.55], [-0.50, 0.92, 3.60], 616, 640, fov_deg=42.0)
            im_r = render_scene(combine_scenes(arena, sc_comp),  [-2.15, 1.35,  1.85], [ 0.00, 1.12, 0.05], 616, 640, fov_deg=38.0)
            frame.paste(im_l, (16, 64))
            frame.paste(im_r, (648, 64))
            draw.rectangle([24, 660, 480, 694], fill=(12, 24, 18), outline=(95, 225, 150), width=1)
            draw.text((34, 669), "In-Game 3P Chase View (Target Sightline Unobstructed)", fill=(125, 245, 175), font=get_font(12, True))
            draw.rectangle([656, 660, 1245, 694], fill=(12, 24, 18), outline=(235, 195, 95), width=1)
            draw.text((666, 669), "Narrowed Dash + 0-HP Broken Braces + Additive Hull + Sword Override", fill=(245, 215, 125), font=get_font(12, True))

        writer.append_data(np.array(frame))
    writer.close()
    out_mp4.write_bytes(tmp_mp4.read_bytes())
    print(f"Saved {out_mp4.name} ({out_mp4.stat().st_size:,} bytes)")


def main():
    ev29 = StandardGltfEvaluator(str(SB_V29_GLB))
    ev30 = StandardGltfEvaluator(str(SB_V30_GLB))
    faf_ev = StandardGltfEvaluator(str(FAF_ND_GLB))

    build_sheet_3_ingame_dash_and_trackmasks(faf_ev, ev30)
    build_showcase_video(ev29, ev30, faf_ev)
    print("UPDATED SHEET 3 & VIDEO COMPLETED SUCCESSFULLY.")


if __name__ == "__main__":
    main()
