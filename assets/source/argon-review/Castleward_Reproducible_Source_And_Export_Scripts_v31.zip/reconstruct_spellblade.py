import io
import os
import struct
import numpy as np
from PIL import Image, ImageDraw
from blend_io import BlendFile
from mesh_builder import MeshBuilder, BoneFrame, PALETTE


def rot_z(pts, deg, pivot=(0.0, 0.0)):
    if abs(deg) < 1e-5:
        return [(float(p[0]), float(p[1]), float(p[2])) for p in pts]
    rad = np.radians(deg)
    c, s = np.cos(rad), np.sin(rad)
    px, py = pivot
    out = []
    for p in pts:
        x, y, z = p[0] - px, p[1] - py, p[2]
        nx = x * c - y * s + px
        ny = x * s + y * c + py
        out.append((float(nx), float(ny), float(z)))
    return out



def transform_helmet_builder(mb, scale=1.15, pitch_deg=13.8, roll_deg=10.2, yaw_deg=9.5, pivot=(0.0, 0.04, 1.82), shift=(-0.006, -0.074, 0.038)):
    """
    Applies the calibrated heroic chin-down pitch (+11 deg), head roll (+5.2 deg tilting crown toward viewer right and chin toward viewer left),
    head yaw (+9.5 deg), 1.20x heroic head scale, and neck offset to match the 896x896 Helmet Focus and 500x800 Hero 3/4 concept grids!
    """
    px, py, pz = pivot
    sx, sy, sz = shift
    rp = np.radians(pitch_deg)
    cp, sp = np.cos(rp), np.sin(rp)
    rr = np.radians(roll_deg)
    cr, sr = np.cos(rr), np.sin(rr)
    ry = np.radians(yaw_deg)
    cy, sy_r = np.cos(ry), np.sin(ry)

    for i, (x, y, z) in enumerate(mb.verts):
        dx = (x - px) * scale
        dy = (y - py) * scale
        dz = (z - pz) * scale
        # 1. Chin-down pitch around X-axis:
        dy1 = dy * cp + dz * sp
        dz1 = -dy * sp + dz * cp
        dx1 = dx
        # 2. Head roll around Y-axis (+roll tilts +Z toward -X / viewer right, and -Z toward +X / viewer left):
        dxr = dx1 * cr - dz1 * sr
        dzr = dx1 * sr + dz1 * cr
        dyr = dy1
        # 3. Yaw around Z-axis:
        dx2 = dxr * cy - dyr * sy_r
        dy2 = dxr * sy_r + dyr * cy
        dz2 = dzr
        mb.verts[i] = (float(px + dx2 + sx), float(py + dy2 + sy), float(pz + dz2 + sz))
    return mb

def add_sharp_cube(mb, center, half_extents, weights, mat="SORCERY", col="WHITE"):
    cx, cy, cz = center
    hx, hy, hz = half_extents
    r0 = [(cx-hx, cy+hy, cz-hz), (cx+hx, cy+hy, cz-hz), (cx+hx, cy-hy, cz-hz), (cx-hx, cy-hy, cz-hz)]
    r1 = [(cx-hx, cy+hy, cz+hz), (cx+hx, cy+hy, cz+hz), (cx+hx, cy-hy, cz+hz), (cx-hx, cy-hy, cz+hz)]
    mb.add_loft([r0, r1], weights=weights, mat=mat, colors=col, closed_ring=True, cap_start=True, cap_end=True, cap_color=col)


def add_framed_rect_plate(mb, corners_3d, normal_dir, thickness, border_frac, weights,
                          mat_border="METAL", col_border="BRASS_MAIN", col_border_edge="BRASS_BRIGHT",
                          mat_inner="MATTE", col_inner="LEATHER_MAIN", open_top=False):
    pts = [np.array(p, dtype=np.float32) for p in corners_3d]
    n = np.array(normal_dir, dtype=np.float32)
    n /= np.linalg.norm(n)
    c = np.mean(pts, axis=0)

    in_pts = []
    for i, p in enumerate(pts):
        ip = p * (1.0 - border_frac) + c * border_frac
        if open_top and i in (0, 1):
            ip[2] = p[2] - 0.004
        in_pts.append(ip)

    v_back   = [mb.add_vert(p - 0.25 * thickness * n, weights) for p in pts]
    v_out_f  = [mb.add_vert(p + 0.85 * thickness * n, weights) for p in pts]
    v_in_f   = [mb.add_vert(p + 0.85 * thickness * n, weights) for p in in_pts]
    v_in_rec = [mb.add_vert(p + 0.40 * thickness * n, weights) for p in in_pts]

    ref = c - 0.2 * thickness * n
    for i in range(4):
        inext = (i + 1) % 4
        if open_top and i == 0:
            mb.add_quad(v_back[i], v_back[inext], v_out_f[inext], v_out_f[i], mat=mat_inner, color=col_inner, outward_ref=ref)
            mb.add_quad(v_out_f[i], v_out_f[inext], v_in_f[inext], v_in_f[i], mat=mat_inner, color=col_inner, outward_ref=ref)
            mb.add_quad(v_in_f[i], v_in_f[inext], v_in_rec[inext], v_in_rec[i], mat=mat_inner, color=col_inner, outward_ref=c + thickness * n)
        else:
            mb.add_quad(v_back[i], v_back[inext], v_out_f[inext], v_out_f[i], mat=mat_border, color=col_border, outward_ref=ref)
            b_col = col_border_edge if i in (0, 3) else col_border
            mb.add_quad(v_out_f[i], v_out_f[inext], v_in_f[inext], v_in_f[i], mat=mat_border, color=b_col, outward_ref=ref)
            mb.add_quad(v_in_f[i], v_in_f[inext], v_in_rec[inext], v_in_rec[i], mat=mat_border, color="BRASS_SHADE", outward_ref=c + thickness * n)

    mb.add_poly(v_in_rec, mat=mat_inner, color=col_inner, outward_ref=ref)
    mb.add_poly(v_back[::-1], mat=mat_inner, color="UNDERSUIT_DARK", outward_ref=c + thickness * n)


def upgrade_banner_texture(bf):
    W, H = 1024, 1024
    u_grid = np.linspace(0.0, 1.0, W, dtype=np.float32)[None, :]
    v_grid = np.linspace(1.0, 0.0, H, dtype=np.float32)[:, None]

    local_u = np.mod(u_grid, 0.5) / 0.5
    fold_wave = 0.045 * np.cos((local_u - 0.5) * 4.0 * np.pi) + 0.025 * np.cos((local_u - 0.5) * 2.0 * np.pi)
    vert_grad = -0.04 * (1.0 - v_grid)

    crimson_base = np.array([0.46, 0.115, 0.130], dtype=np.float32)
    rgb = np.clip(crimson_base[None, None, :] + (fold_wave + vert_grad)[:, :, None], 0.04, 1.0)

    gold_main = (186, 146,  96)
    gold_hi   = (208, 168, 114)
    dark_line = ( 34,  12,  16)

    img = Image.fromarray((rgb * 255).astype(np.uint8), mode="RGB")
    draw = ImageDraw.Draw(img)

    def u_px(u_val):
        return int(round(u_val * (W - 1)))

    def v_px(v_val):
        return int(round((1.0 - v_val) * (H - 1)))

    # Outer gold borders (u = 0.000..0.083 and 0.417..0.500, which terminate at the first mesh step v = 0.118)
    draw.rectangle([u_px(0.000), v_px(1.000), u_px(0.083), v_px(0.118)], fill=gold_main)
    draw.rectangle([u_px(0.417), v_px(1.000), u_px(0.500), v_px(0.118)], fill=gold_main)
    # Inward L-hook gold step at the bottom of the first step (v = 0.118..0.172 across u = 0.083..0.138 and 0.362..0.417)
    draw.rectangle([u_px(0.083), v_px(0.172), u_px(0.138), v_px(0.118)], fill=gold_main)
    draw.rectangle([u_px(0.362), v_px(0.172), u_px(0.417), v_px(0.118)], fill=gold_main)
    # Crisp dark groove framing the inner edge of the gold border and L-hook
    draw.rectangle([u_px(0.083), v_px(0.960), u_px(0.089), v_px(0.172)], fill=dark_line)
    draw.rectangle([u_px(0.411), v_px(0.960), u_px(0.417), v_px(0.172)], fill=dark_line)
    draw.rectangle([u_px(0.083), v_px(0.178), u_px(0.144), v_px(0.172)], fill=dark_line)
    draw.rectangle([u_px(0.356), v_px(0.178), u_px(0.417), v_px(0.172)], fill=dark_line)
    draw.rectangle([u_px(0.138), v_px(0.178), u_px(0.144), v_px(0.118)], fill=dark_line)
    draw.rectangle([u_px(0.356), v_px(0.178), u_px(0.362), v_px(0.118)], fill=dark_line)

    # METabardBack complete 3-Step Staircase Gold Border wrapping all the way around the bottom center tongue (matching Concept Art: Back!):
    # Step 1 (Outer columns u = 0.500..0.583 and 0.917..1.000, down to v = 0.162)
    draw.rectangle([u_px(0.500), v_px(1.000), u_px(0.583), v_px(0.162)], fill=gold_main)
    draw.rectangle([u_px(0.917), v_px(1.000), u_px(1.000), v_px(0.162)], fill=gold_main)
    # Step 2 (Middle columns u = 0.583..0.667 and 0.833..0.917, v = 0.094..0.218)
    draw.rectangle([u_px(0.583), v_px(0.218), u_px(0.667), v_px(0.094)], fill=gold_main)
    draw.rectangle([u_px(0.833), v_px(0.218), u_px(0.917), v_px(0.094)], fill=gold_main)
    # Step 3 (Center tongue perimeter: left/right vertical gold bars u = 0.667..0.712 and 0.788..0.833 from v = 0.000..0.148, plus bottom horizontal gold bar u = 0.667..0.833 from v = 0.000..0.052!)
    draw.rectangle([u_px(0.667), v_px(0.148), u_px(0.712), v_px(0.000)], fill=gold_main)
    draw.rectangle([u_px(0.788), v_px(0.148), u_px(0.833), v_px(0.000)], fill=gold_main)
    draw.rectangle([u_px(0.667), v_px(0.052), u_px(0.833), v_px(0.000)], fill=gold_main)
    # Crisp dark groove framing the entire 3-step staircase inner perimeter
    draw.rectangle([u_px(0.583), v_px(0.960), u_px(0.589), v_px(0.218)], fill=dark_line)
    draw.rectangle([u_px(0.911), v_px(0.960), u_px(0.917), v_px(0.218)], fill=dark_line)
    draw.rectangle([u_px(0.583), v_px(0.224), u_px(0.673), v_px(0.218)], fill=dark_line)
    draw.rectangle([u_px(0.827), v_px(0.224), u_px(0.917), v_px(0.218)], fill=dark_line)
    draw.rectangle([u_px(0.667), v_px(0.224), u_px(0.673), v_px(0.148)], fill=dark_line)
    draw.rectangle([u_px(0.827), v_px(0.224), u_px(0.833), v_px(0.148)], fill=dark_line)
    draw.rectangle([u_px(0.667), v_px(0.154), u_px(0.718), v_px(0.148)], fill=dark_line)
    draw.rectangle([u_px(0.782), v_px(0.154), u_px(0.833), v_px(0.148)], fill=dark_line)
    draw.rectangle([u_px(0.712), v_px(0.154), u_px(0.718), v_px(0.052)], fill=dark_line)
    draw.rectangle([u_px(0.782), v_px(0.154), u_px(0.788), v_px(0.052)], fill=dark_line)
    draw.rectangle([u_px(0.712), v_px(0.058), u_px(0.788), v_px(0.052)], fill=dark_line)

    def draw_trident(uc, vc, sc_u, sc_v):
        def pt(du, dv):
            return (u_px(uc + du * sc_u), v_px(vc + dv * sc_v))

        spear_poly = [
            pt( 0.000,  0.225),
            pt(-0.042,  0.065),
            pt(-0.015,  0.080),
            pt(-0.015, -0.010),
            pt(-0.052,  0.024),
            pt(-0.062,  0.095),
            pt(-0.088,  0.038),
            pt(-0.072,  0.028),
            pt(-0.076, -0.012),
            pt(-0.016, -0.062),
            pt(-0.015, -0.120),
            pt(-0.032, -0.142),
            pt( 0.000, -0.205),
            pt( 0.032, -0.142),
            pt( 0.015, -0.120),
            pt( 0.016, -0.062),
            pt( 0.076, -0.012),
            pt( 0.072,  0.028),
            pt( 0.088,  0.038),
            pt( 0.062,  0.095),
            pt( 0.052,  0.024),
            pt( 0.015, -0.010),
            pt( 0.015,  0.080),
            pt( 0.042,  0.065),
        ]
        draw.polygon(spear_poly, fill=gold_main, outline=dark_line)
        hi_poly = [
            pt( 0.000,  0.225),
            pt(-0.042,  0.065),
            pt(-0.015,  0.080),
            pt(-0.015, -0.120),
            pt(-0.032, -0.142),
            pt( 0.000, -0.205),
        ]
        draw.polygon(hi_poly, fill=gold_hi)

    draw_trident(0.250, 0.455, 1.24, 1.08)
    draw_trident(0.750, 0.665, 1.24, 1.08)

    out_rgba = img.convert("RGBA")
    bf.update_packed_image("IMSpellbladeBanner", out_rgba)


def build_helmet_shell():
    """
    V81 Contour-Locked Box-Helm Shell:
    - Calibrated to the 896x896 Helmet Focus Green Contour Overlay (Row 3, Col 4) with a crisp brow overhang and clean eye-slit clearance!
    """
    mb = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    w = "head"

    def box_helm_ring(rx_front, yf_c, yf_corner, rx_side, yb_side, rx_back, yb_back, yb_c, z_c, z_corner, z_side, z_back):
        return [
            ( 0.000,           yf_c,      z_c),              # 0: Front center
            (-rx_front * 1.04, yf_corner, z_corner - 0.008), # 1: Left (-X, viewer right) Front-Outer Brow Corner
            (-rx_side  * 1.03, yb_side,   z_side   - 0.005), # 2: Left (-X) Rear-Side Corner
            (-rx_back,         yb_back,   z_back),           # 3: Left (-X) Back Corner
            ( 0.000,           yb_c,      z_back),           # 4: Back center
            ( rx_back,         yb_back,   z_back),           # 5: Right (+X, viewer left) Back Corner
            ( rx_side,         yb_side,   z_side),           # 6: Right (+X, viewer left) Rear-Side Corner
            ( rx_front,        yf_corner, z_corner),         # 7: Right (+X, viewer left) Front-Outer Brow Corner
        ]

    r0     = box_helm_ring(0.098, 0.238, 0.206, 0.127, 0.022, 0.106, -0.076, -0.114, 1.888, 1.904, 1.900, 1.888)
    r1_lip = box_helm_ring(0.100, 0.233, 0.201, 0.129, 0.020, 0.108, -0.078, -0.116, 1.938, 1.951, 1.946, 1.934)
    r1_out = box_helm_ring(0.097, 0.228, 0.196, 0.126, 0.019, 0.105, -0.076, -0.114, 1.942, 1.955, 1.950, 1.938)
    r1_in  = box_helm_ring(0.088, 0.215, 0.183, 0.116, 0.016, 0.096, -0.068, -0.104, 1.948, 1.961, 1.956, 1.943)
    r2     = box_helm_ring(0.064, 0.184, 0.156, 0.082, 0.012, 0.070, -0.052, -0.088, 2.010, 2.012, 2.004, 1.992)

    cols_brow    = ["STEEL_MAIN",  "STEEL_FACET", "STEEL_FACET", "STEEL_MAIN",  "STEEL_MAIN",  "STEEL_FACET", "STEEL_MAIN",  "STEEL_LIGHT"]
    cols_lip     = ["STEEL_LIGHT", "STEEL_MAIN",  "STEEL_FACET", "STEEL_LIGHT", "STEEL_LIGHT", "STEEL_MAIN",  "STEEL_EDGE",  "STEEL_BRIGHT"]
    cols_step    = ["STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE"]
    cols_chamfer = ["STEEL_LIGHT", "STEEL_MAIN",  "STEEL_FACET", "STEEL_MAIN",  "STEEL_MAIN",  "STEEL_MAIN",  "STEEL_LIGHT", "STEEL_BRIGHT"]

    mb.add_loft(
        [r0, r1_lip, r1_out, r1_in, r2],
        weights=w,
        mat="METAL",
        colors=[cols_brow, cols_lip, cols_step, cols_chamfer],
        closed_ring=True,
        cap_start=True,
        cap_end=True,
        cap_color="STEEL_LIGHT",
    )

    rb0 = [(-0.124, 0.018, 1.872), (-0.108, -0.080, 1.868), (0.0, -0.118, 1.866), (0.108, -0.080, 1.868), (0.124, 0.018, 1.872)]
    rb1 = [(-0.126, 0.018, 1.902), (-0.110, -0.082, 1.898), (0.0, -0.120, 1.896), (0.110, -0.082, 1.898), (0.126, 0.018, 1.902)]
    rb2 = [(-0.116, 0.018, 1.906), (-0.100, -0.072, 1.902), (0.0, -0.108, 1.900), (0.100, -0.072, 1.902), (0.116, 0.018, 1.906)]
    mb.add_loft([rb0, rb1, rb2], weights=w, mat="METAL", colors=[["STEEL_MAIN", "STEEL_LIGHT", "STEEL_LIGHT", "STEEL_MAIN"], ["STEEL_EDGE", "STEEL_BRIGHT", "STEEL_BRIGHT", "STEEL_EDGE"]], closed_ring=False)

    for sign in (-1.0, 1.0):
        rx_mult = 1.03 if sign < 0 else 1.0
        x_eb = sign * 0.125 * rx_mult
        if sign > 0:
            eb_corners = [
                (x_eb - 0.002, 0.104, 1.882),
                (x_eb + 0.003, 0.022, 1.878),
                (x_eb + 0.001, 0.024, 1.776),
                (x_eb - 0.003, 0.106, 1.772),
            ]
        else:
            eb_corners = [
                (x_eb - 0.003, 0.022, 1.874),
                (x_eb + 0.002, 0.104, 1.878),
                (x_eb + 0.003, 0.106, 1.768),
                (x_eb - 0.001, 0.024, 1.772),
            ]
        add_framed_rect_plate(
            mb, eb_corners, normal_dir=(sign * 0.98, 0.14, 0.04),
            thickness=0.018, border_frac=0.34, weights=w,
            mat_border="METAL", col_border="STEEL_LIGHT" if sign > 0 else "STEEL_MAIN", col_border_edge="STEEL_EDGE",
            mat_inner="MATTE", col_inner="FACE_DARK",
            open_top=False
        )

    def gold_trim_ring(hx_out, hx_in, yf_face, yf_base, z_face, z_base):
        return [
            ( 0.000,   yf_face + 0.003, z_face),
            (-hx_in,   yf_face,         z_face),
            (-hx_out,  yf_base,         z_base),
            ( 0.000,   yf_base,         z_base),
            ( hx_out,  yf_base,         z_base),
            ( hx_in,   yf_face,         z_face),
        ]

    b0 = gold_trim_ring(0.003, 0.002, 0.248, 0.226, 1.854, 1.856)
    b1 = gold_trim_ring(0.029, 0.023, 0.250, 0.228, 1.888, 1.888)
    b2 = gold_trim_ring(0.029, 0.023, 0.238, 0.214, 1.942, 1.940)
    b3 = gold_trim_ring(0.030, 0.024, 0.212, 0.176, 2.020, 2.004)
    b4 = gold_trim_ring(0.030, 0.024, 0.035, 0.035, 2.018, 2.002)

    g_cols_brow  = ["BRASS_MAIN",   "BRASS_SHADE", "BRASS_DARK", "BRASS_DARK", "BRASS_SHADE", "BRASS_BRIGHT"]
    g_cols_chamf = ["BRASS_MAIN",   "BRASS_SHADE", "BRASS_DARK", "BRASS_DARK", "BRASS_SHADE", "BRASS_BRIGHT"]
    g_cols_top   = ["BRASS_BRIGHT", "BRASS_MAIN",  "BRASS_SHADE","BRASS_DARK", "BRASS_MAIN",  "BRASS_BRIGHT"]
    mb.add_loft(
        [b0, b1, b2, b3, b4],
        weights=w,
        mat="METAL",
        colors=[g_cols_brow, g_cols_brow, g_cols_chamf, g_cols_top],
        closed_ring=True,
        cap_start=True,
        cap_end=True,
        cap_color="BRASS_BRIGHT",
    )

    return mb


def build_helmet_jaw():
    """
    V82 Flat-Planed Wedge Jaw & Un-Occluded Visor Sill:
    - Keeps j_top (z_in=1.842, z_cheek=1.860, yf_step=0.218) and j_sill (z_in=1.846, z_cheek=1.864) cleanly below the 4-vertex parallelogram eye bar (z=1.866..1.898) so zero grey metal ever pinches or blocks the horizontal cyan eye slits!
    """
    mb = MeshBuilder(["MAKitMatte", "MAKitMetal"])
    w = "head"

    def cav_ring(z):
        return [
            ( 0.000,  0.194, z),
            (-0.026,  0.192, z),
            (-0.092,  0.168, z),
            (-0.104,  0.115, z),
            ( 0.000, -0.065, z),
            ( 0.104,  0.115, z),
            ( 0.092,  0.168, z),
            ( 0.026,  0.192, z),
        ]

    mb.add_loft([cav_ring(1.726), cav_ring(1.930)], weights=w, mat="MATTE", colors="FACE_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    mb.add_beveled_box(
        center=(0.000, 0.202, 1.792),
        half_extents=(0.005, 0.006, 0.058),
        bevel=0.18,
        weights=w,
        mat="METAL",
        col_main="STEEL_DARK",
        col_edge="STEEL_FACET",
        col_dark="FACE_DARK",
    )

    def jaw_shell_ring(x_in, yf_in, x_step, yf_step, x_cheek, yf_cheek, x_temp, yf_temp, rx_side, yb_side, rx_back, yb_back, yb_c, z_in, z_cheek, z_temp, z_side, z_back, dz_r=0.0):
        return [
            (-x_in,          yf_in,    z_in),
            (-x_step,        yf_step,  z_in),
            (-x_cheek*1.04,  yf_cheek, z_cheek + dz_r),
            (-x_temp *1.04,  yf_temp,  z_temp  + dz_r),
            (-rx_side*1.03,  yb_side,  z_side  + dz_r*0.6),
            (-rx_back,       yb_back,  z_back),
            ( 0.000,         yb_c,     z_back),
            ( rx_back,       yb_back,  z_back),
            ( rx_side,       yb_side,  z_side),
            ( x_temp,        yf_temp,  z_temp),
            ( x_cheek,       yf_cheek, z_cheek),
            ( x_step,        yf_step,  z_in),
            ( x_in,          yf_in,    z_in),
        ]

    j_under   = jaw_shell_ring(0.032, 0.198, 0.048, 0.214, 0.089, 0.200, 0.090, 0.199, 0.122, 0.022, 0.105, -0.076, -0.116, 1.728, 1.742, 1.743, 1.754, 1.746, dz_r=-0.005)
    j_bot_lip = jaw_shell_ring(0.032, 0.202, 0.050, 0.218, 0.091, 0.204, 0.092, 0.203, 0.125, 0.022, 0.108, -0.079, -0.119, 1.742, 1.756, 1.757, 1.768, 1.760, dz_r=-0.005)
    j_bot_in  = jaw_shell_ring(0.032, 0.200, 0.049, 0.216, 0.090, 0.202, 0.091, 0.201, 0.123, 0.022, 0.106, -0.077, -0.117, 1.745, 1.759, 1.760, 1.771, 1.763, dz_r=-0.005)
    j_top     = jaw_shell_ring(0.032, 0.202, 0.050, 0.218, 0.095, 0.204, 0.096, 0.203, 0.127, 0.022, 0.106, -0.076, -0.116, 1.842, 1.860, 1.902, 1.900, 1.888, dz_r=-0.008)
    j_sill    = jaw_shell_ring(0.032, 0.194, 0.046, 0.198, 0.091, 0.190, 0.093, 0.192, 0.120, 0.022, 0.100, -0.072, -0.112, 1.846, 1.864, 1.904, 1.902, 1.890, dz_r=-0.008)

    jaw_rim_cols = [
        "STEEL_DARK",  "STEEL_FACET", "STEEL_DARK", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET",
        "STEEL_FACET", "STEEL_MAIN",  "STEEL_MAIN", "STEEL_DARK",  "STEEL_LIGHT", "STEEL_FACET"
    ]
    jaw_step_cols = [
        "STEEL_SHADE", "STEEL_DARK", "STEEL_DARK", "STEEL_DARK", "STEEL_DARK", "STEEL_DARK",
        "STEEL_DARK",  "STEEL_DARK", "STEEL_DARK", "STEEL_DARK", "STEEL_DARK", "STEEL_DARK"
    ]
    jaw_face_cols = [
        "STEEL_DARK",  # 0->1: Left deep 45-deg inner visor crevice wall
        "STEEL_MAIN",  # 1->2: Left flat front cheek facet
        "STEEL_SHADE", # 2->3: Left razor-vertical outer eye-slit crevice wall
        "STEEL_FACET", # 3->4: Left 45-deg side cheek/temple facet
        "STEEL_FACET", # 4->5: Left rear temple
        "STEEL_FACET", # 5->6: Left back skull
        "STEEL_FACET", # 6->7: Right back skull
        "STEEL_MAIN",  # 7->8: Right rear temple
        "STEEL_MAIN",  # 8->9: Right 45-deg side cheek/temple facet
        "STEEL_SHADE", # 9->10: Right razor-vertical outer eye-slit crevice wall
        "STEEL_LIGHT", # 10->11: Right flat front cheek facet
        "STEEL_FACET", # 11->12: Right 45-deg inner visor crevice wall
    ]
    jaw_sill_cols = [
        "STEEL_SHADE", "STEEL_DARK", "STEEL_SHADE", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET",
        "STEEL_FACET", "STEEL_MAIN", "STEEL_MAIN",  "STEEL_SHADE", "STEEL_FACET", "STEEL_SHADE"
    ]
    mb.add_loft(
        [j_under, j_bot_lip, j_bot_in, j_top, j_sill],
        weights=w,
        mat="METAL",
        colors=[jaw_rim_cols, jaw_step_cols, jaw_face_cols, jaw_sill_cols],
        closed_ring=False,
    )

    return mb


def build_visor():
    """
    V82 Razor-Clean 4-Vertex Parallelogram L-Shaped Cyan Visor Bars:
    - Uses a pure 4-vertex parallelogram for the horizontal eye bar (x=0.018..0.091, z_bot=1.864..1.878, z_top=1.882..1.896 at y_in=0.222, y_out=0.205) and starts the vertical bar cleanly at the bottom edge of the eye bar (z=1.866 down to 1.734) so there is zero vertical stub sticking up above the eye bar and zero occlusion from the cheekplate!
    """
    mb = MeshBuilder(["MAVisorGlow"])
    w = "head"

    for sign in (-1.0, 1.0):
        dz_out = -0.008 if sign < 0 else 0.0
        eye_pts = [
            (sign * 0.0180, 0.222, 1.882),
            (sign * 0.0910, 0.205, 1.898 + dz_out),
            (sign * 0.0900, 0.205, 1.878 + dz_out),
            (sign * 0.0180, 0.222, 1.864),
        ]
        mb.add_flat_beveled_plate(
            eye_pts, normal_dir=(sign * 0.18, 0.98, 0.0), thickness=0.006, bevel_inset=0.06, weights=w,
            mat="VISOR", col_face="WHITE", col_edge="WHITE", col_side="WHITE", col_back="WHITE"
        )

        vert_pts = [
            (sign * 0.0180, 0.222, 1.868),
            (sign * 0.0315, 0.218, 1.870),
            (sign * 0.0300, 0.208, 1.736),
            (sign * 0.0180, 0.211, 1.734),
        ]
        mb.add_flat_beveled_plate(
            vert_pts, normal_dir=(sign * 0.12, 0.99, 0.0), thickness=0.006, bevel_inset=0.06, weights=w,
            mat="VISOR", col_face="WHITE", col_edge="WHITE", col_side="WHITE", col_back="WHITE"
        )

    return mb


def build_crest():
    """
    V81 Flat-Fronted Beveled Spartan Crimson Plume Crest:
    """
    mb = MeshBuilder(["MAKitMatte"])
    w = "head"

    blocks_spec = [
        ( 0.145, 2.012,  0.136, 2.116,  0.028, 2.008,  0.016, 2.102, 0.027, 0.023),
        ( 0.032, 1.998,  0.020, 2.056, -0.054, 1.976, -0.076, 2.030, 0.024, 0.021),
        (-0.048, 1.970, -0.070, 2.008, -0.112, 1.908, -0.156, 1.958, 0.023, 0.020),
        (-0.106, 1.902, -0.148, 1.942, -0.124, 1.792, -0.186, 1.842, 0.022, 0.019),
    ]

    for (yfb, zfb, yft, zft, ybb, zbb, ybt, zbt, hwb, hwt) in blocks_spec:
        def c_horiz_ring(yf, zf, yb, zb, hw):
            return [
                ( 0.000,     yf + 0.001, zf),
                (-hw,        yf,         zf),
                (-hw * 0.94, yb,         zb),
                ( 0.000,     yb - 0.002, zb),
                ( hw * 0.94, yb,         zb),
                ( hw,        yf,         zf),
            ]

        r_bot = c_horiz_ring(yfb, zfb, ybb, zbb, hwb)
        ym_f, zm_f = 0.12*yfb + 0.88*yft, 0.12*zfb + 0.88*zft
        ym_b, zm_b = 0.12*ybb + 0.88*ybt, 0.12*zbb + 0.88*zbt
        r_mid = c_horiz_ring(ym_f, zm_f, ym_b, zm_b, hwt)
        r_top = c_horiz_ring(yft - 0.006, zft, ybt + 0.006, zbt, hwt * 0.84)

        cols_body = ["CLOTH_MAIN",  "CLOTH_SHADE", "CLOTH_MAIN",  "CLOTH_LIGHT", "CLOTH_BRIGHT", "CLOTH_MAIN"]
        cols_bevl = ["CLOTH_LIGHT", "CLOTH_MAIN",  "CLOTH_LIGHT", "CLOTH_BRIGHT","CLOTH_BRIGHT", "CLOTH_LIGHT"]
        mb.add_loft([r_bot, r_mid, r_top], weights=w, mat="MATTE", colors=[cols_body, cols_bevl], closed_ring=True, cap_start=True, cap_end=True, cap_color="CLOTH_BRIGHT")

    return mb


def build_pauldron_left():
    """
    V81 Sharp Upward-Sweeping 4-Facet Fortress Pauldron:
    - Keeps the 50-deg diagonal Upper Gold Collar (s1/ic1) and 4-facet mid-ridge (Point 1 at 50% height), while removing the drooping s4/rm3 tip so s3 (at x=-0.470, z=1.508..1.596) and rm2 (sweeping sharply upward from z=1.434 at rm1 to z=1.478..1.534 at rm2!) form the exact crisp, upward-sweeping V-wing silhouette of Concept: Pauldron!
    """
    mb = MeshBuilder(["MAKitMetal"])
    w = "clavicle.L"

    def p_wing_sec(x_bot, x_mid, x_top, wrap_x, yf_bot, yf_mid, yf_top, z_bot, z_mid, z_top, y_shift=0.0, thick=0.028):
        yb_bot, yb_mid, yb_top = yf_bot * 0.96, yf_mid * 0.96, yf_top * 0.96
        return [
            (x_bot + wrap_x,        yf_bot + y_shift, z_bot),            # 0: Front lower edge (at bottom gold rim)
            (x_mid + wrap_x * 0.85, yf_mid + y_shift, z_mid),            # 1: Prominent 50%-height Mid-Pauldron Facet Ridge!
            (x_top,                 yf_top + y_shift*0.6, z_top),        # 2: Central top-front peak
            (x_top,                -yb_top + y_shift*0.6, z_top),        # 3: Central top-back peak
            (x_mid + wrap_x * 0.85,-yb_mid + y_shift, z_mid),            # 4: Back 50%-height Mid-Pauldron Facet Ridge!
            (x_bot + wrap_x,       -yb_bot + y_shift, z_bot + 0.010),    # 5: Back lower edge
            (x_bot + wrap_x + thick*0.45, -yb_bot*0.86 + y_shift, z_bot - thick + 0.010), # 6: Underside back
            (x_bot + wrap_x + thick*0.45,  yf_bot*0.86 + y_shift, z_bot - thick),         # 7: Underside front
        ]

    s0 = p_wing_sec(-0.202, -0.168, -0.142, 0.008, 0.148, 0.172, 0.056, 1.568, 1.646, 1.738, y_shift= 0.006)
    s1 = p_wing_sec(-0.270, -0.246, -0.198, 0.014, 0.184, 0.194, 0.058, 1.518, 1.616, 1.724, y_shift= 0.012)
    s2 = p_wing_sec(-0.368, -0.382, -0.336, 0.020, 0.150, 0.168, 0.052, 1.448, 1.572, 1.678, y_shift= 0.000)
    s3 = p_wing_sec(-0.470, -0.468, -0.436, 0.022, 0.098, 0.108, 0.042, 1.512, 1.558, 1.596, y_shift=-0.008)

    gold_seg  = ["BRASS_MAIN",  "BRASS_BRIGHT", "BRASS_BRIGHT", "BRASS_MAIN",  "BRASS_SHADE", "STEEL_SHADE", "STEEL_SHADE", "BRASS_SHADE"]
    steel_in  = ["STEEL_FACET", "STEEL_LIGHT",  "STEEL_EDGE",   "STEEL_LIGHT", "STEEL_FACET", "STEEL_DARK",  "STEEL_SHADE", "STEEL_DARK"]
    steel_out = ["STEEL_MAIN",  "STEEL_FACET",  "STEEL_EDGE",   "STEEL_FACET", "STEEL_MAIN",  "STEEL_DARK",  "STEEL_SHADE", "STEEL_DARK"]

    mb.add_loft(
        [s0, s1, s2, s3],
        weights=w,
        mat="METAL",
        colors=[gold_seg, steel_in, steel_out],
        closed_ring=True,
        cap_start=True,
        cap_end=True,
        cap_color="STEEL_BRIGHT",
    )

    ic0 = p_wing_sec(-0.200, -0.164, -0.138, 0.008, 0.152, 0.178, 0.062, 1.566, 1.652, 1.746, y_shift=0.006, thick=0.034)
    ic1 = p_wing_sec(-0.272, -0.248, -0.200, 0.014, 0.192, 0.200, 0.064, 1.516, 1.622, 1.732, y_shift=0.012, thick=0.034)
    mb.add_loft([ic0, ic1], weights=w, mat="METAL", colors=[gold_seg], closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT")

    def rim_clean_sec(x_bot, wrap_x, yf, z_bot, z_top, y_shift=0.0):
        yb = yf * 0.96
        return [
            (x_bot + wrap_x - 0.008,  yf + 0.008 + y_shift, z_bot),
            (x_bot + wrap_x - 0.010,  yf + 0.006 + y_shift, z_top),
            (x_bot + wrap_x - 0.010, -yb - 0.006 + y_shift, z_top + 0.010),
            (x_bot + wrap_x - 0.008, -yb - 0.008 + y_shift, z_bot + 0.010),
        ]

    rm0 = rim_clean_sec(-0.256, 0.014, 0.188, 1.500, 1.560, y_shift= 0.012)
    rm1 = rim_clean_sec(-0.368, 0.020, 0.152, 1.434, 1.496, y_shift= 0.000)
    rm2 = rim_clean_sec(-0.468, 0.022, 0.100, 1.478, 1.534, y_shift=-0.008)
    mb.add_loft(
        [rm0, rm1, rm2],
        weights=w,
        mat="METAL",
        colors=["BRASS_MAIN", "BRASS_BRIGHT"],
        closed_ring=True,
        cap_start=True,
        cap_end=True,
        cap_color="BRASS_BRIGHT",
    )

    pad_corners = [
        (-0.244, 0.198, 1.638),
        (-0.316, 0.204, 1.556),
        (-0.248, 0.204, 1.484),
        (-0.180, 0.192, 1.558),
    ]
    mb.add_flat_beveled_plate(
        pad_corners,
        normal_dir=(-0.34, 0.92, 0.16),
        thickness=0.015,
        bevel_inset=0.15,
        weights=w,
        mat="METAL",
        col_face="BRASS_MAIN",
        col_edge="BRASS_BRIGHT",
        col_side="BRASS_SHADE",
    )
    mb.add_diamond_boss(
        center=(-0.248, 0.204, 1.556),
        normal=(-0.34, 0.92, 0.16),
        up_vec=(-0.12, 0.05, 0.99),
        radius_u=0.034,
        radius_v=0.034,
        height=0.028,
        weights=w,
        mat="METAL",
        col_main="BRASS_MAIN",
        col_edge="BRASS_BRIGHT",
        col_base="BRASS_SHADE",
    )

    return mb


def build_breastplate():
    mb = MeshBuilder(["MAKitMatte", "MAKitMetal"])

    def core_ring(rx, yf, yb, z):
        return [
            ( 0.000,      yf,        z),
            (-rx * 0.72,  yf * 0.75, z),
            (-rx,         0.000,     z),
            (-rx * 0.72,  yb * 0.75, z),
            ( 0.000,      yb,        z),
            ( rx * 0.72,  yb * 0.75, z),
            ( rx,         0.000,     z),
            ( rx * 0.72,  yf * 0.75, z),
        ]

    # Extend dark neck/undersuit core up to Z = 1.790 so there is a rich dark shadow cavity inside the open scarf bowl under the chin!
    c_rings = [
        core_ring(0.175, 0.145, -0.135, 0.950),
        core_ring(0.165, 0.165, -0.145, 1.160),
        core_ring(0.162, 0.175, -0.150, 1.300),
        core_ring(0.215, 0.195, -0.165, 1.520),
        core_ring(0.125, 0.165, -0.115, 1.790),
    ]
    mb.add_loft(c_rings, weights=["pelvis", "pelvis", "spine", "chest", "chest"], mat="MATTE", colors="UNDERSUIT_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK")

    def torso_ring(rx, yf_c, yf_s, yb_c, yb_s, z):
        return [
            ( 0.000,      yf_c,   z),
            (-rx * 0.90,  yf_s,   z),
            (-rx,        -0.015,  z),
            (-rx * 0.95,  yb_s,   z),
            ( 0.000,      yb_c,   z),
            ( rx * 0.95,  yb_s,   z),
            ( rx,        -0.015,  z),
            ( rx * 0.90,  yf_s,   z),
        ]

    for z_bot, z_top, rx_b, rx_t, yf_b, yf_t, yb_b, yb_t, w_tag in [
        (1.275, 1.398, 0.222, 0.242, 0.228, 0.240, -0.170, -0.178, "spine"),
        (1.392, 1.558, 0.240, 0.264, 0.238, 0.252, -0.176, -0.184, "chest"),
    ]:
        tr0 = torso_ring(rx_b, yf_b, yf_b - 0.024, yb_b, yb_b + 0.016, z_bot)
        tr1 = torso_ring(rx_t, yf_t, yf_t - 0.020, yb_t, yb_t + 0.016, z_top - 0.012)
        tr2 = torso_ring(rx_t - 0.004, yf_t - 0.004, yf_t - 0.024, yb_t + 0.004, yb_t + 0.018, z_top)
        lame_c = ["STEEL_DARK",  "STEEL_DARK",  "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_DARK",  "STEEL_FACET"]
        top_c  = ["STEEL_FACET", "STEEL_MAIN",  "STEEL_DARK",  "STEEL_SHADE", "STEEL_SHADE", "STEEL_DARK",  "STEEL_MAIN",  "STEEL_LIGHT"]
        mb.add_loft([tr0, tr1, tr2], weights=w_tag, mat="METAL", colors=[lame_c, top_c], closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK")

    def plackart_row(x_gold_out, x_gold_in, y_side, y_keel, z):
        y_back = y_side - 0.032
        return [
            (-x_gold_out, y_back,           z),
            (-x_gold_out, y_side + 0.010,   z),
            (-x_gold_in,  y_side + 0.014,   z),
            (-x_gold_in,  y_side,           z),
            ( 0.000,      y_keel,           z),
            ( x_gold_in,  y_side,           z),
            ( x_gold_in,  y_side + 0.014,   z),
            ( x_gold_out, y_side + 0.010,   z),
            ( x_gold_out, y_back,           z),
        ]

    # Sharp golden V-point at the belt (x_gold_in=0.003, x_gold_out=0.046) flaring to a broad, muscular chest plastron (x_gold_out=0.188 at pr1)!
    pr0 = plackart_row(0.046, 0.003, 0.232, 0.248, 1.272)
    pr1 = plackart_row(0.174, 0.134, 0.258, 0.294, 1.462)
    pr2 = plackart_row(0.142, 0.104, 0.228, 0.248, 1.568)

    row_cols_lower = ["BRASS_SHADE", "BRASS_MAIN",   "BRASS_EDGE", "STEEL_SHADE", "STEEL_DARK",   "BRASS_EDGE", "BRASS_MAIN",   "BRASS_SHADE", "STEEL_SHADE"]
    row_cols_upper = ["BRASS_MAIN",  "BRASS_BRIGHT", "BRASS_EDGE", "STEEL_MAIN",  "STEEL_BRIGHT", "BRASS_EDGE", "BRASS_BRIGHT", "BRASS_MAIN",  "STEEL_SHADE"]

    mb.add_loft(
        [pr0, pr1, pr2],
        weights=["spine", "chest", "chest"],
        mat="METAL",
        colors=[row_cols_lower, row_cols_upper],
        closed_ring=True,
        cap_start=True,
        cap_end=True,
        cap_color="BRASS_BRIGHT",
    )

    # Open, low-slung Red Scarf Collar Bowl calibrated to the 896x896 grid:
    # Sits BELOW the helmet jaw (front V-trough at Z = 1.705, sides at Z = 1.755) with an inward-sloping dark collar bowl!
    def scarf_ring(rx, yf_v, yf_side, yb_v, yb_side, z_front_v, z_side, z_back):
        return [
            ( 0.000,      yf_v,     z_front_v),
            (-rx * 0.62,  yf_side,  z_side),
            (-rx,         0.015,    z_side + 0.014),
            (-rx * 0.82,  yb_side,  z_back + 0.008),
            ( 0.000,      yb_v,     z_back),
            ( rx * 0.82,  yb_side,  z_back + 0.008),
            ( rx,         0.015,    z_side + 0.014),
            ( rx * 0.62,  yf_side,  z_side),
        ]

    # 3 Stepped, Overlapping Crimson Cloth Folds on the Red Scarf (visible across Front, Side, Back, and Helmet Detail!):
    s0     = scarf_ring(0.172, 0.274, 0.234, -0.204, -0.182, 1.498, 1.595, 1.518)
    s1_out = scarf_ring(0.224, 0.286, 0.246, -0.224, -0.196, 1.580, 1.666, 1.602)
    s1_in  = scarf_ring(0.206, 0.264, 0.228, -0.202, -0.180, 1.588, 1.672, 1.610)
    s2_out = scarf_ring(0.222, 0.272, 0.236, -0.222, -0.194, 1.642, 1.724, 1.682)
    s2_in  = scarf_ring(0.204, 0.248, 0.218, -0.200, -0.178, 1.648, 1.730, 1.690)
    s3_out = scarf_ring(0.226, 0.254, 0.222, -0.218, -0.192, 1.686, 1.780, 1.752)
    s4     = scarf_ring(0.164, 0.206, 0.188, -0.165, -0.148, 1.714, 1.790, 1.770)

    scarf_cols_bright = ["CLOTH_BRIGHT", "CLOTH_LIGHT", "CLOTH_MAIN", "CLOTH_LIGHT", "CLOTH_BRIGHT", "CLOTH_MAIN", "CLOTH_LIGHT", "CLOTH_BRIGHT"]
    scarf_cols_mid    = ["CLOTH_LIGHT",  "CLOTH_MAIN",  "CLOTH_SHADE","CLOTH_MAIN",  "CLOTH_LIGHT",  "CLOTH_SHADE","CLOTH_MAIN",  "CLOTH_LIGHT"]
    scarf_cols_crev   = ["CLOTH_DARK",   "CLOTH_DARK",  "CLOTH_DARK", "CLOTH_DARK",  "CLOTH_DARK",   "CLOTH_DARK", "CLOTH_DARK",  "CLOTH_DARK"]

    mb.add_loft(
        [s0, s1_out, s1_in, s2_out, s2_in, s3_out, s4],
        weights="chest",
        mat="MATTE",
        colors=[scarf_cols_mid, scarf_cols_crev, scarf_cols_bright, scarf_cols_crev, scarf_cols_bright, scarf_cols_mid],
        closed_ring=True,
        cap_start=True,
        cap_end=True,
        cap_color="FACE_DARK",
    )

    # Removed fake cape_side_grid flaps so METabardBack gold border is the true outer edge in Back & Side views!

    b0 = torso_ring(0.216, 0.238, 0.218, -0.178, -0.164, 1.180)
    b1 = torso_ring(0.222, 0.244, 0.224, -0.184, -0.170, 1.235)
    b2 = torso_ring(0.216, 0.238, 0.218, -0.178, -0.164, 1.290)
    mb.add_loft(
        [b0, b1, b2],
        weights="pelvis",
        mat="MATTE",
        colors=["LEATHER_SHADE", "LEATHER_LIGHT"],
        closed_ring=True,
        cap_start=True,
        cap_end=True,
        cap_color="LEATHER_MAIN",
    )

    # Recessed dark interior of Belt Buckle
    mb.add_beveled_box(center=(0.000, 0.246, 1.235), half_extents=(0.044, 0.010, 0.048), weights="pelvis", mat="MATTE", col_main="FACE_DARK", col_edge="LEATHER_DARK", col_dark="FACE_DARK")
    # 4 Chamfered Bright Silver-Steel Frame Bars (Top, Bottom, Left, Right at y=0.246 -> front at y=0.260)
    mb.add_beveled_box(center=( 0.000, 0.258, 1.284), half_extents=(0.056, 0.014, 0.014), bevel=0.22, weights="pelvis", mat="METAL", col_main="STEEL_BRIGHT", col_edge="STEEL_BRIGHT", col_dark="STEEL_LIGHT")
    mb.add_beveled_box(center=( 0.000, 0.258, 1.186), half_extents=(0.056, 0.014, 0.014), bevel=0.22, weights="pelvis", mat="METAL", col_main="STEEL_BRIGHT", col_edge="STEEL_BRIGHT", col_dark="STEEL_LIGHT")
    mb.add_beveled_box(center=( 0.044, 0.258, 1.235), half_extents=(0.014, 0.014, 0.058), bevel=0.22, weights="pelvis", mat="METAL", col_main="STEEL_BRIGHT", col_edge="STEEL_BRIGHT", col_dark="STEEL_LIGHT")
    mb.add_beveled_box(center=(-0.044, 0.258, 1.235), half_extents=(0.014, 0.014, 0.058), bevel=0.22, weights="pelvis", mat="METAL", col_main="STEEL_BRIGHT", col_edge="STEEL_BRIGHT", col_dark="STEEL_LIGHT")
    # Horizontal Buckle Tongue Pin recessed 6mm behind the outer frame bars (y=0.242 -> front at y=0.252) so the Right Bar is unbroken!
    mb.add_beveled_box(center=( 0.022, 0.254, 1.235), half_extents=(0.020, 0.010, 0.008), bevel=0.20, weights="pelvis", mat="METAL", col_main="STEEL_LIGHT", col_edge="STEEL_BRIGHT", col_dark="STEEL_FACET")

    for sign in (-1.0, 1.0):
        for lx in (0.076, 0.164):
            mb.add_beveled_box(center=(sign * lx, 0.236, 1.235), half_extents=(0.009, 0.015, 0.056), weights="pelvis", mat="MATTE", col_main="LEATHER_LIGHT", col_edge="LEATHER_LIGHT", col_dark="LEATHER_SHADE")

        mb.add_diamond_boss(
            center=(sign * 0.136, 0.240, 1.235),
            normal=(sign * 0.26, 0.96, 0.0),
            up_vec=(0.0, 0.0, 1.0),
            radius_u=0.042,
            radius_v=0.045,
            height=0.020,
            weights="pelvis",
            mat="METAL",
            col_main="BRASS_MAIN",
            col_edge="BRASS_BRIGHT",
            col_base="BRASS_SHADE",
        )
        mb.add_diamond_boss(
            center=(sign * 0.138, 0.250, 1.235),
            normal=(sign * 0.26, 0.96, 0.0),
            up_vec=(0.0, 0.0, 1.0),
            radius_u=0.019,
            radius_v=0.021,
            height=0.014,
            weights="pelvis",
            mat="METAL",
            col_main="STEEL_BRIGHT",
            col_edge="STEEL_BRIGHT",
            col_base="STEEL_LIGHT",
        )

    for sign in (-1.0, 1.0):
        flap_pts = [
            (sign * 0.125, 0.208, 0.835),
            (sign * 0.182, 0.202, 0.835),
            (sign * 0.202, 0.218, 0.585),
            (sign * 0.162, 0.228, 0.585),
            (sign * 0.162, 0.232, 0.515),
            (sign * 0.118, 0.236, 0.515),
        ]
        mb.add_flat_beveled_plate(
            flap_pts,
            normal_dir=(sign * 0.15, 0.98, 0.0),
            thickness=0.016,
            bevel_inset=0.10,
            weights="pelvis",
            mat="MATTE",
            col_face="CLOTH_SHADE",
            col_edge="CLOTH_MAIN",
            col_side="CLOTH_DARK",
            col_back="CLOTH_DARK",
        )

    return mb


def build_arm_and_gauntlet(is_right=False, first_person=False):
    """
    Calibrated to the 500x800 Hero 3/4 grid and IMshoulder.png:
    - Commanding, athletic shoulder-to-elbow-to-wrist arc:
      - Left Arm: Shoulder (-0.275, 0.000, 1.545) -> Elbow (-0.395, 0.015, 1.315) -> Wrist (-0.505, 0.275, 1.185) -> Hand (-0.555, 0.385, 1.195)
      - Right Arm: Shoulder (0.275, 0.015, 1.545) -> Elbow (0.415, 0.015, 1.320) -> Wrist (0.505, 0.075, 1.055) -> Hand (0.545, 0.095, 0.945)
    """
    mb = MeshBuilder(["MAKitMatte", "MAKitMetal"])
    suffix = ".R" if is_right else ".L"
    sign = 1.0 if is_right else -1.0

    if not first_person:
        if not is_right:
            ua_h, ua_t = (-0.245, -0.020, 1.565), (-0.345,  0.095, 1.255)
            fa_h, fa_t = (-0.345,  0.095, 1.255), (-0.428,  0.455, 1.185)
            ha_h, ha_t = (-0.428,  0.455, 1.185), (-0.472,  0.565, 1.182)
        else:
            ua_h, ua_t = ( 0.265, -0.045, 1.575), ( 0.385, -0.128, 1.335)
            fa_h, fa_t = ( 0.385, -0.128, 1.335), ( 0.465,  0.005, 1.060)
            ha_h, ha_t = ( 0.465,  0.005, 1.060), ( 0.495,  0.035, 0.940)
    else:
        if not is_right:
            ua_h, ua_t = (-0.440, 0.080, -0.490), (-0.390, 0.360, -0.400)
            fa_h, fa_t = (-0.390, 0.360, -0.400), (-0.330, 0.640, -0.310)
            ha_h, ha_t = (-0.330, 0.640, -0.310), (-0.300, 0.760, -0.255)
        else:
            ua_h, ua_t = ( 0.440, 0.080, -0.490), ( 0.390, 0.360, -0.400)
            fa_h, fa_t = ( 0.390, 0.360, -0.400), ( 0.330, 0.640, -0.310)
            ha_h, ha_t = ( 0.330, 0.640, -0.310), ( 0.300, 0.760, -0.255)

    ua_frame = BoneFrame(ua_h, ua_t, up_hint=(0.0, 1.0, 0.0))
    fa_up_hint = (0.0, 1.0, 0.0) if not first_person else (sign * 0.65, 0.25, 0.70)
    fa_frame = BoneFrame(fa_h, fa_t, up_hint=fa_up_hint)

    def oct_ring(frame, t, ru, rv, ridge_u=0.0, ridge_v=0.0, tilt_u=0.0, tilt_v=0.0):
        d = 0.74
        pts_uv = [
            ( 0.0,          rv + ridge_v),
            ( ru * d,       rv * d),
            ( ru + ridge_u, 0.0),
            ( ru * d,      -rv * d),
            ( 0.0,         -rv - ridge_v * 0.5),
            (-ru * d,      -rv * d),
            (-ru - ridge_u, 0.0),
            (-ru * d,       rv * d),
        ]
        return [frame.pt(u, v, t + tilt_u * (u / max(ru, 1e-4)) + tilt_v * (v / max(rv, 1e-4))) for (u, v) in pts_uv]

    ua_w = f"upper_arm{suffix}"
    elbow_joint_cols = ["UNDERSUIT_DARK", "UNDERSUIT_DARK", "STEEL_SHADE", "STEEL_DARK", "STEEL_DARK", "STEEL_FACET", "STEEL_DARK", "UNDERSUIT_DARK"]
    mb.add_loft(
        [oct_ring(ua_frame, 0.00, 0.088, 0.088), oct_ring(ua_frame, 0.80, 0.094, 0.094), oct_ring(ua_frame, 1.02, 0.102, 0.104)],
        weights=ua_w, mat="METAL", colors=[elbow_joint_cols, elbow_joint_cols], closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK"
    )
    lame_main = ["STEEL_DARK",  "STEEL_DARK",  "STEEL_DARK", "STEEL_DARK",  "STEEL_DARK",  "STEEL_FACET", "STEEL_FACET", "STEEL_DARK"]
    lame_edge = ["STEEL_FACET", "STEEL_FACET", "STEEL_DARK", "STEEL_FACET", "STEEL_FACET", "STEEL_MAIN",  "STEEL_MAIN",  "STEEL_FACET"]
    lame_under= ["STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE","STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE"]
    tilt_u_val = -sign * 0.14
    tilt_v_val = -0.02 if is_right else 0.05
    for t_a, t_m, t_b, r_top, r_bot in [(0.08, 0.42, 0.49, 0.112, 0.132), (0.48, 0.78, 0.85, 0.108, 0.126)]:
        mb.add_loft(
            [
                oct_ring(ua_frame, t_a, r_top,         r_top,         ridge_u=0.014, ridge_v=0.014, tilt_u=tilt_u_val, tilt_v=tilt_v_val),
                oct_ring(ua_frame, t_m, r_bot,         r_bot,         ridge_u=0.016, ridge_v=0.015, tilt_u=tilt_u_val, tilt_v=tilt_v_val),
                oct_ring(ua_frame, t_b, r_bot - 0.002, r_bot - 0.002, ridge_u=0.015, ridge_v=0.014, tilt_u=tilt_u_val, tilt_v=tilt_v_val),
                oct_ring(ua_frame, t_b, r_top - 0.016, r_top - 0.016, ridge_u=0.006, ridge_v=0.006, tilt_u=tilt_u_val, tilt_v=tilt_v_val),
            ],
            weights=ua_w, mat="METAL", colors=[lame_main, lame_edge, lame_under], closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_SHADE"
        )

    fa_w = f"forearm{suffix}"
    out_u = -sign

    mb.add_loft(
        [oct_ring(fa_frame, -0.02, 0.072, 0.072), oct_ring(fa_frame, 1.04, 0.066, 0.066)],
        weights=fa_w, mat="MATTE", colors="UNDERSUIT_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK"
    )

    # Clean, Untwisted Forearm Vambrace (aligned with ua_frame so all 8 faces flow smoothly from upper arm to wrist!):
    fa_tilt_u = -sign * 0.10
    v0    = oct_ring(fa_frame, 0.08, 0.120, 0.116, ridge_u=0.016, ridge_v=0.016, tilt_u=fa_tilt_u, tilt_v=-0.03)
    v1    = oct_ring(fa_frame, 0.20, 0.118, 0.114, ridge_u=0.016, ridge_v=0.016, tilt_u=fa_tilt_u, tilt_v=-0.02)
    v1_in = oct_ring(fa_frame, 0.21, 0.114, 0.110, ridge_u=0.015, ridge_v=0.015, tilt_u=fa_tilt_u, tilt_v=-0.02)
    v2    = oct_ring(fa_frame, 0.78, 0.096, 0.092, ridge_u=0.012, ridge_v=0.012)

    gold_band_cols  = ["BRASS_MAIN", "BRASS_SHADE", "BRASS_SHADE", "BRASS_MAIN", "BRASS_BRIGHT", "BRASS_BRIGHT", "BRASS_BRIGHT", "BRASS_MAIN"]
    step_dark_cols  = ["STEEL_SHADE","STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE","STEEL_SHADE",  "STEEL_SHADE",  "STEEL_SHADE",  "STEEL_SHADE"]
    vam_plated_cols = ["STEEL_MAIN", "STEEL_DARK",  "STEEL_DARK",  "STEEL_MAIN", "STEEL_LIGHT",  "STEEL_LIGHT",  "STEEL_BRIGHT", "STEEL_LIGHT"]

    mb.add_loft(
        [v0, v1, v1_in, v2],
        weights=fa_w,
        mat="METAL",
        colors=[gold_band_cols, step_dark_cols, vam_plated_cols],
        closed_ring=True,
        cap_start=True,
        cap_end=True,
        cap_color="BRASS_MAIN",
    )

    # Flush Outer-Lateral Dark Groove along the Forearm Vambrace (aligned with the outer face out_u * fa_frame.u so it never sticks out as a cluttered box!)
    mb.add_beveled_box(
        center=fa_frame.pt(out_u * 0.104, 0.018, 0.48),
        half_extents=(0.008, 0.014, 0.110),
        axes=(fa_frame.u, fa_frame.v, fa_frame.w),
        bevel=0.16,
        weights=fa_w,
        mat="MATTE",
        col_main="FACE_DARK",
        col_edge="STEEL_DARK",
        col_dark="FACE_DARK",
    )

    # Crisp Beveled Gold Wrist Cuff (wc0->wc1 at t=0.77..0.93) + Dark-Steel Inner Wrist Ring (wc1->wc2 at t=0.93..1.00)
    wc0 = oct_ring(fa_frame, 0.77, 0.105, 0.101, ridge_u=0.014, ridge_v=0.014)
    wc1 = oct_ring(fa_frame, 0.93, 0.103, 0.099, ridge_u=0.014, ridge_v=0.014)
    wc2 = oct_ring(fa_frame, 1.00, 0.090, 0.086, ridge_u=0.010, ridge_v=0.010)
    mb.add_loft(
        [wc0, wc1, wc2],
        weights=fa_w,
        mat="METAL",
        colors=[gold_band_cols, step_dark_cols],
        closed_ring=True,
        cap_start=True,
        cap_end=True,
        cap_color="STEEL_DARK",
    )

    ha_w = f"hand{suffix}"
    if is_right and not first_person:
        wrist_pt = np.array(fa_t, dtype=np.float32)
        w_fa = fa_frame.w.copy()
        b_dir = np.array([0.54, 0.67, -0.508], dtype=np.float32)
        b_dir /= np.linalg.norm(b_dir)

        f_out = np.array([0.48, 0.76, 0.44], dtype=np.float32)
        f_out -= np.dot(f_out, b_dir) * b_dir
        f_out /= np.linalg.norm(f_out)

        f_perp = np.cross(b_dir, f_out)
        if f_perp[2] > 0:
            f_perp = -f_perp
        f_perp /= np.linalg.norm(f_perp)

        hand_root = wrist_pt + 0.028 * w_fa - 0.012 * f_out

        mb.add_beveled_box(
            center=hand_root + 0.052 * f_perp,
            half_extents=(0.066, 0.034, 0.046),
            axes=(b_dir, f_out, f_perp),
            bevel=0.18,
            weights=ha_w,
            mat="MATTE",
            col_main="LEATHER_DARK",
            col_edge="LEATHER_SHADE",
            col_dark="LEATHER_DARK",
        )

        mb.add_beveled_box(
            center=hand_root + 0.024 * f_perp + 0.040 * f_out,
            half_extents=(0.074, 0.026, 0.025),
            axes=(b_dir, f_out, f_perp),
            bevel=0.16,
            weights=ha_w,
            mat="METAL",
            col_main="STEEL_MAIN",
            col_edge="STEEL_LIGHT",
            col_dark="STEEL_DARK",
        )
        mb.add_beveled_box(
            center=hand_root + 0.068 * f_perp + 0.042 * f_out,
            half_extents=(0.076, 0.028, 0.023),
            axes=(b_dir, f_out, f_perp),
            bevel=0.16,
            weights=ha_w,
            mat="METAL",
            col_main="BRASS_MAIN",
            col_edge="BRASS_BRIGHT",
            col_dark="BRASS_SHADE",
        )

        # Recessed dark detail notch on the upper dorsal hand plate (matching Row 1 Col 5!)
        mb.add_beveled_box(
            center=hand_root + 0.016 * f_perp + 0.052 * f_out - 0.028 * b_dir,
            half_extents=(0.020, 0.008, 0.010),
            axes=(b_dir, f_out, f_perp),
            bevel=0.15,
            weights=ha_w,
            mat="MATTE",
            col_main="FACE_DARK",
            col_edge="STEEL_DARK",
            col_dark="FACE_DARK",
        )

        grip_c = hand_root + 0.104 * f_perp
        for f_i, (s_pos, flen) in enumerate([
            ( 0.054, 1.00),
            ( 0.018, 1.06),
            (-0.018, 1.02),
            (-0.054, 0.92),
        ]):
            fc = grip_c + s_pos * b_dir
            # Dark knuckle under-core so gaps between phalanges read as deep dark armored joints
            p0 = fc - 0.024 * f_perp + 0.038 * f_out
            p1 = fc + 0.018 * flen * f_perp + 0.044 * f_out
            p2 = fc + 0.054 * flen * f_perp + 0.024 * f_out
            p3 = fc + 0.062 * flen * f_perp - 0.018 * f_out
            for seg_i, (sa, sb, col_m, col_e) in enumerate([
                (p0, p1, "STEEL_LIGHT", "STEEL_BRIGHT"),
                (p1, p2, "STEEL_FACET", "STEEL_LIGHT"),
                (p2, p3, "STEEL_DARK",  "STEEL_FACET"),
            ]):
                sf = BoneFrame(sa, sb, up_hint=f_out)
                mb.add_beveled_box(
                    center=0.5 * (sa + sb),
                    half_extents=(0.0135, 0.016, 0.43 * sf.length),
                    axes=(b_dir, sf.v, sf.w),
                    bevel=0.18,
                    weights=ha_w,
                    mat="METAL",
                    col_main=col_m,
                    col_edge=col_e,
                    col_dark="FACE_DARK",
                )
    else:
        if not first_person:
            ha_frame = BoneFrame(ha_h, ha_t, up_hint=(0.25, -0.10, 0.96))
            d_sign = -1.0
        else:
            if not is_right:
                ha_frame = BoneFrame(ha_h, ha_t, up_hint=(0.35, -0.15, 0.92))
                d_sign = -1.0
            else:
                ha_frame = BoneFrame(ha_h, ha_t, up_hint=(0.75, 0.35, 0.55))
                d_sign = 1.0

        p_r0 = oct_ring(ha_frame, 0.00, 0.072, 0.044)
        p_r1 = oct_ring(ha_frame, 0.52, 0.076, 0.046)
        p_r2 = oct_ring(ha_frame, 0.88, 0.072, 0.042)
        mb.add_loft([p_r0, p_r1, p_r2], weights=ha_w, mat="MATTE", colors="LEATHER_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_DARK")

        mb.add_beveled_box(
            center=ha_frame.pt(0.0, d_sign * 0.048, 0.18),
            half_extents=(0.078, 0.022, 0.024),
            axes=(ha_frame.u, ha_frame.v, ha_frame.w),
            bevel=0.16,
            weights=ha_w,
            mat="METAL",
            col_main="STEEL_FACET",
            col_edge="STEEL_LIGHT",
            col_dark="STEEL_DARK",
        )
        mb.add_beveled_box(
            center=ha_frame.pt(0.0, d_sign * 0.050, 0.44),
            half_extents=(0.080, 0.024, 0.024),
            axes=(ha_frame.u, ha_frame.v, ha_frame.w),
            bevel=0.16,
            weights=ha_w,
            mat="METAL",
            col_main="BRASS_MAIN",
            col_edge="BRASS_BRIGHT",
            col_dark="BRASS_SHADE",
        )

        finger_u_offsets = [-0.056, -0.019, 0.019, 0.056]
        finger_lengths   = [ 0.076,  0.084, 0.080, 0.072]
        for f_i, (u_off, flen) in enumerate(zip(finger_u_offsets, finger_lengths)):
            base_pt = ha_frame.pt(u_off, d_sign * 0.012, 0.72)
            spread_u = (u_off * 1.25) * ha_frame.u
            palm_up = -d_sign * ha_frame.v
            p1 = base_pt + 0.38 * flen * ha_frame.w + 0.14 * flen * palm_up + 0.20 * spread_u
            p2 = p1      + 0.24 * flen * ha_frame.w + 0.34 * flen * palm_up + 0.10 * spread_u
            p3 = p2      - 0.04 * flen * ha_frame.w + 0.36 * flen * palm_up
            for seg_idx, (sa, sb, rad, col_m) in enumerate([
                (base_pt, p1, 0.019, "STEEL_LIGHT"),
                (p1,      p2, 0.018, "STEEL_FACET"),
                (p2,      p3, 0.016, "STEEL_DARK"),
            ]):
                sf = BoneFrame(sa, sb, up_hint=ha_frame.v)
                mb.add_beveled_box(
                    center=0.5 * (sa + sb),
                    half_extents=(rad, rad * 0.82, 0.54 * sf.length),
                    axes=(sf.u, sf.v, sf.w),
                    bevel=0.12,
                    weights=ha_w,
                    mat="METAL",
                    col_main=col_m,
                    col_edge="STEEL_EDGE",
                    col_dark="STEEL_SHADE",
                )

    return mb


def build_sorcery_cluster(first_person=False):
    mb = MeshBuilder(["MASorceryAccent"])
    w = "hand.L"

    if not first_person:
        base_c = np.array([-0.468, 0.555, 1.265], dtype=np.float32)
        scale = 1.0
    else:
        base_c = np.array([-0.305, 0.725, -0.205], dtype=np.float32)
        scale = 0.85

    voxels = [
        ( 0.000,  0.000, 0.058, 0.028, 0.028, 0.070),
        (-0.032,  0.008, 0.025, 0.022, 0.022, 0.035),
        ( 0.032, -0.006, 0.030, 0.022, 0.022, 0.040),
        ( 0.005,  0.030, 0.022, 0.022, 0.022, 0.032),
        (-0.005, -0.028, 0.028, 0.020, 0.020, 0.035),
        (-0.065,  0.020, 0.045, 0.012, 0.012, 0.012),
        ( 0.068, -0.015, 0.065, 0.013, 0.013, 0.013),
        (-0.052, -0.025, 0.115, 0.014, 0.014, 0.014),
        ( 0.055,  0.025, 0.130, 0.015, 0.015, 0.015),
        (-0.030,  0.015, 0.165, 0.013, 0.013, 0.013),
        ( 0.032, -0.018, 0.185, 0.012, 0.012, 0.012),
        (-0.060,  0.005, 0.205, 0.010, 0.010, 0.010),
        ( 0.015,  0.022, 0.225, 0.011, 0.011, 0.011),
    ]

    for (dx, dy, dz, hx, hy, hz) in voxels:
        c = base_c + scale * np.array([dx, dy, dz], dtype=np.float32)
        add_sharp_cube(mb, c, (scale*hx, scale*hy, scale*hz), weights=w, mat="SORCERY", col="WHITE")

    return mb


def build_hero_sword(first_person=False):
    mb = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    w = "hand.R"

    if not first_person:
        fa_h, fa_t = (0.385, -0.128, 1.335), (0.465, 0.005, 1.060)
        fa_frame = BoneFrame(fa_h, fa_t, up_hint=(0.55, 0.72, 0.42))
        wrist_pt = np.array(fa_t, dtype=np.float32)
        w_fa = fa_frame.w.copy()

        b_dir = np.array([0.54, 0.67, -0.508], dtype=np.float32)
        b_dir /= np.linalg.norm(b_dir)
        v_dir = np.array([0.48, 0.76, 0.44], dtype=np.float32)
        v_dir -= np.dot(v_dir, b_dir) * b_dir
        v_dir /= np.linalg.norm(v_dir)
        u_dir = np.cross(v_dir, b_dir)
        u_dir /= np.linalg.norm(u_dir)

        f_perp = np.cross(b_dir, v_dir)
        if f_perp[2] > 0:
            f_perp = -f_perp
        f_perp /= np.linalg.norm(f_perp)
        hand_root = wrist_pt + 0.028 * w_fa - 0.012 * v_dir
        grip_c = hand_root + 0.104 * f_perp
        blade_end = 1.020
    else:
        grip_c = np.array([0.2913, 0.6893, -0.2932], dtype=np.float32)
        b_dir = np.array([0.2897, 0.7677, 0.5715], dtype=np.float32)
        b_dir /= np.linalg.norm(b_dir)
        u_dir = np.array([0.9754, -0.1610, -0.1509], dtype=np.float32)
        u_dir -= np.dot(u_dir, b_dir) * b_dir
        u_dir /= np.linalg.norm(u_dir)
        v_dir = np.cross(b_dir, u_dir)
        v_dir /= np.linalg.norm(v_dir)
        blade_end = 0.820

    def s_pt(u, v, s):
        return grip_c + s * b_dir + u * u_dir + v * v_dir

    p_rings = [
        [s_pt(0.008*np.cos(a), 0.008*np.sin(a), -0.305) for a in np.linspace(0, 2*np.pi, 8, endpoint=False)],
        [s_pt(0.064*np.cos(a), 0.056*np.sin(a), -0.255) for a in np.linspace(0, 2*np.pi, 8, endpoint=False)],
        [s_pt(0.058*np.cos(a), 0.050*np.sin(a), -0.205) for a in np.linspace(0, 2*np.pi, 8, endpoint=False)],
        [s_pt(0.036*np.cos(a), 0.032*np.sin(a), -0.180) for a in np.linspace(0, 2*np.pi, 8, endpoint=False)],
    ]
    p_c1 = ["BRASS_BRIGHT", "BRASS_MAIN", "BRASS_SHADE", "BRASS_DARK", "BRASS_SHADE", "BRASS_MAIN", "BRASS_BRIGHT", "BRASS_EDGE"]
    p_c2 = ["BRASS_MAIN",   "BRASS_SHADE","BRASS_DARK",  "BRASS_SHADE","BRASS_MAIN",  "BRASS_EDGE", "BRASS_BRIGHT", "BRASS_MAIN"]
    mb.add_loft(
        p_rings, weights=w, mat="METAL",
        colors=[p_c1, p_c2, p_c1],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT"
    )

    g_rings = []
    g_cols = []
    for i, s_val in enumerate(np.linspace(-0.175, 0.080, 11)):
        rad_u = 0.025 if i % 2 == 0 else 0.031
        rad_v = 0.022 if i % 2 == 0 else 0.026
        g_rings.append([s_pt(rad_u*np.cos(a), rad_v*np.sin(a), s_val) for a in np.linspace(0, 2*np.pi, 8, endpoint=False)])
        if i < 10:
            g_cols.append("LEATHER_LIGHT" if i % 2 == 0 else "LEATHER_SHADE")
    mb.add_loft(g_rings, weights=w, mat="MATTE", colors=g_cols, closed_ring=True)

    s_guard = 0.102
    for n_sign, col_e in [(1.0, "BRASS_BRIGHT"), (-1.0, "BRASS_EDGE")]:
        mb.add_diamond_boss(
            center=s_pt(0.0, 0.0, s_guard),
            normal=n_sign * v_dir,
            up_vec=b_dir,
            radius_u=0.094,
            radius_v=0.090,
            height=0.052,
            weights=w,
            mat="METAL",
            col_main="BRASS_MAIN",
            col_edge=col_e,
            col_base="BRASS_SHADE",
        )
        mb.add_diamond_boss(
            center=s_pt(0.0, n_sign * 0.042, s_guard),
            normal=n_sign * v_dir,
            up_vec=b_dir,
            radius_u=0.042,
            radius_v=0.044,
            height=0.028,
            weights=w,
            mat="MATTE",
            col_main="RUBY_MAIN",
            col_edge="RUBY_BRIGHT",
            col_base="RUBY_SHADE",
        )

    for q_sign in (-1.0, 1.0):
        def quillon_ring(u_dist, hs, hv, s_shift=s_guard):
            return [
                s_pt(q_sign * u_dist,  0.0,       s_shift + hs),
                s_pt(q_sign * u_dist,  hv,        s_shift),
                s_pt(q_sign * u_dist,  0.0,       s_shift - hs),
                s_pt(q_sign * u_dist, -hv,        s_shift),
            ]
        qr0 = quillon_ring(0.046, 0.042, 0.036)
        qr1 = quillon_ring(0.145, 0.032, 0.028)
        qr2 = quillon_ring(0.182, 0.056, 0.048)
        qr3 = quillon_ring(0.222, 0.008, 0.008)
        mb.add_loft(
            [qr0, qr1, qr2, qr3],
            weights=w, mat="METAL",
            colors=["BRASS_MAIN", "BRASS_BRIGHT", "BRASS_EDGE"],
            closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT"
        )

    def blade_section(w_half, thick_bevel, thick_fuller, s_val):
        fw = w_half * 0.42
        bw = w_half * 0.56
        return [
            s_pt( w_half, 0.0,           s_val),
            s_pt( bw,     thick_bevel,   s_val),
            s_pt( fw,     thick_fuller,  s_val),
            s_pt(-fw,     thick_fuller,  s_val),
            s_pt(-w_half, 0.0,           s_val),
            s_pt(-bw,    -thick_bevel,   s_val),
            s_pt(-fw,    -thick_fuller,  s_val),
            s_pt( fw,    -thick_fuller,  s_val),
        ]

    b0 = blade_section(0.118, 0.028, 0.010, 0.122)
    b1 = blade_section(0.116, 0.027, 0.010, 0.440)
    b2 = blade_section(0.118, 0.026, 0.010, 0.780)
    b3 = blade_section(0.066, 0.018, 0.016, 0.910)
    b4 = blade_section(0.004, 0.003, 0.003, blade_end)

    blade_cols_fuller = ["STEEL_BRIGHT", "STEEL_EDGE", "STEEL_DARK",  "STEEL_LIGHT", "STEEL_BRIGHT", "STEEL_EDGE", "STEEL_DARK",  "STEEL_LIGHT"]
    blade_cols_tip    = ["STEEL_BRIGHT", "STEEL_EDGE", "STEEL_LIGHT", "STEEL_BRIGHT","STEEL_BRIGHT", "STEEL_EDGE", "STEEL_LIGHT", "STEEL_BRIGHT"]

    mb.add_loft(
        [b0, b1, b2, b3, b4],
        weights=w,
        mat="METAL",
        colors=[blade_cols_fuller, blade_cols_fuller, blade_cols_tip, blade_cols_tip],
        closed_ring=True,
        cap_start=True,
        cap_end=True,
        cap_color="STEEL_BRIGHT",
    )

    return mb


def build_greave(is_right=False):
    mb = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    suffix = ".R" if is_right else ".L"
    sign = 1.0 if is_right else -1.0
    yaw_deg = -7.0 if is_right else 10.0

    if not is_right:
        th_h, th_t = (-0.175,  0.030, 1.060), (-0.245,  0.125, 0.680)
        sh_h, sh_t = (-0.245,  0.125, 0.680), (-0.295,  0.025, 0.255)
    else:
        th_h, th_t = ( 0.185,  0.015, 1.060), ( 0.275,  0.100, 0.690)
        sh_h, sh_t = ( 0.275,  0.100, 0.690), ( 0.350, -0.055, 0.255)

    rad = np.radians(yaw_deg)
    up_out = (float(-np.sin(rad)), float(np.cos(rad)), 0.0)
    th_frame = BoneFrame(th_h, th_t, up_hint=up_out)
    sh_frame = BoneFrame(sh_h, sh_t, up_hint=up_out)
    th_w = f"thigh{suffix}"
    sh_w = f"shin{suffix}"

    def leg_ring(frame, t, rx, yf, yb, ridge_y=0.0):
        return [
            frame.pt( 0.0,       yf + ridge_y, t),
            frame.pt(-rx * 0.76, yf * 0.78,    t),
            frame.pt(-rx,        0.0,          t),
            frame.pt(-rx * 0.78,-yb * 0.78,    t),
            frame.pt( 0.0,      -yb,           t),
            frame.pt( rx * 0.78,-yb * 0.78,    t),
            frame.pt( rx,        0.0,          t),
            frame.pt( rx * 0.76, yf * 0.78,    t),
        ]

    mb.add_loft(
        [leg_ring(th_frame, -0.05, 0.132, 0.122, 0.122), leg_ring(th_frame, 1.18, 0.106, 0.108, 0.106)],
        weights=th_w, mat="MATTE", colors="UNDERSUIT_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK"
    )
    tc0 = leg_ring(th_frame, 0.06, 0.146, 0.138, 0.130, ridge_y=0.014)
    tc1 = leg_ring(th_frame, 0.52, 0.140, 0.134, 0.126, ridge_y=0.016)
    tc2 = leg_ring(th_frame, 0.96, 0.120, 0.118, 0.112, ridge_y=0.012)
    th_cols = ["STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_DARK", "STEEL_DARK"]
    mb.add_loft([tc0, tc1, tc2], weights=th_w, mat="METAL", colors=th_cols, closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK")

    strap_pts = [
        (sign * 0.126, 0.218, 1.190),
        (sign * 0.160, 0.208, 1.190),
        (sign * 0.192, 0.194, 0.885),
        (sign * 0.172, 0.200, 0.915),
        (sign * 0.152, 0.206, 0.885),
    ]
    mb.add_flat_beveled_plate(
        strap_pts,
        normal_dir=(sign * 0.25, 0.96, 0.06),
        thickness=0.015,
        bevel_inset=0.10,
        weights=th_w,
        mat="MATTE",
        col_face="LEATHER_MAIN",
        col_edge="LEATHER_LIGHT",
        col_side="LEATHER_DARK",
    )
    mb.add_beveled_box(
        center=(sign * 0.162, 0.208, 1.040),
        half_extents=(0.018, 0.012, 0.014),
        weights=th_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
    )

    for tier_i, (z_hi, z_lo, x_tl, x_tr, x_br, x_bl, y_in, y_out) in enumerate([
        (1.190, 1.055, 0.164, 0.284, 0.316, 0.190, 0.162, 0.034),
        (1.062, 0.925, 0.188, 0.316, 0.350, 0.216, 0.176, 0.048),
        (0.932, 0.795, 0.214, 0.350, 0.384, 0.244, 0.188, 0.062),
    ]):
        t_corners = [
            (sign * x_tl, y_in,          z_hi),
            (sign * x_tr, y_out,         z_hi),
            (sign * x_br, y_out + 0.012, z_lo),
            (sign * x_bl, y_in  + 0.012, z_lo),
        ]
        n_dir = (sign * 0.62, 0.77, 0.14)
        add_framed_rect_plate(
            mb, t_corners, normal_dir=n_dir,
            thickness=0.018, border_frac=0.18, weights=th_w,
            mat_border="METAL", col_border="BRASS_MAIN", col_border_edge="BRASS_EDGE",
            mat_inner="MATTE", col_inner="LEATHER_SHADE",
            open_top=(tier_i > 0)
        )
        c_mid = np.mean(t_corners, axis=0) + 0.012 * np.array(n_dir)
        mb.add_beveled_box(center=c_mid, half_extents=(0.008, 0.008, 0.008), weights=th_w, mat="METAL", col_main="BRASS_BRIGHT", col_edge="BRASS_BRIGHT", col_dark="BRASS_MAIN")

    mb.add_loft(
        [leg_ring(sh_frame, -0.15, 0.104, 0.106, 0.104), leg_ring(sh_frame, 1.25, 0.072, 0.074, 0.072)],
        weights=sh_w, mat="MATTE", colors="UNDERSUIT_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK"
    )

    ls0 = leg_ring(sh_frame, 0.10, 0.124, 0.126, 0.138, ridge_y=0.016)
    ls1 = leg_ring(sh_frame, 0.54, 0.108, 0.104, 0.114, ridge_y=0.016)
    ls2 = leg_ring(sh_frame, 1.16, 0.092, 0.088, 0.092, ridge_y=0.012)
    ls_cols = ["STEEL_DARK",  "STEEL_DARK", "STEEL_FACET","STEEL_MAIN",  "STEEL_MAIN",  "STEEL_FACET", "STEEL_DARK", "STEEL_FACET"]
    mb.add_loft([ls0, ls1, ls2], weights=sh_w, mat="METAL", colors=[ls_cols, ls_cols], closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK")

    def knee_arch_row(t_side, t_mid, u_side, u_mid, v_side, v_mid):
        return [
            sh_frame.pt(-u_side, v_side, t_side),
            sh_frame.pt(-u_mid,  v_mid,  t_mid),
            sh_frame.pt( u_mid,  v_mid,  t_mid),
            sh_frame.pt( u_side, v_side, t_side),
        ]

    # Wrap Knee Poleyn outer wings back to v_side = -0.055 and u_side = 0.146 so the Gold-Trimmed Knee Poleyn Wings are boldly visible in BOTH Side View and Back View!
    k_top_grid = [
        knee_arch_row(-0.20, -0.36, 0.144, 0.084, -0.052, 0.140),
        knee_arch_row(-0.10, -0.24, 0.148, 0.088, -0.048, 0.146),
    ]
    mb.add_faceted_shield_plate(
        k_top_grid, outward_hint=sh_frame.v, thickness=0.028, bevel_inset=0.14, weights=sh_w,
        mat="METAL", col_faces=[["BRASS_MAIN", "BRASS_BRIGHT", "BRASS_MAIN"]], col_bevel="BRASS_BRIGHT", col_side="BRASS_SHADE"
    )

    k_main_grid = [
        knee_arch_row(-0.10, -0.24, 0.148, 0.088, -0.048, 0.146),
        knee_arch_row( 0.00,  0.08, 0.142, 0.084, -0.050, 0.144),
    ]
    mb.add_faceted_shield_plate(
        k_main_grid, outward_hint=sh_frame.v, thickness=0.034, bevel_inset=0.15, weights=sh_w,
        mat="METAL", col_faces=[["STEEL_MAIN", "STEEL_BRIGHT", "STEEL_LIGHT"]], col_bevel="STEEL_BRIGHT", col_side="STEEL_DARK"
    )

    k_bot_grid = [
        knee_arch_row(-0.01,  0.07, 0.142, 0.084, -0.050, 0.144),
        knee_arch_row( 0.08,  0.18, 0.134, 0.078, -0.052, 0.138),
    ]
    mb.add_faceted_shield_plate(
        k_bot_grid, outward_hint=sh_frame.v, thickness=0.026, bevel_inset=0.14, weights=sh_w,
        mat="METAL", col_faces=[["BRASS_SHADE", "BRASS_MAIN", "BRASS_EDGE"]], col_bevel="BRASS_BRIGHT", col_side="BRASS_SHADE"
    )

    # Stepped Bronze/Gold Upper Crown Rim directly above the Upper-Shin Square Shield!
    us_top_rim = [
        knee_arch_row( 0.10,  0.10, 0.140, 0.088, 0.062, 0.156),
        knee_arch_row( 0.18,  0.18, 0.144, 0.092, 0.066, 0.160),
    ]
    mb.add_faceted_shield_plate(
        us_top_rim, outward_hint=sh_frame.v, thickness=0.032, bevel_inset=0.14, weights=sh_w,
        mat="METAL", col_faces=[["BRASS_SHADE", "BRASS_MAIN", "BRASS_BRIGHT"]], col_bevel="BRASS_EDGE", col_side="BRASS_SHADE"
    )

    # Broad, Chunky Upper-Shin Square Shield Plate (u=0.142, v=0.158) matching Row 3 Col 4 Neon-Green overlay!
    us_main_grid = [
        knee_arch_row( 0.18,  0.18, 0.142, 0.090, 0.065, 0.158),
        knee_arch_row( 0.54,  0.56, 0.132, 0.084, 0.058, 0.150),
    ]
    mb.add_faceted_shield_plate(
        us_main_grid, outward_hint=sh_frame.v, thickness=0.036, bevel_inset=0.16, weights=sh_w,
        mat="METAL", col_faces=[["STEEL_FACET", "STEEL_LIGHT", "STEEL_BRIGHT"]], col_bevel="STEEL_BRIGHT", col_side="STEEL_DARK"
    )

    # Crisp Recessed C-Channel Indentation on the front face of the Upper-Shin Square Shield
    c_notch_corners = [
        sh_frame.pt(-0.068, 0.172, 0.28),
        sh_frame.pt( 0.044, 0.172, 0.28),
        sh_frame.pt( 0.044, 0.170, 0.41),
        sh_frame.pt(-0.068, 0.170, 0.41),
    ]
    mb.add_flat_beveled_plate(
        c_notch_corners, normal_dir=sh_frame.v, thickness=0.010, bevel_inset=0.20, weights=sh_w,
        mat="MATTE", col_face="FACE_DARK", col_edge="STEEL_DARK", col_side="FACE_DARK"
    )

    # Upper Gold/Bronze Calf Rim wrapping around the back of the knee/upper calf (visible in Back & Side Views!)
    uc_r0 = leg_ring(sh_frame, 0.08, 0.134, 0.130, 0.156)
    uc_r1 = leg_ring(sh_frame, 0.20, 0.136, 0.132, 0.158)
    mb.add_loft([uc_r0, uc_r1], weights=sh_w, mat="METAL", colors="BRASS_MAIN", closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT")

    # Proud Brown Leather Calf Strap wrapping around the Upper-Shin Shield and Calf (rx=0.134, yb=0.154 so it sits proud of ls0..ls1!)
    st_r0 = leg_ring(sh_frame, 0.28, 0.134, 0.134, 0.154)
    st_r1 = leg_ring(sh_frame, 0.44, 0.130, 0.130, 0.150)
    mb.add_loft([st_r0, st_r1], weights=sh_w, mat="MATTE", colors="LEATHER_MAIN", closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_LIGHT")

    k_u = 1.0 if np.dot(sh_frame.u, np.array([sign, 0.0, 0.0])) > 0 else -1.0
    mb.add_beveled_box(
        center=sh_frame.pt(k_u * 0.136, 0.055, 0.36),
        half_extents=(0.022, 0.038, 0.038),
        axes=(sh_frame.u, sh_frame.v, sh_frame.w),
        bevel=0.16,
        weights=sh_w,
        mat="METAL",
        col_main="BRASS_MAIN",
        col_edge="BRASS_BRIGHT",
        col_dark="BRASS_SHADE",
    )
    # Rear Calf Gold Keeper Buckle (visible in Back View!)
    mb.add_beveled_box(
        center=sh_frame.pt(0.0, -0.154, 0.36),
        half_extents=(0.036, 0.018, 0.036),
        axes=(sh_frame.u, sh_frame.v, sh_frame.w),
        bevel=0.16,
        weights=sh_w,
        mat="METAL",
        col_main="BRASS_MAIN",
        col_edge="BRASS_BRIGHT",
        col_dark="BRASS_SHADE",
    )

    return mb


def build_boot(is_right=False):
    """
    Calibrated to Row 3 Col 4 of v34_all_details_overlay.png:
    - Wide, chunky chiseled 3-facet Sabaton Toe-Box extending forward to y_front = +0.342 (rx = 0.148)
    - 38-deg diagonal Chevron Ankle Strap high at the front instep (Z = 0.175..0.238) and sloping steeply down toward the heel/outer buckle (Z = 0.075..0.132)
    """
    mb = MeshBuilder(["MAKitMatte", "MAKitMetal"])
    w = "foot.R" if is_right else "foot.L"
    cx = 0.350 if is_right else -0.295
    cy = -0.055 if is_right else 0.025
    yaw_deg = -16.0 if is_right else 22.0
    sign = 1.0 if is_right else -1.0

    def boot_ring_trap(fw, rx, y_front, y_corner, y_back, z, dorsal_lift=0.0, front_peak=0.0, back_peak=0.0):
        ym = 0.30 * y_front + 0.70 * y_back
        pts = [
            (cx - fw,      cy + y_front,        z + dorsal_lift + front_peak),
            (cx - rx*0.84, cy + y_corner,       z + dorsal_lift*0.4 + front_peak*0.45),
            (cx - rx,      cy + ym,             z),
            (cx - rx*0.86, cy + y_back + 0.025, z + back_peak * 0.5),
            (cx - fw*0.8,  cy + y_back,         z + back_peak),
            (cx + fw*0.8,  cy + y_back,         z + back_peak),
            (cx + rx*0.86, cy + y_back + 0.025, z + back_peak * 0.5),
            (cx + rx,      cy + ym,             z),
            (cx + rx*0.84, cy + y_corner,       z + dorsal_lift*0.4 + front_peak*0.45),
            (cx + fw,      cy + y_front,        z + dorsal_lift + front_peak),
        ]
        return rot_z(pts, yaw_deg, pivot=(cx, cy))

    s0 = boot_ring_trap(0.058, 0.146, 0.318, 0.268, -0.168, 0.000)
    s1 = boot_ring_trap(0.060, 0.148, 0.322, 0.272, -0.170, 0.024)
    mb.add_loft([s0, s1], weights=w, mat="METAL", colors="STEEL_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK")

    b0      = boot_ring_trap(0.056, 0.142, 0.316, 0.265, -0.164, 0.024, dorsal_lift=0.002)
    b1      = boot_ring_trap(0.052, 0.138, 0.298, 0.250, -0.160, 0.072, dorsal_lift=0.010, back_peak=0.010)
    b1_back = boot_ring_trap(0.050, 0.134, 0.218, 0.180, -0.161, 0.098, dorsal_lift=0.014, back_peak=0.015)
    b1_step = boot_ring_trap(0.046, 0.126, 0.212, 0.174, -0.161, 0.088, dorsal_lift=0.012, back_peak=0.015)
    b2      = boot_ring_trap(0.048, 0.130, 0.164, 0.128, -0.162, 0.116, dorsal_lift=0.016, back_peak=0.020)
    b3      = boot_ring_trap(0.044, 0.118, 0.104, 0.076, -0.158, 0.245, dorsal_lift=0.012, back_peak=0.028)

    cols_prow = ["STEEL_DARK",  "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_FACET", "STEEL_SHADE", "STEEL_DARK", "STEEL_FACET", "STEEL_LIGHT", "STEEL_FACET"]
    cols_deck = ["STEEL_FACET", "STEEL_DARK",  "STEEL_DARK",  "STEEL_SHADE", "STEEL_LIGHT", "STEEL_SHADE", "STEEL_DARK", "STEEL_FACET", "STEEL_EDGE",  "STEEL_LIGHT"]
    cols_step = ["STEEL_DARK",  "STEEL_DARK",  "STEEL_DARK",  "STEEL_SHADE", "STEEL_FACET", "STEEL_SHADE", "STEEL_DARK", "STEEL_DARK",  "STEEL_DARK",  "STEEL_DARK"]
    cols_neck = ["STEEL_DARK",  "STEEL_DARK",  "STEEL_SHADE", "BRASS_MAIN",  "BRASS_BRIGHT","BRASS_MAIN",  "STEEL_SHADE","STEEL_DARK",  "STEEL_DARK",  "STEEL_DARK"]

    mb.add_loft(
        [b0, b1, b1_back, b1_step, b2, b3],
        weights=w, mat="METAL",
        colors=[cols_prow, cols_deck, cols_step, cols_deck, cols_neck],
        closed_ring=True, cap_start=False, cap_end=True, cap_color="STEEL_DARK"
    )

    # 38-deg Diagonal Chevron Ankle Strap (high at front instep Z=0.175..0.235, sloping steeply down to Z=0.075..0.125 at sides/heel!)
    ac0 = boot_ring_trap(0.044, 0.128, 0.158, 0.115, -0.176, 0.075, dorsal_lift=0.014, front_peak=0.100, back_peak=0.022)
    ac1 = boot_ring_trap(0.046, 0.132, 0.164, 0.120, -0.178, 0.128, dorsal_lift=0.016, front_peak=0.108, back_peak=0.026)
    ac2 = boot_ring_trap(0.040, 0.116, 0.138, 0.100, -0.170, 0.142, dorsal_lift=0.012, front_peak=0.098, back_peak=0.022)
    ac_cols = ["BRASS_SHADE", "LEATHER_LIGHT", "LEATHER_MAIN", "LEATHER_SHADE", "BRASS_MAIN", "LEATHER_SHADE", "LEATHER_MAIN", "LEATHER_LIGHT", "BRASS_MAIN", "BRASS_EDGE"]
    mb.add_loft(
        [ac0, ac1, ac2],
        weights=w, mat="METAL",
        colors=[ac_cols, ac_cols],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_MAIN"
    )

    kp_pt = rot_z([(cx + sign * 0.126, 0.015, 0.118)], yaw_deg, pivot=(cx, cy))[0]
    mb.add_beveled_box(
        center=kp_pt,
        half_extents=(0.022, 0.032, 0.032),
        weights=w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_EDGE", col_dark="BRASS_SHADE"
    )

    return mb


def polish_original_tabards(bf):
    me_layout = bf.get_layout("Mesh")
    cd_layout = bf.get_layout("CustomData")
    cdl_layout = bf.get_layout("CustomDataLayer")

    for b in bf.blocks:
        if b["code"] == "ME" and bf.get_id_name(b) in ("METabardFront", "METabardBack"):
            mname = bf.get_id_name(b)
            buf = b["payload"]
            totvert, totedge, totpoly, totloop = struct.unpack_from("<4i", buf, me_layout["totvert"][0])

            v_off = me_layout["vdata"][0]
            l_ptr = struct.unpack_from("<Q", buf, v_off + cd_layout["layers"][0])[0]
            totl = struct.unpack_from("<i", buf, v_off + cd_layout["totlayer"][0])[0]
            lb = bf.ptr_map[l_ptr]
            for li in range(totl):
                loff = li * 120
                lname = bytes(lb["payload"][loff+cdl_layout["name"][0]:loff+cdl_layout["name"][0]+68]).split(b"\x00")[0].decode()
                if lname == "position":
                    dptr = struct.unpack_from("<Q", lb["payload"], loff + cdl_layout["data"][0])[0]
                    db = bf.ptr_map[dptr]
                    verts = np.frombuffer(db["payload"], dtype=np.float32).reshape(totvert, 3).copy()
                    if mname == "METabardFront":
                        y_med = np.median(verts[:, 1])
                        for vi in range(totvert):
                            x, y, z = verts[vi]
                            t = np.clip((1.26 - z) / (1.26 - 0.495), 0.0, 1.0)
                            is_front = (y >= y_med - 1e-4)
                            scale_x = (0.94 + 0.68 * (t ** 0.88)) * (1.0 if is_front else 0.96)
                            verts[vi, 0] = x * scale_x
                            # Subtle natural cloth curve over the upper thighs/knees in Side View
                            y_curve = 0.240 + 0.018 * np.sin(t * np.pi * 0.75) - 0.008 * (t ** 2)
                            verts[vi, 1] = y_curve if is_front else (y_curve - 0.024)
                    elif mname == "METabardBack":
                        orig_x = verts[:, 0].copy()
                        orig_y = verts[:, 1].copy()
                        orig_z = verts[:, 2].copy()
                        for vi in range(totvert):
                            x, y, z = verts[vi]
                            t = np.clip((1.62 - z) / (1.62 - 0.45), 0.0, 1.0)
                            same_xz = (np.abs(orig_z - z) < 0.02) & (np.abs(orig_x - x) < 0.02)
                            y_pair_med = np.mean(orig_y[same_xz]) if np.any(same_xz) else (-0.245 - 0.18 * t)
                            is_inner = (y > y_pair_med)
                            scale_x = (0.84 + 0.60 * (t ** 1.12)) * (0.96 if is_inner else 1.0)
                            verts[vi, 0] = x * scale_x
                            y_base = -0.192 - 0.068 * t - 0.034 * (t ** 1.8) - 0.005 * np.cos(x * 12.0)
                            verts[vi, 1] = (y_base + 0.018) if is_inner else y_base
                    db["payload"] = bytearray(verts.astype(np.float32).tobytes())

            l_off = me_layout["ldata"][0]
            l_ptr = struct.unpack_from("<Q", buf, l_off + cd_layout["layers"][0])[0]
            totl = struct.unpack_from("<i", buf, l_off + cd_layout["totlayer"][0])[0]
            lb = bf.ptr_map[l_ptr]
            for li in range(totl):
                loff = li * 120
                lname = bytes(lb["payload"][loff+cdl_layout["name"][0]:loff+cdl_layout["name"][0]+68]).split(b"\x00")[0].decode()
                if lname == "ArmorColor":
                    dptr = struct.unpack_from("<Q", lb["payload"], loff + cdl_layout["data"][0])[0]
                    db = bf.ptr_map[dptr]
                    ac = np.tile(np.array([0.66, 0.55, 0.56, 1.0], dtype=np.float32), (totloop, 1))
                    db["payload"] = bytearray(ac.tobytes())


def reconstruct_all():
    os.makedirs("/working_dir/c_bc1ba559921be6b9/artifacts/file_generation/ttl=63d/output", exist_ok=True)
    os.makedirs("/working_dir/c_bc1ba559921be6b9/artifacts/file_generation/ttl=63d/intermediate", exist_ok=True)

    tp_src = "/working_dir/c_bc1ba559921be6b9/work/Spellblade-production-third-person.blend"
    tp_out = "/working_dir/c_bc1ba559921be6b9/artifacts/file_generation/ttl=63d/output/Spellblade-review-candidate-third-person.blend"
    bf_tp = BlendFile(tp_src)

    upgrade_banner_texture(bf_tp)
    polish_original_tabards(bf_tp)

    pauldron_l = build_pauldron_left()
    pauldron_r = MeshBuilder(["MAKitMetal"])
    pauldron_r.mirror_from(pauldron_l)
    # Apply contrapposto shoulder shift: Right shoulder (+X, viewer left) is +0.038m outward and +0.048m higher;
    # Left shoulder (-X, viewer right) is +0.025m inward and +0.022m higher!
    for i, (x, y, z) in enumerate(pauldron_r.verts):
        pauldron_r.verts[i] = (float(x - 0.005), float(y - 0.072), float(z + 0.024))
    for i, (x, y, z) in enumerate(pauldron_l.verts):
        pauldron_l.verts[i] = (float(x + 0.012), float(y - 0.040), float(z + 0.012))

    replacements_tp = {
        "MEHelmetShellCanonical": transform_helmet_builder(build_helmet_shell()),
        "MEHelmetJawCanonical":   transform_helmet_builder(build_helmet_jaw()),
        "MEVisorCanonical":       transform_helmet_builder(build_visor()),
        "MECrestCanonical":       transform_helmet_builder(build_crest()),
        "MEPauldron.L":           pauldron_l,
        "MEPauldron.R":           pauldron_r,
        "MEBreastplate":          build_breastplate(),
        "MEGauntlet.L.001":       build_arm_and_gauntlet(is_right=False, first_person=False),
        "MEGauntlet.R.001":       build_arm_and_gauntlet(is_right=True,  first_person=False),
        "MEPalmRune.001":         build_sorcery_cluster(first_person=False),
        "MEHeroSword":            build_hero_sword(first_person=False),
        "MEGreave.L":             build_greave(is_right=False),
        "MEGreave.R":             build_greave(is_right=True),
        "MEBoot.L":               build_boot(is_right=False),
        "MEBoot.R":               build_boot(is_right=True),
    }

    for mname, builder in replacements_tp.items():
        builder.bake_loop_shading()
        bf_tp.replace_mesh(mname, builder)
        print(f"[TP] Replaced {mname:24s}: V={len(builder.verts):4d}, P={len(builder.polys):4d}")

    bf_tp.set_armature_rest_pose_in_pose_channels()
    sz_tp = bf_tp.save(tp_out)
    print(f"Saved TP candidate: {tp_out} ({sz_tp} bytes)")

    fp_src = "/working_dir/c_bc1ba559921be6b9/work/Spellblade-production-first-person.blend"
    fp_out = "/working_dir/c_bc1ba559921be6b9/artifacts/file_generation/ttl=63d/output/Spellblade-review-candidate-first-person.blend"
    bf_fp = BlendFile(fp_src)

    replacements_fp = {
        "MEArm.L":         build_arm_and_gauntlet(is_right=False, first_person=True),
        "MEArm.R":         build_arm_and_gauntlet(is_right=True,  first_person=True),
        "MEPalmRune":      build_sorcery_cluster(first_person=True),
        "MEHeroSword.001": build_hero_sword(first_person=True),
    }
    for mname, builder in replacements_fp.items():
        builder.bake_loop_shading()
        bf_fp.replace_mesh(mname, builder)
        print(f"[FP] Replaced {mname:24s}: V={len(builder.verts):4d}, P={len(builder.polys):4d}")

    bf_fp.set_armature_rest_pose_in_pose_channels()
    sz_fp = bf_fp.save(fp_out)
    print(f"Saved FP candidate: {fp_out} ({sz_fp} bytes)")


if __name__ == "__main__":
    reconstruct_all()
