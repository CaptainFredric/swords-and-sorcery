#!/usr/bin/env python3
"""
Castleward — Spellblade v2.8 Deep Sculptural & Design Fidelity Builder
======================================================================
Implements the 6 comprehensive sculptural upgrades across all 15 canonical `ME*` meshes
based on direct close-up comparison against `CANONICAL_SPELLBLADE_KEEP.png`,
`CANONICAL_HELMET_FOCUS_KEEP.png`, `CANONICAL_HAND_DETAIL_KEEP.png`, `shoulder.png`,
`tabard.png`, `boot.png`, `side.png`, and `back.png`:
  1. Helmet, Visor & Plume Crest: Commanding scowling V-brow box-helm, stepped champagne-brass
     nasal/brow T-bar, chiseled cheekbone bevels, dark T-cavity with central steel divider,
     dual-tone glowing cyan L-visor slits, framed ear-guards, and continuous 4-block crimson crest.
  2. 3-Tier Fortress Pauldrons: Steeply faceted slate-steel dome, thick V-peaked champagne-brass
     perimeter rim, inner-front square besagew corner plate with pyramid boss, and 2 overlapping
     dark-steel upper-arm rerebrace lames extending cleanly to the elbow couter.
  3. Torso Cuirass, Scarf & War-Belt: Athletic V-tapered diagonal side plackart lames, dimensional
     keeled mid-slate steel breastplate with recessed dark upper gorget inside a raised champagne-brass
     V-chevron, snug 2-fold V-notched crimson neck scarf + rear cape collar, and 3D saddle-leather
     war-belt with silver-steel buckle and diamond brass hip bosses.
  4. Arms, 5-Digit Gauntlets & Broadsword: Seamless elbow couter transition, tapered octagonal
     vambrace with outer fuller groove, 2 leather straps with brass keepers, flared brass wrist cuff,
     2-piece steel/brass dorsal hand plate, and 5 articulated 3-segment armored digits (4 curled
     fingers + thumb wrapped around the sword grip, plus `Node 28` closed & `Node 29` cupped open left hand).
  5. 3D Sculpted Pleated Crimson Tabards (`METabardFront`, `METabardBack`): Genuine 3D multi-pleated
     crimson cloth field (`7` vertical flutes with `1.8 cm` thickness), 3D beveled 3-step crenellated
     champagne-brass border, and 3D sculpted Golden Spear-Trident emblem proud of the cloth surface.
  6. Lower Armor (`MEGreave.L/R`, `MEBoot.L/R`): Dark-charcoal/dark-iron gambeson thighs for high
     value contrast, dual-layer brown-leather + silver-loop hip tassets (`tabard.png`), tall hexagonal
     steel knee poleyns with V-angled gold brow rim & L-stepped steel bevel recess (`boot.png`),
     solid multi-planar front-keeled shin greaves (`rx = 0.132 -> 0.106`), 38° V-angled leather/brass
     ankle straps, and wide 5-facet trapezoidal steel sabaton boots.
"""
import sys, math, struct
import numpy as np
from pathlib import Path

sys.path.insert(0, '/working_dir/c_bc1ba559921be6b9/artifacts/file_generation/ttl=63d/intermediate')
from mesh_builder import MeshBuilder, BoneFrame, PALETTE
import reconstruct_spellblade as rs_prev


def transform_helmet_upright(mb: MeshBuilder) -> MeshBuilder:
    piv_y, piv_z = 0.04, 1.76
    rad_p = math.radians(5.0)
    cp, sp = math.cos(rad_p), math.sin(rad_p)
    for i, (x, y, z) in enumerate(mb.verts):
        dy = y - piv_y
        dz = z - piv_z
        ny = piv_y + dy * cp + dz * sp - 0.022
        nz = piv_z - dy * sp + dz * cp - 0.008
        mb.verts[i] = (float(x), float(ny), float(nz))
    return mb


def build_v28_refined_helmet_parts():
    """
    Returns `(mb_shell, mb_jaw, mb_visor, mb_crest)` sculpted directly to match
    `CANONICAL_HELMET_FOCUS_KEEP.png` and `side.png`:
      - Wider, more commanding temple/brow silhouette (`rx_front = 0.110`, `rx_side = 0.138`)
      - Fierce downward-sloping V-brow (`z_corner = 1.910` sloping down to `z_center = 1.872`)
      - Stepped champagne-brass nasal & brow T-bar tapering to a sharp V-tip at `z = 1.842`
      - Chiseled cheekbone bevels on the wedge jaw + dark central faceplate divider pillar
      - Dual-tone glowing cyan L-visor bars (`MAVisorGlow`) angled with the scowling V-brow
      - Continuous, gap-free 4-segment Spartan crimson plume crest (`MECrestCanonical`)
    """
    w = "head"

    # 1. MEHelmetShellCanonical (Dome, Scowling V-Brow, Ear-Guards, Gold Nasal/Brow Bar)
    mb_shell = MeshBuilder(["MAKitMetal", "MAKitMatte"])

    def helm_ring(rx_front, yf_c, yf_corner, rx_side, yb_side, rx_back, yb_back, yb_c, z_c, z_corner, z_side, z_back):
        return [
            ( 0.000,     yf_c,      z_c),      # 0: Front center V-brow keel
            (-rx_front,  yf_corner, z_corner), # 1: Left Front-Outer Brow Corner
            (-rx_side,   yb_side,   z_side),   # 2: Left Rear-Side Temple Corner
            (-rx_back,   yb_back,   z_back),   # 3: Left Back Corner
            ( 0.000,     yb_c,      z_back),   # 4: Back center keel
            ( rx_back,   yb_back,   z_back),   # 5: Right Back Corner
            ( rx_side,   yb_side,   z_side),   # 6: Right Rear-Side Temple Corner
            ( rx_front,  yf_corner, z_corner), # 7: Right Front-Outer Brow Corner
        ]

    r0     = helm_ring(0.110, 0.246, 0.212, 0.138, 0.020, 0.114, -0.082, -0.122, 1.872, 1.908, 1.902, 1.888)
    r1_lip = helm_ring(0.112, 0.242, 0.208, 0.140, 0.018, 0.116, -0.084, -0.124, 1.936, 1.954, 1.948, 1.936)
    r1_out = helm_ring(0.108, 0.236, 0.202, 0.136, 0.017, 0.112, -0.082, -0.120, 1.942, 1.958, 1.952, 1.940)
    r1_in  = helm_ring(0.096, 0.220, 0.188, 0.124, 0.014, 0.102, -0.074, -0.110, 1.952, 1.966, 1.960, 1.946)
    r2     = helm_ring(0.068, 0.188, 0.158, 0.088, 0.010, 0.076, -0.056, -0.094, 2.018, 2.014, 2.006, 1.996)

    cols_brow    = ["STEEL_LIGHT", "STEEL_FACET", "STEEL_FACET", "STEEL_MAIN",  "STEEL_MAIN",  "STEEL_FACET", "STEEL_MAIN",  "STEEL_LIGHT"]
    cols_lip     = ["STEEL_BRIGHT","STEEL_MAIN",  "STEEL_FACET", "STEEL_LIGHT", "STEEL_LIGHT", "STEEL_MAIN",  "STEEL_EDGE",  "STEEL_BRIGHT"]
    cols_step    = ["STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE"]
    cols_chamfer = ["STEEL_BRIGHT","STEEL_MAIN",  "STEEL_FACET", "STEEL_MAIN",  "STEEL_MAIN",  "STEEL_MAIN",  "STEEL_LIGHT", "STEEL_BRIGHT"]

    mb_shell.add_loft(
        [r0, r1_lip, r1_out, r1_in, r2],
        weights=w, mat="METAL",
        colors=[cols_brow, cols_lip, cols_step, cols_chamfer],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_LIGHT",
    )

    # Rear neck-guard rim band
    rb0 = [(-0.136, 0.016, 1.870), (-0.116, -0.084, 1.866), (0.0, -0.126, 1.864), (0.116, -0.084, 1.866), (0.136, 0.016, 1.870)]
    rb1 = [(-0.138, 0.016, 1.902), (-0.118, -0.086, 1.898), (0.0, -0.128, 1.896), (0.118, -0.086, 1.898), (0.138, 0.016, 1.902)]
    rb2 = [(-0.126, 0.016, 1.906), (-0.108, -0.076, 1.902), (0.0, -0.116, 1.900), (0.108, -0.076, 1.902), (0.126, 0.016, 1.906)]
    mb_shell.add_loft([rb0, rb1, rb2], weights=w, mat="METAL", colors=[["STEEL_MAIN", "STEEL_LIGHT", "STEEL_LIGHT", "STEEL_MAIN"], ["STEEL_EDGE", "STEEL_BRIGHT", "STEEL_BRIGHT", "STEEL_EDGE"]], closed_ring=False)

    # Symmetrical Framed Side Ear-Guards (`CANONICAL_HELMET_FOCUS_KEEP.png`)
    for sign in (-1.0, 1.0):
        x_eb = sign * 0.136
        if sign > 0:
            eb_corners = [
                (x_eb - 0.002, 0.108, 1.886),
                (x_eb + 0.003, 0.018, 1.882),
                (x_eb + 0.001, 0.020, 1.770),
                (x_eb - 0.003, 0.110, 1.766),
            ]
        else:
            eb_corners = [
                (x_eb - 0.003, 0.018, 1.882),
                (x_eb + 0.002, 0.108, 1.886),
                (x_eb + 0.003, 0.110, 1.766),
                (x_eb - 0.001, 0.020, 1.770),
            ]
        rs_prev.add_framed_rect_plate(
            mb_shell, eb_corners, normal_dir=(sign * 0.98, 0.14, 0.04),
            thickness=0.020, border_frac=0.34, weights=w,
            mat_border="METAL", col_border="STEEL_LIGHT", col_border_edge="STEEL_BRIGHT",
            mat_inner="MATTE", col_inner="FACE_DARK",
            open_top=False
        )

    # Raised Beveled Champagne-Brass Central Nasal/Brow Bar + Horizontal Brow Step (`CANONICAL_HELMET_FOCUS_KEEP.png`)
    def gold_trim_ring(hx_out, hx_in, yf_face, yf_base, z_face, z_base):
        return [
            ( 0.000,   yf_face + 0.005, z_face),
            (-hx_in,   yf_face,         z_face),
            (-hx_out,  yf_base,         z_base),
            ( 0.000,   yf_base,         z_base),
            ( hx_out,  yf_base,         z_base),
            ( hx_in,   yf_face,         z_face),
        ]

    b0 = gold_trim_ring(0.004, 0.003, 0.258, 0.232, 1.842, 1.844)
    b1 = gold_trim_ring(0.033, 0.026, 0.260, 0.234, 1.882, 1.882)
    b2 = gold_trim_ring(0.033, 0.026, 0.248, 0.220, 1.944, 1.942)
    b3 = gold_trim_ring(0.034, 0.027, 0.218, 0.180, 2.024, 2.008)
    b4 = gold_trim_ring(0.034, 0.027, 0.035, 0.035, 2.022, 2.006)

    g_cols_brow = ["BRASS_BRIGHT", "BRASS_MAIN", "BRASS_DARK", "BRASS_DARK", "BRASS_MAIN", "BRASS_BRIGHT"]
    g_cols_top  = ["BRASS_BRIGHT", "BRASS_EDGE", "BRASS_SHADE","BRASS_DARK", "BRASS_EDGE", "BRASS_BRIGHT"]
    mb_shell.add_loft(
        [b0, b1, b2, b3, b4],
        weights=w, mat="METAL",
        colors=[g_cols_brow, g_cols_brow, g_cols_brow, g_cols_top],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT",
    )

    # 2. MEHelmetJawCanonical (Recessed Visor Cavity, Central Faceplate Divider, Chiseled Cheekguards)
    mb_jaw = MeshBuilder(["MAKitMetal", "MAKitMatte"])

    def cav_ring(z):
        return [
            ( 0.000,  0.196, z),
            (-0.030,  0.194, z),
            (-0.098,  0.170, z),
            (-0.112,  0.115, z),
            ( 0.000, -0.068, z),
            ( 0.112,  0.115, z),
            ( 0.098,  0.170, z),
            ( 0.030,  0.194, z),
        ]
    mb_jaw.add_loft([cav_ring(1.720), cav_ring(1.930)], weights=w, mat="MATTE", colors="FACE_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    # Central dark-steel vertical visor divider pillar between the two cyan slits (`CANONICAL_HELMET_FOCUS_KEEP.png`)
    mb_jaw.add_beveled_box(
        center=(0.000, 0.214, 1.796),
        half_extents=(0.012, 0.012, 0.062),
        bevel=0.20, weights=w, mat="METAL",
        col_main="STEEL_FACET", col_edge="STEEL_LIGHT", col_dark="FACE_DARK",
    )

    def jaw_shell_ring(x_in, yf_in, x_step, yf_step, x_cheek, yf_cheek, x_temp, yf_temp, rx_side, yb_side, rx_back, yb_back, yb_c, z_in, z_cheek, z_temp, z_side, z_back):
        return [
            (-x_in,     yf_in,    z_in),
            (-x_step,   yf_step,  z_in),
            (-x_cheek,  yf_cheek, z_cheek),
            (-x_temp,   yf_temp,  z_temp),
            (-rx_side,  yb_side,  z_side),
            (-rx_back,  yb_back,  z_back),
            ( 0.000,    yb_c,     z_back),
            ( rx_back,  yb_back,  z_back),
            ( rx_side,  yb_side,  z_side),
            ( x_temp,   yf_temp,  z_temp),
            ( x_cheek,  yf_cheek, z_cheek),
            ( x_step,   yf_step,  z_in),
            ( x_in,     yf_in,    z_in),
        ]

    j_under   = jaw_shell_ring(0.032, 0.202, 0.052, 0.222, 0.098, 0.208, 0.100, 0.205, 0.132, 0.020, 0.112, -0.080, -0.120, 1.724, 1.738, 1.740, 1.752, 1.744)
    j_bot_lip = jaw_shell_ring(0.032, 0.206, 0.054, 0.226, 0.102, 0.212, 0.104, 0.209, 0.136, 0.020, 0.116, -0.082, -0.122, 1.740, 1.754, 1.756, 1.768, 1.760)
    j_bot_in  = jaw_shell_ring(0.032, 0.204, 0.052, 0.224, 0.100, 0.210, 0.102, 0.207, 0.134, 0.020, 0.114, -0.080, -0.120, 1.744, 1.758, 1.760, 1.771, 1.763)
    j_top     = jaw_shell_ring(0.032, 0.206, 0.054, 0.226, 0.104, 0.212, 0.106, 0.210, 0.138, 0.020, 0.114, -0.080, -0.120, 1.840, 1.862, 1.904, 1.902, 1.888)
    j_sill    = jaw_shell_ring(0.032, 0.196, 0.048, 0.202, 0.098, 0.194, 0.100, 0.196, 0.128, 0.020, 0.108, -0.076, -0.116, 1.844, 1.866, 1.906, 1.904, 1.890)

    jaw_rim_cols  = ["STEEL_DARK", "STEEL_LIGHT", "STEEL_DARK", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET", "STEEL_MAIN", "STEEL_MAIN", "STEEL_DARK", "STEEL_LIGHT", "STEEL_DARK"]
    jaw_step_cols = ["STEEL_SHADE"] * 12
    jaw_face_cols = ["STEEL_DARK", "STEEL_LIGHT", "STEEL_SHADE", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET", "STEEL_MAIN", "STEEL_MAIN", "STEEL_SHADE", "STEEL_LIGHT", "STEEL_DARK"]
    jaw_sill_cols = ["STEEL_SHADE", "STEEL_EDGE", "STEEL_SHADE", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET", "STEEL_FACET", "STEEL_MAIN", "STEEL_MAIN", "STEEL_SHADE", "STEEL_EDGE", "STEEL_SHADE"]

    mb_jaw.add_loft(
        [j_under, j_bot_lip, j_bot_in, j_top, j_sill],
        weights=w, mat="METAL",
        colors=[jaw_rim_cols, jaw_step_cols, jaw_face_cols, jaw_sill_cols],
        closed_ring=False,
    )

    # 3. MEVisorCanonical (Scowling Dual-Tone Glowing Cyan L-Shaped Visor Bars)
    mb_visor = MeshBuilder(["MAVisorGlow"])
    for sign in (-1.0, 1.0):
        eye_pts = [
            (sign * 0.0175, 0.226, 1.878),
            (sign * 0.0980, 0.210, 1.898),
            (sign * 0.0965, 0.210, 1.876),
            (sign * 0.0175, 0.226, 1.858),
        ]
        mb_visor.add_flat_beveled_plate(
            eye_pts, normal_dir=(sign * 0.18, 0.98, 0.0), thickness=0.008, bevel_inset=0.14, weights=w,
            mat="VISOR", col_face="WHITE", col_edge="WHITE", col_side="WHITE", col_back="WHITE"
        )
        vert_pts = [
            (sign * 0.0175, 0.226, 1.864),
            (sign * 0.0325, 0.222, 1.866),
            (sign * 0.0310, 0.212, 1.734),
            (sign * 0.0175, 0.215, 1.732),
        ]
        mb_visor.add_flat_beveled_plate(
            vert_pts, normal_dir=(sign * 0.12, 0.99, 0.0), thickness=0.008, bevel_inset=0.14, weights=w,
            mat="VISOR", col_face="WHITE", col_edge="WHITE", col_side="WHITE", col_back="WHITE"
        )

    # 4. MECrestCanonical (Continuous, Sweeping 4-Segment Spartan Crimson Plume Crest — `side.png`)
    mb_crest = MeshBuilder(["MAKitMatte"])
    blocks_spec = [
        ( 0.148, 2.012,  0.156, 2.126,  0.022, 2.008,  0.012, 2.108, 0.030, 0.025),
        ( 0.026, 2.002,  0.018, 2.078, -0.058, 1.980, -0.082, 2.046, 0.027, 0.023),
        (-0.052, 1.974, -0.076, 2.024, -0.116, 1.912, -0.164, 1.968, 0.025, 0.022),
        (-0.110, 1.908, -0.156, 1.952, -0.128, 1.792, -0.194, 1.846, 0.024, 0.020),
    ]
    for (yfb, zfb, yft, zft, ybb, zbb, ybt, zbt, hwb, hwt) in blocks_spec:
        def c_horiz_ring(yf, zf, yb, zb, hw):
            return [
                ( 0.000,     yf + 0.003, zf),
                (-hw,        yf,         zf),
                (-hw * 0.94, yb,         zb),
                ( 0.000,     yb - 0.003, zb),
                ( hw * 0.94, yb,         zb),
                ( hw,        yf,         zf),
            ]
        r_bot = c_horiz_ring(yfb, zfb, ybb, zbb, hwb)
        ym_f, zm_f = 0.14*yfb + 0.86*yft, 0.14*zfb + 0.86*zft
        ym_b, zm_b = 0.14*ybb + 0.86*ybt, 0.14*zbb + 0.86*zbt
        r_mid = c_horiz_ring(ym_f, zm_f, ym_b, zm_b, hwt)
        r_top = c_horiz_ring(yft - 0.005, zft, ybt + 0.005, zbt, hwt * 0.84)
        cols_body = ["CLOTH_MAIN",  "CLOTH_SHADE", "CLOTH_MAIN",  "CLOTH_LIGHT", "CLOTH_BRIGHT", "CLOTH_MAIN"]
        cols_bevl = ["CLOTH_BRIGHT","CLOTH_MAIN",  "CLOTH_LIGHT", "CLOTH_BRIGHT","CLOTH_BRIGHT", "CLOTH_LIGHT"]
        mb_crest.add_loft([r_bot, r_mid, r_top], weights=w, mat="MATTE", colors=[cols_body, cols_bevl], closed_ring=True, cap_start=True, cap_end=True, cap_color="CLOTH_BRIGHT")

    return (
        transform_helmet_upright(mb_shell),
        transform_helmet_upright(mb_jaw),
        transform_helmet_upright(mb_visor),
        transform_helmet_upright(mb_crest),
    )


def build_v28_refined_pauldron_pair():
    """
    Builds the symmetrical Left and Right 3-Tier Chiseled Fortress Pauldrons (`shoulder.png`)
    with an extended lower rerebrace lame so there is zero elbow gap in any view or pose!
    """
    pauldron_l = rs_prev.build_pauldron_left()
    # Add a 3rd inner-lower dark-steel rerebrace lame bridging down to z=1.320 so the upper arm
    # transitions into the forearm couter with zero gap (`shoulder.png` & Panel 4)!
    ua_h, ua_t = (-0.345, -0.025, 1.545), (-0.402, 0.145, 1.285)
    ua_frame = BoneFrame(ua_h, ua_t, up_hint=(0.0, 1.0, 0.0))
    def r_ring(t, ru, rv):
        d = 0.76
        pts = [(0, rv), (ru*d, rv*d), (ru, 0), (ru*d, -rv*d), (0, -rv), (-ru*d, -rv*d), (-ru, 0), (-ru*d, rv*d)]
        return [ua_frame.pt(u, v, t) for (u, v) in pts]
    pauldron_l.add_loft(
        [r_ring(0.42, 0.118, 0.116), r_ring(0.78, 0.112, 0.110), r_ring(0.84, 0.106, 0.104)],
        weights="upper_arm.L", mat="METAL",
        colors=[["STEEL_DARK", "STEEL_SHADE", "STEEL_SHADE", "STEEL_DARK", "STEEL_DARK", "STEEL_FACET", "STEEL_MAIN", "STEEL_FACET"], "STEEL_LIGHT"],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK"
    )

    pauldron_r = MeshBuilder(["MAKitMetal"])
    pauldron_r.mirror_from(pauldron_l)
    for i, (x, y, z) in enumerate(pauldron_l.verts):
        pauldron_l.verts[i] = (float(x + 0.008), float(y - 0.024), float(z + 0.010))
    for i, (x, y, z) in enumerate(pauldron_r.verts):
        pauldron_r.verts[i] = (float(x - 0.008), float(y - 0.024), float(z + 0.010))
    return pauldron_l, pauldron_r


def build_v28_refined_breastplate_scarf_and_belt():
    """
    Sculpts the athletic V-tapered Torso Cuirass, Recessed Dark Upper Gorget, Keeled Slate-Steel
    Breastplate inside the Raised Champagne-Brass V-Chevron, Diagonal Side Plackart Lames,
    Compact V-Notched 2-Fold Crimson Scarf + Rear Collar, and Saddle-Leather War-Belt (`CANONICAL_SPELLBLADE_KEEP.png`).
    """
    mb = MeshBuilder(["MAKitMatte", "MAKitMetal"])

    def core_ring(rx, yf, yb, z):
        return [
            ( 0.000,      yf,        z),
            (-rx * 0.72,  yf * 0.75, z),
            (-rx,         0.000,     z),
            (-rx * 0.72,  yb * 0.75, z),
            ( 0.000,      yb,        z),
            ( rx * 0.72,  yb * 0.75, z),
            ( rx,         0.000,     z),
            ( rx * 0.72,  yf * 0.75, z),
        ]

    c_rings = [
        core_ring(0.168, 0.142, -0.132, 0.950),
        core_ring(0.162, 0.160, -0.142, 1.160),
        core_ring(0.165, 0.172, -0.148, 1.300),
        core_ring(0.205, 0.190, -0.162, 1.520),
        core_ring(0.122, 0.160, -0.112, 1.800),
    ]
    mb.add_loft(c_rings, weights=["pelvis", "pelvis", "spine", "chest", "chest"], mat="MATTE", colors="UNDERSUIT_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK")

    def torso_ring(rx, yf_c, yf_s, yb_c, yb_s, z):
        return [
            ( 0.000,      yf_c,   z),
            (-rx * 0.88,  yf_s,   z),
            (-rx,        -0.015,  z),
            (-rx * 0.94,  yb_s,   z),
            ( 0.000,      yb_c,   z),
            ( rx * 0.94,  yb_s,   z),
            ( rx,        -0.015,  z),
            ( rx * 0.88,  yf_s,   z),
        ]

    # Athletic V-Tapered Diagonal Dark-Steel Side Plackart/Rib Lames (`rx = 0.184` at waist flaring to `0.236` at chest!)
    for z_bot, z_top, rx_b, rx_t, yf_b, yf_t, yb_b, yb_t, w_tag in [
        (1.275, 1.385, 0.184, 0.208, 0.212, 0.224, -0.164, -0.172, "spine"),
        (1.378, 1.495, 0.204, 0.228, 0.222, 0.236, -0.170, -0.178, "chest"),
        (1.488, 1.575, 0.224, 0.242, 0.232, 0.242, -0.176, -0.184, "chest"),
    ]:
        tr0 = torso_ring(rx_b, yf_b, yf_b - 0.024, yb_b, yb_b + 0.016, z_bot)
        tr1 = torso_ring(rx_t, yf_t, yf_t - 0.020, yb_t, yb_t + 0.016, z_top - 0.010)
        tr2 = torso_ring(rx_t - 0.005, yf_t - 0.005, yf_t - 0.024, yb_t + 0.004, yb_t + 0.018, z_top)
        lame_c = ["STEEL_DARK",  "STEEL_DARK",  "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_DARK",  "STEEL_FACET"]
        top_c  = ["STEEL_FACET", "STEEL_LIGHT", "STEEL_MAIN",  "STEEL_SHADE", "STEEL_SHADE", "STEEL_MAIN",  "STEEL_LIGHT", "STEEL_BRIGHT"]
        mb.add_loft([tr0, tr1, tr2], weights=w_tag, mat="METAL", colors=[lame_c, top_c], closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK")

    # Keeled Slate-Steel Breastplate with Recessed Dark Upper Gorget & Raised Champagne-Brass V-Chevron (`CANONICAL_SPELLBLADE_KEEP.png`)
    def plackart_row(x_gold_out, x_gold_in, y_side, y_keel, z):
        y_back = y_side - 0.034
        return [
            (-x_gold_out, y_back,           z),
            (-x_gold_out, y_side + 0.014,   z),
            (-x_gold_in,  y_side + 0.018,   z),
            (-x_gold_in,  y_side + 0.002,   z),
            ( 0.000,      y_keel,           z),
            ( x_gold_in,  y_side + 0.002,   z),
            ( x_gold_in,  y_side + 0.018,   z),
            ( x_gold_out, y_side + 0.014,   z),
            ( x_gold_out, y_back,           z),
        ]

    pr0 = plackart_row(0.042, 0.003, 0.228, 0.248, 1.274) # Sharp V-apex at top of belt buckle
    pr1 = plackart_row(0.148, 0.106, 0.252, 0.292, 1.430) # Broad pectoral swell with prominent central keel
    pr2 = plackart_row(0.184, 0.142, 0.248, 0.284, 1.535) # Upper pectoral ridge
    pr3 = plackart_row(0.172, 0.132, 0.226, 0.252, 1.598) # Recessed dark upper gorget under crimson scarf

    # Left pectoral face (`col 4`) is lit (`STEEL_BRIGHT`), right pectoral face (`col 3`) is mid-slate (`STEEL_MAIN`),
    # and upper gorget tier (`row_cols_top`) is darker (`STEEL_FACET` / `STEEL_DARK`) for authentic depth under the scarf!
    row_cols_low = ["BRASS_SHADE", "BRASS_MAIN",   "BRASS_EDGE", "STEEL_MAIN",  "STEEL_LIGHT",  "BRASS_EDGE", "BRASS_MAIN",   "BRASS_SHADE", "STEEL_SHADE"]
    row_cols_mid = ["BRASS_MAIN",  "BRASS_BRIGHT", "BRASS_EDGE", "STEEL_MAIN",  "STEEL_BRIGHT", "BRASS_EDGE", "BRASS_BRIGHT", "BRASS_MAIN",  "STEEL_SHADE"]
    row_cols_top = ["BRASS_MAIN",  "BRASS_BRIGHT", "BRASS_EDGE", "STEEL_DARK",  "STEEL_FACET",  "BRASS_EDGE", "BRASS_BRIGHT", "BRASS_MAIN",  "STEEL_SHADE"]

    mb.add_loft(
        [pr0, pr1, pr2, pr3],
        weights=["spine", "chest", "chest", "chest"],
        mat="METAL",
        colors=[row_cols_low, row_cols_mid, row_cols_top],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT",
    )

    # Snug, Chiseled 2-Fold V-Notched Crimson Neck Scarf (`CANONICAL_HELMET_FOCUS_KEEP.png` & `side.png`)
    def scarf_ring(rx, yf_v, yf_side, yb_v, yb_side, z_front_v, z_side, z_back):
        return [
            ( 0.000,      yf_v,     z_front_v),
            (-rx * 0.62,  yf_side,  z_side),
            (-rx,         0.012,    z_side + 0.012),
            (-rx * 0.82,  yb_side,  z_back + 0.008),
            ( 0.000,      yb_v,     z_back),
            ( rx * 0.82,  yb_side,  z_back + 0.008),
            ( rx,         0.012,    z_side + 0.012),
            ( rx * 0.62,  yf_side,  z_side),
        ]

    s0     = scarf_ring(0.158, 0.256, 0.218, -0.192, -0.172, 1.530, 1.608, 1.545)
    s1_out = scarf_ring(0.206, 0.268, 0.228, -0.212, -0.188, 1.596, 1.674, 1.618)
    s1_in  = scarf_ring(0.190, 0.246, 0.212, -0.194, -0.172, 1.606, 1.682, 1.626)
    s2_out = scarf_ring(0.212, 0.254, 0.218, -0.210, -0.186, 1.668, 1.754, 1.718)
    s3     = scarf_ring(0.158, 0.202, 0.184, -0.158, -0.142, 1.714, 1.776, 1.756)

    scarf_cols_bright = ["CLOTH_BRIGHT", "CLOTH_LIGHT", "CLOTH_MAIN", "CLOTH_LIGHT", "CLOTH_BRIGHT", "CLOTH_MAIN", "CLOTH_LIGHT", "CLOTH_BRIGHT"]
    scarf_cols_mid    = ["CLOTH_LIGHT",  "CLOTH_MAIN",  "CLOTH_SHADE","CLOTH_MAIN",  "CLOTH_LIGHT",  "CLOTH_SHADE","CLOTH_MAIN",  "CLOTH_LIGHT"]
    scarf_cols_crev   = ["CLOTH_DARK",   "CLOTH_DARK",  "CLOTH_DARK", "CLOTH_DARK",  "CLOTH_DARK",   "CLOTH_DARK", "CLOTH_DARK",  "CLOTH_DARK"]

    mb.add_loft(
        [s0, s1_out, s1_in, s2_out, s3],
        weights="chest",
        mat="MATTE",
        colors=[scarf_cols_mid, scarf_cols_crev, scarf_cols_bright, scarf_cols_mid],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK",
    )

    # Cohesive Trapezoidal Upper-Back Crimson Cape Collar Fold (`back.png` & `side.png`)
    back_collar_pts = [
        (-0.142, -0.186, 1.605),
        ( 0.142, -0.186, 1.605),
        ( 0.160, -0.198, 1.460),
        (-0.160, -0.198, 1.460),
    ]
    mb.add_flat_beveled_plate(
        back_collar_pts, normal_dir=(0.0, -0.98, 0.12), thickness=0.018, bevel_inset=0.14, weights="chest",
        mat="MATTE", col_face="CLOTH_MAIN", col_edge="CLOTH_LIGHT", col_side="CLOTH_DARK"
    )

    # Saddle-Leather War-Belt (`tabard.png`)
    b0 = torso_ring(0.196, 0.232, 0.212, -0.172, -0.158, 1.180)
    b1 = torso_ring(0.202, 0.238, 0.218, -0.178, -0.164, 1.235)
    b2 = torso_ring(0.196, 0.232, 0.212, -0.172, -0.158, 1.290)
    mb.add_loft([b0, b1, b2], weights="pelvis", mat="MATTE", colors=["LEATHER_SHADE", "LEATHER_LIGHT"], closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_MAIN")

    # Silver-Steel Belt Buckle Frame & Recessed Tongue Pin (`tabard.png`)
    mb.add_beveled_box(center=(0.000, 0.242, 1.235), half_extents=(0.044, 0.010, 0.048), weights="pelvis", mat="MATTE", col_main="FACE_DARK", col_edge="LEATHER_DARK", col_dark="FACE_DARK")
    mb.add_beveled_box(center=( 0.000, 0.254, 1.284), half_extents=(0.056, 0.014, 0.014), bevel=0.22, weights="pelvis", mat="METAL", col_main="STEEL_BRIGHT", col_edge="STEEL_BRIGHT", col_dark="STEEL_LIGHT")
    mb.add_beveled_box(center=( 0.000, 0.254, 1.186), half_extents=(0.056, 0.014, 0.014), bevel=0.22, weights="pelvis", mat="METAL", col_main="STEEL_BRIGHT", col_edge="STEEL_BRIGHT", col_dark="STEEL_LIGHT")
    mb.add_beveled_box(center=( 0.044, 0.254, 1.235), half_extents=(0.014, 0.014, 0.058), bevel=0.22, weights="pelvis", mat="METAL", col_main="STEEL_BRIGHT", col_edge="STEEL_BRIGHT", col_dark="STEEL_LIGHT")
    mb.add_beveled_box(center=(-0.044, 0.254, 1.235), half_extents=(0.014, 0.014, 0.058), bevel=0.22, weights="pelvis", mat="METAL", col_main="STEEL_BRIGHT", col_edge="STEEL_BRIGHT", col_dark="STEEL_LIGHT")
    mb.add_beveled_box(center=( 0.022, 0.250, 1.235), half_extents=(0.020, 0.010, 0.008), bevel=0.20, weights="pelvis", mat="METAL", col_main="STEEL_LIGHT", col_edge="STEEL_BRIGHT", col_dark="STEEL_FACET")

    for sign in (-1.0, 1.0):
        for lx in (0.074, 0.156):
            mb.add_beveled_box(center=(sign * lx, 0.232, 1.235), half_extents=(0.009, 0.015, 0.056), weights="pelvis", mat="MATTE", col_main="LEATHER_LIGHT", col_edge="LEATHER_LIGHT", col_dark="LEATHER_SHADE")
        mb.add_diamond_boss(
            center=(sign * 0.128, 0.236, 1.235), normal=(sign * 0.26, 0.96, 0.0), up_vec=(0.0, 0.0, 1.0),
            radius_u=0.038, radius_v=0.040, height=0.018, weights="pelvis", mat="METAL",
            col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_base="BRASS_SHADE",
        )
        mb.add_diamond_boss(
            center=(sign * 0.130, 0.246, 1.235), normal=(sign * 0.26, 0.96, 0.0), up_vec=(0.0, 0.0, 1.0),
            radius_u=0.017, radius_v=0.019, height=0.012, weights="pelvis", mat="METAL",
            col_main="STEEL_BRIGHT", col_edge="STEEL_BRIGHT", col_base="STEEL_LIGHT",
        )

    return mb


def build_v28_sculpted_3d_tabard(is_front=True):
    """
    Constructs a genuine 3D Sculpted Pleated Crimson & Champagne-Brass Tabard (`METabardFront`
    or `METabardBack` — `tabard.png` & `back.png`) with:
      1. 3D Pleated Crimson Cloth Field (`7` vertical cloth strips with alternating convex/concave
         flute depth `±0.012 m` and `0.018 m` physical thickness so real 3D folds catch the light!).
      2. 3D Beveled Champagne-Brass 3-Step Crenellated Border (`BRASS_BRIGHT` / `BRASS_MAIN` / `BRASS_SHADE`)
         framing the left, right, and stepped bottom hem (`tabard.png` & `back.png`).
      3. 3D Sculpted Beveled Champagne-Brass Spear-Trident Heraldic Emblem (`central diamond spearhead`,
         `tapered shaft`, `bottom diamond pommel`, and `2 curved/angled upward side prongs with inner barbs`)
         raised `4 mm` proud of the pleated crimson cloth!
      4. Smooth 3-joint cloth skinning weights (`tabard_root -> tabard_front_01 -> tabard_front_02`
         or `chest -> tabard_back_01 -> tabard_back_02`).
    """
    mb = MeshBuilder(["MAKitMatte", "MAKitMetal"])

    if is_front:
        z_top, z_bot_outer, z_bot_mid, z_bot_ctr = 1.186, 0.655, 0.575, 0.495
        hw_top, hw_bot = 0.092, 0.138
        n_dir = (0.0, 1.0, 0.0)
    else:
        z_top, z_bot_outer, z_bot_mid, z_bot_ctr = 1.560, 0.625, 0.535, 0.445
        hw_top, hw_bot = 0.128, 0.212
        n_dir = (0.0, -1.0, 0.0)

    def w_at_z(z_val):
        if is_front:
            if z_val >= 1.02:
                u = float(np.clip((1.186 - z_val) / 0.166, 0.0, 1.0))
                return {"tabard_root": u, "pelvis": 1.0 - u}
            elif z_val >= 0.76:
                u = float(np.clip((1.02 - z_val) / 0.26, 0.0, 1.0))
                return {"tabard_front_01": u, "tabard_root": 1.0 - u}
            else:
                u = float(np.clip((0.76 - z_val) / 0.26, 0.0, 1.0))
                return {"tabard_front_02": u, "tabard_front_01": 1.0 - u}
        else:
            if z_val >= 1.32:
                u = float(np.clip((1.560 - z_val) / 0.24, 0.0, 1.0))
                return {"tabard_back_01": u, "chest": 1.0 - u}
            elif z_val >= 0.88:
                u = float(np.clip((1.32 - z_val) / 0.44, 0.0, 1.0))
                return {"tabard_back_02": u, "tabard_back_01": 1.0 - u}
            else:
                return {"tabard_back_02": 0.92, "tabard_back_01": 0.08}

    def y_surf(x_val, z_val, flute_offset=0.0):
        if is_front:
            t = np.clip((z_top - z_val) / (z_top - z_bot_ctr), 0.0, 1.0)
            return float(0.238 + 0.016 * math.sin(t * math.pi * 0.78) - 0.006 * (t ** 2) + flute_offset)
        else:
            t = np.clip((z_top - z_val) / (z_top - z_bot_ctr), 0.0, 1.0)
            return float(-0.190 - 0.064 * t - 0.030 * (t ** 1.75) + flute_offset)

    # 1. Build the 3D Pleated Crimson Cloth Field + Stepped Gold Border as a 9-column x 12-row 3D grid
    #    Columns `c = 0..8` span from `-hw(z)` to `+hw(z)`:
    #      - `c = 0..1` and `c = 7..8` are the raised Champagne-Brass Side Borders (`border_w = 0.22 * hw`)
    #      - `c = 1..7` (6 inner bands) form the 3D Pleated Crimson Cloth Field with alternating flute depths!
    u_fracs  = [-1.00, -0.76, -0.50, -0.25, 0.00, +0.25, +0.50, +0.76, +1.00]
    flutes_f = [ 0.004, 0.004,-0.008,+0.007,-0.007,+0.007,-0.008, 0.004, 0.004] if is_front else [-0.004,-0.004,+0.008,-0.007,+0.007,-0.007,+0.008,-0.004,-0.004]
    thick = 0.018 if is_front else -0.018

    n_rows = 10
    z_rows = np.linspace(z_top, z_bot_outer, n_rows)

    front_grid_v = np.zeros((n_rows, 9), dtype=np.int32)
    back_grid_v  = np.zeros((n_rows, 9), dtype=np.int32)

    for r_i, zv in enumerate(z_rows):
        t_z = (z_top - zv) / (z_top - z_bot_ctr)
        hw = hw_top + (hw_bot - hw_top) * (t_z ** 0.92)
        w_dict = w_at_z(zv)
        for c_i, (uf, fl) in enumerate(zip(u_fracs, flutes_f)):
            xv = uf * hw
            yv = y_surf(xv, zv, flute_offset=fl * (0.35 + 0.65 * t_z))
            front_grid_v[r_i, c_i] = mb.add_vert((xv, yv, zv), w_dict)
            back_grid_v[r_i, c_i]  = mb.add_vert((xv, yv - thick, zv), w_dict)

    col_band_mats = ["METAL", "MATTE", "MATTE", "MATTE", "MATTE", "MATTE", "MATTE", "METAL"]
    col_band_cols = [
        "BRASS_MAIN",   # Left gold border
        "CLOTH_SHADE",  # Pleat 1 shadow
        "CLOTH_BRIGHT", # Pleat 2 highlight
        "CLOTH_MAIN",   # Center-left pleat
        "CLOTH_LIGHT",  # Center-right pleat
        "CLOTH_SHADE",  # Pleat 5 shadow
        "CLOTH_BRIGHT", # Pleat 6 highlight
        "BRASS_BRIGHT", # Right gold border
    ]

    ref_behind = (0.0, 0.0, 0.90)
    for r_i in range(n_rows - 1):
        # Bottom row above `z_bot_outer` transitions outer columns (`c=0, 7`) to gold bottom border
        is_bot_band = (r_i == n_rows - 2)
        for c_i in range(8):
            m_k = "METAL" if (c_i in (0, 7) or (is_bot_band and c_i in (0, 1, 6, 7))) else col_band_mats[c_i]
            c_k = "BRASS_MAIN" if (is_bot_band and c_i in (1, 6)) else col_band_cols[c_i]
            v00, v01 = front_grid_v[r_i, c_i], front_grid_v[r_i, c_i + 1]
            v11, v10 = front_grid_v[r_i + 1, c_i + 1], front_grid_v[r_i + 1, c_i]
            mb.add_quad(v00, v01, v11, v10, mat=m_k, color=c_k, outward_ref=ref_behind)

            b00, b01 = back_grid_v[r_i, c_i], back_grid_v[r_i, c_i + 1]
            b11, b10 = back_grid_v[r_i + 1, c_i + 1], back_grid_v[r_i + 1, c_i]
            mb.add_quad(b00, b10, b11, b01, mat="MATTE", color="CLOTH_DARK", outward_ref=(0.0, 0.5 if is_front else -0.5, 0.90))

        # Left and right side thickness walls
        mb.add_quad(back_grid_v[r_i, 0], back_grid_v[r_i+1, 0], front_grid_v[r_i+1, 0], front_grid_v[r_i, 0], mat="METAL", color="BRASS_SHADE", outward_ref=ref_behind)
        mb.add_quad(front_grid_v[r_i, 8], front_grid_v[r_i+1, 8], back_grid_v[r_i+1, 8], back_grid_v[r_i, 8], mat="METAL", color="BRASS_SHADE", outward_ref=ref_behind)

    # 2. Add the Crenellated 3-Step Bottom Hem & Gold Stepped Border (`z_bot_outer -> z_bot_mid -> z_bot_ctr`)
    #    Step 1 (Mid-width step `c = 1..7`, `z = z_bot_outer .. z_bot_mid`):
    #      - Outer bands `c = 1..2` and `c = 6..7` are Gold Stepped Border
    #      - Inner bands `c = 2..6` are Crimson Cloth
    t_mid = (z_top - z_bot_mid) / (z_top - z_bot_ctr)
    hw_m  = hw_top + (hw_bot - hw_top) * (t_mid ** 0.92)
    w_mid = w_at_z(z_bot_mid)
    mid_f = [mb.add_vert((u_fracs[c] * hw_m, y_surf(u_fracs[c] * hw_m, z_bot_mid, flutes_f[c]), z_bot_mid), w_mid) for c in range(1, 8)]
    mid_b = [mb.add_vert((u_fracs[c] * hw_m, y_surf(u_fracs[c] * hw_m, z_bot_mid, flutes_f[c]) - thick, z_bot_mid), w_mid) for c in range(1, 8)]

    for idx_m, c_i in enumerate(range(1, 7)):
        is_gold = (c_i in (1, 5, 6))
        mk = "METAL" if is_gold else "MATTE"
        ck = "BRASS_MAIN" if is_gold else col_band_cols[c_i]
        mb.add_quad(front_grid_v[-1, c_i], front_grid_v[-1, c_i+1], mid_f[idx_m+1], mid_f[idx_m], mat=mk, color=ck, outward_ref=ref_behind)
        mb.add_quad(back_grid_v[-1, c_i], mid_b[idx_m], mid_b[idx_m+1], back_grid_v[-1, c_i+1], mat="MATTE", color="CLOTH_DARK", outward_ref=(0.0, 0.5 if is_front else -0.5, 0.60))

    # Step 2 (Center tongue `c = 2..6`, `z = z_bot_mid .. z_bot_ctr`, all Gold Border at bottom tip!):
    w_ctr = w_at_z(z_bot_ctr)
    ctr_f = [mb.add_vert((u_fracs[c] * hw_bot, y_surf(u_fracs[c] * hw_bot, z_bot_ctr, flutes_f[c]), z_bot_ctr), w_ctr) for c in range(2, 7)]
    ctr_b = [mb.add_vert((u_fracs[c] * hw_bot, y_surf(u_fracs[c] * hw_bot, z_bot_ctr, flutes_f[c]) - thick, z_bot_ctr), w_ctr) for c in range(2, 7)]
    for idx_c in range(4):
        mb.add_quad(mid_f[idx_c+1], mid_f[idx_c+2], ctr_f[idx_c+1], ctr_f[idx_c], mat="METAL", color="BRASS_BRIGHT" if idx_c >= 2 else "BRASS_MAIN", outward_ref=ref_behind)
        mb.add_quad(mid_b[idx_c+1], ctr_b[idx_c], ctr_b[idx_c+1], mid_b[idx_c+2], mat="MATTE", color="CLOTH_DARK", outward_ref=(0.0, 0.5 if is_front else -0.5, 0.55))

    # 3. Sculpt the 3D Raised Champagne-Brass Spear-Trident Emblem (`tabard.png` & `back.png`)!
    #    Slightly proud (`+0.005 m` along `n_dir`) of the crimson cloth so it never z-fights and catches 3D highlights!
    def add_emblem_poly(pts_xz, col_face="BRASS_BRIGHT", col_edge="BRASS_MAIN"):
        poly_3d = []
        for (px, pz) in pts_xz:
            py = y_surf(px, pz, flute_offset=(0.010 if is_front else -0.010))
            poly_3d.append((px, py, pz))
        mb.add_flat_beveled_plate(
            poly_3d, normal_dir=n_dir, thickness=0.008, bevel_inset=0.18,
            weights=w_at_z( float(np.mean([p[1] for p in pts_xz])) ),
            mat="METAL", col_face=col_face, col_edge=col_edge, col_side="BRASS_SHADE", col_back="CLOTH_DARK"
        )

    if is_front:
        s_x, z_c, s_z = 1.0, 0.865, 1.0
    else:
        s_x, z_c, s_z = 1.32, 1.045, 1.38

    # A. Central Spearhead (tall diamond-dagger point) + Shaft + Lower Diamond Pommel
    add_emblem_poly([
        ( 0.000 * s_x, z_c + 0.165 * s_z),
        (-0.022 * s_x, z_c + 0.068 * s_z),
        (-0.009 * s_x, z_c + 0.052 * s_z),
        ( 0.009 * s_x, z_c + 0.052 * s_z),
        ( 0.022 * s_x, z_c + 0.068 * s_z),
    ], col_face="BRASS_BRIGHT", col_edge="BRASS_EDGE")

    add_emblem_poly([
        (-0.009 * s_x, z_c + 0.056 * s_z),
        (-0.010 * s_x, z_c - 0.115 * s_z),
        ( 0.010 * s_x, z_c - 0.115 * s_z),
        ( 0.009 * s_x, z_c + 0.056 * s_z),
    ], col_face="BRASS_MAIN", col_edge="BRASS_BRIGHT")

    add_emblem_poly([
        ( 0.000 * s_x, z_c - 0.105 * s_z),
        (-0.022 * s_x, z_c - 0.142 * s_z),
        ( 0.000 * s_x, z_c - 0.185 * s_z),
        ( 0.022 * s_x, z_c - 0.142 * s_z),
    ], col_face="BRASS_BRIGHT", col_edge="BRASS_MAIN")

    # B. Left and Right Curved/Angled Trident Side Prongs with Barbed Tips (`tabard.png`)
    for sign in (-1.0, 1.0):
        # Lower diagonal arm branching from central shaft
        add_emblem_poly([
            (sign * 0.006 * s_x, z_c - 0.058 * s_z),
            (sign * 0.046 * s_x, z_c - 0.012 * s_z),
            (sign * 0.052 * s_x, z_c + 0.018 * s_z),
            (sign * 0.034 * s_x, z_c + 0.014 * s_z),
            (sign * 0.006 * s_x, z_c - 0.028 * s_z),
        ], col_face="BRASS_MAIN" if sign < 0 else "BRASS_BRIGHT", col_edge="BRASS_BRIGHT")
        # Upper barbed side prong point
        add_emblem_poly([
            (sign * 0.034 * s_x, z_c + 0.010 * s_z),
            (sign * 0.054 * s_x, z_c + 0.014 * s_z),
            (sign * 0.058 * s_x, z_c + 0.055 * s_z),
            (sign * 0.044 * s_x, z_c + 0.108 * s_z),
            (sign * 0.028 * s_x, z_c + 0.042 * s_z),
        ], col_face="BRASS_BRIGHT", col_edge="BRASS_EDGE")

    return mb


def build_v28_refined_legs_greaves_and_boots(is_right=False):
    """
    Constructs the Lower Armor (`MEGreave.L/R` & `MEBoot.L/R`) calibrated directly to
    `boot.png`, `tabard.png`, and `CANONICAL_SPELLBLADE_KEEP.png`:
      1. Dark-Charcoal Gambeson & Dark-Iron Thighs (`UNDERSUIT_DARK` / `STEEL_DARK`) for high
         value contrast against the bright Knee Poleyns, Crimson Tabard, and Brown Leather Tassets.
      2. Dual-layer Brown-Leather & Silver-Loop Hip Tassets (`tabard.png`) + contoured side-hip tassets.
      3. Tall, Sculpted Hexagonal/Shield Knee Poleyn (`boot.png`) with V-angled champagne-brass
         upper brow rim, 3-plane chiseled steel front shield, asymmetric L-stepped steel bevel recess,
         side poleyn wings, and brown-leather rear/side knee strap with brass keeper.
      4. Solid, Multi-Planar Front-Keeled Shin Greave (`rx = 0.132 -> 0.108`, eliminating skinny ankles!)
         running seamlessly into the 38° V-angled brown-leather ankle strap and wide 5-facet trapezoidal Sabaton Boot!
    """
    mb = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    suffix = ".R" if is_right else ".L"
    sign = 1.0 if is_right else -1.0
    yaw_deg = -9.0 if is_right else 9.0

    th_h = (sign * 0.175,  0.015, 1.060)
    th_t = (sign * 0.232,  0.050, 0.635)
    sh_h = (sign * 0.232,  0.050, 0.635)
    sh_t = (sign * 0.268, -0.010, 0.225)

    rad = math.radians(yaw_deg)
    up_out = (float(-math.sin(rad)), float(np.cos(rad)), 0.0)
    th_frame = BoneFrame(th_h, th_t, up_hint=up_out)
    sh_frame = BoneFrame(sh_h, sh_t, up_hint=up_out)
    th_w = f"thigh{suffix}"
    sh_w = f"shin{suffix}"
    ft_w = f"foot{suffix}"

    def leg_ring(frame, t, rx, yf, yb, ridge_y=0.0):
        return [
            frame.pt( 0.0,       yf + ridge_y, t),
            frame.pt(-rx * 0.76, yf * 0.78,    t),
            frame.pt(-rx,        0.0,          t),
            frame.pt(-rx * 0.78,-yb * 0.78,    t),
            frame.pt( 0.0,      -yb,           t),
            frame.pt( rx * 0.78,-yb * 0.78,    t),
            frame.pt( rx,        0.0,          t),
            frame.pt( rx * 0.76, yf * 0.78,    t),
        ]

    # 1. Dark-Charcoal Quilted Gambeson & Dark-Iron Thigh Breeches (`CANONICAL_SPELLBLADE_KEEP.png`)
    mb.add_loft(
        [leg_ring(th_frame, -0.06, 0.134, 0.126, 0.126), leg_ring(th_frame, 1.10, 0.112, 0.112, 0.110)],
        weights=th_w, mat="MATTE", colors="UNDERSUIT_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK"
    )
    tc0 = leg_ring(th_frame, 0.06, 0.146, 0.138, 0.130, ridge_y=0.014)
    tc1 = leg_ring(th_frame, 0.50, 0.140, 0.134, 0.126, ridge_y=0.016)
    tc2 = leg_ring(th_frame, 0.90, 0.124, 0.120, 0.114, ridge_y=0.012)
    th_cols = ["STEEL_DARK", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_SHADE", "STEEL_DARK", "STEEL_DARK"]
    mb.add_loft([tc0, tc1, tc2], weights=th_w, mat="METAL", colors=th_cols, closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK")

    # 2. Authentic `tabard.png` Hip Tassets (Inner leather strap + Outer wider leather tasset with silver-steel loop mount)
    inner_strap = [
        (sign * 0.114, 0.218, 1.190),
        (sign * 0.156, 0.210, 1.190),
        (sign * 0.190, 0.194, 0.815),
        (sign * 0.146, 0.204, 0.815),
    ]
    mb.add_flat_beveled_plate(
        inner_strap, normal_dir=(sign * 0.24, 0.96, 0.08), thickness=0.015, bevel_inset=0.12, weights=th_w,
        mat="MATTE", col_face="LEATHER_MAIN", col_edge="LEATHER_LIGHT", col_side="LEATHER_DARK"
    )

    outer_tasset = [
        (sign * 0.144, 0.214, 1.190),
        (sign * 0.222, 0.180, 1.190),
        (sign * 0.256, 0.162, 0.965),
        (sign * 0.174, 0.198, 0.965),
    ]
    mb.add_flat_beveled_plate(
        outer_tasset, normal_dir=(sign * 0.42, 0.90, 0.10), thickness=0.018, bevel_inset=0.14, weights=th_w,
        mat="MATTE", col_face="LEATHER_LIGHT", col_edge="LEATHER_MAIN", col_side="LEATHER_DARK"
    )
    sq_mount = [
        (sign * 0.174, 0.206, 1.072),
        (sign * 0.220, 0.186, 1.072),
        (sign * 0.232, 0.178, 1.002),
        (sign * 0.186, 0.198, 1.002),
    ]
    rs_prev.add_framed_rect_plate(
        mb, sq_mount, normal_dir=(sign * 0.42, 0.90, 0.10), thickness=0.012, border_frac=0.32, weights=th_w,
        mat_border="METAL", col_border="STEEL_LIGHT", col_border_edge="STEEL_BRIGHT",
        mat_inner="MATTE", col_inner="LEATHER_DARK", open_top=False
    )

    for tier_i, (z_hi, z_lo, x_f, x_b) in enumerate([
        (1.185, 1.045, 0.206, 0.214),
        (1.050, 0.915, 0.222, 0.230),
    ]):
        t_corners = [
            (sign * x_f,  0.140, z_hi),
            (sign * x_b, -0.015, z_hi),
            (sign * (x_b + 0.012), -0.010, z_lo),
            (sign * (x_f + 0.012),  0.145, z_lo),
        ]
        n_dir = (sign * 0.92, 0.36, 0.12)
        rs_prev.add_framed_rect_plate(
            mb, t_corners, normal_dir=n_dir, thickness=0.014, border_frac=0.18, weights=th_w,
            mat_border="METAL", col_border="BRASS_MAIN", col_border_edge="BRASS_EDGE",
            mat_inner="MATTE", col_inner="LEATHER_SHADE", open_top=(tier_i > 0)
        )

    # 3. Tall, Sculpted Chiseled Knee Poleyn (`boot.png` — V-Angled Gold Brow Rim + Tall 3-Plane Steel Shield + L-Bevel Step)
    def knee_row(t_side, t_mid, u_side, u_mid, v_side, v_mid):
        return [
            sh_frame.pt(-u_side, v_side, t_side),
            sh_frame.pt(-u_mid,  v_mid,  t_mid),
            sh_frame.pt( u_mid,  v_mid,  t_mid),
            sh_frame.pt( u_side, v_side, t_side),
        ]

    # V-Angled Champagne-Brass Upper Brow Rim (`boot.png`)
    k_brow_grid = [
        knee_row(-0.10, -0.16, 0.152, 0.096, -0.012, 0.162),
        knee_row( 0.02, -0.02, 0.156, 0.100, -0.008, 0.168),
    ]
    mb.add_faceted_shield_plate(
        k_brow_grid, outward_hint=sh_frame.v, thickness=0.034, bevel_inset=0.14, weights=sh_w,
        mat="METAL", col_faces=[["BRASS_MAIN", "BRASS_BRIGHT", "BRASS_EDGE"]], col_bevel="BRASS_BRIGHT", col_side="BRASS_SHADE"
    )

    # Tall 3-Plane Chiseled Steel Knee Shield (`t = -0.02 .. +0.44` on `sh_frame` — `boot.png`)
    k_face_grid = [
        knee_row( 0.02, -0.02, 0.154, 0.098, -0.008, 0.166),
        knee_row( 0.24,  0.22, 0.150, 0.094, -0.010, 0.162),
        knee_row( 0.42,  0.45, 0.140, 0.086, -0.014, 0.150),
    ]
    mb.add_faceted_shield_plate(
        k_face_grid, outward_hint=sh_frame.v, thickness=0.038, bevel_inset=0.15, weights=sh_w,
        mat="METAL",
        col_faces=[
            ["STEEL_FACET", "STEEL_LIGHT", "STEEL_BRIGHT"],
            ["STEEL_DARK",  "STEEL_MAIN",  "STEEL_LIGHT"],
        ],
        col_bevel="STEEL_BRIGHT", col_side="STEEL_DARK"
    )

    # Subtle Stepped Steel Bevel Indentation on the Knee Shield Face (`boot.png`)
    c_notch = [
        sh_frame.pt(-0.056, 0.174, 0.12),
        sh_frame.pt( 0.042, 0.174, 0.12),
        sh_frame.pt( 0.042, 0.172, 0.26),
        sh_frame.pt(-0.056, 0.172, 0.26),
    ]
    mb.add_flat_beveled_plate(
        c_notch, normal_dir=sh_frame.v, thickness=0.008, bevel_inset=0.22, weights=sh_w,
        mat="METAL", col_face="STEEL_FACET", col_edge="STEEL_DARK", col_side="STEEL_SHADE"
    )

    # Rear & Side Brown-Leather Knee Strap with Brass Keeper (`boot.png` & `back.png`)
    st_r0 = leg_ring(sh_frame, 0.14, 0.140, 0.128, 0.152)
    st_r1 = leg_ring(sh_frame, 0.30, 0.136, 0.124, 0.148)
    mb.add_loft([st_r0, st_r1], weights=sh_w, mat="MATTE", colors="LEATHER_MAIN", closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_LIGHT")
    k_u = 1.0 if np.dot(sh_frame.u, np.array([sign, 0.0, 0.0])) > 0 else -1.0
    mb.add_beveled_box(
        center=sh_frame.pt(k_u * 0.142, 0.035, 0.22),
        half_extents=(0.022, 0.038, 0.036),
        axes=(sh_frame.u, sh_frame.v, sh_frame.w),
        bevel=0.16, weights=sh_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
    )
    mb.add_beveled_box(
        center=sh_frame.pt(0.0, -0.150, 0.22),
        half_extents=(0.036, 0.018, 0.034),
        axes=(sh_frame.u, sh_frame.v, sh_frame.w),
        bevel=0.16, weights=sh_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
    )

    # 4. Solid, Multi-Planar Front-Keeled Steel Shin Greave (`rx = 0.134 -> 0.106` — solid armored ankle!)
    ls0 = leg_ring(sh_frame, 0.04, 0.134, 0.134, 0.144, ridge_y=0.026)
    ls1 = leg_ring(sh_frame, 0.42, 0.128, 0.130, 0.136, ridge_y=0.030)
    ls2 = leg_ring(sh_frame, 0.76, 0.116, 0.118, 0.118, ridge_y=0.026)
    ls3 = leg_ring(sh_frame, 1.06, 0.106, 0.108, 0.104, ridge_y=0.022)
    ls_cols = ["STEEL_BRIGHT", "STEEL_LIGHT", "STEEL_FACET", "STEEL_DARK", "STEEL_DARK", "STEEL_FACET", "STEEL_MAIN", "STEEL_BRIGHT"]
    mb.add_loft([ls0, ls1, ls2, ls3], weights=sh_w, mat="METAL", colors=[ls_cols, ls_cols, ls_cols], closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK")

    # 5. Wide Chiseled 5-Facet Trapezoidal Sabaton Boot & 38-Deg Chevron Leather Ankle Strap (`boot.png`)
    cx, cy = sh_t[0], sh_t[1]

    def boot_ring_trap(fw, rx, y_front, y_corner, y_back, z, dorsal_lift=0.0, front_peak=0.0, back_peak=0.0):
        ym = 0.30 * y_front + 0.70 * y_back
        pts = [
            (cx - fw,      cy + y_front,        z + dorsal_lift + front_peak),
            (cx - rx*0.84, cy + y_corner,       z + dorsal_lift*0.4 + front_peak*0.45),
            (cx - rx,      cy + ym,             z),
            (cx - rx*0.86, cy + y_back + 0.025, z + back_peak * 0.5),
            (cx - fw*0.8,  cy + y_back,         z + back_peak),
            (cx + fw*0.8,  cy + y_back,         z + back_peak),
            (cx + rx*0.86, cy + y_back + 0.025, z + back_peak * 0.5),
            (cx + rx,      cy + ym,             z),
            (cx + rx*0.84, cy + y_corner,       z + dorsal_lift*0.4 + front_peak*0.45),
            (cx + fw,      cy + y_front,        z + dorsal_lift + front_peak),
        ]
        return rs_prev.rot_z(pts, yaw_deg, pivot=(cx, cy))

    s0 = boot_ring_trap(0.062, 0.150, 0.326, 0.274, -0.170, 0.000)
    s1 = boot_ring_trap(0.064, 0.152, 0.330, 0.278, -0.172, 0.026)
    mb.add_loft([s0, s1], weights=ft_w, mat="METAL", colors="STEEL_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK")

    b0      = boot_ring_trap(0.060, 0.146, 0.322, 0.270, -0.166, 0.026, dorsal_lift=0.002)
    b1      = boot_ring_trap(0.056, 0.142, 0.302, 0.254, -0.162, 0.078, dorsal_lift=0.012, back_peak=0.012)
    b1_back = boot_ring_trap(0.054, 0.138, 0.220, 0.182, -0.162, 0.106, dorsal_lift=0.016, back_peak=0.016)
    b1_step = boot_ring_trap(0.050, 0.130, 0.214, 0.176, -0.162, 0.096, dorsal_lift=0.014, back_peak=0.016)
    b2      = boot_ring_trap(0.052, 0.134, 0.166, 0.130, -0.164, 0.126, dorsal_lift=0.018, back_peak=0.022)
    b3      = boot_ring_trap(0.048, 0.122, 0.112, 0.084, -0.158, 0.242, dorsal_lift=0.016, back_peak=0.028)

    cols_prow = ["STEEL_MAIN",  "STEEL_FACET", "STEEL_DARK",  "STEEL_SHADE", "STEEL_LIGHT", "STEEL_SHADE", "STEEL_DARK", "STEEL_FACET", "STEEL_LIGHT", "STEEL_BRIGHT"]
    cols_deck = ["STEEL_LIGHT", "STEEL_MAIN",  "STEEL_DARK",  "STEEL_SHADE", "STEEL_BRIGHT","STEEL_SHADE", "STEEL_DARK", "STEEL_MAIN",  "STEEL_BRIGHT","STEEL_BRIGHT"]
    cols_step = ["STEEL_DARK",  "STEEL_DARK",  "STEEL_DARK",  "STEEL_SHADE", "STEEL_FACET", "STEEL_SHADE", "STEEL_DARK", "STEEL_DARK",  "STEEL_DARK",  "STEEL_DARK"]
    cols_inst = ["BRASS_MAIN",  "BRASS_EDGE",  "STEEL_SHADE", "BRASS_MAIN",  "BRASS_BRIGHT","BRASS_MAIN",  "STEEL_SHADE","BRASS_EDGE",  "BRASS_BRIGHT","BRASS_BRIGHT"]

    mb.add_loft(
        [b0, b1, b1_back, b1_step, b2, b3],
        weights=ft_w, mat="METAL",
        colors=[cols_prow, cols_deck, cols_step, cols_inst, cols_step],
        closed_ring=True, cap_start=False, cap_end=True, cap_color="STEEL_DARK"
    )

    # 38-deg Diagonal Chevron Brown-Leather & Brass Ankle Strap (`boot.png`)
    ac0 = boot_ring_trap(0.048, 0.134, 0.164, 0.120, -0.174, 0.082, dorsal_lift=0.016, front_peak=0.108, back_peak=0.024)
    ac1 = boot_ring_trap(0.050, 0.138, 0.170, 0.126, -0.176, 0.138, dorsal_lift=0.018, front_peak=0.116, back_peak=0.028)
    ac2 = boot_ring_trap(0.044, 0.124, 0.146, 0.108, -0.168, 0.152, dorsal_lift=0.014, front_peak=0.106, back_peak=0.024)
    ac_cols = ["LEATHER_LIGHT", "LEATHER_MAIN", "LEATHER_SHADE", "LEATHER_DARK", "BRASS_MAIN", "LEATHER_DARK", "LEATHER_SHADE", "LEATHER_MAIN", "LEATHER_LIGHT", "BRASS_BRIGHT"]
    mb.add_loft(
        [ac0, ac1, ac2],
        weights=ft_w, mat="MATTE",
        colors=[ac_cols, ac_cols],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_LIGHT"
    )

    for k_side in (-1.0, 1.0):
        kp_pt = rs_prev.rot_z([(cx + k_side * 0.130, cy + 0.020, 0.128)], yaw_deg, pivot=(cx, cy))[0]
        mb.add_beveled_box(
            center=kp_pt,
            half_extents=(0.020, 0.028, 0.030),
            weights=ft_w, mat="MATTE", col_main="LEATHER_LIGHT", col_edge="BRASS_MAIN", col_dark="LEATHER_DARK"
        )

    return mb
