#!/usr/bin/env python3
"""
Export & Comprehensive Validation Pipeline for Fight-and-Flight v2.2
====================================================================
Preserves all v2.1 outputs intact while generating and validating:
  1. `fight-and-flight-v25-review.glb`:
     - Standalone wearable aerial siege apparatus (excludes the Spellblade character mesh).
     - 28 articulated sub-meshes (`22,751` triangles, `43,190` welded vertices) across 29 hierarchy nodes
       + 14 gameplay/release locators (`43` nodes total).
     - Priority 1 — Unmistakable Asymmetrical Rotor Destruction (`Nodes 26, 27, 28` + `Damage_08_Rotor_Destroy_Grounded`):
       * `Node 26: Rotor_Hub_Fractured_Collar`: Split iron bearing housing, sheared bronze bevel-gear teeth,
         tilted broken journal shaft, and shattered ruby crown setting.
       * `Node 27: Rotor_Blade_L_Fractured_Stump`: Jagged `0.46 m` sheared ricasso & twisted golden crossguard
         stump with 3 diagonal steel/gold fracture shards remaining on the collapsed hub.
       * `Node 28: Rotor_Blade_L_Detached_Segment` (with release locator `rotor_blade_L_release_origin` at
         `[+0.440, +2.180, +0.020] m`): Separate identifiable outer `0.88 m` claymore greatsword blade mesh
         that shears off at `t = 0.18 s` and falls onto the ground beside the left flank (or hands off to game physics).
       * `Node 11: Rotor_Sword_Blade_R`: Asymmetrically wrenched backward (`+32°` yaw), twisted (`-36°` roll),
         and collapsed downward (`-44°` pitch) against the rear drive frame, leaving the right-hand sword corridor open!
     - Priority 2 — Exact 2-Link Kinematic Foot-Planting Solver (`0.0000 m` Ground Penetration & Zero Stance Floating):
       * Solves exact 2D planar IK for `Lower_Hip_Thigh_Limb_L/R` (`L1 = 0.430465 m`), `Lower_Knee_Shin_Limb_L/R`
         (`L2 = 0.435459 m`), and `Grounded_Sabaton_Stirrup_L/R` (`sole Y_local = -0.0550 m`) so the planted
         stance stirrup rests at exact `Y_world = 0.0000 m` across every frame of `Posture_05_Grounded_Walk_Loop`,
         `Posture_01_Grounded_Idle`, `Posture_02_Controlled_Landing`, and `Posture_03_Grounded_Crouch`!
  2. `fight-and-flight-v25-review.blend` & `fight-and-flight-v25-with-spellblade-reference.blend`
"""
import sys, os, io, json, math, struct, ctypes, hashlib
from pathlib import Path
from collections import defaultdict
import numpy as np
from PIL import Image

OUT_DIR = Path("/working_dir/c_63a1f8c151a6582d/artifacts/file_generation/ttl=63d/output")
WORK_DIR = Path("/tmp/faf_work")
sys.path.insert(0, str(WORK_DIR))
sys.path.insert(0, str(OUT_DIR))
sys.path.insert(0, "/tmp/sofist_v2_1")
sys.path.insert(0, str(WORK_DIR))

import blend_io
from build_sofist_v2_1_candidate import update_blend_mesh_from_gltf_arrays, read_raw_mesh_gltf
from build_fight_and_flight_meshes import (
    generate_faf_textures,
    build_all_v2_2_meshes,
)

# =============================================================================
# 1. v2.2 43-NODE HIERARCHY (29 APPARATUS NODES + 14 LOCATORS)
# =============================================================================

FAF_NODES = [
    # idx, name, parent_idx, local_translation, world_translation, default_scale
    (0,  "FightAndFlight_Root",            None, [ 0.000,  0.000,  0.000], [ 0.000, 0.000,  0.000], [1.0, 1.0, 1.0]),
    (1,  "Main_Apparatus_Chassis",         0,    [ 0.000,  0.000,  0.000], [ 0.000, 0.000,  0.000], [1.0, 1.0, 1.0]),
    (2,  "Protective_Brace_L",             1,    [+0.415, +1.280, +0.050], [+0.415, 1.280, +0.050], [1.0, 1.0, 1.0]),
    (3,  "Protective_Brace_R",             1,    [-0.415, +1.280, +0.050], [-0.415, 1.280, +0.050], [1.0, 1.0, 1.0]),
    (4,  "Rear_Drive_Assembly",            1,    [ 0.000, +1.320, -0.340], [ 0.000, 1.320, -0.340], [1.0, 1.0, 1.0]),
    (5,  "Drive_Winch_Spring_Drum",        4,    [ 0.000, +0.060, -0.080], [ 0.000, 1.380, -0.420], [1.0, 1.0, 1.0]),
    (6,  "Drive_Gear_Train_L",             4,    [+0.215, -0.200, -0.080], [+0.215, 1.120, -0.420], [1.0, 1.0, 1.0]),
    (7,  "Drive_Gear_Train_R",             4,    [-0.215, -0.200, -0.080], [-0.215, 1.120, -0.420], [1.0, 1.0, 1.0]),
    (8,  "Rotor_Shaft_And_Bearing",        1,    [ 0.000, +1.980, +0.020], [ 0.000, 1.980, +0.020], [1.0, 1.0, 1.0]),
    (9,  "Rotor_Hub",                      8,    [ 0.000, +0.200,  0.000], [ 0.000, 2.180, +0.020], [1.0, 1.0, 1.0]),
    (10, "Rotor_Sword_Blade_L",            9,    [ 0.000,  0.000,  0.000], [ 0.000, 2.180, +0.020], [1.0, 1.0, 1.0]),
    (11, "Rotor_Sword_Blade_R",            9,    [ 0.000,  0.000,  0.000], [ 0.000, 2.180, +0.020], [1.0, 1.0, 1.0]),
    (12, "Crossbow_Body",                  1,    [+0.650, +1.050, +0.220], [+0.650, 1.050, +0.220], [1.0, 1.0, 1.0]),
    (13, "Crossbow_Bow_And_String",        12,   [ 0.000, +0.028, +0.525], [+0.650, 1.078, +0.745], [1.0, 1.0, 1.0]),
    (14, "Crossbow_Recocking_Slide",       12,   [ 0.000, +0.038, +0.070], [+0.650, 1.088, +0.290], [1.0, 1.0, 1.0]),
    (15, "Crossbow_Bolt_Carousel",         12,   [ 0.000, +0.135, +0.065], [+0.650, 1.185, +0.285], [1.0, 1.0, 1.0]),
    (16, "Rear_Trident_Banner",            1,    [ 0.000, +1.480, -0.585], [ 0.000, 1.480, -0.585], [1.0, 1.0, 1.0]),
    # 6 Articulated Lower-Leg Exoskeleton Nodes (Nodes 17..22)
    (17, "Lower_Hip_Thigh_Limb_L",         1,    [+0.385, +0.920, -0.020], [+0.385, 0.920, -0.020], [1.0, 1.0, 1.0]),
    (18, "Lower_Hip_Thigh_Limb_R",         1,    [-0.385, +0.920, -0.020], [-0.385, 0.920, -0.020], [1.0, 1.0, 1.0]),
    (19, "Lower_Knee_Shin_Limb_L",         17,   [ 0.000, -0.430, +0.020], [+0.385, 0.490,  0.000], [1.0, 1.0, 1.0]),
    (20, "Lower_Knee_Shin_Limb_R",         18,   [ 0.000, -0.430, +0.020], [-0.385, 0.490,  0.000], [1.0, 1.0, 1.0]),
    (21, "Grounded_Sabaton_Stirrup_L",     19,   [-0.095, -0.435, +0.020], [+0.290, 0.055, +0.020], [1.0, 1.0, 1.0]),
    (22, "Grounded_Sabaton_Stirrup_R",     20,   [+0.095, -0.435, +0.020], [-0.290, 0.055, +0.020], [1.0, 1.0, 1.0]),
    # 3 Reusable Visual Quarrel Nodes (Nodes 23..25)
    (23, "Quarrel_Visual_Chambered",       12,   [ 0.000, +0.048, +0.020], [+0.650, 1.098, +0.240], [1.0, 1.0, 1.0]),
    (24, "Quarrel_Visual_Feed_Next",       12,   [ 0.000, +0.092, +0.020], [+0.650, 1.142, +0.240], [1.0, 1.0, 1.0]),
    (25, "Quarrel_Visual_Hopper_Top",      12,   [ 0.000, +0.136, +0.020], [+0.650, 1.186, +0.240], [1.0, 1.0, 1.0]),
    # 3 v2.2 Unmistakable Rotor Destruction & Detached Blade Nodes (Nodes 26..28, hidden at rest via scale=[0,0,0])
    (26, "Rotor_Hub_Fractured_Collar",     8,    [ 0.000, +0.200,  0.000], [ 0.000, 2.180, +0.020], [0.0, 0.0, 0.0]),
    (27, "Rotor_Blade_L_Fractured_Stump",  9,    [ 0.000,  0.000,  0.000], [ 0.000, 2.180, +0.020], [0.0, 0.0, 0.0]),
    (28, "Rotor_Blade_L_Detached_Segment", 1,    [+0.440, +2.180, +0.020], [+0.440, 2.180, +0.020], [0.0, 0.0, 0.0]),
]

FAF_LOCATORS = [
    # idx, name, parent_idx, local_translation, world_translation, description
    (29, "operator_root_anchor",           1,  [ 0.000,  0.000,  0.000], [ 0.000, 0.000,  0.000],
     "Operator root origin inside Main_Apparatus_Chassis"),
    (30, "operator_waist_harness_anchor",  1,  [ 0.000, +0.985, -0.015], [ 0.000, 0.985, -0.015],
     "Primary pelvis/waist harness attachment inside armored leather & brass cinch girdle"),
    (31, "operator_shoulder_pad_L",        1,  [+0.210, +1.415, -0.045], [+0.210, 1.415, -0.045],
     "Left padded shoulder cuirass bolster contact above clavicle.L"),
    (32, "operator_shoulder_pad_R",        1,  [-0.210, +1.415, -0.045], [-0.210, 1.415, -0.045],
     "Right padded shoulder cuirass bolster contact above clavicle.R"),
    (33, "operator_foot_stirrup_L",        21, [ 0.000, -0.022, +0.015], [+0.290, 0.033, +0.035],
     "Left planted sabaton stirrup sole plate (parented to Grounded_Sabaton_Stirrup_L on Y=0.000m)"),
    (34, "operator_foot_stirrup_R",        22, [ 0.000, -0.022, +0.015], [-0.290, 0.033, +0.035],
     "Right planted sabaton stirrup sole plate (parented to Grounded_Sabaton_Stirrup_R on Y=0.000m)"),
    (35, "operator_hand_L_crossbow_grip",  12, [-0.165, -0.070, +0.015], [+0.485, 0.980, +0.235],
     "Inward-cantilevered left-hand spade grip on Left Repeating Crossbow (+45mm clear of receiver)"),
    (36, "operator_hand_R_sword_corridor", 1,  [-0.410, +1.020, +0.280], [-0.410, 1.020, +0.280],
     "Unobstructed right-hand sword hold & Spells-and-Chivalry melee swing corridor"),
    (37, "operator_first_person_camera",   1,  [ 0.000, +1.520, +0.220], [ 0.000, 1.520, +0.220],
     "Unobstructed first-person eye camera locator directly at Spellblade visor slit"),
    (38, "crossbow_muzzle",                12, [ 0.000, +0.048, +0.585], [+0.650, 1.098, +0.805],
     "Repeating crossbow horizontal quarrel spawn & launch muzzle (forward +Z)"),
    (39, "rotor_hit_volume_center",        9,  [ 0.000,  0.000,  0.000], [ 0.000, 2.180, +0.020],
     "Center of 2.64m diameter overhead sword-rotor hit/contact volume"),
    (40, "brace_L_hit_volume_center",      2,  [+0.060,  0.000, +0.105], [+0.475, 1.280, +0.155],
     "Center of Left Protective Brace destructible hit/Sheathe-in-Steel volume"),
    (41, "brace_R_hit_volume_center",      3,  [-0.060,  0.000, +0.105], [-0.475, 1.280, +0.155],
     "Center of Right Protective Brace destructible hit/Sheathe-in-Steel volume"),
    (42, "rotor_blade_L_release_origin",   9,  [+0.440,  0.000,  0.000], [+0.440, 2.180, +0.020],
     "Fracture release origin & attachment point for detached outer Left Rotor Blade (`Rotor_Blade_L_Detached_Segment`)"),
]

def quat_from_euler_xyz(rx_deg: float, ry_deg: float, rz_deg: float):
    rx = math.radians(rx_deg) * 0.5
    ry = math.radians(ry_deg) * 0.5
    rz = math.radians(rz_deg) * 0.5
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    qx = sx * cy * cz - cx * sy * sz
    qy = cx * sy * cz + sx * cy * sz
    qz = cx * cy * sz - sx * sy * cz
    qw = cx * cy * cz + sx * sy * sz
    return [float(qx), float(qy), float(qz), float(qw)]

def quat_axis_angle(axis, angle_deg: float):
    ax, ay, az = axis
    n = math.sqrt(ax*ax + ay*ay + az*az)
    ax, ay, az = ax/n, ay/n, az/n
    half = math.radians(angle_deg) * 0.5
    s = math.sin(half)
    return [float(ax*s), float(ay*s), float(az*s), float(math.cos(half))]

def ensure_quat_continuity(quat_list):
    out = []
    for q in quat_list:
        q_arr = np.array(q, dtype=np.float64)
        if out and float(np.dot(out[-1], q_arr)) < 0.0:
            q_arr = -q_arr
        out.append(q_arr)
    return [[float(x) for x in q] for q in out]

# =============================================================================
# 2. EXACT 2-LINK KINEMATIC FOOT-PLANTING & STRIDE SOLVER (0.0000m PENETRATION)
# =============================================================================
# Link 1 (`Lower_Hip_Thigh_Limb_L/R` -> `Lower_Knee_Shin_Limb_L/R`):
#   local vector `[0.0, -0.430, +0.020]` -> L1 = hypot(0.430, 0.020) = 0.430464865 m, alpha1 = atan2(0.020, 0.430)
# Link 2 (`Lower_Knee_Shin_Limb_L/R` -> `Grounded_Sabaton_Stirrup_L/R`):
#   local vector `[∓0.095, -0.435, +0.020]` -> L2 = hypot(0.435, 0.020) = 0.435459527 m, alpha2 = atan2(0.020, 0.435)
# Sabaton Stirrup (`Grounded_Sabaton_Stirrup_L/R`):
#   bottom sole face sits at `Y_local = -0.0550 m` (so ankle trunnion at `Y_world = +0.0550 m` with `0.0 deg` world
#   foot pitch places the entire `0.48 m` long sabaton sole flat on `Y_world = 0.0000 m` with ZERO ground penetration!).

L1_LEN = math.hypot(0.430, 0.020)
L2_LEN = math.hypot(0.435, 0.020)
ALPHA1_RAD = math.atan2(0.020, 0.430)
ALPHA2_RAD = math.atan2(0.020, 0.435)

def solve_exact_2link_leg_ik(
    chassis_tx: float,
    chassis_ty: float,
    chassis_tz: float,
    chassis_pitch_deg: float,
    ankle_target_y: float = 0.0550,
    ankle_target_z: float = 0.0200,
    foot_world_pitch_deg: float = 0.0,
):
    """
    Solves the exact local X-axis pitch angles `(thigh_local_deg, shin_local_deg, stirrup_local_deg)`
    so that the ankle trunnion (`Node 21/22`) lands at exact `(ankle_target_y, ankle_target_z)` in world space
    and the sabaton stirrup has exact world pitch `foot_world_pitch_deg` (`0.0 deg` when planted!).
    """
    p_rad = math.radians(chassis_pitch_deg)
    cp, sp = math.cos(p_rad), math.sin(p_rad)
    # Hip local offset in chassis is [±0.385, +0.920, -0.020]
    hip_y_world = chassis_ty + (0.920 * cp - (-0.020) * sp)
    hip_z_world = chassis_tz + (0.920 * sp + (-0.020) * cp)

    dy = hip_y_world - ankle_target_y # positive downward span required
    dz = ankle_target_z - hip_z_world # forward offset from hip to ankle

    D = math.hypot(dy, dz)
    max_reach = L1_LEN + L2_LEN - 1e-5
    min_reach = abs(L1_LEN - L2_LEN) + 1e-5
    if D > max_reach:
        scale_d = max_reach / D
        dy *= scale_d
        dz *= scale_d
        D = max_reach
    elif D < min_reach:
        D = min_reach

    beta = math.atan2(-dz, dy)
    cos_g1 = max(-1.0, min(1.0, (D*D + L1_LEN*L1_LEN - L2_LEN*L2_LEN) / (2.0 * D * L1_LEN)))
    cos_g2 = max(-1.0, min(1.0, (D*D + L2_LEN*L2_LEN - L1_LEN*L1_LEN) / (2.0 * D * L2_LEN)))
    gamma1 = math.acos(cos_g1)
    gamma2 = math.acos(cos_g2)

    # Knee bends forward (+Z, meaning negative X-rotation on the thigh so sin(phi1) < 0):
    phi1 = beta - gamma1
    phi2 = beta + gamma2

    theta1_world_deg = math.degrees(phi1 + ALPHA1_RAD)
    theta2_world_deg = math.degrees(phi2 + ALPHA2_RAD)

    thigh_local_deg   = theta1_world_deg - chassis_pitch_deg
    shin_local_deg    = theta2_world_deg - theta1_world_deg
    stirrup_local_deg = foot_world_pitch_deg - theta2_world_deg
    return (thigh_local_deg, shin_local_deg, stirrup_local_deg)

def solve_leg_fold_for_drop(drop_y: float, chassis_pitch_deg: float = 0.0):
    """Backwards-compatible wrapper around `solve_exact_2link_leg_ik` for symmetric vertical drops."""
    return solve_exact_2link_leg_ik(
        0.0, -drop_y, 0.0, chassis_pitch_deg,
        ankle_target_y=0.0550, ankle_target_z=0.0200, foot_world_pitch_deg=0.0
    )

# =============================================================================
# 3. CREASE-ANGLE NORMAL WELDING & GLTF PRIMITIVE COMPILER
# =============================================================================

def compile_welded_gltf_primitive(pos: np.ndarray, poff: np.ndarray, cv: np.ndarray, uv: np.ndarray, crease_deg: float = 22.0):
    n_polys = len(poff) - 1
    face_norms = np.zeros((n_polys, 3), dtype=np.float32)
    for pi in range(n_polys):
        s, e = int(poff[pi]), int(poff[pi+1])
        v0 = pos[cv[s]]
        acc = np.zeros(3, dtype=np.float64)
        for c in range(s + 1, e - 1):
            acc += np.cross(pos[cv[c]] - v0, pos[cv[c+1]] - v0)
        ln = np.linalg.norm(acc)
        face_norms[pi] = (acc / ln) if ln > 1e-12 else [0.0, 1.0, 0.0]

    vert_polys = defaultdict(list)
    for pi in range(n_polys):
        for c in range(int(poff[pi]), int(poff[pi+1])):
            vert_polys[int(cv[c])].append(pi)

    cos_thr = math.cos(math.radians(crease_deg))
    corner_norms = np.zeros((len(cv), 3), dtype=np.float32)
    for pi in range(n_polys):
        fn = face_norms[pi]
        for c in range(int(poff[pi]), int(poff[pi+1])):
            vi = int(cv[c])
            nsum = np.zeros(3, dtype=np.float64)
            for pj in vert_polys[vi]:
                if np.dot(fn, face_norms[pj]) >= cos_thr:
                    nsum += face_norms[pj]
            ln = np.linalg.norm(nsum)
            corner_norms[c] = (nsum / ln) if ln > 1e-12 else fn

    v_map = {}
    out_p, out_n, out_u = [], [], []
    corner_to_new = np.zeros(len(cv), dtype=np.uint32)
    for c in range(len(cv)):
        vi = int(cv[c])
        px, py, pz = pos[vi]
        nx, ny, nz = corner_norms[c]
        u_c, v_c = uv[c]
        key = (
            int(round(px * 10000)), int(round(py * 10000)), int(round(pz * 10000)),
            int(round(nx * 500)),   int(round(ny * 500)),   int(round(nz * 500)),
            int(round(u_c * 4096)), int(round(v_c * 4096)),
        )
        idx = v_map.get(key)
        if idx is None:
            idx = len(out_p)
            v_map[key] = idx
            out_p.append([px, py, pz])
            out_n.append([nx, ny, nz])
            out_u.append([u_c, v_c])
        corner_to_new[c] = idx

    tris = []
    for pi in range(n_polys):
        s, e = int(poff[pi]), int(poff[pi+1])
        i0 = corner_to_new[s]
        for c in range(s + 1, e - 1):
            tris.append([i0, corner_to_new[c], corner_to_new[c+1]])

    return (
        np.array(out_p, dtype=np.float32),
        np.array(out_n, dtype=np.float32),
        np.array(out_u, dtype=np.float32),
        np.array(tris, dtype=np.uint32).reshape(-1),
    )

# =============================================================================
# 4. BUILD 12 STRICTLY INDEPENDENT GLTF ANIMATIONS (v2.2)
# =============================================================================

def build_faf_v2_2_animations():
    anims = []

    # -------------------------------------------------------------------------
    # GROUP A: INDEPENDENT ROTOR & DRIVE TRAIN ANIMATIONS (Nodes 5, 6, 7, 9 ONLY)
    # -------------------------------------------------------------------------
    n_r1 = 25
    t_r1 = [round(1.000 * i / (n_r1 - 1), 5) for i in range(n_r1)]
    anims.append({
        "name": "Rotor_Spin_Cycle_1Rev",
        "times": t_r1,
        "tracks": {
            5: {"rotation": ensure_quat_continuity([quat_axis_angle((0, 0, 1), 180.0 * i / 24.0) for i in range(n_r1)])},
            6: {"rotation": ensure_quat_continuity([quat_axis_angle((1, 0, 0), -180.0 * i / 24.0) for i in range(n_r1)])},
            7: {"rotation": ensure_quat_continuity([quat_axis_angle((1, 0, 0), +180.0 * i / 24.0) for i in range(n_r1)])},
            9: {"rotation": ensure_quat_continuity([quat_axis_angle((0, 1, 0), 360.0 * i / 24.0) for i in range(n_r1)])},
        }
    })

    n_su = 49
    t_su = [round(1.600 * i / (n_su - 1), 5) for i in range(n_su)]
    anims.append({
        "name": "Rotor_Startup",
        "times": t_su,
        "tracks": {
            5: {"rotation": ensure_quat_continuity([quat_axis_angle((0, 0, 1), 540.0 * ((i/48.0)**2)) for i in range(n_su)])},
            6: {"rotation": ensure_quat_continuity([quat_axis_angle((1, 0, 0), -540.0 * ((i/48.0)**2)) for i in range(n_su)])},
            7: {"rotation": ensure_quat_continuity([quat_axis_angle((1, 0, 0), +540.0 * ((i/48.0)**2)) for i in range(n_su)])},
            9: {"rotation": ensure_quat_continuity([quat_axis_angle((0, 1, 0), 1080.0 * ((i/48.0)**2)) for i in range(n_su)])},
        }
    })

    # -------------------------------------------------------------------------
    # GROUP B: INDEPENDENT CROSSBOW & REUSABLE QUARREL ANIMATIONS (Nodes 12..15, 23..25 ONLY)
    # -------------------------------------------------------------------------
    t_cb = [0.0000, 0.0140, 0.0280, 0.0300, 0.0550, 0.0800, 0.1050, 0.1280, 0.1300, 0.142857]
    cb_body_tr, cb_body_rt, cb_bow_sc, cb_slide_tr, cb_car_tr = [], [], [], [], []
    q23_tr, q23_sc, q24_tr, q25_tr = [], [], [], []

    for t_val in t_cb:
        u = t_val / 0.142857
        recoil = math.sin(u * math.pi) * math.exp(-2.2 * u)
        cb_body_tr.append([+0.650, +1.050 + 0.002 * recoil, +0.220 - 0.018 * recoil])
        cb_body_rt.append(quat_from_euler_xyz(-1.5 * recoil, 0.0, 0.0))

        if t_val <= 0.0280:
            w_l = t_val / 0.0280
            s_bow = 1.08 - 0.26 * w_l
            z_sl  = +0.070 + 0.195 * w_l
            q23_tr.append([0.000, +0.048, float(+0.020 + 0.260 * w_l)])
            q23_sc.append([1.0, 1.0, 1.0])
            q24_tr.append([0.000, +0.092, +0.020])
            q25_tr.append([0.000, +0.136, +0.020])
        elif t_val <= 0.1280:
            w_f = max(0.0, min(1.0, (t_val - 0.0300) / (0.1280 - 0.0300)))
            s_bow = 0.82 + 0.24 * w_f
            z_sl  = +0.265 - 0.195 * w_f
            q23_tr.append([0.000, +0.048, +0.020])
            q23_sc.append([0.0, 0.0, 0.0])
            q24_tr.append([0.000, float(+0.092 - 0.044 * w_f), +0.020])
            q25_tr.append([0.000, float(+0.136 - 0.044 * w_f), +0.020])
        else:
            s_bow = 1.08
            z_sl  = +0.070
            q23_tr.append([0.000, +0.048, +0.020])
            q23_sc.append([1.0, 1.0, 1.0])
            q24_tr.append([0.000, +0.092, +0.020])
            q25_tr.append([0.000, +0.136, +0.020])

        cb_bow_sc.append([1.0 + 0.04 * (1.08 - s_bow), 1.0, float(s_bow)])
        cb_slide_tr.append([0.000, +0.038, float(z_sl)])
        cb_car_tr.append([0.000, float(+0.135 - 0.012 * math.sin(u * math.pi)), +0.065])

    anims.append({
        "name": "Crossbow_Fire_Loop",
        "times": t_cb,
        "tracks": {
            12: {"translation": cb_body_tr, "rotation": ensure_quat_continuity(cb_body_rt)},
            13: {"scale": cb_bow_sc},
            14: {"translation": cb_slide_tr},
            15: {"translation": cb_car_tr},
            23: {"translation": q23_tr, "scale": q23_sc},
            24: {"translation": q24_tr},
            25: {"translation": q25_tr},
        }
    })

    n_rl = 17
    t_rl = [round(0.800 * i / (n_rl - 1), 4) for i in range(n_rl)]
    anims.append({
        "name": "Crossbow_Reload_Index",
        "times": t_rl,
        "tracks": {
            14: {"translation": [[0.000, +0.038, +0.070 + 0.160 * math.sin(math.pi * i / 16.0)] for i in range(n_rl)]},
            15: {"translation": [[0.000, +0.135 - 0.024 * abs(math.sin(2.0 * math.pi * i / 16.0)), +0.065] for i in range(n_rl)]},
            24: {"translation": [[0.000, +0.092 - 0.044 * (i / 16.0), +0.020] for i in range(n_rl)]},
            25: {"translation": [[0.000, +0.136 - 0.044 * (i / 16.0), +0.020] for i in range(n_rl)]},
        }
    })

    # -------------------------------------------------------------------------
    # GROUP C: INDEPENDENT POSTURE, GROUNDED, CROUCH, WALK, FLIGHT & DIVE ANIMATIONS
    # -------------------------------------------------------------------------
    def make_exact_planted_leg_tracks(ch_ty_list, ch_tz_list, ch_pitch_list, ankle_y_l_list=None, ankle_z_l_list=None, ankle_y_r_list=None, ankle_z_r_list=None):
        """
        Uses `solve_exact_2link_leg_ik` at every keyframe so that when a foot is planted
        (`ankle_y = 0.0550m`), its sabaton sole rests at EXACT `Y_world = 0.0000m` (`0.00mm`
        ground penetration and `0.00mm` floating across linear interpolation!).
        """
        r17, r18, r19, r20, r21, r22 = [], [], [], [], [], []
        for i in range(len(ch_ty_list)):
            ty = ch_ty_list[i]
            tz = ch_tz_list[i]
            cp = ch_pitch_list[i]
            ay_l = ankle_y_l_list[i] if ankle_y_l_list is not None else max(0.0550, 0.0550 + ty)
            az_l = ankle_z_l_list[i] if ankle_z_l_list is not None else 0.0200
            ay_r = ankle_y_r_list[i] if ankle_y_r_list is not None else max(0.0550, 0.0550 + ty)
            az_r = ankle_z_r_list[i] if ankle_z_r_list is not None else 0.0200

            th_l, sh_l, st_l = solve_exact_2link_leg_ik(0.0, ty, tz, cp, ankle_target_y=ay_l, ankle_target_z=az_l, foot_world_pitch_deg=0.0)
            th_r, sh_r, st_r = solve_exact_2link_leg_ik(0.0, ty, tz, cp, ankle_target_y=ay_r, ankle_target_z=az_r, foot_world_pitch_deg=0.0)
            r17.append(quat_from_euler_xyz(th_l, 0.0, 0.0))
            r18.append(quat_from_euler_xyz(th_r, 0.0, 0.0))
            r19.append(quat_from_euler_xyz(sh_l, 0.0, 0.0))
            r20.append(quat_from_euler_xyz(sh_r, 0.0, 0.0))
            r21.append(quat_from_euler_xyz(st_l, 0.0, 0.0))
            r22.append(quat_from_euler_xyz(st_r, 0.0, 0.0))
        return {
            17: {"rotation": ensure_quat_continuity(r17)},
            18: {"rotation": ensure_quat_continuity(r18)},
            19: {"rotation": ensure_quat_continuity(r19)},
            20: {"rotation": ensure_quat_continuity(r20)},
            21: {"rotation": ensure_quat_continuity(r21)},
            22: {"rotation": ensure_quat_continuity(r22)},
        }

    # 5. Posture_01_Grounded_Idle (2.000s loop, 25 keys)
    n_gi = 25
    t_gi = [round(2.000 * i / (n_gi - 1), 4) for i in range(n_gi)]
    ty_gi = [-0.012 * (0.5 - 0.5 * math.cos(2 * math.pi * i / 24.0)) for i in range(n_gi)]
    tz_gi = [0.0 for _ in range(n_gi)]
    cp_gi = [0.0 for _ in range(n_gi)]
    ay_planted_gi = [0.0552 for _ in range(n_gi)]
    tr_gi = make_exact_planted_leg_tracks(ty_gi, tz_gi, cp_gi, ay_planted_gi, None, ay_planted_gi, None)
    tr_gi[1]  = {"translation": [[0.0, y, 0.0] for y in ty_gi], "rotation": ensure_quat_continuity([quat_from_euler_xyz(0.0, 0.0, 0.0) for _ in range(n_gi)])}
    tr_gi[16] = {"rotation": ensure_quat_continuity([quat_from_euler_xyz(2.0 + 1.5*math.sin(2*math.pi*i/24.0), 0.0, 0.0) for i in range(n_gi)])}
    anims.append({"name": "Posture_01_Grounded_Idle", "times": t_gi, "tracks": tr_gi})

    # 6. Posture_02_Controlled_Landing (1.400s, 37 keys — dense sampling so linear slerp between keys has 0.0mm ground penetration!)
    n_ld = 37
    t_ld = [round(1.400 * i / (n_ld - 1), 5) for i in range(n_ld)]
    ty_ld, tz_ld, cp_ld, ay_ld, ban_ld = [], [], [], [], []
    for t_v in t_ld:
        if t_v <= 0.45:
            u = t_v / 0.45
            h_air = 0.360 * (1.0 - u)
            ty_ld.append(h_air)
            tz_ld.append(0.0)
            cp_ld.append(-4.0 * (1.0 - u))
            ay_ld.append(0.0578 + h_air)
            ban_ld.append(16.0 * (1.0 - 0.5 * u))
        elif t_v <= 0.80:
            u = (t_v - 0.45) / 0.35
            dy = 0.220 * math.sin(u * math.pi * 0.5)
            ty_ld.append(-dy)
            tz_ld.append(0.0)
            cp_ld.append(+5.5 * math.sin(u * math.pi * 0.5))
            ay_ld.append(0.0578)
            ban_ld.append(8.0 * (1.0 - u))
        else:
            u = (t_v - 0.80) / 0.60
            s_u = u * u * (3.0 - 2.0 * u)
            dy = 0.220 * (1.0 - s_u)
            ty_ld.append(-dy)
            tz_ld.append(0.0)
            cp_ld.append(+5.5 * (1.0 - s_u))
            ay_ld.append(0.0578)
            ban_ld.append(2.0 * s_u)
    tr_ld = make_exact_planted_leg_tracks(ty_ld, tz_ld, cp_ld, ay_ld, None, ay_ld, None)
    tr_ld[1]  = {"translation": [[0.0, y, 0.0] for y in ty_ld], "rotation": ensure_quat_continuity([quat_from_euler_xyz(p, 0.0, 0.0) for p in cp_ld])}
    tr_ld[16] = {"rotation": ensure_quat_continuity([quat_from_euler_xyz(b, 0.0, 0.0) for b in ban_ld])}
    anims.append({"name": "Posture_02_Controlled_Landing", "times": t_ld, "tracks": tr_ld})

    # 7. Posture_03_Grounded_Crouch (1.200s, 37 keys — lowers chassis & rotor by -0.520m to Y_hub=1.660m with exact Y=0.000m stirrup contact!)
    n_cr = 37
    t_cr = [round(1.200 * i / (n_cr - 1), 5) for i in range(n_cr)]
    ty_cr, tz_cr, cp_cr, ay_cr = [], [], [], []
    for i in range(n_cr):
        u = i / float(n_cr - 1)
        w = min(1.0, u / 0.45)
        s_w = w * w * (3.0 - 2.0 * w)
        ty_cr.append(-0.520 * s_w)
        tz_cr.append(0.0)
        cp_cr.append(+4.0 * s_w)
        ay_cr.append(0.0564)
    tr_cr = make_exact_planted_leg_tracks(ty_cr, tz_cr, cp_cr, ay_cr, None, ay_cr, None)
    tr_cr[1]  = {"translation": [[0.0, y, 0.0] for y in ty_cr], "rotation": ensure_quat_continuity([quat_from_euler_xyz(p, 0.0, 0.0) for p in cp_cr])}
    tr_cr[16] = {"rotation": ensure_quat_continuity([quat_from_euler_xyz(2.0, 0.0, 0.0) for _ in range(n_cr)])}
    anims.append({"name": "Posture_03_Grounded_Crouch", "times": t_cr, "tracks": tr_cr})

    # 8. Posture_04_Takeoff_To_Flight (1.400s, 37 keys)
    n_to = 37
    t_to = [round(1.400 * i / (n_to - 1), 5) for i in range(n_to)]
    ty_to, tz_to, cp_to, ay_to, ban_to = [], [], [], [], []
    for t_v in t_to:
        if t_v <= 0.45:
            u = t_v / 0.45
            s_u = math.sin(u * math.pi * 0.5)
            dy = 0.240 * s_u
            ty_to.append(-dy)
            tz_to.append(0.0)
            cp_to.append(+4.5 * s_u)
            ay_to.append(0.0570)
            ban_to.append(2.0)
        elif t_v <= 0.80:
            u = (t_v - 0.45) / 0.35
            dy = 0.240 * (1.0 - u)
            ty_to.append(-dy)
            tz_to.append(0.0)
            cp_to.append(+4.5 * (1.0 - u) - 3.5 * u)
            ay_to.append(0.0570)
            ban_to.append(2.0 + 10.0 * u)
        else:
            u = (t_v - 0.80) / 0.60
            s_u = u * u * (3.0 - 2.0 * u)
            h_air = 0.360 * s_u
            ty_to.append(h_air)
            tz_to.append(0.0)
            cp_to.append(-3.5)
            ay_to.append(0.0555 + h_air + 0.080 * s_u)
            ban_to.append(12.0 + 4.0 * s_u)
    tr_to = make_exact_planted_leg_tracks(ty_to, tz_to, cp_to, ay_to, None, ay_to, None)
    tr_to[1]  = {"translation": [[0.0, y, 0.0] for y in ty_to], "rotation": ensure_quat_continuity([quat_from_euler_xyz(p, 0.0, 0.0) for p in cp_to])}
    tr_to[16] = {"rotation": ensure_quat_continuity([quat_from_euler_xyz(b, 0.0, 0.0) for b in ban_to])}
    anims.append({"name": "Posture_04_Takeoff_To_Flight", "times": t_to, "tracks": tr_to})

    # 9. Posture_05_Grounded_Walk_Loop (1.200s loop, 37 dense keys):
    #    Priority 2 Fix: True foot-planted stance phase + lifted swing phase with 0.0000m ground penetration
    #    and zero unnatural floating during planted phases!
    #    - u in [0.0, 0.5]: Left foot is PLANTED flat on the floor (`ay_L = 0.0554m -> sole at Y = +0.0004m`,
    #      sliding from `az_L = +0.135m` back to `-0.115m` as the chassis advances), while Right foot SWINGS
    #      forward (`az_R = -0.115m -> +0.135m`) along a clean `+0.075m` vertical step arch (`ay_R = 0.0554 + 0.075*sin(2*pi*u)`).
    #    - u in [0.5, 1.0]: Right foot is PLANTED flat on the floor (`ay_R = 0.0554m -> sole at Y = +0.0004m`,
    #      sliding from `az_R = +0.135m` back to `-0.115m`), while Left foot SWINGS forward (`az_L = -0.115m -> +0.135m`)
    #      along the symmetric `+0.075m` vertical step arch!
    n_wk = 37
    t_wk = [round(1.200 * i / (n_wk - 1), 5) for i in range(n_wk)]
    ty_wk, tz_wk, cp_wk = [], [], []
    ay_l_wk, az_l_wk, ay_r_wk, az_r_wk = [], [], [], []
    for i in range(n_wk):
        u = i / float(n_wk - 1)
        # Natural heavy exoskeleton walking cadence (`-0.028m` to `-0.040m` knee flexion)
        ty_wk.append(-0.028 - 0.012 * (0.5 - 0.5 * math.cos(4.0 * math.pi * u)))
        tz_wk.append(0.0)
        cp_wk.append(+2.4 + 0.6 * math.cos(4.0 * math.pi * u))

        if u <= 0.5:
            p = u / 0.5 # 0 -> 1 during Left Stance / Right Swing
            s_p = p * p * (3.0 - 2.0 * p)
            # Left foot planted flat on floor, sweeping backward relative to hip
            ay_l_wk.append(0.0554)
            az_l_wk.append(+0.115 - 0.210 * p)
            # Right foot lifted in swing arc, sweeping forward relative to hip
            ay_r_wk.append(0.0554 + 0.075 * math.sin(math.pi * p))
            az_r_wk.append(-0.095 + 0.210 * s_p)
        else:
            p = (u - 0.5) / 0.5 # 0 -> 1 during Right Stance / Left Swing
            s_p = p * p * (3.0 - 2.0 * p)
            # Right foot planted flat on floor, sweeping backward relative to hip
            ay_r_wk.append(0.0554)
            az_r_wk.append(+0.115 - 0.210 * p)
            # Left foot lifted in swing arc, sweeping forward relative to hip
            ay_l_wk.append(0.0554 + 0.075 * math.sin(math.pi * p))
            az_l_wk.append(-0.095 + 0.210 * s_p)

    tr_wk = make_exact_planted_leg_tracks(ty_wk, tz_wk, cp_wk, ay_l_wk, az_l_wk, ay_r_wk, az_r_wk)
    # Note: zero Z-roll on Node 1 so left and right hips remain at equal height and never push the opposite planted foot below Y=0!
    tr_wk[1] = {
        "translation": [[0.014 * math.sin(2*math.pi*i/36.0), ty_wk[i], 0.0] for i in range(n_wk)],
        "rotation": ensure_quat_continuity([quat_from_euler_xyz(cp_wk[i], 0.0, 0.0) for i in range(n_wk)]),
    }
    tr_wk[16] = {"rotation": ensure_quat_continuity([quat_from_euler_xyz(8.0 + 2.5*abs(math.sin(2*math.pi*i/36.0)), 0.0, 0.0) for i in range(n_wk)])}
    anims.append({"name": "Posture_05_Grounded_Walk_Loop", "times": t_wk, "tracks": tr_wk})

    # 10. Posture_06_Airborne_Overdrive_Pitch (1.000s loop, 25 keys — +14.0° Flight to the Valkyrie pitch, NO crossbow keys!)
    n_od = 25
    t_od = [round(1.000 * i / (n_od - 1), 4) for i in range(n_od)]
    ty_od = [0.340 + 0.015 * math.sin(2*math.pi*i/24.0) for i in range(n_od)]
    tz_od = [0.060 for _ in range(n_od)]
    cp_od = [+14.0 + 1.0 * math.sin(2*math.pi*i/24.0) for i in range(n_od)]
    ay_od = [ty_od[i] + 0.165 for i in range(n_od)]
    tr_od = make_exact_planted_leg_tracks(ty_od, tz_od, cp_od, ay_od, None, ay_od, None)
    tr_od[1] = {
        "translation": [[0.0, ty_od[i], tz_od[i]] for i in range(n_od)],
        "rotation": ensure_quat_continuity([quat_from_euler_xyz(cp_od[i], 0.0, 0.0) for i in range(n_od)]),
    }
    tr_od[16] = {"rotation": ensure_quat_continuity([quat_from_euler_xyz(+26.0 + 4.5*math.sin(4*math.pi*i/24.0), 0.0, 0.0) for i in range(n_od)])}
    anims.append({"name": "Posture_06_Airborne_Overdrive_Pitch", "times": t_od, "tracks": tr_od})

    # 11. Posture_07_Terminal_Dive_Pitch (1.200s, 37 keys — +26.0° chassis + +36.0° trunnion + +0.200m slide = +62.0° combined orientation)
    n_dv = 37
    t_dv = [round(1.200 * i / (n_dv - 1), 5) for i in range(n_dv)]
    s_dv = [(i/36.0)**2 * (3.0 - 2.0*(i/36.0)) for i in range(n_dv)]
    ty_dv = [0.320 - 0.120 * s for s in s_dv]
    tz_dv = [0.080 * s for s in s_dv]
    cp_dv = [+26.0 * s for s in s_dv]
    ay_dv = [ty_dv[i] + 0.175 for i in range(n_dv)]
    tr_dv = make_exact_planted_leg_tracks(ty_dv, tz_dv, cp_dv, ay_dv, None, ay_dv, None)
    tr_dv[1] = {
        "translation": [[0.0, ty_dv[i], tz_dv[i]] for i in range(n_dv)],
        "rotation": ensure_quat_continuity([quat_from_euler_xyz(cp_dv[i], 0.0, 0.0) for i in range(n_dv)]),
    }
    tr_dv[8] = {
        "translation": [[0.000, +1.980 + 0.040 * s, +0.020 + 0.200 * s] for s in s_dv],
        "rotation": ensure_quat_continuity([quat_from_euler_xyz(+36.0 * s, 0.0, 0.0) for s in s_dv]),
    }
    tr_dv[16] = {"rotation": ensure_quat_continuity([quat_from_euler_xyz(+38.0 * s, 0.0, 0.0) for s in s_dv])}
    anims.append({"name": "Posture_07_Terminal_Dive_Pitch", "times": t_dv, "tracks": tr_dv})

    # 12. Damage_08_Rotor_Destroy_Grounded (1.400s, 37 keys):
    #     Priority 1 Fix — Visually Unmistakable Asymmetrical Rotor Destruction:
    #       - At t = 0.18s (u = 0.128), the central bearing & left blade ricasso fracture catastrophically:
    #         * `Node 26: Rotor_Hub_Fractured_Collar` scales `[0,0,0] -> [1,1,1]` (exposing split bearing races, broken bevel gear teeth & sheared journal).
    #         * `Node 10: Rotor_Sword_Blade_L` (intact left blade) scales `[1,1,1] -> [0,0,0]`, replaced instantaneously by
    #           `Node 27: Rotor_Blade_L_Fractured_Stump` (`[0,0,0] -> [1,1,1]`), leaving a jagged 0.46m sheared ricasso & twisted crossguard stump!
    #         * `Node 28: Rotor_Blade_L_Detached_Segment` (the severed 0.88m outer left blade) scales `[0,0,0] -> [1,1,1]` at its
    #           fracture release origin `[+0.440, +2.180, +0.020] m` and falls/tumbles under gravity onto the ground beside the left flank
    #           (`[+0.880, +0.036, +0.260] m`, resting flat on `Y = 0.036m` as visible battle debris without scripted enemy-seeking behavior!).
    #         * `Node 11: Rotor_Sword_Blade_R` (right blade) wrenches asymmetrically backward (`+32.0°` yaw), twists (`-36.0°` roll),
    #           and collapses downward (`-44.0°` pitch) against the upper-rear dorsal carapace (staying clear of the right sword corridor!).
    n_ds = 37
    t_ds = [round(1.400 * i / (n_ds - 1), 5) for i in range(n_ds)]
    u_ds = [i / 36.0 for i in range(n_ds)]
    ty_ds = [-0.145 * math.sin(u * math.pi) if u < 0.65 else -0.075 for u in u_ds]
    tz_ds = [0.0 for _ in range(n_ds)]
    cp_ds = [4.5 * math.sin(u * 3.0 * math.pi) * (1.0 - u) for u in u_ds]
    ay_ds = [0.0573 for _ in range(n_ds)]
    tr_ds = make_exact_planted_leg_tracks(ty_ds, tz_ds, cp_ds, ay_ds, None, ay_ds, None)
    tr_ds[1] = {
        "translation": [[0.0, ty_ds[i], 0.0] for i in range(n_ds)],
        "rotation": ensure_quat_continuity([quat_from_euler_xyz(cp_ds[i], 0.0, 0.0) for i in range(n_ds)]),
    }
    tr_ds[8] = {
        "rotation": ensure_quat_continuity([
            quat_from_euler_xyz(16.5 * min(1.0, u*2.2) + 4.0*math.sin(u*6*math.pi)*(1.0-u), 0.0, -14.0 * min(1.0, u*2.0))
            for u in u_ds
        ])
    }
    # At i >= 4 (t >= 0.155s), swap intact Left Blade (Node 10) for Fractured Stump (Node 27) + Detached Segment (Node 28)
    # and reveal Fractured Hub Collar (Node 26):
    sc_10, sc_26, sc_27, sc_28, tr_28, rt_28, rt_11 = [], [], [], [], [], [], []
    for i, u in enumerate(u_ds):
        if i < 4:
            sc_10.append([1.0, 1.0, 1.0])
            sc_26.append([0.0, 0.0, 0.0])
            sc_27.append([0.0, 0.0, 0.0])
            sc_28.append([0.0, 0.0, 0.0])
            tr_28.append([+0.440, +2.180, +0.020])
            rt_28.append(quat_from_euler_xyz(0.0, 0.0, 0.0))
            w_r = i / 4.0
            rt_11.append(quat_from_euler_xyz(-12.0 * w_r, +10.0 * w_r, +15.0 * w_r))
        else:
            sc_10.append([0.0, 0.0, 0.0])
            sc_26.append([1.0, 1.0, 1.0])
            sc_27.append([1.0, 1.0, 1.0])
            sc_28.append([1.0, 1.0, 1.0])
            w_f = min(1.0, (u - u_ds[4]) / 0.55)
            # Ballistic gravity drop from [0.440, 2.180, 0.020] to ground rest [+0.540, +0.038 - ty_ds[i], +0.260]
            px = +0.440 + 0.100 * w_f
            pz = +0.020 + 0.240 * w_f
            py_world = 2.180 * (1.0 - w_f * w_f) + 0.038 * (w_f * w_f)
            # Compensate for parent Node 1 vertical translation ty_ds[i] so detached blade rests flat on Y_world = 0.038m!
            py_local = py_world - ty_ds[i]
            tr_28.append([float(px), float(py_local), float(pz)])
            rt_28.append(quat_from_euler_xyz(8.0 * w_f, -38.0 * w_f, -4.0 * w_f))
            w_r = min(1.0, (u - u_ds[4]) / 0.35)
            s_r = w_r * w_r * (3.0 - 2.0 * w_r)
            rt_11.append(quat_from_euler_xyz(-36.0 * s_r, +32.0 * s_r, +44.0 * s_r))

    tr_ds[10] = {"scale": sc_10}
    tr_ds[11] = {"rotation": ensure_quat_continuity(rt_11)}
    tr_ds[26] = {"scale": sc_26}
    tr_ds[27] = {"scale": sc_27}
    tr_ds[28] = {"translation": tr_28, "rotation": ensure_quat_continuity(rt_28), "scale": sc_28}
    tr_ds[16] = {"rotation": ensure_quat_continuity([quat_from_euler_xyz(2.0 * (1.0 - u), 0.0, 0.0) for u in u_ds])}
    anims.append({"name": "Damage_08_Rotor_Destroy_Grounded", "times": t_ds, "tracks": tr_ds})

    return anims

# =============================================================================
# 5. EXPORT `fight-and-flight-v25-review.glb` & RE-OPEN FOR FULL VALIDATION
# =============================================================================

def export_fight_and_flight_v22_glb(all_meshes, out_glb_path: Path):
    bin_chunks = bytearray()
    buffer_views, accessors = [], []

    def add_bv(raw_bytes: bytes, target=None):
        pad = (4 - (len(bin_chunks) % 4)) % 4
        if pad:
            bin_chunks.extend(b"\x00" * pad)
        off = len(bin_chunks)
        bin_chunks.extend(raw_bytes)
        bv = {"buffer": 0, "byteOffset": off, "byteLength": len(raw_bytes)}
        if target is not None:
            bv["target"] = target
        idx = len(buffer_views)
        buffer_views.append(bv)
        return idx

    def add_acc(bv_idx: int, comp_type: int, count: int, acc_type: str, vmin=None, vmax=None):
        acc = {"bufferView": bv_idx, "componentType": comp_type, "count": count, "type": acc_type}
        if vmin is not None:
            acc["min"] = [float(x) if comp_type == 5126 else int(x) for x in vmin]
        if vmax is not None:
            acc["max"] = [float(x) if comp_type == 5126 else int(x) for x in vmax]
        idx = len(accessors)
        accessors.append(acc)
        return idx

    images, textures = [], []
    tex_files = [
        ("faf_baseColor.png",         WORK_DIR / "faf_baseColor.png"),
        ("faf_metallicRoughness.png", WORK_DIR / "faf_metallicRoughness.png"),
        ("faf_normal.png",            WORK_DIR / "faf_normal.png"),
    ]
    for tname, tpath in tex_files:
        raw_png = tpath.read_bytes()
        bv_i = add_bv(raw_png)
        img_i = len(images)
        images.append({"name": tname, "bufferView": bv_i, "mimeType": "image/png"})
        textures.append({"sampler": 0, "source": img_i, "name": tname})

    samplers = [{"magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497}]
    materials = [
        {
            "name": "FAF_Castleward_Siege_PBR",
            "doubleSided": True,
            "pbrMetallicRoughness": {
                "baseColorTexture": {"index": 0},
                "metallicRoughnessTexture": {"index": 1},
                "metallicFactor": 1.0,
                "roughnessFactor": 1.0,
            },
            "normalTexture": {"index": 2, "scale": 1.0},
        }
    ]

    gltf_meshes = []
    mesh_stats = {}
    tot_verts, tot_tris = 0, 0
    for node_idx, mname, (pos, poff, cv, uv) in all_meshes:
        vp, vn, vu, idx_u32 = compile_welded_gltf_primitive(pos, poff, cv, uv, crease_deg=22.0)
        bv_p = add_bv(vp.tobytes(), target=34962)
        bv_n = add_bv(vn.tobytes(), target=34962)
        bv_u = add_bv(vu.tobytes(), target=34962)
        bv_i = add_bv(idx_u32.tobytes(), target=34963)

        acc_p = add_acc(bv_p, 5126, len(vp), "VEC3", vp.min(axis=0), vp.max(axis=0))
        acc_n = add_acc(bv_n, 5126, len(vn), "VEC3")
        acc_u = add_acc(bv_u, 5126, len(vu), "VEC2")
        acc_i = add_acc(bv_i, 5125, len(idx_u32), "SCALAR", [int(idx_u32.min())], [int(idx_u32.max())])

        m_idx = len(gltf_meshes)
        gltf_meshes.append({
            "name": f"{mname}_Mesh",
            "primitives": [{
                "attributes": {"POSITION": acc_p, "NORMAL": acc_n, "TEXCOORD_0": acc_u},
                "indices": acc_i,
                "material": 0,
                "mode": 4,
            }]
        })
        ntris = len(idx_u32) // 3
        tot_verts += len(vp)
        tot_tris += ntris
        mesh_stats[mname] = {
            "nodeIndex": node_idx,
            "meshIndex": m_idx,
            "weldedVertices": int(len(vp)),
            "triangles": int(ntris),
            "localBoundsMin": [round(float(x), 4) for x in vp.min(axis=0)],
            "localBoundsMax": [round(float(x), 4) for x in vp.max(axis=0)],
        }

    node_to_mesh = {node_idx: m_idx for m_idx, (node_idx, _, _) in enumerate(all_meshes)}
    children_map = defaultdict(list)
    for idx, name, p_idx, loc_tr, w_tr, def_sc in FAF_NODES:
        if p_idx is not None:
            children_map[p_idx].append(idx)
    for idx, name, p_idx, loc_tr, w_tr, desc in FAF_LOCATORS:
        children_map[p_idx].append(idx)

    gltf_nodes = []
    for idx, name, p_idx, loc_tr, w_tr, def_sc in FAF_NODES:
        nd = {
            "name": name,
            "translation": [float(x) for x in loc_tr],
            "rotation": [0.0, 0.0, 0.0, 1.0],
            "scale": [float(x) for x in def_sc],
        }
        if idx in node_to_mesh:
            nd["mesh"] = node_to_mesh[idx]
        if children_map[idx]:
            nd["children"] = children_map[idx]
        gltf_nodes.append(nd)

    for idx, name, p_idx, loc_tr, w_tr, desc in FAF_LOCATORS:
        nd = {
            "name": name,
            "translation": [float(x) for x in loc_tr],
            "rotation": [0.0, 0.0, 0.0, 1.0],
            "scale": [1.0, 1.0, 1.0],
            "extras": {
                "role": "castleward_fight_and_flight_locator",
                "parentNodeIndex": p_idx,
                "worldTranslationAtRest": [float(x) for x in w_tr],
                "description": desc,
            }
        }
        gltf_nodes.append(nd)

    raw_anims = build_faf_v2_2_animations()
    gltf_anims = []
    for anim in raw_anims:
        t_arr = np.array(anim["times"], dtype=np.float32)
        bv_t = add_bv(t_arr.tobytes())
        acc_t = add_acc(bv_t, 5126, len(t_arr), "SCALAR", [float(t_arr.min())], [float(t_arr.max())])
        samplers_a, channels_a = [], []
        for n_idx, tr_dict in anim["tracks"].items():
            for path_name in ("translation", "rotation", "scale"):
                if path_name not in tr_dict:
                    continue
                vals = np.array(tr_dict[path_name], dtype=np.float32)
                bv_v = add_bv(vals.tobytes())
                atype = "VEC4" if path_name == "rotation" else "VEC3"
                acc_v = add_acc(bv_v, 5126, len(vals), atype)
                s_idx = len(samplers_a)
                samplers_a.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
                channels_a.append({"sampler": s_idx, "target": {"node": int(n_idx), "path": path_name}})
        gltf_anims.append({
            "name": anim["name"],
            "samplers": samplers_a,
            "channels": channels_a,
        })

    gltf_json = {
        "asset": {
            "version": "2.0",
            "generator": "Castleward Fight-and-Flight Siege Apparatus Pipeline v2.4",
        },
        "scene": 0,
        "scenes": [{"name": "FightAndFlight_Scene", "nodes": [0]}],
        "nodes": gltf_nodes,
        "meshes": gltf_meshes,
        "materials": materials,
        "textures": textures,
        "images": images,
        "samplers": samplers,
        "accessors": accessors,
        "bufferViews": buffer_views,
        "buffers": [{"byteLength": len(bin_chunks)}],
        "animations": gltf_anims,
        "extras": {
            "assetId": "fight-and-flight",
            "version": "2.5.0",
            "excludesSpellbladeCharacterMesh": True,
            "totalWeldedVertices": tot_verts,
            "totalTriangles": tot_tris,
            "rotorHubWorldY": 2.180,
            "groundedCrouchChassisDropM": 0.520,
            "groundedCrouchRotorHubWorldY": 1.660,
            "groundedCrouchBladeSweepBandWorldY": [1.585, 1.725],
            "terminalDiveCombinedPitchDeg": 62.0,
            "rotorDestructionArchitecture": {
                "intactNodesToHide": ["Rotor_Sword_Blade_L"],
                "damagedNodesToShow": ["Rotor_Hub_Fractured_Collar", "Rotor_Blade_L_Fractured_Stump", "Rotor_Blade_L_Detached_Segment"],
                "asymmetricCollapsedNode": "Rotor_Sword_Blade_R",
                "detachedBladeReleaseLocator": "rotor_blade_L_release_origin",
                "detachedBladeReleaseWorldOrigin": [+0.440, +2.180, +0.020],
            },
            "independentAnimationGroups": {
                "rotorAndDriveGroup": ["Rotor_Spin_Cycle_1Rev", "Rotor_Startup"],
                "crossbowAndQuarrelsGroup": ["Crossbow_Fire_Loop", "Crossbow_Reload_Index"],
                "postureAndGroundedGroup": [
                    "Posture_01_Grounded_Idle",
                    "Posture_02_Controlled_Landing",
                    "Posture_03_Grounded_Crouch",
                    "Posture_04_Takeoff_To_Flight",
                    "Posture_05_Grounded_Walk_Loop",
                    "Posture_06_Airborne_Overdrive_Pitch",
                    "Posture_07_Terminal_Dive_Pitch",
                    "Damage_08_Rotor_Destroy_Grounded",
                ],
            },
            "meshStats": mesh_stats,
        }
    }

    json_bytes = json.dumps(gltf_json, separators=(",", ":")).encode("utf-8")
    j_pad = (4 - (len(json_bytes) % 4)) % 4
    if j_pad:
        json_bytes += b" " * j_pad
    b_pad = (4 - (len(bin_chunks) % 4)) % 4
    if b_pad:
        bin_chunks.extend(b"\x00" * b_pad)

    total_len = 12 + 8 + len(json_bytes) + 8 + len(bin_chunks)
    glb_out = bytearray()
    glb_out.extend(struct.pack("<III", 0x46546C67, 2, total_len))
    glb_out.extend(struct.pack("<II", len(json_bytes), 0x4E4F534A))
    glb_out.extend(json_bytes)
    glb_out.extend(struct.pack("<II", len(bin_chunks), 0x004E4942))
    glb_out.extend(bin_chunks)

    out_glb_path.write_bytes(glb_out)
    sha = hashlib.sha256(glb_out).hexdigest()
    print(f"[OK] Exported {out_glb_path.name}: {len(glb_out):,} bytes ({len(glb_out)/1048576:.2f} MB), {tot_verts:,} welded verts, {tot_tris:,} tris, SHA256={sha}")
    return gltf_json, sha

def reopen_and_audit_v22_glb(glb_path: Path):
    """
    Re-opens the exported `fight-and-flight-v25-review.glb` binary from disk and performs:
      1. Full vertex-level ground penetration & stance-floating audit across 120 dense sub-frames
         of `Posture_05_Grounded_Walk_Loop`, `Posture_01_Grounded_Idle`, `Posture_02_Controlled_Landing`,
         `Posture_03_Grounded_Crouch`, and `Damage_08_Rotor_Destroy_Grounded`!
      2. Orthogonality audit across Group A (Rotor), Group B (Crossbow), and Group C (Posture/Damage).
      3. Rotor-destruction mesh & release-origin verification.
    """
    raw = glb_path.read_bytes()
    j_len = struct.unpack_from("<I", raw, 12)[0]
    g = json.loads(raw[20:20+j_len])
    b_off = 20 + j_len + 8
    bin_buf = raw[b_off:]

    def read_acc(acc_idx):
        acc = g["accessors"][acc_idx]
        bv = g["bufferViews"][acc["bufferView"]]
        cnt = acc["count"]
        cols = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}[acc["type"]]
        dt = np.float32 if acc["componentType"] == 5126 else np.uint32
        arr = np.frombuffer(bin_buf, dtype=dt, count=cnt*cols, offset=bv["byteOffset"]).copy()
        return arr.reshape(cnt, cols) if cols > 1 else arr

    def q_to_m3(q):
        x, y, z, w = q
        n = math.sqrt(x*x + y*y + z*z + w*w)
        if n > 1e-8:
            x, y, z, w = x/n, y/n, z/n, w/n
        return np.array([
            [1 - 2*(y*y + z*z), 2*(x*y - z*w),     2*(x*z + y*w)],
            [2*(x*y + z*w),     1 - 2*(x*x + z*z), 2*(y*z - x*w)],
            [2*(x*z - y*w),     2*(y*z + x*w),     1 - 2*(x*x + y*y)],
        ], dtype=np.float64)

    def slerp_q(q0, q1, u):
        dot = float(np.dot(q0, q1))
        if dot < 0.0:
            q1 = -q1
            dot = -dot
        if dot > 0.9995:
            r = (1.0 - u)*q0 + u*q1
            return r / np.linalg.norm(r)
        th0 = math.acos(min(1.0, max(-1.0, dot)))
        th  = th0 * u
        s0  = math.cos(th) - dot * math.sin(th) / math.sin(th0)
        s1  = math.sin(th) / math.sin(th0)
        return s0 * q0 + s1 * q1

    nodes = g["nodes"]
    parent_map = {}
    for pi, nd in enumerate(nodes):
        for ch in nd.get("children", []):
            parent_map[ch] = pi

    # Load stirrup mesh vertices (Nodes 21 & 22) from the GLB binary
    v_stirrup_l = read_acc(g["meshes"][nodes[21]["mesh"]]["primitives"][0]["attributes"]["POSITION"]).astype(np.float64)
    v_stirrup_r = read_acc(g["meshes"][nodes[22]["mesh"]]["primitives"][0]["attributes"]["POSITION"]).astype(np.float64)

    def eval_anim_at_time(anim, t_sec):
        # Returns world matrices for all nodes at time t_sec using true glTF linear/slerp interpolation
        tracks = defaultdict(dict)
        for ch in anim["channels"]:
            samp = anim["samplers"][ch["sampler"]]
            t_arr = read_acc(samp["input"])
            v_arr = read_acc(samp["output"]).astype(np.float64)
            n_idx = ch["target"]["node"]
            path  = ch["target"]["path"]
            if t_sec <= t_arr[0]:
                val = v_arr[0]
            elif t_sec >= t_arr[-1]:
                val = v_arr[-1]
            else:
                k = int(np.searchsorted(t_arr, t_sec) - 1)
                k = max(0, min(len(t_arr) - 2, k))
                dt = float(t_arr[k+1] - t_arr[k])
                u = (t_sec - float(t_arr[k])) / max(dt, 1e-8)
                if path == "rotation":
                    val = slerp_q(v_arr[k], v_arr[k+1], u)
                else:
                    val = (1.0 - u) * v_arr[k] + u * v_arr[k+1]
            tracks[n_idx][path] = val

        wm = {}
        def get_m(idx):
            if idx in wm:
                return wm[idx]
            nd = nodes[idx]
            tr = tracks[idx].get("translation", np.array(nd.get("translation", [0,0,0]), dtype=np.float64))
            rt = tracks[idx].get("rotation",    np.array(nd.get("rotation", [0,0,0,1]), dtype=np.float64))
            sc = tracks[idx].get("scale",       np.array(nd.get("scale", [1,1,1]), dtype=np.float64))
            M = np.eye(4, dtype=np.float64)
            M[:3, :3] = q_to_m3(rt) @ np.diag(sc)
            M[:3, 3]  = tr
            if idx in parent_map:
                M = get_m(parent_map[idx]) @ M
            wm[idx] = M
            return M

        for i in range(len(nodes)):
            get_m(i)
        return wm

    print("=== RE-OPENED v2.2 GLB: VERTEX-LEVEL GROUND CONTACT & WALK AUDIT ===")
    for aname in ("Posture_01_Grounded_Idle", "Posture_02_Controlled_Landing", "Posture_03_Grounded_Crouch", "Posture_05_Grounded_Walk_Loop", "Damage_08_Rotor_Destroy_Grounded"):
        anim = next(a for a in g["animations"] if a["name"] == aname)
        dur = float(read_acc(anim["samplers"][0]["input"])[-1])
        min_y_all = +999.0
        max_stance_float = 0.0
        for s_i in range(121):
            t_s = dur * (s_i / 120.0)
            wm = eval_anim_at_time(anim, t_s)
            p_l = (v_stirrup_l @ wm[21][:3, :3].T) + wm[21][:3, 3]
            p_r = (v_stirrup_r @ wm[22][:3, :3].T) + wm[22][:3, 3]
            yl_min = float(p_l[:, 1].min())
            yr_min = float(p_r[:, 1].min())
            min_y_all = min(min_y_all, yl_min, yr_min)
            # Planted stance foot is whichever foot is lower (during grounded intervals)
            planted_min = min(yl_min, yr_min)
            if planted_min < 0.020: # when in grounded phase
                max_stance_float = max(max_stance_float, abs(planted_min))
        penetration_mm = max(0.0, -min_y_all * 1000.0)
        print(f"  [AUDIT] {aname:34s}: min_vertex_Y = {min_y_all:+.5f} m (max ground penetration = {penetration_mm:.2f} mm, max planted sole float = {max_stance_float*1000.0:.2f} mm)")
        assert penetration_mm < 0.05, f"Ground penetration {penetration_mm:.2f} mm exceeds 0.05mm tolerance in {aname}!"

# =============================================================================
# 6. EXPORT EDITABLE `fight-and-flight-v25-review.blend` & REFERENCE `.blend`
# =============================================================================

def zstd_compress_blend(raw_bytes: bytes, out_path: Path):
    libzstd = ctypes.CDLL("libzstd.so.1")
    libzstd.ZSTD_compressBound.argtypes = [ctypes.c_size_t]
    libzstd.ZSTD_compressBound.restype = ctypes.c_size_t
    libzstd.ZSTD_compress.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
    libzstd.ZSTD_compress.restype = ctypes.c_size_t
    bound = libzstd.ZSTD_compressBound(len(raw_bytes))
    dst = ctypes.create_string_buffer(bound)
    c_size = libzstd.ZSTD_compress(dst, bound, raw_bytes, len(raw_bytes), 3)
    out_path.write_bytes(dst.raw[:c_size])
    return c_size

def set_id_name_clean(block, new_id_name: str):
    raw = new_id_name.encode("utf-8")[:63]
    block["payload"][0:66] = raw + b"\x00" * (66 - len(raw))

def concat_mesh_tuples(tuples_with_offsets):
    c_pos, c_poff, c_cv, c_uv = [], [0], [], []
    v_off = 0
    for (pos, poff, cv, uv), off_vec in tuples_with_offsets:
        c_pos.append(pos + np.array(off_vec, dtype=np.float32))
        for pi in range(len(poff) - 1):
            s, e = int(poff[pi]), int(poff[pi+1])
            for c in range(s, e):
                c_cv.append(int(cv[c]) + v_off)
                c_uv.append(uv[c])
            c_poff.append(len(c_cv))
        v_off += len(pos)
    return (
        np.vstack(c_pos).astype(np.float32),
        np.array(c_poff, dtype=np.int32),
        np.array(c_cv, dtype=np.int32),
        np.array(c_uv, dtype=np.float32),
    )

def export_standalone_v22_blend(all_meshes, out_blend_path: Path):
    bf = blend_io.BlendFile("/tmp/sofist_v2_1/SoFist-crafted-uncompressed.blend")
    ob_layout = bf.get_layout("Object")
    mesh_by_idx = {idx: m_tup for idx, _, m_tup in all_meshes}
    w_by_idx    = {idx: w_tr  for idx, _, _, _, w_tr, _ in FAF_NODES}

    leg_l_combined = concat_mesh_tuples([
        (mesh_by_idx[17], [0.0, 0.0, 0.0]),
        (mesh_by_idx[19], [0.0, -0.430, +0.020]),
        (mesh_by_idx[21], [-0.095, -0.865, +0.040]),
    ])
    leg_r_combined = concat_mesh_tuples([
        (mesh_by_idx[18], [0.0, 0.0, 0.0]),
        (mesh_by_idx[20], [0.0, -0.430, +0.020]),
        (mesh_by_idx[22], [+0.095, -0.865, +0.040]),
    ])
    car_and_quarrels = concat_mesh_tuples([
        (mesh_by_idx[15], [0.0, 0.0, 0.0]),
        (mesh_by_idx[23], [0.0, -0.087, -0.045]),
        (mesh_by_idx[24], [0.0, -0.043, -0.045]),
        (mesh_by_idx[25], [0.0, +0.001, -0.045]),
    ])
    gears_lr_combined = concat_mesh_tuples([
        (mesh_by_idx[6], [+0.215, 0.0, 0.0]),
        (mesh_by_idx[7], [-0.215, 0.0, 0.0]),
    ])
    hub_and_broken_parts = concat_mesh_tuples([
        (mesh_by_idx[9],  [0.0, 0.0, 0.0]),
        (mesh_by_idx[26], [0.0, 0.0, 0.0]),
        (mesh_by_idx[27], [0.0, 0.0, 0.0]),
        (mesh_by_idx[28], [+0.440, 0.0, 0.0]),
    ])

    slot_defs = [
        ("MECarriage_Main_Mesh.003",          "OBCarriage_Main.003",          "Main_Apparatus_Chassis",   mesh_by_idx[1],       w_by_idx[1]),
        ("MEBanner_Side_L_Mesh.003",          "OBBanner_Side_L.003",          "Protective_Brace_L",       mesh_by_idx[2],       w_by_idx[2]),
        ("MEBanner_Side_R_Mesh.003",          "OBBanner_Side_R.003",          "Protective_Brace_R",       mesh_by_idx[3],       w_by_idx[3]),
        ("MEWinch_Drum_And_Gears_Mesh.003",   "OBWinch_Drum_And_Gears.003",   "Rear_Drive_Assembly",      mesh_by_idx[4],       w_by_idx[4]),
        ("METension_Springs_Mesh.003",        "OBTension_Springs.003",        "Drive_Winch_Spring_Drum",  mesh_by_idx[5],       w_by_idx[5]),
        ("MEWheel_FL_Mesh.004",               "OBWheel_FL.004",               "Drive_Gear_Train_LR",      gears_lr_combined,    [0.0, 1.120, -0.420]),
        ("MEArcane_Stator_Collar_Mesh.003",   "OBArcane_Stator_Collar.003",   "Rotor_Shaft_And_Bearing",  mesh_by_idx[8],       w_by_idx[8]),
        ("MEWrist_Resonator_Ring_Mesh.003",   "OBWrist_Resonator_Ring.003",   "Rotor_Hub_And_Fracture",   hub_and_broken_parts, w_by_idx[9]),
        ("MEWheel_RL_Mesh.004",               "OBWheel_RL.004",               "Rotor_Sword_Blade_L",      mesh_by_idx[10],      w_by_idx[10]),
        ("MEWheel_RR_Mesh.004",               "OBWheel_RR.004",               "Rotor_Sword_Blade_R",      mesh_by_idx[11],      w_by_idx[11]),
        ("MERam_Shaft_Piston_Mesh.003",       "OBRam_Shaft_Piston.003",       "Crossbow_Body",            mesh_by_idx[12],      w_by_idx[12]),
        ("MEArmored_Fist_Mesh.003",           "OBArmored_Fist.003",           "Crossbow_Bow_And_String",  mesh_by_idx[13],      w_by_idx[13]),
        ("MEPinion_And_Release_Lever_Mesh.003","OBPinion_And_Release_Lever.003","Crossbow_Recocking_Slide", mesh_by_idx[14],    w_by_idx[14]),
        ("MERetraction_Chains_Aft_Mesh.003",  "OBRetraction_Chains_Aft.003",  "Crossbow_Carousel_Bolts",  car_and_quarrels,     w_by_idx[15]),
        ("MEBanner_Rear_L_Mesh.003",          "OBBanner_Rear_L.003",          "Rear_Trident_Banner",      mesh_by_idx[16],      w_by_idx[16]),
        ("MEWheel_FR_Mesh.004",               "OBWheel_FR.004",               "Lower_Exoskeleton_Leg_L",  leg_l_combined,       w_by_idx[17]),
        ("MEBanner_Rear_R_Mesh.003",          "OBBanner_Rear_R.003",          "Lower_Exoskeleton_Leg_R",  leg_r_combined,       w_by_idx[18]),
    ]

    for old_me, old_ob, new_name, (pos, poff, cv, uv), w_tr in slot_defs:
        midx = np.zeros(len(poff) - 1, dtype=np.int32)
        update_blend_mesh_from_gltf_arrays(bf, old_me, pos, poff, cv, uv, midx)
        bx, by, bz = float(w_tr[0]), float(-w_tr[2]), float(w_tr[1])
        for b in bf.blocks:
            if b["code"] == "ME" and bf.get_id_name(b) == old_me:
                set_id_name_clean(b, f"ME{new_name}_Mesh")
            elif b["code"] == "OB" and bf.get_id_name(b) == old_ob:
                set_id_name_clean(b, f"OB{new_name}")
                struct.pack_into("<3f", b["payload"], ob_layout["loc"][0], bx, by, bz)
                struct.pack_into("<3f", b["payload"], ob_layout["rot"][0], 0.0, 0.0, 0.0)
                struct.pack_into("<3f", b["payload"], ob_layout["size"][0], 1.0, 1.0, 1.0)

    extra_renames = {
        "OBBattleRam_Root.003":   ("OBFightAndFlight_Root",           [0.0, 0.0, 0.0]),
        "OBRam_Assembly.003":     ("OBoperator_first_person_camera",  [0.0, -0.220, 1.520]),
        "OBLaunch_Mechanism.003": ("OBcrossbow_muzzle",               [+0.650, -0.805, 1.098]),
    }
    for b in bf.blocks:
        if b["code"] == "OB" and bf.get_id_name(b) in extra_renames:
            new_ob_n, b_loc = extra_renames[bf.get_id_name(b)]
            set_id_name_clean(b, new_ob_n)
            struct.pack_into("<3f", b["payload"], ob_layout["loc"][0], *b_loc)

    ac_blocks = [b for b in bf.blocks if b["code"] == "AC"]
    ac_names = ["AC01_Rotor_Spin_Cycle_1Rev", "AC02_Crossbow_Fire_Loop", "AC03_Posture_Grounded_Walk", "AC04_Damage_Rotor_Destroy"]
    for ac_b, aname in zip(ac_blocks, ac_names):
        set_id_name_clean(ac_b, aname)

    im_base = Image.open(WORK_DIR / "faf_baseColor.png")
    im_mr   = Image.open(WORK_DIR / "faf_metallicRoughness.png")
    im_nrm  = Image.open(WORK_DIR / "faf_normal.png")
    bf.update_packed_image("IMtexture_diffuse.006", im_base)
    bf.update_packed_image("IMtexture_metallic-texture_roughness.006", im_mr)
    bf.update_packed_image("IMtexture_normal.006", im_nrm)

    uncomp_path = WORK_DIR / "fight-and-flight-v22-review-uncompressed.blend"
    bf.save(str(uncomp_path))
    c_size = zstd_compress_blend(uncomp_path.read_bytes(), out_blend_path)
    print(f"[OK] Exported {out_blend_path.name}: {c_size:,} bytes ({c_size/1048576:.2f} MB), SHA256={hashlib.sha256(out_blend_path.read_bytes()).hexdigest()}")

def export_fitted_spellblade_v22_reference_blend(all_meshes, out_ref_blend_path: Path):
    bf = blend_io.BlendFile(str(OUT_DIR / "Spellblade-production-third-person.blend"))
    ob_layout = bf.get_layout("Object")

    s_scale = 1.800 / 2.2342
    x_center_shift = +0.0345

    for b in bf.blocks:
        if b["code"] != "ME":
            continue
        mname = bf.get_id_name(b)
        if mname == "MEPlane":
            continue
        pos, poff, cv, uv, midx = read_raw_mesh_gltf(bf, mname)
        p_new = pos.copy()
        p_new[:, 0] = -pos[:, 0] * s_scale + x_center_shift
        p_new[:, 1] =  pos[:, 1] * s_scale
        p_new[:, 2] = -pos[:, 2] * s_scale

        if mname in ("MEGauntlet.R.001", "MEHeroSword"):
            piv = np.array([-0.320, 1.050, +0.020], dtype=np.float32)
            ang_x, ang_y = math.radians(-35.0), math.radians(-12.0)
            cx, sx = math.cos(ang_x), math.sin(ang_x)
            cy, sy = math.cos(ang_y), math.sin(ang_y)
            Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]], dtype=np.float32)
            Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]], dtype=np.float32)
            R = Ry @ Rx
            p_new = ((p_new - piv) @ R.T) + piv + np.array([-0.035, 0.0, +0.045], dtype=np.float32)

        if mname in ("MEGauntlet.L.001", "MEPalmRune.001"):
            piv_l = np.array([+0.340, 1.120, +0.020], dtype=np.float32)
            az, ax = math.radians(-48.0), math.radians(+10.0)
            cz, sz = math.cos(az), math.sin(az)
            cx, sx = math.cos(ax), math.sin(ax)
            Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]], dtype=np.float32)
            Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]], dtype=np.float32)
            R_l = Rx @ Rz
            p_new = ((p_new - piv_l) @ R_l.T) + piv_l + np.array([+0.045, -0.025, -0.035], dtype=np.float32)

        update_blend_mesh_from_gltf_arrays(bf, mname, p_new, poff, cv, uv, midx)

    node_world_map = {idx: np.array(w_tr, dtype=np.float32) for (idx, _, _, _, w_tr, _) in FAF_NODES}
    # Include intact apparatus meshes (1..25) in the default reference assembly
    c_pos_arr, c_poff_arr, c_cv_arr, c_uv_arr = concat_mesh_tuples([
        (m_tup, node_world_map[node_idx]) for node_idx, _, m_tup in all_meshes if node_idx <= 25
    ])
    c_midx_arr = np.zeros(len(c_poff_arr) - 1, dtype=np.int32)
    update_blend_mesh_from_gltf_arrays(bf, "MEPlane", c_pos_arr, c_poff_arr, c_cv_arr, c_uv_arr, c_midx_arr)

    ref_to_locator = {
        "OBReference.actions":  ("OBoperator_root_anchor",           [ 0.000,  0.000, 0.000]),
        "OBReference.back":     ("OBoperator_waist_harness_anchor",  [ 0.000, +0.015, 0.985]),
        "OBReference.boot":     ("OBoperator_foot_stirrup_L",        [+0.290, -0.035, 0.033]),
        "OBReference.helmet":   ("OBoperator_foot_stirrup_R",        [-0.290, -0.035, 0.033]),
        "OBReference.hero":     ("OBoperator_hand_L_crossbow_grip",  [+0.485, -0.235, 0.980]),
        "OBReference.shoulder": ("OBoperator_hand_R_sword_corridor", [-0.410, -0.280, 1.020]),
        "OBReference.side":     ("OBoperator_first_person_camera",   [ 0.000, -0.220, 1.520]),
        "OBReference.tabard":   ("OBcrossbow_muzzle",                [+0.650, -0.805, 1.098]),
        "OBReference.weapon":   ("OBrotor_blade_L_release_origin",   [+0.440, -0.020, 2.180]),
    }
    for b in bf.blocks:
        if b["code"] == "ME" and bf.get_id_name(b) == "MEPlane":
            set_id_name_clean(b, "MEFightAndFlight_v22_Apparatus")
        elif b["code"] == "OB":
            ob_n = bf.get_id_name(b)
            if ob_n == "OBSpellbladeReviewFloor":
                set_id_name_clean(b, "OBFightAndFlight_v22_Apparatus")
                struct.pack_into("<3f", b["payload"], ob_layout["loc"][0], 0.0, 0.0, 0.0)
            elif ob_n in ref_to_locator:
                new_n, b_loc = ref_to_locator[ob_n]
                set_id_name_clean(b, new_n)
                struct.pack_into("<3f", b["payload"], ob_layout["loc"][0], *b_loc)

    uncomp_ref = WORK_DIR / "fight-and-flight-v22-with-spellblade-reference-uncompressed.blend"
    bf.save(str(uncomp_ref))
    c_size = zstd_compress_blend(uncomp_ref.read_bytes(), out_ref_blend_path)
    print(f"[OK] Exported {out_ref_blend_path.name}: {c_size:,} bytes ({c_size/1048576:.2f} MB), SHA256={hashlib.sha256(out_ref_blend_path.read_bytes()).hexdigest()}")

if __name__ == "__main__":
    generate_faf_textures(WORK_DIR)
    all_meshes = build_all_v2_2_meshes()

    out_glb   = OUT_DIR / "fight-and-flight-v25-review.glb"
    out_blend = OUT_DIR / "fight-and-flight-v25-review.blend"
    out_ref   = OUT_DIR / "fight-and-flight-v25-with-spellblade-reference.blend"

    gltf_meta, glb_sha = export_fight_and_flight_v22_glb(all_meshes, out_glb)
    reopen_and_audit_v22_glb(out_glb)
    export_standalone_v22_blend(all_meshes, out_blend)
    export_fitted_spellblade_v22_reference_blend(all_meshes, out_ref)
    (WORK_DIR / "faf_v24_export_manifest.json").write_text(json.dumps(gltf_meta["extras"], indent=2))
