#!/usr/bin/env python3
"""
Castleward — Part B & Part D: Fight-and-Flight v2.9 Physically Coherent Siege Destruction
& Sheathe-in-Steel Repair Compatibility Package
=========================================================================================
Preserves `fight-and-flight-v28-cockpit-gait-damage.glb` and `.blend` untouched and produces:
  - `fight-and-flight-v29-coherent-destruction.glb` (67 nodes, 44 meshes, 47 animation clips)
  - `fight-and-flight-v29-coherent-destruction.blend`

Implements all requirements in Part B (B1–B6), Part D, and Part E:
  - B1 & Part D (Component-Specific & Additive Damage + Repair Coexistence):
      * `Clip 35: Damage_Comp_Brace_L_Looseness_And_Flex` (1.20s loop, additive/blendable for L-Brace > 0 HP)
      * `Clip 36: Damage_Comp_Brace_L_Broken_ZeroHP` (0.80s one-shot + permanent hold for L-Brace == 0 HP)
      * `Clip 37: Damage_Comp_Brace_R_Looseness_And_Flex` (1.20s loop, additive/blendable for R-Brace > 0 HP)
      * `Clip 38: Damage_Comp_Brace_R_Broken_ZeroHP` (0.80s one-shot + permanent hold for R-Brace == 0 HP)
      * `Clip 39: Damage_Comp_Rotor_Wobble_And_Vibration` (1.00s loop, additive/blendable for Rotor > 0 HP)
      * `Clip 40: Damage_Comp_Chassis_Buckle_And_Compression` (1.40s loop, hull-only compression/smoke without breaking rotor!)
  - B2 (Rotor Failure vs. Whole-Machine Destruction):
      * `Clip 41: Damage_Comp_Rotor_ZeroHP_Decay_And_Windmill` (2.40s one-shot + hold: rotor thrust lost,
        inertia decays from 3.5 rev/s to slow windmill stall, shaft droops +18.5 deg, while chassis & legs
        remain upright and operable for landing/ground movement!)
  - B3 (Airborne Destruction Sequence — Local-Space, Simulation-Driven Trajectory):
      * `Clip 42: Destruction_Airborne_01_Break_And_Shudder` (0.65s one-shot entry: violent shudder, thrust loss, inertia spin)
      * `Clip 43: Destruction_Airborne_02_Falling_Wreck_Loop` (1.00s loop: windmilling rotor, trailing banner, flailing braces/legs)
      * `Clip 44: Destruction_Airborne_03_Ground_Impact_To_Ruined_Rest` (1.20s one-shot impact compression -> bounce -> ruined rest)
  - B4 (Pilot Fate & Ejection Clearance — Zero Baked Operator):
      * `Clip 45: Operator_Release_Harness_Open_And_Clearance` (0.75s one-shot: braces flare outward ±28 deg,
        rotor mast pitches AFT -22 deg away from exit corridor, crossbow swings clear +42 deg, so escaping/surviving/dying
        pilot never clips collapsing beams!)
  - B5 & B6 (Improved Recognizable Final Wreck & Valkyrie Dive Terminal Transition):
      * Refined `Clip 34: Damage_Stage_3_Collapsed_Harness_And_Grounded_Wreck` (2.00s: stable ground contact, compact footprint)
      * `Clip 46: Destruction_Valkyrie_Dive_Terminal_Shatter_And_Ruin` (1.50s one-shot high-energy dive detonation ruin)
"""
import os, sys, io, json, math, struct, shutil, hashlib
from pathlib import Path
import numpy as np

ROOT = Path("/working_dir/c_63a1f8c151a6582d")
OUT_DIR = ROOT / "artifacts/file_generation/ttl=63d/output"
WORK_DIR = Path("/tmp/faf_work")

sys.path.insert(0, str(WORK_DIR))
sys.path.insert(0, str(OUT_DIR))
sys.path.insert(0, "/tmp/sofist_v2_1")

from export_fight_and_flight_v25 import quat_from_euler_xyz, ensure_quat_continuity
from faf_v27_halo_dash_dive import _smoothstep
import build_faf_v28_cockpit_gait_damage as b28_faf
_orig_v28_faf_clips = b28_faf.build_additional_v28_faf_clips


def build_v29_coherent_faf_clips():
    """
    Returns the complete list of v2.8 clips (Clips 26..35, with Clip 35 refined for B4/B5 pilot
    clearance and stable ground contact) PLUS 12 new v2.9 clips (Clips 36..47, 0-indexed 35..46)
    covering B1, B2, B3, B4, B5, B6, and Part D.
    """
    base_clips = _orig_v28_faf_clips()
    # Strip rotor/halo nodes (8, 9, 61, 62) from Gait_01..04 so Ground Gaits are 100% disjoint
    # from Rotor_Spin_Cycle_1Rev (Nodes 5,6,7,9,61..64) and Damage_Comp_Rotor_Wobble_And_Vibration (Nodes 8,10,11,65)!
    for gc in base_clips:
        if gc["name"].startswith("Gait_"):
            for r_node in (8, 9, 61, 62):
                gc["tracks"].pop(r_node, None)

    # Refine `Damage_Stage_3_Collapsed_Harness_And_Grounded_Wreck` (Clip index 34) so that:
    # 1. During initial collapse (u = 0.00..0.32), braces flare OUTWARD and shaft tilts AFT-RIGHT first
    #    so an escaping/dismounting pilot in the central/front corridor is 100% clear (B4).
    # 2. The final settled wreck (u = 0.68..1.00) rests cleanly on Y >= 0.00m with a compact 1.85m x 1.72m
    #    footprint, recognizable sword-rotor, crossbow, crimson trident banner, and folded exoskeleton legs (B5).
    for c in base_clips:
        if c["name"] == "Damage_Stage_3_Collapsed_Harness_And_Grounded_Wreck":
            N_d3 = 49
            T_d3 = 2.00
            times_d3 = [round(i * (T_d3 / (N_d3 - 1)), 4) for i in range(N_d3)]
            trk = {k: {"translation": [], "rotation": [], "scale": []} for k in [1, 2, 3, 8, 9, 10, 11, 16, 17, 18, 19, 20, 21, 22, 26, 27, 28, 47, 48, 50, 51, 61, 62, 63, 64, 66]}
            for i in range(N_d3):
                u = i / float(N_d3 - 1)
                # Phase 1 (0..0.28): Harness release & structural snap (pilot exit corridor clear!)
                # Phase 2 (0.28..0.62): Progressive gravity collapse & leg buckling
                # Phase 3 (0.62..0.78): Ground impact & secondary timber/iron settle bounce
                # Phase 4 (0.78..1.00): Persistent recognizable grounded wreck rest pose
                c_fall = _smoothstep(0.12, 0.58, u)
                bounce = math.sin((u - 0.58) / 0.18 * math.pi) * 0.045 if 0.58 <= u <= 0.76 else 0.0
                c_settle = c_fall - bounce

                # Node 1: Main_Apparatus_Chassis settles at dy = -0.54m (resting on buckled legs & lower frame),
                # pitched +24 deg forward-right and rolled +16 deg so harness, gearbox & banner remain clearly recognizable!
                trk[1]["translation"].append([round(0.06 * c_settle, 4), round(-0.54 * c_settle, 4), round(0.05 * c_settle, 4)])
                trk[1]["rotation"].append(quat_from_euler_xyz(24.0 * c_settle, 11.0 * c_settle, 16.0 * c_settle))
                trk[1]["scale"].append([1.0, 1.0, 1.0])

                # Intact braces hide at u >= 0.14; damaged braces (47, 48) splay outward (clearing pilot corridor!)
                intact_s = [1.0, 1.0, 1.0] if u < 0.14 else [0.001, 0.001, 0.001]
                dmg_s    = [0.001, 0.001, 0.001] if u < 0.14 else [1.0, 1.0, 1.0]
                for bn in (2, 3):
                    trk[bn]["translation"].append([0.0, 0.0, 0.0])
                    trk[bn]["rotation"].append([0.0, 0.0, 0.0, 1.0])
                    trk[bn]["scale"].append(intact_s)

                trk[47]["translation"].append([round(0.455 + 0.095 * c_settle, 4), round(1.28 - 0.11 * c_settle, 4), 0.05])
                trk[47]["rotation"].append(quat_from_euler_xyz(12.0 * c_settle, 18.0 * c_settle, -34.0 * c_settle))
                trk[47]["scale"].append(dmg_s)

                trk[48]["translation"].append([round(-0.455 - 0.095 * c_settle, 4), round(1.28 - 0.11 * c_settle, 4), 0.05])
                trk[48]["rotation"].append(quat_from_euler_xyz(14.0 * c_settle, -18.0 * c_settle, 36.0 * c_settle))
                trk[48]["scale"].append(dmg_s)

                # Node 8: Rotor_Shaft_And_Bearing droops +34 deg sideways-aft-right (never sweeping through front pilot exit!)
                trk[8]["translation"].append([round(0.03 * c_settle, 4), round(1.985 - 0.12 * c_settle, 4), round(-0.025 - 0.04 * c_settle, 4)])
                trk[8]["rotation"].append(quat_from_euler_xyz(-18.0 * c_settle, 14.0 * c_settle, -34.0 * c_settle))
                trk[8]["scale"].append([1.0, 1.0, 1.0])

                # Node 9: Rotor_Hub slows from 1.2 rev to rest at 205 deg
                ang_hub = 205.0 * (1.0 - (1.0 - min(1.0, u / 0.68)) ** 2.2)
                trk[9]["translation"].append([0.0, 0.2, 0.0])
                trk[9]["rotation"].append(quat_from_euler_xyz(8.0 * c_settle, ang_hub, -10.0 * c_settle))
                trk[9]["scale"].append([1.0, 1.0, 1.0])

                # Node 10 (Blade L splits into stump Node 27 + grounded broken blade Node 28 at u >= 0.22)
                b_split = u >= 0.22
                trk[10]["translation"].append([0.0, 0.0, 0.0])
                trk[10]["rotation"].append(quat_from_euler_xyz(0.0, 0.0, -14.0 * c_settle))
                trk[10]["scale"].append([0.001, 0.001, 0.001] if b_split else [1.0, 1.0, 1.0])

                trk[11]["translation"].append([0.0, 0.0, 0.0])
                trk[11]["rotation"].append(quat_from_euler_xyz(6.0 * c_settle, 0.0, 22.0 * c_settle))
                trk[11]["scale"].append([1.0, 1.0, 1.0])

                trk[26]["translation"].append([0.0, 0.2, 0.0])
                trk[26]["rotation"].append([0.0, 0.0, 0.0, 1.0])
                trk[26]["scale"].append(dmg_s)

                trk[27]["translation"].append([0.0, 0.0, 0.0])
                trk[27]["rotation"].append([0.0, 0.0, 0.0, 1.0])
                trk[27]["scale"].append([1.0, 1.0, 1.0] if b_split else [0.001, 0.001, 0.001])

                # Node 28: Detached Sword-Rotor Blade Segment lands and rests recognizably beside the wreck at Y=0.58m local (world Y~0.04m)
                u_b = _smoothstep(0.22, 0.68, u)
                trk[28]["translation"].append([round(0.44 + 0.38 * u_b, 4), round(2.185 - 1.58 * u_b, 4), round(-0.025 + 0.36 * u_b, 4)])
                trk[28]["rotation"].append(quat_from_euler_xyz(76.0 * u_b, 28.0 * u_b, -54.0 * u_b))
                trk[28]["scale"].append([1.0, 1.0, 1.0] if b_split else [0.001, 0.001, 0.001])

                # Node 16: Crimson Trident Banner drapes over the rear gearbox
                trk[16]["translation"].append([0.0, 1.48, -0.635])
                trk[16]["rotation"].append(quat_from_euler_xyz(-28.0 * c_settle, 8.0 * c_settle, -12.0 * c_settle))
                trk[16]["scale"].append([1.0, 1.0, 1.0])

                # Exoskeleton legs (Nodes 17..22) fold into a grounded kneeling/splayed wreck support posture
                trk[17]["translation"].append([0.435, 0.92, -0.01])
                trk[17]["rotation"].append(quat_from_euler_xyz(-64.0 * c_settle, 14.0 * c_settle, 18.0 * c_settle))
                trk[17]["scale"].append([1.0, 1.0, 1.0])

                trk[18]["translation"].append([-0.435, 0.92, -0.01])
                trk[18]["rotation"].append(quat_from_euler_xyz(-54.0 * c_settle, -16.0 * c_settle, -22.0 * c_settle))
                trk[18]["scale"].append([1.0, 1.0, 1.0])

                trk[19]["translation"].append([0.0, -0.43, 0.02])
                trk[19]["rotation"].append(quat_from_euler_xyz(82.0 * c_settle, 0.0, 0.0))
                trk[19]["scale"].append([1.0, 1.0, 1.0])

                trk[20]["translation"].append([0.0, -0.43, 0.02])
                trk[20]["rotation"].append(quat_from_euler_xyz(74.0 * c_settle, 0.0, 0.0))
                trk[20]["scale"].append([1.0, 1.0, 1.0])

                trk[21]["translation"].append([-0.115, -0.435, 0.02])
                trk[21]["rotation"].append(quat_from_euler_xyz(-38.0 * c_settle, 0.0, 12.0 * c_settle))
                trk[21]["scale"].append([1.0, 1.0, 1.0])

                trk[22]["translation"].append([0.115, -0.435, 0.02])
                trk[22]["rotation"].append(quat_from_euler_xyz(-36.0 * c_settle, 0.0, -14.0 * c_settle))
                trk[22]["scale"].append([1.0, 1.0, 1.0])

                # Crossbow Gimbal (50) & Cradle (51) list downward-left onto the ground
                trk[50]["translation"].append([0.565, round(1.195 - 0.08 * c_settle, 4), 0.365])
                trk[50]["rotation"].append(quat_from_euler_xyz(18.0 * c_settle, -26.0 * c_settle, -18.0 * c_settle))
                trk[50]["scale"].append([1.0, 1.0, 1.0])

                trk[51]["translation"].append([0.0, 0.095, 0.0])
                trk[51]["rotation"].append(quat_from_euler_xyz(28.0 * c_settle, 0.0, 0.0))
                trk[51]["scale"].append([1.0, 1.0, 1.0])

                for hn in (61, 62, 63, 64):
                    trk[hn]["translation"].append([0.0, 0.0, 0.0])
                    trk[hn]["rotation"].append([0.0, 0.0, 0.0, 1.0])
                    trk[hn]["scale"].append([0.001, 0.001, 0.001])

                smk = 0.90 * math.sin(min(1.0, u / 0.85) * math.pi) + 0.25
                trk[66]["translation"].append([0.0, round(0.16 * u, 4), 0.0])
                trk[66]["rotation"].append(quat_from_euler_xyz(0.0, 140.0 * u, 0.0))
                trk[66]["scale"].append([round(smk, 4)] * 3)

            for k in trk:
                trk[k]["rotation"] = ensure_quat_continuity(trk[k]["rotation"])
            c["times"] = times_d3
            c["tracks"] = trk

    v29_extra_clips = []

    # =========================================================================
    # B1 & PART D: COMPONENT-SPECIFIC & ADDITIVE DAMAGE CLIPS (Clips 36..41)
    # =========================================================================

    # 36 (idx 35): `Damage_Comp_Brace_L_Looseness_And_Flex` (1.20 s, loop, >0 HP repairable)
    N_bl = 25
    T_bl = 1.20
    t_bl = [round(i * (T_bl / (N_bl - 1)), 4) for i in range(N_bl)]
    trk_bl = {2: {"translation": [], "rotation": []}, 40: {"translation": [], "rotation": []}}
    for i in range(N_bl):
        u = i / float(N_bl - 1)
        s2 = math.sin(2.0 * math.pi * u)
        s6 = math.sin(6.0 * math.pi * u)
        trk_bl[2]["translation"].append([round(0.455 + 0.026 + 0.009 * s2, 4), round(1.28 - 0.012 * abs(s2), 4), round(0.05 + 0.006 * s6, 4)])
        trk_bl[2]["rotation"].append(quat_from_euler_xyz(3.5 * s6, 5.2 * s2, -6.5 - 4.2 * abs(s2)))
        trk_bl[40]["translation"].append([round(0.025 + 0.008 * s6, 4), 0.215, 0.035])
        trk_bl[40]["rotation"].append([0.0, 0.0, 0.0, 1.0])
    for k in trk_bl:
        trk_bl[k]["rotation"] = ensure_quat_continuity(trk_bl[k]["rotation"])
    v29_extra_clips.append({"name": "Damage_Comp_Brace_L_Looseness_And_Flex", "times": t_bl, "tracks": trk_bl})

    # 37 (idx 36): `Damage_Comp_Brace_L_Broken_ZeroHP` (0.80 s, one-shot + permanent hold at 0 HP)
    N_bl0 = 17
    T_bl0 = 0.80
    t_bl0 = [round(i * (T_bl0 / (N_bl0 - 1)), 4) for i in range(N_bl0)]
    trk_bl0 = {2: {"translation": [], "rotation": [], "scale": []}, 47: {"translation": [], "rotation": [], "scale": []}}
    for i in range(N_bl0):
        u = i / float(N_bl0 - 1)
        w = _smoothstep(0.0, 0.45, u)
        rattle = math.sin(u * 4.0 * math.pi) * (1.0 - w) * 4.0
        trk_bl0[2]["translation"].append([0.455, 1.28, 0.05])
        trk_bl0[2]["rotation"].append([0.0, 0.0, 0.0, 1.0])
        trk_bl0[2]["scale"].append([0.001, 0.001, 0.001] if u >= 0.08 else [1.0, 1.0, 1.0])
        trk_bl0[47]["translation"].append([round(0.455 + 0.068 * w, 4), round(1.28 - 0.075 * w, 4), 0.05])
        trk_bl0[47]["rotation"].append(quat_from_euler_xyz(9.0 * w + rattle, 14.0 * w, -26.0 * w - rattle))
        trk_bl0[47]["scale"].append([1.0, 1.0, 1.0] if u >= 0.08 else [0.001, 0.001, 0.001])
    for k in trk_bl0:
        trk_bl0[k]["rotation"] = ensure_quat_continuity(trk_bl0[k]["rotation"])
    v29_extra_clips.append({"name": "Damage_Comp_Brace_L_Broken_ZeroHP", "times": t_bl0, "tracks": trk_bl0})

    # 38 (idx 37): `Damage_Comp_Brace_R_Looseness_And_Flex` (1.20 s, loop, >0 HP repairable)
    trk_br = {3: {"translation": [], "rotation": []}, 41: {"translation": [], "rotation": []}}
    for i in range(N_bl):
        u = i / float(N_bl - 1)
        c2 = math.cos(2.0 * math.pi * u)
        s6 = math.sin(6.0 * math.pi * u)
        trk_br[3]["translation"].append([round(-0.455 - 0.026 - 0.009 * c2, 4), round(1.28 - 0.012 * abs(c2), 4), round(0.05 - 0.006 * s6, 4)])
        trk_br[3]["rotation"].append(quat_from_euler_xyz(-3.5 * s6, -5.2 * c2, 6.5 + 4.2 * abs(c2)))
        trk_br[41]["translation"].append([round(-0.025 - 0.008 * s6, 4), 0.215, 0.035])
        trk_br[41]["rotation"].append([0.0, 0.0, 0.0, 1.0])
    for k in trk_br:
        trk_br[k]["rotation"] = ensure_quat_continuity(trk_br[k]["rotation"])
    v29_extra_clips.append({"name": "Damage_Comp_Brace_R_Looseness_And_Flex", "times": t_bl, "tracks": trk_br})

    # 39 (idx 38): `Damage_Comp_Brace_R_Broken_ZeroHP` (0.80 s, one-shot + permanent hold at 0 HP)
    trk_br0 = {3: {"translation": [], "rotation": [], "scale": []}, 48: {"translation": [], "rotation": [], "scale": []}}
    for i in range(N_bl0):
        u = i / float(N_bl0 - 1)
        w = _smoothstep(0.0, 0.45, u)
        rattle = math.sin(u * 4.0 * math.pi) * (1.0 - w) * 4.0
        trk_br0[3]["translation"].append([-0.455, 1.28, 0.05])
        trk_br0[3]["rotation"].append([0.0, 0.0, 0.0, 1.0])
        trk_br0[3]["scale"].append([0.001, 0.001, 0.001] if u >= 0.08 else [1.0, 1.0, 1.0])
        trk_br0[48]["translation"].append([round(-0.455 - 0.068 * w, 4), round(1.28 - 0.075 * w, 4), 0.05])
        trk_br0[48]["rotation"].append(quat_from_euler_xyz(10.0 * w - rattle, -14.0 * w, 28.0 * w + rattle))
        trk_br0[48]["scale"].append([1.0, 1.0, 1.0] if u >= 0.08 else [0.001, 0.001, 0.001])
    for k in trk_br0:
        trk_br0[k]["rotation"] = ensure_quat_continuity(trk_br0[k]["rotation"])
    v29_extra_clips.append({"name": "Damage_Comp_Brace_R_Broken_ZeroHP", "times": t_bl0, "tracks": trk_br0})

    # 40 (idx 39): `Damage_Comp_Rotor_Wobble_And_Vibration` (1.00 s, loop, >0 HP repairable rotor instability)
    # Disjoint from Node 9 (Rotor_Hub) & Nodes 61..64 (Halo) so Rotor_Spin_Cycle_1Rev composes with ZERO conflicts!
    N_rw = 25
    T_rw = 1.00
    t_rw = [round(i * (T_rw / (N_rw - 1)), 4) for i in range(N_rw)]
    trk_rw = {k: {"translation": [], "rotation": [], "scale": []} for k in [8, 10, 11, 65]}
    for i in range(N_rw):
        u = i / float(N_rw - 1)
        s2 = math.sin(2.0 * math.pi * u)
        c2 = math.cos(2.0 * math.pi * u)
        s8 = math.sin(8.0 * math.pi * u)
        trk_rw[8]["translation"].append([round(0.016 * s8, 4), round(1.985 - 0.014 * abs(s2), 4), round(-0.025 + 0.016 * c2, 4)])
        trk_rw[8]["rotation"].append(quat_from_euler_xyz(9.5 * s2, 5.0 * s8, 9.2 * c2))
        trk_rw[8]["scale"].append([1.0, 1.0, 1.0])

        trk_rw[10]["translation"].append([0.0, 0.0, 0.0])
        trk_rw[10]["rotation"].append(quat_from_euler_xyz(3.5 * s8, 0.0, -6.5 - 4.0 * abs(s2)))
        trk_rw[10]["scale"].append([1.0, 1.0, 1.0])

        trk_rw[11]["translation"].append([0.0, 0.0, 0.0])
        trk_rw[11]["rotation"].append(quat_from_euler_xyz(-3.5 * s8, 0.0, 6.5 + 4.0 * abs(c2)))
        trk_rw[11]["scale"].append([1.0, 1.0, 1.0])

        trk_rw[65]["translation"].append([0.0, round(0.04 * abs(s2), 4), 0.0])
        trk_rw[65]["rotation"].append(quat_from_euler_xyz(0.0, 180.0 * u, 0.0))
        trk_rw[65]["scale"].append([round(0.55 + 0.25 * abs(s8), 4)] * 3)
    for k in trk_rw:
        trk_rw[k]["rotation"] = ensure_quat_continuity(trk_rw[k]["rotation"])
    v29_extra_clips.append({"name": "Damage_Comp_Rotor_Wobble_And_Vibration", "times": t_rw, "tracks": trk_rw})

    # 41 (idx 40): `Damage_Comp_Chassis_Buckle_And_Compression` (1.40 s, loop, hull-only — disjoint from Legs 17..22, Gimbal 50, Drive Gears 5..7, and Rotor 8..11!)
    N_cb = 29
    T_cb = 1.40
    t_cb = [round(i * (T_cb / (N_cb - 1)), 4) for i in range(N_cb)]
    trk_cb = {k: {"translation": [], "rotation": [], "scale": []} for k in [1, 4, 66]}
    for i in range(N_cb):
        u = i / float(N_cb - 1)
        s2 = math.sin(2.0 * math.pi * u)
        c2 = math.cos(2.0 * math.pi * u)
        s6 = math.sin(6.0 * math.pi * u)
        # Main chassis sags -0.065m with a compromised +6.5 deg forward buckle and +4.2 deg list
        trk_cb[1]["translation"].append([round(0.012 * s2, 4), round(-0.065 - 0.014 * abs(s2), 4), round(0.015 + 0.008 * c2, 4)])
        trk_cb[1]["rotation"].append(quat_from_euler_xyz(6.5 + 1.8 * s2, 2.2 * c2, 4.2 + 1.5 * s2))
        trk_cb[1]["scale"].append([1.0, 1.0, 1.0])

        # Rear drive housing rattles loosely (leaving Gears 5,6,7 free for Rotor_Spin_Cycle_1Rev!)
        trk_cb[4]["translation"].append([0.0, round(1.32 - 0.022 * abs(s2), 4), round(-0.34 - 0.014 * abs(c2), 4)])
        trk_cb[4]["rotation"].append(quat_from_euler_xyz(-5.5 - 2.5 * s6, 2.2 * s2, 3.0 * c2))
        trk_cb[4]["scale"].append([1.0, 1.0, 1.0])

        trk_cb[66]["translation"].append([0.0, round(0.08 * u, 4), 0.0])
        trk_cb[66]["rotation"].append(quat_from_euler_xyz(0.0, 180.0 * u, 0.0))
        trk_cb[66]["scale"].append([round(0.65 + 0.20 * abs(s2), 4)] * 3)
    for k in trk_cb:
        trk_cb[k]["rotation"] = ensure_quat_continuity(trk_cb[k]["rotation"])
    v29_extra_clips.append({"name": "Damage_Comp_Chassis_Buckle_And_Compression", "times": t_cb, "tracks": trk_cb})

    # =========================================================================
    # B2: ROTOR FAILURE AT ZERO ROTOR HP vs. SURVIVING CHASSIS (Clip 42, idx 41)
    # =========================================================================
    # `Damage_Comp_Rotor_ZeroHP_Decay_And_Windmill` (2.40 s, one-shot + hold)
    # Rotor loses powered flight; inertia decays visibly while shaft droops +18.5 deg and blades
    # windmill to a slow stall, WITHOUT collapsing the main chassis!
    N_rz = 49
    T_rz = 2.40
    t_rz = [round(i * (T_rz / (N_rz - 1)), 4) for i in range(N_rz)]
    trk_rz = {k: {"translation": [], "rotation": [], "scale": []} for k in [8, 9, 10, 11, 26, 61, 62, 63, 64, 65]}
    for i in range(N_rz):
        u = i / float(N_rz - 1)
        w_droop = _smoothstep(0.0, 0.38, u)
        shudder = math.sin(u * 10.0 * math.pi) * math.exp(-3.5 * u)
        # Rotor shaft droops +18.5 deg forward-right and settles
        trk_rz[8]["translation"].append([round(0.018 * w_droop + 0.012 * shudder, 4), round(1.985 - 0.065 * w_droop, 4), round(-0.025 + 0.032 * w_droop, 4)])
        trk_rz[8]["rotation"].append(quat_from_euler_xyz(18.5 * w_droop + 4.5 * shudder, -8.0 * w_droop, -14.0 * w_droop + 5.0 * shudder))
        trk_rz[8]["scale"].append([1.0, 1.0, 1.0])

        # Decaying rotational inertia: 2.8 full revolutions decaying smoothly via (1 - (1 - u)^2.8)
        ang_decay = 1008.0 * (1.0 - (1.0 - u) ** 2.8)
        trk_rz[9]["translation"].append([0.0, 0.2, 0.0])
        trk_rz[9]["rotation"].append(quat_from_euler_xyz(7.5 * math.sin(u * 4.0 * math.pi) * (1.0 - 0.6 * u), ang_decay, -6.5 * w_droop))
        trk_rz[9]["scale"].append([1.0, 1.0, 1.0])

        # Blades droop asymmetrically as centrifugal stiffening decays
        trk_rz[10]["translation"].append([0.0, 0.0, 0.0])
        trk_rz[10]["rotation"].append(quat_from_euler_xyz(4.0 * w_droop, 0.0, -19.5 * w_droop + 3.0 * shudder))
        trk_rz[10]["scale"].append([1.0, 1.0, 1.0])

        trk_rz[11]["translation"].append([0.0, 0.0, 0.0])
        trk_rz[11]["rotation"].append(quat_from_euler_xyz(-5.0 * w_droop, 0.0, 23.5 * w_droop - 3.0 * shudder))
        trk_rz[11]["scale"].append([1.0, 1.0, 1.0])

        # Fractured bearing collar (Node 26) visible once shaft droops
        trk_rz[26]["translation"].append([0.0, 0.2, 0.0])
        trk_rz[26]["rotation"].append([0.0, 0.0, 0.0, 1.0])
        trk_rz[26]["scale"].append([1.0, 1.0, 1.0] if u >= 0.06 else [0.001, 0.001, 0.001])

        # Halo streaks extinguish rapidly in first 0.25s as powered thrust is lost
        h_s = max(0.001, 0.65 * (1.0 - min(1.0, u / 0.18)))
        for hn in (61, 62, 63, 64):
            trk_rz[hn]["translation"].append([0.0, 0.0, 0.0])
            trk_rz[hn]["rotation"].append([0.0, 0.0, 0.0, 1.0])
            trk_rz[hn]["scale"].append([round(h_s, 4)] * 3 if hn in (61, 62) else [0.001, 0.001, 0.001])

        # Bearing smoke plume
        trk_rz[65]["translation"].append([0.0, round(0.12 * u, 4), 0.0])
        trk_rz[65]["rotation"].append(quat_from_euler_xyz(0.0, 220.0 * u, 0.0))
        trk_rz[65]["scale"].append([round(0.85 * math.sin(min(1.0, u / 0.7) * math.pi) + 0.30, 4)] * 3)
    for k in trk_rz:
        trk_rz[k]["rotation"] = ensure_quat_continuity(trk_rz[k]["rotation"])
    v29_extra_clips.append({"name": "Damage_Comp_Rotor_ZeroHP_Decay_And_Windmill", "times": t_rz, "tracks": trk_rz})

    # =========================================================================
    # B3: AIRBORNE DESTRUCTION SEQUENCE (Clips 43, 44, 45 — idxs 42, 43, 44)
    # =========================================================================
    # 1. `Destruction_Airborne_01_Break_And_Shudder` (0.65 s, one-shot local-space break)
    N_ab1 = 21
    T_ab1 = 0.65
    t_ab1 = [round(i * (T_ab1 / (N_ab1 - 1)), 4) for i in range(N_ab1)]
    ab_nodes = [1, 2, 3, 8, 9, 10, 11, 16, 17, 18, 19, 20, 21, 22, 26, 27, 28, 47, 48, 50, 51, 61, 62, 63, 64, 65, 66]
    trk_ab1 = {k: {"translation": [], "rotation": [], "scale": []} for k in ab_nodes}
    for i in range(N_ab1):
        u = i / float(N_ab1 - 1)
        w = _smoothstep(0.0, 0.85, u)
        jolt = math.sin(u * 8.0 * math.pi) * math.exp(-2.2 * u)
        # Local-space violent mechanical break shudder + nose-down/banked falling attitude (NO fixed world-space Y drop!)
        trk_ab1[1]["translation"].append([round(0.045 * jolt, 4), round(0.035 * math.cos(u * 6.0 * math.pi) * (1.0 - 0.5 * u), 4), round(-0.030 * jolt, 4)])
        trk_ab1[1]["rotation"].append(quat_from_euler_xyz(18.0 * w + 9.0 * jolt, -12.0 * w + 6.0 * jolt, 14.0 * w - 8.0 * jolt))
        trk_ab1[1]["scale"].append([1.0, 1.0, 1.0])

        int_s = [1.0, 1.0, 1.0] if u < 0.12 else [0.001, 0.001, 0.001]
        dmg_s = [0.001, 0.001, 0.001] if u < 0.12 else [1.0, 1.0, 1.0]
        for bn in (2, 3):
            trk_ab1[bn]["translation"].append([0.0, 0.0, 0.0])
            trk_ab1[bn]["rotation"].append([0.0, 0.0, 0.0, 1.0])
            trk_ab1[bn]["scale"].append(int_s)

        trk_ab1[47]["translation"].append([round(0.455 + 0.055 * w, 4), round(1.28 - 0.04 * w, 4), 0.05])
        trk_ab1[47]["rotation"].append(quat_from_euler_xyz(8.0 * w, 12.0 * w, -22.0 * w + 6.0 * jolt))
        trk_ab1[47]["scale"].append(dmg_s)

        trk_ab1[48]["translation"].append([round(-0.455 - 0.055 * w, 4), round(1.28 - 0.04 * w, 4), 0.05])
        trk_ab1[48]["rotation"].append(quat_from_euler_xyz(10.0 * w, -12.0 * w, 24.0 * w - 6.0 * jolt))
        trk_ab1[48]["scale"].append(dmg_s)

        # Rotor shaft snaps -20 deg aft-right; rotor loses thrust and windmills through inertia (320 deg)
        trk_ab1[8]["translation"].append([round(0.02 * w, 4), round(1.985 - 0.06 * w, 4), round(-0.025 - 0.03 * w, 4)])
        trk_ab1[8]["rotation"].append(quat_from_euler_xyz(-16.0 * w + 5.0 * jolt, 10.0 * w, -22.0 * w))
        trk_ab1[8]["scale"].append([1.0, 1.0, 1.0])

        trk_ab1[9]["translation"].append([0.0, 0.2, 0.0])
        trk_ab1[9]["rotation"].append(quat_from_euler_xyz(6.0 * jolt, 320.0 * (1.0 - (1.0 - u) ** 1.6), -8.0 * w))
        trk_ab1[9]["scale"].append([1.0, 1.0, 1.0])

        trk_ab1[10]["translation"].append([0.0, 0.0, 0.0])
        trk_ab1[10]["rotation"].append(quat_from_euler_xyz(0.0, 0.0, -14.0 * w))
        trk_ab1[10]["scale"].append(int_s)

        trk_ab1[11]["translation"].append([0.0, 0.0, 0.0])
        trk_ab1[11]["rotation"].append(quat_from_euler_xyz(5.0 * w, 0.0, 16.0 * w + 4.0 * jolt))
        trk_ab1[11]["scale"].append([1.0, 1.0, 1.0])

        trk_ab1[26]["translation"].append([0.0, 0.2, 0.0])
        trk_ab1[26]["rotation"].append([0.0, 0.0, 0.0, 1.0])
        trk_ab1[26]["scale"].append(dmg_s)

        trk_ab1[27]["translation"].append([0.0, 0.0, 0.0])
        trk_ab1[27]["rotation"].append([0.0, 0.0, 0.0, 1.0])
        trk_ab1[27]["scale"].append(dmg_s)

        # Sheared blade segment (28) separates outward-aft in local space
        trk_ab1[28]["translation"].append([round(0.44 + 0.55 * w, 4), round(2.185 + 0.18 * w, 4), round(-0.025 - 0.35 * w, 4)])
        trk_ab1[28]["rotation"].append(quat_from_euler_xyz(45.0 * w, 65.0 * w, -80.0 * w))
        trk_ab1[28]["scale"].append(dmg_s)

        # Banner streams upward (+38 deg) under downward airflow!
        trk_ab1[16]["translation"].append([0.0, 1.48, -0.635])
        trk_ab1[16]["rotation"].append(quat_from_euler_xyz(38.0 * w + 6.0 * jolt, 5.0 * jolt, -8.0 * w))
        trk_ab1[16]["scale"].append([1.0, 1.0, 1.0])

        # Legs dangle loosely beneath the falling harness
        trk_ab1[17]["translation"].append([0.435, 0.92, -0.01])
        trk_ab1[17]["rotation"].append(quat_from_euler_xyz(14.0 * w + 5.0 * jolt, 8.0 * w, 10.0 * w))
        trk_ab1[17]["scale"].append([1.0, 1.0, 1.0])

        trk_ab1[18]["translation"].append([-0.435, 0.92, -0.01])
        trk_ab1[18]["rotation"].append(quat_from_euler_xyz(18.0 * w - 5.0 * jolt, -8.0 * w, -12.0 * w))
        trk_ab1[18]["scale"].append([1.0, 1.0, 1.0])

        for kn in (19, 20):
            trk_ab1[kn]["translation"].append([0.0, -0.43, 0.02])
            trk_ab1[kn]["rotation"].append(quat_from_euler_xyz(24.0 * w + 6.0 * abs(jolt), 0.0, 0.0))
            trk_ab1[kn]["scale"].append([1.0, 1.0, 1.0])
        for fn, fx in [(21, -0.115), (22, 0.115)]:
            trk_ab1[fn]["translation"].append([fx, -0.435, 0.02])
            trk_ab1[fn]["rotation"].append(quat_from_euler_xyz(16.0 * w, 0.0, 0.0))
            trk_ab1[fn]["scale"].append([1.0, 1.0, 1.0])

        trk_ab1[50]["translation"].append([0.565, 1.195, 0.365])
        trk_ab1[50]["rotation"].append(quat_from_euler_xyz(14.0 * w, -22.0 * w + 5.0 * jolt, -12.0 * w))
        trk_ab1[50]["scale"].append([1.0, 1.0, 1.0])

        trk_ab1[51]["translation"].append([0.0, 0.095, 0.0])
        trk_ab1[51]["rotation"].append(quat_from_euler_xyz(20.0 * w, 0.0, 0.0))
        trk_ab1[51]["scale"].append([1.0, 1.0, 1.0])

        for hn in (61, 62, 63, 64):
            trk_ab1[hn]["translation"].append([0.0, 0.0, 0.0])
            trk_ab1[hn]["rotation"].append([0.0, 0.0, 0.0, 1.0])
            trk_ab1[hn]["scale"].append([0.001, 0.001, 0.001])

        for sn in (65, 66):
            trk_ab1[sn]["translation"].append([0.0, round(0.14 * w, 4), 0.0])
            trk_ab1[sn]["rotation"].append(quat_from_euler_xyz(0.0, 160.0 * u, 0.0))
            trk_ab1[sn]["scale"].append([round(0.85 * w + 0.15, 4)] * 3)
    for k in trk_ab1:
        trk_ab1[k]["rotation"] = ensure_quat_continuity(trk_ab1[k]["rotation"])
    v29_extra_clips.append({"name": "Destruction_Airborne_01_Break_And_Shudder", "times": t_ab1, "tracks": trk_ab1})

    # 2. `Destruction_Airborne_02_Falling_Wreck_Loop` (1.00 s, loop while airborne — zero world-space altitude baked!)
    N_ab2 = 25
    T_ab2 = 1.00
    t_ab2 = [round(i * (T_ab2 / (N_ab2 - 1)), 4) for i in range(N_ab2)]
    trk_ab2 = {k: {"translation": [], "rotation": [], "scale": []} for k in ab_nodes}
    for i in range(N_ab2):
        u = i / float(N_ab2 - 1)
        s2 = math.sin(2.0 * math.pi * u)
        c2 = math.cos(2.0 * math.pi * u)
        s4 = math.sin(4.0 * math.pi * u)
        # Falling attitude oscillation around local CoM (simulation controls actual world fall & rotation)
        trk_ab2[1]["translation"].append([round(0.025 * s2, 4), round(0.020 * c2, 4), round(-0.020 * s4, 4)])
        trk_ab2[1]["rotation"].append(quat_from_euler_xyz(18.0 + 4.5 * s2, -12.0 + 5.0 * c2, 14.0 + 4.0 * s4))
        trk_ab2[1]["scale"].append([1.0, 1.0, 1.0])

        for bn in (2, 3, 10, 61, 62, 63, 64):
            trk_ab2[bn]["translation"].append([0.0, 0.0, 0.0])
            trk_ab2[bn]["rotation"].append([0.0, 0.0, 0.0, 1.0])
            trk_ab2[bn]["scale"].append([0.001, 0.001, 0.001])

        trk_ab2[47]["translation"].append([round(0.510 + 0.015 * s4, 4), 1.24, 0.05])
        trk_ab2[47]["rotation"].append(quat_from_euler_xyz(8.0 + 4.0 * s2, 12.0, -22.0 - 6.0 * abs(s4)))
        trk_ab2[47]["scale"].append([1.0, 1.0, 1.0])

        trk_ab2[48]["translation"].append([round(-0.510 - 0.015 * s4, 4), 1.24, 0.05])
        trk_ab2[48]["rotation"].append(quat_from_euler_xyz(10.0 - 4.0 * s2, -12.0, 24.0 + 6.0 * abs(s4)))
        trk_ab2[48]["scale"].append([1.0, 1.0, 1.0])

        trk_ab2[8]["translation"].append([0.02, 1.925, -0.055])
        trk_ab2[8]["rotation"].append(quat_from_euler_xyz(-16.0 + 4.0 * s2, 10.0 + 3.0 * c2, -22.0 + 3.5 * s4))
        trk_ab2[8]["scale"].append([1.0, 1.0, 1.0])

        # Unpowered windmilling rotation (1 full turn per 1.0s loop)
        trk_ab2[9]["translation"].append([0.0, 0.2, 0.0])
        trk_ab2[9]["rotation"].append(quat_from_euler_xyz(6.0 * s2, 360.0 * u, -8.0 + 4.0 * c2))
        trk_ab2[9]["scale"].append([1.0, 1.0, 1.0])

        trk_ab2[11]["translation"].append([0.0, 0.0, 0.0])
        trk_ab2[11]["rotation"].append(quat_from_euler_xyz(5.0 + 3.0 * s4, 0.0, 16.0 + 5.0 * s2))
        trk_ab2[11]["scale"].append([1.0, 1.0, 1.0])

        for dn, dy in [(26, 0.2), (27, 0.0)]:
            trk_ab2[dn]["translation"].append([0.0, dy, 0.0])
            trk_ab2[dn]["rotation"].append([0.0, 0.0, 0.0, 1.0])
            trk_ab2[dn]["scale"].append([1.0, 1.0, 1.0])

        trk_ab2[28]["translation"].append([0.99, 2.365, -0.375])
        trk_ab2[28]["rotation"].append(quat_from_euler_xyz(45.0, 65.0 + 180.0 * u, -80.0))
        trk_ab2[28]["scale"].append([1.0, 1.0, 1.0])

        # Banner streams upward (+44 deg) fluttering in slipstream
        trk_ab2[16]["translation"].append([0.0, 1.48, -0.635])
        trk_ab2[16]["rotation"].append(quat_from_euler_xyz(44.0 + 8.0 * s4, 6.0 * s2, -8.0 + 5.0 * c2))
        trk_ab2[16]["scale"].append([1.0, 1.0, 1.0])

        # Legs flail/trail in slipstream
        trk_ab2[17]["translation"].append([0.435, 0.92, -0.01])
        trk_ab2[17]["rotation"].append(quat_from_euler_xyz(14.0 + 8.0 * s2, 8.0, 10.0 + 4.0 * c2))
        trk_ab2[17]["scale"].append([1.0, 1.0, 1.0])

        trk_ab2[18]["translation"].append([-0.435, 0.92, -0.01])
        trk_ab2[18]["rotation"].append(quat_from_euler_xyz(18.0 - 8.0 * s2, -8.0, -12.0 - 4.0 * c2))
        trk_ab2[18]["scale"].append([1.0, 1.0, 1.0])

        for kn in (19, 20):
            trk_ab2[kn]["translation"].append([0.0, -0.43, 0.02])
            trk_ab2[kn]["rotation"].append(quat_from_euler_xyz(24.0 + 7.0 * abs(s2), 0.0, 0.0))
            trk_ab2[kn]["scale"].append([1.0, 1.0, 1.0])
        for fn, fx in [(21, -0.115), (22, 0.115)]:
            trk_ab2[fn]["translation"].append([fx, -0.435, 0.02])
            trk_ab2[fn]["rotation"].append(quat_from_euler_xyz(16.0 + 5.0 * s4, 0.0, 0.0))
            trk_ab2[fn]["scale"].append([1.0, 1.0, 1.0])

        trk_ab2[50]["translation"].append([0.565, 1.195, 0.365])
        trk_ab2[50]["rotation"].append(quat_from_euler_xyz(14.0 + 5.0 * s4, -22.0 + 6.0 * s2, -12.0))
        trk_ab2[50]["scale"].append([1.0, 1.0, 1.0])

        trk_ab2[51]["translation"].append([0.0, 0.095, 0.0])
        trk_ab2[51]["rotation"].append(quat_from_euler_xyz(20.0 + 4.0 * c2, 0.0, 0.0))
        trk_ab2[51]["scale"].append([1.0, 1.0, 1.0])

        for sn in (65, 66):
            trk_ab2[sn]["translation"].append([0.0, 0.14, 0.0])
            trk_ab2[sn]["rotation"].append(quat_from_euler_xyz(0.0, 360.0 * u, 0.0))
            trk_ab2[sn]["scale"].append([round(0.90 + 0.15 * s4, 4)] * 3)
    for k in trk_ab2:
        trk_ab2[k]["rotation"] = ensure_quat_continuity(trk_ab2[k]["rotation"])
    v29_extra_clips.append({"name": "Destruction_Airborne_02_Falling_Wreck_Loop", "times": t_ab2, "tracks": trk_ab2})

    # 3. `Destruction_Airborne_03_Ground_Impact_To_Ruined_Rest` (1.20 s, one-shot transition from falling posture to ruined rest)
    N_ab3 = 31
    T_ab3 = 1.20
    t_ab3 = [round(i * (T_ab3 / (N_ab3 - 1)), 4) for i in range(N_ab3)]
    trk_ab3 = {k: {"translation": [], "rotation": [], "scale": []} for k in ab_nodes}
    for i in range(N_ab3):
        u = i / float(N_ab3 - 1)
        # Fast ground slam compression (u=0..0.28), rebound bounce (0.28..0.55), settle to exact Stage 3 Wreck pose (0.55..1.00)
        w_imp = _smoothstep(0.0, 0.30, u)
        reb = math.sin((u - 0.30) / 0.25 * math.pi) * 0.065 if 0.30 <= u <= 0.55 else 0.0
        w = w_imp - reb

        trk_ab3[1]["translation"].append([round(0.06 * w, 4), round(-0.54 * w, 4), round(0.05 * w, 4)])
        trk_ab3[1]["rotation"].append(quat_from_euler_xyz(18.0 + 6.0 * w, -12.0 + 23.0 * w, 14.0 + 2.0 * w))
        trk_ab3[1]["scale"].append([1.0, 1.0, 1.0])

        for bn in (2, 3, 10, 61, 62, 63, 64):
            trk_ab3[bn]["translation"].append([0.0, 0.0, 0.0])
            trk_ab3[bn]["rotation"].append([0.0, 0.0, 0.0, 1.0])
            trk_ab3[bn]["scale"].append([0.001, 0.001, 0.001])

        trk_ab3[47]["translation"].append([round(0.510 + 0.040 * w, 4), round(1.24 - 0.07 * w, 4), 0.05])
        trk_ab3[47]["rotation"].append(quat_from_euler_xyz(8.0 + 4.0 * w, 12.0 + 6.0 * w, -22.0 - 12.0 * w))
        trk_ab3[47]["scale"].append([1.0, 1.0, 1.0])

        trk_ab3[48]["translation"].append([round(-0.510 - 0.040 * w, 4), round(1.24 - 0.07 * w, 4), 0.05])
        trk_ab3[48]["rotation"].append(quat_from_euler_xyz(10.0 + 4.0 * w, -12.0 - 6.0 * w, 24.0 + 12.0 * w))
        trk_ab3[48]["scale"].append([1.0, 1.0, 1.0])

        trk_ab3[8]["translation"].append([round(0.02 + 0.01 * w, 4), round(1.925 - 0.06 * w, 4), round(-0.055 - 0.01 * w, 4)])
        trk_ab3[8]["rotation"].append(quat_from_euler_xyz(-16.0 - 2.0 * w, 10.0 + 4.0 * w, -22.0 - 12.0 * w))
        trk_ab3[8]["scale"].append([1.0, 1.0, 1.0])

        ang_stop = 205.0 * (1.0 - (1.0 - min(1.0, u / 0.50)) ** 2.0)
        trk_ab3[9]["translation"].append([0.0, 0.2, 0.0])
        trk_ab3[9]["rotation"].append(quat_from_euler_xyz(8.0 * w, ang_stop, -8.0 - 2.0 * w))
        trk_ab3[9]["scale"].append([1.0, 1.0, 1.0])

        trk_ab3[11]["translation"].append([0.0, 0.0, 0.0])
        trk_ab3[11]["rotation"].append(quat_from_euler_xyz(5.0 + 1.0 * w, 0.0, 16.0 + 6.0 * w))
        trk_ab3[11]["scale"].append([1.0, 1.0, 1.0])

        for dn, dy in [(26, 0.2), (27, 0.0)]:
            trk_ab3[dn]["translation"].append([0.0, dy, 0.0])
            trk_ab3[dn]["rotation"].append([0.0, 0.0, 0.0, 1.0])
            trk_ab3[dn]["scale"].append([1.0, 1.0, 1.0])

        trk_ab3[28]["translation"].append([round(0.99 - 0.17 * w, 4), round(2.365 - 1.76 * w, 4), round(-0.375 + 0.71 * w, 4)])
        trk_ab3[28]["rotation"].append(quat_from_euler_xyz(45.0 + 31.0 * w, 65.0 - 37.0 * w, -80.0 + 26.0 * w))
        trk_ab3[28]["scale"].append([1.0, 1.0, 1.0])

        trk_ab3[16]["translation"].append([0.0, 1.48, -0.635])
        trk_ab3[16]["rotation"].append(quat_from_euler_xyz(44.0 - 72.0 * w, 8.0 * w, -8.0 - 4.0 * w))
        trk_ab3[16]["scale"].append([1.0, 1.0, 1.0])

        trk_ab3[17]["translation"].append([0.435, 0.92, -0.01])
        trk_ab3[17]["rotation"].append(quat_from_euler_xyz(14.0 - 78.0 * w, 8.0 + 6.0 * w, 10.0 + 8.0 * w))
        trk_ab3[17]["scale"].append([1.0, 1.0, 1.0])

        trk_ab3[18]["translation"].append([-0.435, 0.92, -0.01])
        trk_ab3[18]["rotation"].append(quat_from_euler_xyz(18.0 - 72.0 * w, -8.0 - 8.0 * w, -12.0 - 10.0 * w))
        trk_ab3[18]["scale"].append([1.0, 1.0, 1.0])

        trk_ab3[19]["translation"].append([0.0, -0.43, 0.02])
        trk_ab3[19]["rotation"].append(quat_from_euler_xyz(24.0 + 58.0 * w, 0.0, 0.0))
        trk_ab3[19]["scale"].append([1.0, 1.0, 1.0])

        trk_ab3[20]["translation"].append([0.0, -0.43, 0.02])
        trk_ab3[20]["rotation"].append(quat_from_euler_xyz(24.0 + 50.0 * w, 0.0, 0.0))
        trk_ab3[20]["scale"].append([1.0, 1.0, 1.0])

        trk_ab3[21]["translation"].append([-0.115, -0.435, 0.02])
        trk_ab3[21]["rotation"].append(quat_from_euler_xyz(16.0 - 54.0 * w, 0.0, 12.0 * w))
        trk_ab3[21]["scale"].append([1.0, 1.0, 1.0])

        trk_ab3[22]["translation"].append([0.115, -0.435, 0.02])
        trk_ab3[22]["rotation"].append(quat_from_euler_xyz(16.0 - 52.0 * w, 0.0, -14.0 * w))
        trk_ab3[22]["scale"].append([1.0, 1.0, 1.0])

        trk_ab3[50]["translation"].append([0.565, round(1.195 - 0.08 * w, 4), 0.365])
        trk_ab3[50]["rotation"].append(quat_from_euler_xyz(14.0 + 4.0 * w, -22.0 - 4.0 * w, -12.0 - 6.0 * w))
        trk_ab3[50]["scale"].append([1.0, 1.0, 1.0])

        trk_ab3[51]["translation"].append([0.0, 0.095, 0.0])
        trk_ab3[51]["rotation"].append(quat_from_euler_xyz(20.0 + 8.0 * w, 0.0, 0.0))
        trk_ab3[51]["scale"].append([1.0, 1.0, 1.0])

        for sn in (65, 66):
            trk_ab3[sn]["translation"].append([0.0, round(0.16 * u, 4), 0.0])
            trk_ab3[sn]["rotation"].append(quat_from_euler_xyz(0.0, 140.0 * u, 0.0))
            trk_ab3[sn]["scale"].append([round(0.35 + 0.65 * (1.0 - u), 4)] * 3)
    for k in trk_ab3:
        trk_ab3[k]["rotation"] = ensure_quat_continuity(trk_ab3[k]["rotation"])
    v29_extra_clips.append({"name": "Destruction_Airborne_03_Ground_Impact_To_Ruined_Rest", "times": t_ab3, "tracks": trk_ab3})

    # =========================================================================
    # B4: PILOT RELEASE, HARNESS CLEARANCE & EJECTION COMPATIBILITY (Clip 46, idx 45)
    # =========================================================================
    # `Operator_Release_Harness_Open_And_Clearance` (0.75 s, one-shot / additive)
    # Ensures side braces flare outward ±28 deg, crossbow swings +42 deg outward-left, and rotor mast
    # tilts AFT -22 deg so escaping/surviving/dismounted Spellblade is 100% clear of all beams!
    N_rel = 19
    T_rel = 0.75
    t_rel = [round(i * (T_rel / (N_rel - 1)), 4) for i in range(N_rel)]
    trk_rel = {k: {"translation": [], "rotation": []} for k in [2, 3, 8, 21, 22, 29, 30, 50]}
    for i in range(N_rel):
        u = i / float(N_rel - 1)
        w_open = _smoothstep(0.0, 0.35, u)
        w_ej   = _smoothstep(0.10, 0.85, u)
        # Side braces flare wide open (±28 deg roll, ±0.06m outward)
        trk_rel[2]["translation"].append([round(0.455 + 0.062 * w_open, 4), 1.28, 0.05])
        trk_rel[2]["rotation"].append(quat_from_euler_xyz(0.0, 18.0 * w_open, -28.0 * w_open))

        trk_rel[3]["translation"].append([round(-0.455 - 0.062 * w_open, 4), 1.28, 0.05])
        trk_rel[3]["rotation"].append(quat_from_euler_xyz(0.0, -18.0 * w_open, 28.0 * w_open))

        # Rotor shaft tilts AFT (-22 deg pitch) to open a 100% unobstructed upper-front escape arc
        trk_rel[8]["translation"].append([0.0, 1.985, round(-0.025 - 0.065 * w_open, 4)])
        trk_rel[8]["rotation"].append(quat_from_euler_xyz(-22.0 * w_open, 0.0, 0.0))

        # Crossbow swings outward-left (+42 deg yaw) out of the front exit corridor
        trk_rel[50]["translation"].append([round(0.565 + 0.045 * w_open, 4), 1.195, 0.365])
        trk_rel[50]["rotation"].append(quat_from_euler_xyz(0.0, 42.0 * w_open, 0.0))

        # Sabaton stirrups pitch down (-24 deg) to release the pilot's boots cleanly
        trk_rel[21]["translation"].append([-0.115, -0.435, 0.02])
        trk_rel[21]["rotation"].append(quat_from_euler_xyz(24.0 * w_open, 0.0, 0.0))
        trk_rel[22]["translation"].append([0.115, -0.435, 0.02])
        trk_rel[22]["rotation"].append(quat_from_euler_xyz(24.0 * w_open, 0.0, 0.0))

        # Operator root anchor (Node 29) & waist anchor (Node 30) translate along the safe forward-upward release trajectory
        trk_rel[29]["translation"].append([0.0, round(0.42 * math.sin(w_ej * math.pi * 0.75), 4), round(0.68 * w_ej, 4)])
        trk_rel[29]["rotation"].append(quat_from_euler_xyz(12.0 * math.sin(w_ej * math.pi), 0.0, 0.0))
        trk_rel[30]["translation"].append([0.0, 0.965, -0.015])
        trk_rel[30]["rotation"].append([0.0, 0.0, 0.0, 1.0])
    for k in trk_rel:
        trk_rel[k]["rotation"] = ensure_quat_continuity(trk_rel[k]["rotation"])
    v29_extra_clips.append({"name": "Operator_Release_Harness_Open_And_Clearance", "times": t_rel, "tracks": trk_rel})

    # =========================================================================
    # B6: VALKYRIE DIVE TERMINAL DETONATION & CRATERED RUIN (Clip 47, idx 46)
    # =========================================================================
    # `Destruction_Valkyrie_Dive_Terminal_Shatter_And_Ruin` (1.50 s, one-shot terminal impact -> cratered ruin)
    N_vd = 37
    T_vd = 1.50
    t_vd = [round(i * (T_vd / (N_vd - 1)), 4) for i in range(N_vd)]
    trk_vd = {k: {"translation": [], "rotation": [], "scale": []} for k in ab_nodes}
    for i in range(N_vd):
        u = i / float(N_vd - 1)
        w_blast = _smoothstep(0.0, 0.22, u)
        shock = math.sin(u * 6.0 * math.pi) * math.exp(-3.2 * u)
        w_settle = _smoothstep(0.0, 0.55, u)

        # High-energy nose-in cratered chassis ruin (dy = -0.62m, pitched +52 deg forward-down into impact crater)
        trk_vd[1]["translation"].append([round(-0.08 * w_settle, 4), round(-0.62 * w_settle + 0.08 * abs(shock), 4), round(0.14 * w_settle, 4)])
        trk_vd[1]["rotation"].append(quat_from_euler_xyz(52.0 * w_settle + 12.0 * shock, -18.0 * w_settle, -24.0 * w_settle))
        trk_vd[1]["scale"].append([1.0, 1.0, 1.0])

        for bn in (2, 3, 10, 61, 62, 63, 64):
            trk_vd[bn]["translation"].append([0.0, 0.0, 0.0])
            trk_vd[bn]["rotation"].append([0.0, 0.0, 0.0, 1.0])
            trk_vd[bn]["scale"].append([0.001, 0.001, 0.001])

        # Side braces blown wide open by terminal detonation
        trk_vd[47]["translation"].append([round(0.455 + 0.16 * w_blast, 4), round(1.28 - 0.18 * w_settle, 4), round(0.05 + 0.08 * w_blast, 4)])
        trk_vd[47]["rotation"].append(quat_from_euler_xyz(24.0 * w_settle, 32.0 * w_blast, -52.0 * w_blast))
        trk_vd[47]["scale"].append([1.0, 1.0, 1.0])

        trk_vd[48]["translation"].append([round(-0.455 - 0.16 * w_blast, 4), round(1.28 - 0.18 * w_settle, 4), round(0.05 + 0.08 * w_blast, 4)])
        trk_vd[48]["rotation"].append(quat_from_euler_xyz(26.0 * w_settle, -32.0 * w_blast, 54.0 * w_blast))
        trk_vd[48]["scale"].append([1.0, 1.0, 1.0])

        # Dorsal rotor mast snaps violently forward (+48 deg) from dive momentum
        trk_vd[8]["translation"].append([round(-0.04 * w_settle, 4), round(1.985 - 0.22 * w_settle, 4), round(-0.025 + 0.18 * w_settle, 4)])
        trk_vd[8]["rotation"].append(quat_from_euler_xyz(48.0 * w_blast, -16.0 * w_settle, 28.0 * w_settle))
        trk_vd[8]["scale"].append([1.0, 1.0, 1.0])

        trk_vd[9]["translation"].append([0.0, 0.2, 0.0])
        trk_vd[9]["rotation"].append(quat_from_euler_xyz(14.0 * w_settle, 145.0 * w_blast, -18.0 * w_settle))
        trk_vd[9]["scale"].append([1.0, 1.0, 1.0])

        trk_vd[11]["translation"].append([0.0, 0.0, 0.0])
        trk_vd[11]["rotation"].append(quat_from_euler_xyz(-12.0 * w_settle, 0.0, 32.0 * w_settle))
        trk_vd[11]["scale"].append([1.0, 1.0, 1.0])

        for dn, dy in [(26, 0.2), (27, 0.0)]:
            trk_vd[dn]["translation"].append([0.0, dy, 0.0])
            trk_vd[dn]["rotation"].append([0.0, 0.0, 0.0, 1.0])
            trk_vd[dn]["scale"].append([1.0, 1.0, 1.0])

        # Detached blade (28) skids forward-right across the ground
        trk_vd[28]["translation"].append([round(0.44 + 0.62 * w_settle, 4), round(2.185 - 1.48 * w_settle, 4), round(-0.025 + 0.54 * w_settle, 4)])
        trk_vd[28]["rotation"].append(quat_from_euler_xyz(68.0 * w_settle, 42.0 * w_settle, -72.0 * w_settle))
        trk_vd[28]["scale"].append([1.0, 1.0, 1.0])

        trk_vd[16]["translation"].append([0.0, 1.48, -0.635])
        trk_vd[16]["rotation"].append(quat_from_euler_xyz(-42.0 * w_settle, 12.0 * w_settle, -16.0 * w_settle))
        trk_vd[16]["scale"].append([1.0, 1.0, 1.0])

        # Legs splayed backward-outward from dive impact
        trk_vd[17]["translation"].append([0.435, 0.92, -0.01])
        trk_vd[17]["rotation"].append(quat_from_euler_xyz(-78.0 * w_settle, 24.0 * w_settle, 32.0 * w_settle))
        trk_vd[17]["scale"].append([1.0, 1.0, 1.0])

        trk_vd[18]["translation"].append([-0.435, 0.92, -0.01])
        trk_vd[18]["rotation"].append(quat_from_euler_xyz(-74.0 * w_settle, -26.0 * w_settle, -34.0 * w_settle))
        trk_vd[18]["scale"].append([1.0, 1.0, 1.0])

        for kn in (19, 20):
            trk_vd[kn]["translation"].append([0.0, -0.43, 0.02])
            trk_vd[kn]["rotation"].append(quat_from_euler_xyz(88.0 * w_settle, 0.0, 0.0))
            trk_vd[kn]["scale"].append([1.0, 1.0, 1.0])
        for fn, fx in [(21, -0.115), (22, 0.115)]:
            trk_vd[fn]["translation"].append([fx, -0.435, 0.02])
            trk_vd[fn]["rotation"].append(quat_from_euler_xyz(-42.0 * w_settle, 0.0, 0.0))
            trk_vd[fn]["scale"].append([1.0, 1.0, 1.0])

        trk_vd[50]["translation"].append([0.565, round(1.195 - 0.14 * w_settle, 4), 0.365])
        trk_vd[50]["rotation"].append(quat_from_euler_xyz(32.0 * w_settle, -38.0 * w_settle, -28.0 * w_settle))
        trk_vd[50]["scale"].append([1.0, 1.0, 1.0])

        trk_vd[51]["translation"].append([0.0, 0.095, 0.0])
        trk_vd[51]["rotation"].append(quat_from_euler_xyz(34.0 * w_settle, 0.0, 0.0))
        trk_vd[51]["scale"].append([1.0, 1.0, 1.0])

        for sn in (65, 66):
            trk_vd[sn]["translation"].append([0.0, round(0.24 * u, 4), 0.0])
            trk_vd[sn]["rotation"].append(quat_from_euler_xyz(0.0, 240.0 * u, 0.0))
            trk_vd[sn]["scale"].append([round(1.25 * math.sin(min(1.0, u / 0.65) * math.pi) + 0.35, 4)] * 3)
    for k in trk_vd:
        trk_vd[k]["rotation"] = ensure_quat_continuity(trk_vd[k]["rotation"])
    v29_extra_clips.append({"name": "Destruction_Valkyrie_Dive_Terminal_Shatter_And_Ruin", "times": t_vd, "tracks": trk_vd})


    # =========================================================================
    # REQUIREMENT 2: CONVINCING OFFENSIVE-DASH ATTACK-FLIGHT SILHOUETTE
    # (Coordinated with Codex physical Dash: zero world-space translation baked;
    # genuine +24 deg chassis forward pitch + +14 deg rotor mast tilt = +38 deg thrust vector,
    # overdrive gear-train & rotor/halo reaction, +34.5 deg world rider lean, +64 deg billowing
    # crimson trident banner, readable 3P couched/poised right-hand broadsword, and flare brake on release!)
    # =========================================================================
    def _eval_dash_state(dash_w: float, flare: float, u_phase: float, spin_revs: float):
        s_osc = math.sin(2.0 * math.pi * 2.0 * u_phase) * dash_w
        c_osc = math.cos(2.0 * math.pi * 2.0 * u_phase) * dash_w
        s_flut = math.sin(2.0 * math.pi * 6.0 * u_phase) * dash_w
        st = {}
        # Node 1: Main_Apparatus_Chassis — genuine +24.0 deg forward attack pitch (-10.5 deg braking flare on release), ZERO world X/Z baked!
        st[1] = (
            [0.0, round(0.035 * dash_w - 0.045 * flare + 0.010 * s_osc, 4), 0.0],
            quat_from_euler_xyz(24.0 * dash_w - 10.5 * flare + 1.2 * s_osc, 0.0, 1.5 * c_osc),
            [1.0, 1.0, 1.0],
        )
        # Nodes 2, 3: Side braces tuck aerodynamic (-9.5 deg) during dash, flare wide (+14 deg) during braking recovery
        st[2] = ([0.455, 1.28, 0.05], quat_from_euler_xyz(0.0, -9.5 * dash_w + 14.0 * flare, 0.0), [1.0, 1.0, 1.0])
        st[3] = ([-0.455, 1.28, 0.05], quat_from_euler_xyz(0.0, +9.5 * dash_w - 14.0 * flare, 0.0), [1.0, 1.0, 1.0])

        # Nodes 4, 5, 6, 7: Rear Drive Assembly & Overdrive Gear Train reaction
        st[4] = ([0.0, round(1.32 + 0.006 * s_flut, 4), -0.34], quat_from_euler_xyz(3.5 * dash_w - 2.0 * flare, 0.0, 0.0), [1.0, 1.0, 1.0])
        gear_ang = 360.0 * spin_revs * 0.5
        st[5] = ([0.0, 0.06, -0.08], quat_from_euler_xyz(0.0, 0.0, gear_ang), [1.0, 1.0, 1.0])
        st[6] = ([0.215, -0.20, -0.08], quat_from_euler_xyz(-gear_ang, 0.0, 0.0), [1.0, 1.0, 1.0])
        st[7] = ([-0.215, -0.20, -0.08], quat_from_euler_xyz(+gear_ang, 0.0, 0.0), [1.0, 1.0, 1.0])

        # Node 8: Rotor_Shaft_And_Bearing tilts an additional +14.0 deg forward (+38.0 deg total world thrust vector!) and -8.0 deg aft on brake flare
        st[8] = (
            [0.0, round(1.985 + 0.042 * dash_w - 0.015 * flare, 4), round(-0.025 + 0.115 * dash_w - 0.045 * flare, 4)],
            quat_from_euler_xyz(14.0 * dash_w - 8.0 * flare + 1.0 * s_osc, 0.0, 0.0),
            [1.0, 1.0, 1.0],
        )
        # Node 9: Rotor_Hub spins at high overdrive with +11 deg blade collective bite on Nodes 10, 11
        st[9] = ([0.0, 0.2, 0.0], quat_from_euler_xyz(0.0, 360.0 * spin_revs, 0.0), [1.0, 1.0, 1.0])
        st[10] = ([0.0, 0.0, 0.0], quat_from_euler_xyz(11.0 * dash_w - 5.0 * flare, 0.0, 0.0), [1.0, 1.0, 1.0])
        st[11] = ([0.0, 0.0, 0.0], quat_from_euler_xyz(-11.0 * dash_w + 5.0 * flare, 0.0, 0.0), [1.0, 1.0, 1.0])

        # Nodes 61..64: Golden-Edged Angelic Rotor Halo flares to full brilliance during Dash overdrive!
        h_pri = max(0.001, min(1.0, 0.35 + 0.65 * dash_w))
        h_ang = max(0.001, min(1.0, 0.85 * dash_w))
        for hn in (61, 62):
            st[hn] = ([0.0, 0.0, 0.0], [0.0, 0.0, 0.0, 1.0], [1.0, round(h_pri, 4), 1.0])
        for hn in (63, 64):
            st[hn] = ([0.0, 0.0, 0.0], [0.0, 0.0, 0.0, 1.0], [1.0, round(h_ang, 4), 1.0])

        # Node 16: Rear_Trident_Banner streams nearly horizontally (+64 deg local + 24 deg chassis = 88 deg world!) with slipstream flutter
        st[16] = (
            [0.0, 1.48, -0.635],
            quat_from_euler_xyz(22.0 + 42.0 * dash_w - 18.0 * flare + 6.5 * s_flut, 4.0 * c_osc, 3.5 * s_osc),
            [1.0, 1.0, 1.0],
        )

        # Nodes 17..22: Exoskeleton Legs sweep aft into a dynamic assault tuck (-32 deg thigh, +58 deg knee, +24 deg sabaton), then swing forward (+14 deg) on braking flare!
        th_d = -8.0 * (1.0 - dash_w) - 32.0 * dash_w + 18.0 * flare + 1.5 * s_osc
        sh_d = +16.0 * (1.0 - dash_w) + 58.0 * dash_w - 14.0 * flare + 2.0 * c_osc
        st_d = +6.0 * (1.0 - dash_w) + 24.0 * dash_w - 12.0 * flare
        st[17] = ([0.435, 0.92, -0.01], quat_from_euler_xyz(th_d, 0.0, 0.0), [1.0, 1.0, 1.0])
        st[18] = ([-0.435, 0.92, -0.01], quat_from_euler_xyz(th_d, 0.0, 0.0), [1.0, 1.0, 1.0])
        st[19] = ([0.0, -0.43, 0.02], quat_from_euler_xyz(sh_d, 0.0, 0.0), [1.0, 1.0, 1.0])
        st[20] = ([0.0, -0.43, 0.02], quat_from_euler_xyz(sh_d, 0.0, 0.0), [1.0, 1.0, 1.0])
        st[21] = ([-0.115, -0.435, 0.02], quat_from_euler_xyz(st_d, 0.0, 0.0), [1.0, 1.0, 1.0])
        st[22] = ([0.115, -0.435, 0.02], quat_from_euler_xyz(st_d, 0.0, 0.0), [1.0, 1.0, 1.0])

        # Node 29 (operator_root_anchor) & Node 30: Rider leans forward +10.5 deg inside the +24 deg pitched cage (+34.5 deg total world lean!)
        st[29] = (
            [0.0, round(0.016 * dash_w - 0.012 * flare, 4), round(0.042 * dash_w - 0.018 * flare, 4)],
            quat_from_euler_xyz(10.5 * dash_w - 5.5 * flare + 0.8 * s_osc, 4.0 * dash_w, 0.0),
            [1.0, 1.0, 1.0],
        )
        # Nodes 56, 57, 58, 59: Right-Hand Sword Corridor — readable 3P forward-poised couched attack silhouette!
        st[56] = (
            [-0.281, 1.35, -0.039],
            quat_from_euler_xyz(-38.0 * dash_w + 14.0 * flare, 18.0 * dash_w, -22.0 * dash_w + 8.0 * flare),
            [1.0, 1.0, 1.0],
        )
        st[57] = (
            [-0.084, -0.135, 0.254],
            quat_from_euler_xyz(-22.0 * dash_w + 10.0 * flare, 10.0 * dash_w, -8.0 * dash_w),
            [1.0, 1.0, 1.0],
        )
        st[58] = (
            [round(0.11 - 0.14 * dash_w + 0.04 * flare, 4), round(0.13 + 0.08 * dash_w, 4), round(0.32 + 0.16 * dash_w - 0.06 * flare, 4)],
            quat_from_euler_xyz(-34.0 * dash_w + 12.0 * flare + 1.5 * s_osc, 14.0 * dash_w, -16.0 * dash_w),
            [1.0, 1.0, 1.0],
        )
        st[59] = (
            [round(0.165 - 0.12 * dash_w, 4), round(0.485 + 0.06 * dash_w, 4), round(0.520 + 0.22 * dash_w, 4)],
            [0.0, 0.0, 0.0, 1.0],
            [1.0, 1.0, 1.0],
        )
        return st

    # Build Clip 47 (`Dash_01_Sustained_Attack_Flight_Loop`, 0.80s loop) & Clip 48 (`Dash_02_Release_Flare_Brake_And_Recovery`, 0.70s one-shot)
    dash_nodes = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 16, 17, 18, 19, 20, 21, 22, 29, 56, 57, 58, 59, 61, 62, 63, 64]
    N_dl = 25
    T_dl = 0.80
    t_dl = [round(i * (T_dl / (N_dl - 1)), 4) for i in range(N_dl)]
    trk_dl = {k: {"translation": [], "rotation": [], "scale": []} for k in dash_nodes}
    for i in range(N_dl):
        u = i / float(N_dl - 1)
        st = _eval_dash_state(dash_w=1.0, flare=0.0, u_phase=u, spin_revs=4.0 * u)
        for k in dash_nodes:
            trk_dl[k]["translation"].append(st[k][0])
            trk_dl[k]["rotation"].append(st[k][1])
            trk_dl[k]["scale"].append(st[k][2])
    for k in dash_nodes:
        trk_dl[k]["rotation"] = ensure_quat_continuity(trk_dl[k]["rotation"])
    v29_extra_clips.append({"name": "Dash_01_Sustained_Attack_Flight_Loop", "times": t_dl, "tracks": trk_dl})

    N_dr = 25
    T_dr = 0.70
    t_dr_rel = [round(i * (T_dr / (N_dr - 1)), 4) for i in range(N_dr)]
    trk_dr_rel = {k: {"translation": [], "rotation": [], "scale": []} for k in dash_nodes}
    for i in range(N_dr):
        u = i / float(N_dr - 1)
        dash_w = 1.0 - _smoothstep(0.0, 0.75, u)
        flare = math.sin(min(1.0, u / 0.85) * math.pi)
        st = _eval_dash_state(dash_w=dash_w, flare=flare, u_phase=u, spin_revs=2.0 * (1.0 - (1.0 - u) ** 1.6))
        for k in dash_nodes:
            trk_dr_rel[k]["translation"].append(st[k][0])
            trk_dr_rel[k]["rotation"].append(st[k][1])
            trk_dr_rel[k]["scale"].append(st[k][2])
    for k in dash_nodes:
        trk_dr_rel[k]["rotation"] = ensure_quat_continuity(trk_dr_rel[k]["rotation"])
    v29_extra_clips.append({"name": "Dash_02_Release_Flare_Brake_And_Recovery", "times": t_dr_rel, "tracks": trk_dr_rel})

    return base_clips + v29_extra_clips


def export_faf_v29():
    # Restore untouched v2.8 files from backup if bak exists
    v28_glb = OUT_DIR / "fight-and-flight-v28-cockpit-gait-damage.glb"
    bak_glb = WORK_DIR / "faf_v28.glb.bak"
    if bak_glb.exists():
        v28_glb.write_bytes(bak_glb.read_bytes())

    # Redirect b28_faf output to /tmp/faf_work/faf_v29_stage.glb so we never touch v28_glb
    b28_faf.OUT_DIR = WORK_DIR
    b28_faf.build_additional_v28_faf_clips = build_v29_coherent_faf_clips
    b28_faf.shutil.copy2 = lambda s, d: Path(d).write_bytes(Path(s).read_bytes())
    # Copy fight-and-flight-v27-final.glb/.blend to WORK_DIR if needed by b28_faf
    for fn in ("fight-and-flight-v27-final.glb", "fight-and-flight-v27-final.blend", "fight-and-flight-v27-review.glb"):
        if not (WORK_DIR / fn).exists() and (OUT_DIR / fn).exists():
            (WORK_DIR / fn).write_bytes((OUT_DIR / fn).read_bytes())
    b28_faf.export_faf_v28_cockpit_gait_damage()

    stage_glb = WORK_DIR / "fight-and-flight-v28-cockpit-gait-damage.glb"
    stage_blend = WORK_DIR / "fight-and-flight-v28-cockpit-gait-damage.blend"
    out_v29_glb = OUT_DIR / "fight-and-flight-v29-coherent-destruction.glb"
    out_v29_blend = OUT_DIR / "fight-and-flight-v29-coherent-destruction.blend"
    out_v29_blend.write_bytes(stage_blend.read_bytes())

    # Upgrade Clip 19 (`Posture_12_Offensive_Dash_Entry_Hold_Recovery`) in stage_glb and write ONCE to out_v29_glb
    raw = stage_glb.read_bytes()
    j_len = struct.unpack_from("<I", raw, 12)[0]
    g_json = json.loads(raw[20:20+j_len].decode("utf-8"))
    b_start = 20 + j_len + 8
    bin_chunks = bytearray(raw[b_start:])
    buffer_views = g_json["bufferViews"]
    accessors = g_json["accessors"]

    def _add_bv(raw_bytes: bytes):
        pad = (4 - (len(bin_chunks) % 4)) % 4
        if pad:
            bin_chunks.extend(b"\x00" * pad)
        off = len(bin_chunks)
        bin_chunks.extend(raw_bytes)
        idx = len(buffer_views)
        buffer_views.append({"buffer": 0, "byteOffset": off, "byteLength": len(raw_bytes)})
        return idx

    def _add_acc(bv_idx, comp_type, count, acc_type, mins=None, maxs=None):
        acc = {"bufferView": bv_idx, "componentType": comp_type, "count": count, "type": acc_type}
        if mins is not None:
            acc["min"] = mins
        if maxs is not None:
            acc["max"] = maxs
        idx = len(accessors)
        accessors.append(acc)
        return idx

    dash_nodes = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 16, 17, 18, 19, 20, 21, 22, 29, 56, 57, 58, 59, 61, 62, 63, 64]
    n_dr = 55
    t_dr = [round(1.800 * i / float(n_dr - 1), 5) for i in range(n_dr)]
    trk_c19 = {k: {"translation": [], "rotation": [], "scale": []} for k in dash_nodes}
    # Re-use _eval_dash_state logic for full 1.80s Entry (0..0.38s) -> Attack Hold (0.38..1.15s) -> Flare Brake Recovery (1.15..1.80s)
    all_v29 = build_v29_coherent_faf_clips()
    c_loop = next(c for c in all_v29 if c["name"] == "Dash_01_Sustained_Attack_Flight_Loop")
    for i in range(n_dr):
        t_sec = t_dr[i]
        if t_sec <= 0.38:
            w = t_sec / 0.38
            dash_w = _smoothstep(0.0, 1.0, w) + 0.12 * math.sin(w * math.pi)
            flare = 0.0
        elif t_sec <= 1.15:
            dash_w = 1.0
            flare = 0.0
        else:
            w = (t_sec - 1.15) / 0.65
            dash_w = 1.0 - _smoothstep(0.0, 1.0, w)
            flare = math.sin(w * math.pi)
        u_ph = t_sec / 0.80
        s_osc = math.sin(2.0 * math.pi * 2.0 * u_ph) * dash_w
        c_osc = math.cos(2.0 * math.pi * 2.0 * u_ph) * dash_w
        s_flut = math.sin(2.0 * math.pi * 6.0 * u_ph) * dash_w
        spin_revs = 6.0 * (t_sec / 1.80)

        trk_c19[1]["translation"].append([0.0, round(0.035 * dash_w - 0.045 * flare + 0.010 * s_osc, 4), 0.0])
        trk_c19[1]["rotation"].append(quat_from_euler_xyz(24.0 * dash_w - 10.5 * flare + 1.2 * s_osc, 0.0, 1.5 * c_osc))
        trk_c19[1]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[2]["translation"].append([0.455, 1.28, 0.05])
        trk_c19[2]["rotation"].append(quat_from_euler_xyz(0.0, -9.5 * dash_w + 14.0 * flare, 0.0))
        trk_c19[2]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[3]["translation"].append([-0.455, 1.28, 0.05])
        trk_c19[3]["rotation"].append(quat_from_euler_xyz(0.0, +9.5 * dash_w - 14.0 * flare, 0.0))
        trk_c19[3]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[4]["translation"].append([0.0, round(1.32 + 0.006 * s_flut, 4), -0.34])
        trk_c19[4]["rotation"].append(quat_from_euler_xyz(3.5 * dash_w - 2.0 * flare, 0.0, 0.0))
        trk_c19[4]["scale"].append([1.0, 1.0, 1.0])

        gear_ang = 360.0 * spin_revs * 0.5
        trk_c19[5]["translation"].append([0.0, 0.06, -0.08])
        trk_c19[5]["rotation"].append(quat_from_euler_xyz(0.0, 0.0, gear_ang))
        trk_c19[5]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[6]["translation"].append([0.215, -0.20, -0.08])
        trk_c19[6]["rotation"].append(quat_from_euler_xyz(-gear_ang, 0.0, 0.0))
        trk_c19[6]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[7]["translation"].append([-0.215, -0.20, -0.08])
        trk_c19[7]["rotation"].append(quat_from_euler_xyz(+gear_ang, 0.0, 0.0))
        trk_c19[7]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[8]["translation"].append([0.0, round(1.985 + 0.042 * dash_w - 0.015 * flare, 4), round(-0.025 + 0.115 * dash_w - 0.045 * flare, 4)])
        trk_c19[8]["rotation"].append(quat_from_euler_xyz(14.0 * dash_w - 8.0 * flare + 1.0 * s_osc, 0.0, 0.0))
        trk_c19[8]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[9]["translation"].append([0.0, 0.2, 0.0])
        trk_c19[9]["rotation"].append(quat_from_euler_xyz(0.0, 360.0 * spin_revs, 0.0))
        trk_c19[9]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[10]["translation"].append([0.0, 0.0, 0.0])
        trk_c19[10]["rotation"].append(quat_from_euler_xyz(11.0 * dash_w - 5.0 * flare, 0.0, 0.0))
        trk_c19[10]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[11]["translation"].append([0.0, 0.0, 0.0])
        trk_c19[11]["rotation"].append(quat_from_euler_xyz(-11.0 * dash_w + 5.0 * flare, 0.0, 0.0))
        trk_c19[11]["scale"].append([1.0, 1.0, 1.0])

        h_pri = max(0.001, min(1.0, 0.35 + 0.65 * dash_w))
        h_ang = max(0.001, min(1.0, 0.85 * dash_w))
        for hn in (61, 62):
            trk_c19[hn]["translation"].append([0.0, 0.0, 0.0])
            trk_c19[hn]["rotation"].append([0.0, 0.0, 0.0, 1.0])
            trk_c19[hn]["scale"].append([1.0, round(h_pri, 4), 1.0])
        for hn in (63, 64):
            trk_c19[hn]["translation"].append([0.0, 0.0, 0.0])
            trk_c19[hn]["rotation"].append([0.0, 0.0, 0.0, 1.0])
            trk_c19[hn]["scale"].append([1.0, round(h_ang, 4), 1.0])

        trk_c19[16]["translation"].append([0.0, 1.48, -0.635])
        trk_c19[16]["rotation"].append(quat_from_euler_xyz(22.0 + 42.0 * dash_w - 18.0 * flare + 6.5 * s_flut, 4.0 * c_osc, 3.5 * s_osc))
        trk_c19[16]["scale"].append([1.0, 1.0, 1.0])

        th_d = -8.0 * (1.0 - dash_w) - 32.0 * dash_w + 18.0 * flare + 1.5 * s_osc
        sh_d = +16.0 * (1.0 - dash_w) + 58.0 * dash_w - 14.0 * flare + 2.0 * c_osc
        st_d = +6.0 * (1.0 - dash_w) + 24.0 * dash_w - 12.0 * flare
        for ln, lx in [(17, 0.435), (18, -0.435)]:
            trk_c19[ln]["translation"].append([lx, 0.92, -0.01])
            trk_c19[ln]["rotation"].append(quat_from_euler_xyz(th_d, 0.0, 0.0))
            trk_c19[ln]["scale"].append([1.0, 1.0, 1.0])
        for kn in (19, 20):
            trk_c19[kn]["translation"].append([0.0, -0.43, 0.02])
            trk_c19[kn]["rotation"].append(quat_from_euler_xyz(sh_d, 0.0, 0.0))
            trk_c19[kn]["scale"].append([1.0, 1.0, 1.0])
        for fn, fx in [(21, -0.115), (22, 0.115)]:
            trk_c19[fn]["translation"].append([fx, -0.435, 0.02])
            trk_c19[fn]["rotation"].append(quat_from_euler_xyz(st_d, 0.0, 0.0))
            trk_c19[fn]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[29]["translation"].append([0.0, round(0.016 * dash_w - 0.012 * flare, 4), round(0.042 * dash_w - 0.018 * flare, 4)])
        trk_c19[29]["rotation"].append(quat_from_euler_xyz(10.5 * dash_w - 5.5 * flare + 0.8 * s_osc, 4.0 * dash_w, 0.0))
        trk_c19[29]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[56]["translation"].append([-0.281, 1.35, -0.039])
        trk_c19[56]["rotation"].append(quat_from_euler_xyz(-38.0 * dash_w + 14.0 * flare, 18.0 * dash_w, -22.0 * dash_w + 8.0 * flare))
        trk_c19[56]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[57]["translation"].append([-0.084, -0.135, 0.254])
        trk_c19[57]["rotation"].append(quat_from_euler_xyz(-22.0 * dash_w + 10.0 * flare, 10.0 * dash_w, -8.0 * dash_w))
        trk_c19[57]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[58]["translation"].append([round(0.11 - 0.14 * dash_w + 0.04 * flare, 4), round(0.13 + 0.08 * dash_w, 4), round(0.32 + 0.16 * dash_w - 0.06 * flare, 4)])
        trk_c19[58]["rotation"].append(quat_from_euler_xyz(-34.0 * dash_w + 12.0 * flare + 1.5 * s_osc, 14.0 * dash_w, -16.0 * dash_w))
        trk_c19[58]["scale"].append([1.0, 1.0, 1.0])

        trk_c19[59]["translation"].append([round(0.165 - 0.12 * dash_w, 4), round(0.485 + 0.06 * dash_w, 4), round(0.520 + 0.22 * dash_w, 4)])
        trk_c19[59]["rotation"].append([0.0, 0.0, 0.0, 1.0])
        trk_c19[59]["scale"].append([1.0, 1.0, 1.0])

    for k in dash_nodes:
        trk_c19[k]["rotation"] = ensure_quat_continuity(trk_c19[k]["rotation"])

    t_arr = np.array(t_dr, dtype=np.float32)
    bv_t = _add_bv(t_arr.tobytes())
    acc_t = _add_acc(bv_t, 5126, len(t_arr), "SCALAR", [float(t_arr.min())], [float(t_arr.max())])
    samplers, channels = [], []
    for target_node, trk in trk_c19.items():
        for path_name, vals in trk.items():
            v_arr = np.array(vals, dtype=np.float32)
            bv_v = _add_bv(v_arr.tobytes())
            acc_type = "VEC4" if path_name == "rotation" else "VEC3"
            acc_v = _add_acc(bv_v, 5126, len(v_arr), acc_type)
            s_idx = len(samplers)
            samplers.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
            channels.append({"sampler": s_idx, "target": {"node": int(target_node), "path": path_name}})

    for a_idx, a_obj in enumerate(g_json["animations"]):
        if a_obj["name"] == "Posture_12_Offensive_Dash_Entry_Hold_Recovery":
            g_json["animations"][a_idx] = {"name": "Posture_12_Offensive_Dash_Entry_Hold_Recovery", "samplers": samplers, "channels": channels}

    g_json["buffers"][0]["byteLength"] = len(bin_chunks)
    j_bytes = json.dumps(g_json, separators=(",", ":")).encode("utf-8")
    j_pad = (4 - (len(j_bytes) % 4)) % 4
    if j_pad:
        j_bytes += b" " * j_pad
    b_pad = (4 - (len(bin_chunks) % 4)) % 4
    if b_pad:
        bin_chunks.extend(b"\x00" * b_pad)
    total_len = 12 + 8 + len(j_bytes) + 8 + len(bin_chunks)
    glb_out = bytearray()
    glb_out.extend(struct.pack("<4sII", b"glTF", 2, total_len))
    glb_out.extend(struct.pack("<I4s", len(j_bytes), b"JSON"))
    glb_out.extend(j_bytes)
    glb_out.extend(struct.pack("<I4s", len(bin_chunks), b"BIN\x00"))
    glb_out.extend(bin_chunks)
    out_v29_glb.write_bytes(glb_out)


    sha_glb = hashlib.sha256(out_v29_glb.read_bytes()).hexdigest()
    sha_blend = hashlib.sha256(out_v29_blend.read_bytes()).hexdigest()
    print(f"[OK] Saved {out_v29_glb.name}: {out_v29_glb.stat().st_size:,} bytes, SHA256={sha_glb}")
    print(f"[OK] Saved {out_v29_blend.name}: {out_v29_blend.stat().st_size:,} bytes, SHA256={sha_blend}")


if __name__ == "__main__":
    export_faf_v29()
