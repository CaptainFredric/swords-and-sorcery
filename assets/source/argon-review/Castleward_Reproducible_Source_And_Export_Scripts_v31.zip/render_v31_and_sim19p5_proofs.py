#!/usr/bin/env python3
"""
Renders Sheet 2, Sheet 3, and Showcase Video for Spellblade v3.1 & Fight-and-Flight 19.5° Sim-Trim Dash:
  1. Spellblade_v31_Turnaround_And_Distance_Comparison.jpg (2400x1680 — already rendered)
  2. Spellblade_v31_Armor_Regions_And_Rig_Articulation_Sheet.jpg (2400x1680)
  3. Fight_And_Flight_v30_Sim19p5_InGame_Dash_And_TrackMask_Sheet.jpg (2400x1680)
  4. Castleward_v31_InGame_Review_And_19p5_Dash_Showcase.mp4 (1280x720, 20 fps)
"""
import os, sys, math
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageOps
import imageio

sys.path.insert(0, '/working_dir/c_bc1ba559921be6b9/artifacts/file_generation/ttl=63d/intermediate')
sys.path.insert(0, '/tmp/faf_work')

from gltf_standard_evaluator import StandardGltfEvaluator as _BaseEv, quat_to_mat3
from render_faf_v27_evidence import render_panel as _rp_orig, get_font
from render_v30_and_narrowed_dash_proofs import (
    StandardGltfEvaluator,
    render_scene,
    combine_scenes,
    transform_scene_by_matrix,
    make_translation_yaw_matrix,
    quat_from_euler_xyz,
    make_arena_corridor_scene,
    draw_badge,
)

OUT_DIR = Path("/working_dir/c_63a1f8c151a6582d/artifacts/file_generation/ttl=63d/output")
WORK_DIR = Path("/tmp/faf_work")
SB_IMGS = WORK_DIR / "sb_imgs"

SB_V29_GLB = OUT_DIR / "spellblade-v29-artistic-refinement.glb"
SB_V30_GLB = OUT_DIR / "spellblade-v30-refined-candidate.glb"
SB_V31_GLB = OUT_DIR / "spellblade-v31-ingame-review-candidate.glb"
FAF_30_GLB = OUT_DIR / "fight-and-flight-v30-sim19p5-dash.glb"


def evaluate_sim19p5_dash_multilayer(
    faf_ev: StandardGltfEvaluator,
    sb_ev: StandardGltfEvaluator,
    dash_clip_name: str,
    dash_t: float,
    sim_pitch_deg: float = 19.5,
    sim_shaft_tilt_deg: float = 0.0,
    rotor_spin_t: float = 0.35,
    sword_layer_mode: str = "resting_dash",
    sword_t: float = 0.35,
    zero_hp_braces: bool = False,
    additive_hull_buckle: float = 0.0,
    include_enemy_target: bool = True,
):
    layers = [
        ("Rotor_Spin_Cycle_1Rev", rotor_spin_t, True, 1.0, "override"),
        ("Crossbow_Aim_Traverse_Elevation_Sweep", 0.25, True, 0.35, "override"),
        (dash_clip_name, dash_t, False, 1.0, "override"),
    ]
    if zero_hp_braces:
        layers.append(("Damage_Comp_Brace_L_Broken_ZeroHP", 0.85, False, 1.0, "override"))
        layers.append(("Damage_Comp_Brace_R_Broken_ZeroHP", 0.85, False, 1.0, "override"))
    if additive_hull_buckle > 0.0:
        layers.append(("Damage_Comp_Chassis_Buckle_And_Compression", 0.50, True, additive_hull_buckle, "additive"))

    if sword_layer_mode == "resting_dash":
        layers.append(("Dash_Narrowed_04_Resting_3P_Couched_Sword_Layer", sword_t, True, 1.0, "override"))
        sb_clip = "Spellblade_10_Machine_Offensive_Dash_Posture"
        sb_time = 0.75
    elif sword_layer_mode == "slash_override":
        layers.append(("Sword_Strike_And_Recovery", sword_t, False, 1.0, "override"))
        sb_clip = "Spellblade_06_Sword_Slash_Combo_And_Recovery"
        sb_time = sword_t
    elif sword_layer_mode == "guard_override":
        layers.insert(0, ("Cockpit_1P_Sword_Guard_And_Parry", sword_t, False, 1.0, "override"))
        sb_clip = "Spellblade_04_Crouch_And_Guard"
        sb_time = 0.45
    else:
        sb_clip = "Spellblade_10_Machine_Offensive_Dash_Posture"
        sb_time = 0.75

    node_ov = {
        1: {
            "translation": [0.0, 0.028 * (sim_pitch_deg / 19.5), 0.0],
            "rotation": quat_from_euler_xyz(sim_pitch_deg, 0.0, 0.0),
        },
        8: {
            "translation": [0.0, 1.985, -0.025],
            "rotation": quat_from_euler_xyz(sim_shaft_tilt_deg, 0.0, 0.0),
        },
    }

    orig_n1_t = list(faf_ev.gltf["nodes"][1].get("translation", [0.0, 0.0, 0.0]))
    orig_n1_r = list(faf_ev.gltf["nodes"][1].get("rotation", [0.0, 0.0, 0.0, 1.0]))
    orig_n8_t = list(faf_ev.gltf["nodes"][8].get("translation", [0.0, 1.985, -0.025]))
    orig_n8_r = list(faf_ev.gltf["nodes"][8].get("rotation", [0.0, 0.0, 0.0, 1.0]))
    try:
        faf_ev.gltf["nodes"][1]["translation"] = node_ov[1]["translation"]
        faf_ev.gltf["nodes"][1]["rotation"] = node_ov[1]["rotation"]
        faf_ev.gltf["nodes"][8]["translation"] = node_ov[8]["translation"]
        faf_ev.gltf["nodes"][8]["rotation"] = node_ov[8]["rotation"]
        P, N, T, VC, VM, VE, wm, audit = faf_ev.evaluate_multilayer_scene_meshes(layers)
    finally:
        faf_ev.gltf["nodes"][1]["translation"] = orig_n1_t
        faf_ev.gltf["nodes"][1]["rotation"] = orig_n1_r
        faf_ev.gltf["nodes"][8]["translation"] = orig_n8_t
        faf_ev.gltf["nodes"][8]["rotation"] = orig_n8_r

    sc_faf = (P, N, T, VC, VM, VE)
    ov_closed = {28: {"scale": [1.0, 1.0, 1.0]}, 29: {"scale": [0.0, 0.0, 0.0]}}
    sc_sb_local = sb_ev.evaluate(sb_clip, sb_time, loop=True, node_overrides=ov_closed)
    sc_sb_world = transform_scene_by_matrix(sc_sb_local, wm[1])
    sc_combined = combine_scenes(sc_faf, sc_sb_world)

    if include_enemy_target:
        ov_open = {28: {"scale": [0.0, 0.0, 0.0]}, 29: {"scale": [1.0, 1.0, 1.0]}}
        sc_enemy_local = sb_ev.evaluate("Spellblade_04_Crouch_And_Guard", 0.40, loop=True, node_overrides=ov_open)
        M_enemy = make_translation_yaw_matrix(-0.95, -0.35, 3.60, yaw_deg=165.0)
        sc_enemy_world = transform_scene_by_matrix(sc_enemy_local, M_enemy)
        sc_combined = combine_scenes(sc_combined, sc_enemy_world)

    return sc_combined, audit


def build_sheet_2_articulation_and_mounted_deformation(closeups, sc30, sc31, ev31: StandardGltfEvaluator, faf_ev: StandardGltfEvaluator):
    print("Rendering Sheet 2: Spellblade_v31_Armor_Regions_And_Rig_Articulation_Sheet.jpg ...")
    W, H = 2400, 1680
    sheet = Image.new("RGB", (W, H), (14, 16, 22))
    draw = ImageDraw.Draw(sheet)

    draw.rectangle([0, 0, W, 72], fill=(20, 24, 34))
    draw.line([(0, 72), (W, 72)], fill=(115, 225, 165), width=3)
    draw.text((24, 10), "CASTLEWARD — SPELLBLADE v3.1 ARMOR CLOSE-UPS, SWORD/GUARD POSES & MOUNTED RIG DEFORMATION", fill=(135, 240, 185), font=get_font(20, True))
    draw.text((24, 40), "Row 1: Helmet, Pauldron & Cuirass Close-Ups (Concept | v3.0 | v3.1)  |  Row 2: Sword Slash, High Guard, Cast & Sprint  |  Row 3: Mounted 19.5° Dash & Gait Deformation", fill=(195, 205, 225), font=get_font(12, False))

    xs3 = [16, 812, 1608]
    y1, pw3, ph1 = 86, 776, 512
    for idx in range(3):
        title, sub, ref_path, eye, tgt, fov = closeups[idx]
        x0 = xs3[idx]
        panel = Image.new("RGB", (pw3, ph1 - 46), (18, 21, 28))
        cw = pw3 // 3

        c_im = Image.open(ref_path).convert("RGB")
        c_fit = ImageOps.contain(c_im, (cw - 4, ph1 - 52), method=Image.Resampling.LANCZOS)
        c_bg = Image.new("RGB", (cw - 2, ph1 - 48), (20, 23, 30))
        c_bg.paste(c_fit, ((cw - 2 - c_fit.width) // 2, (ph1 - 48 - c_fit.height) // 2))
        cd = ImageDraw.Draw(c_bg)
        cd.rectangle([4, ph1 - 78, cw - 8, ph1 - 54], fill=(14, 18, 26), outline=(110, 175, 245), width=1)
        cd.text((8, ph1 - 73), "CONCEPT TARGET", fill=(145, 205, 255), font=get_font(11, True))
        panel.paste(c_bg, (1, 1))

        im30 = render_scene(sc30, eye, tgt, cw - 2, ph1 - 48, fov_deg=fov * 0.94)
        d30 = ImageDraw.Draw(im30)
        d30.rectangle([4, ph1 - 78, cw - 8, ph1 - 54], fill=(24, 18, 12), outline=(225, 170, 85), width=1)
        d30.text((8, ph1 - 73), "v3.0 FOUNDATION", fill=(245, 195, 115), font=get_font(11, True))
        panel.paste(im30, (cw + 1, 1))

        im31 = render_scene(sc31, eye, tgt, cw - 2, ph1 - 48, fov_deg=fov * 0.94)
        d31 = ImageDraw.Draw(im31)
        d31.rectangle([4, ph1 - 78, cw - 8, ph1 - 54], fill=(12, 24, 18), outline=(95, 225, 150), width=1)
        d31.text((8, ph1 - 73), "v3.1 CANDIDATE", fill=(125, 245, 175), font=get_font(11, True))
        panel.paste(im31, (2 * cw + 1, 1))

        sheet.paste(panel, (x0, y1 + 46))
        draw_badge(draw, x0, y1, pw3, title.replace("2", "1"), sub, accent=(115, 225, 165))

    xs4 = [16, 612, 1208, 1804]
    y2, y3, pw4, ph23 = 610, 1134, 580, 508
    ov_open   = {28: {"scale": [0.0, 0.0, 0.0]}, 29: {"scale": [1.0, 1.0, 1.0]}}
    ov_closed = {28: {"scale": [1.0, 1.0, 1.0]}, 29: {"scale": [0.0, 0.0, 0.0]}}

    r2_poses = [
        ("Spellblade_06_Sword_Slash_Combo_And_Recovery", 0.34, ov_closed, [-1.55, 1.15, 2.10], [0.0, 0.98, 0.05], 38.0,
         "2A. RIG ARTICULATION: RIGHT-HAND SWORD SLASH (CLIP 06)",
         "Clean open-arch pauldron clearance, coaxial couter/vambrace & fullered broadsword"),
        ("Spellblade_04_Crouch_And_Guard", 0.45, ov_closed, [-1.35, 1.08, 2.15], [0.0, 0.92, 0.05], 38.0,
         "2B. RIG ARTICULATION: CROUCH & HIGH GUARD PARRY (CLIP 04)",
         "Diagonal cross-body broadsword guard; knee poleyns & 3-tier tassets articulate cleanly"),
        ("Spellblade_07_Open_Palm_Sorcery_Cast_And_Release", 0.42, ov_open, [-1.40, 1.12, 2.15], [0.0, 0.96, 0.05], 38.0,
         "2C. RIG ARTICULATION: SPELLS & CHIVALRY CAST (CLIP 07)",
         "Open left palm sorcery rune (Node 29) + lowered right-hand broadsword ready posture"),
        ("Spellblade_03_Run_Cycle", 0.22, ov_closed, [-1.85, 1.02, 1.75], [0.0, 0.90, 0.05], 38.0,
         "2D. RIG ARTICULATION: SPRINT STRIDE DEFORMATION (CLIP 03)",
         "Pelvis/thigh blended weights hinge the 3-tier hip tassets smoothly during high-knee drive"),
    ]
    for idx, (c_name, t_s, ov, eye, tgt, fov, title, sub) in enumerate(r2_poses):
        sc_p = ev31.evaluate(c_name, t_s, loop=True, node_overrides=ov)
        im = render_scene(sc_p, eye, tgt, pw4, ph23 - 46, fov_deg=fov)
        d = ImageDraw.Draw(im)
        d.rectangle([10, ph23 - 80, pw4 - 10, ph23 - 52], fill=(12, 22, 18), outline=(95, 225, 150), width=1)
        d.text((16, ph23 - 74), f"27-Joint Skinning: Zero Self-Intersection | Coaxial Limb & Tasset Deformation", fill=(125, 245, 175), font=get_font(11, True))
        sheet.paste(im, (xs4[idx], y2 + 46))
        draw_badge(draw, xs4[idx], y2, pw4, title, sub, accent=(235, 195, 95))

    arena = make_arena_corridor_scene(-0.35, target_x=-0.95, target_z=3.60)
    sc_m_dash, _ = evaluate_sim19p5_dash_multilayer(
        faf_ev, ev31,
        dash_clip_name="Dash_Narrowed_02_Sustained_Hold_Loop", dash_t=0.40,
        sim_pitch_deg=19.5, sim_shaft_tilt_deg=0.0,
        rotor_spin_t=0.35, sword_layer_mode="resting_dash", sword_t=0.40,
        zero_hp_braces=False, additive_hull_buckle=0.0, include_enemy_target=False
    )
    sc_m_slash, _ = evaluate_sim19p5_dash_multilayer(
        faf_ev, ev31,
        dash_clip_name="Dash_Narrowed_02_Sustained_Hold_Loop", dash_t=0.40,
        sim_pitch_deg=19.5, sim_shaft_tilt_deg=0.0,
        rotor_spin_t=0.35, sword_layer_mode="slash_override", sword_t=0.32,
        zero_hp_braces=False, additive_hull_buckle=0.0, include_enemy_target=False
    )
    P_w, N_w, T_w, VC_w, VM_w, VE_w, wm_w, _ = faf_ev.evaluate_multilayer_scene_meshes([
        ("Gait_02_Balance_Test_Brisk_Stride_5p5_mps", 0.25, True, 1.0, "override"),
        ("Rotor_Spin_Cycle_1Rev", 0.25, True, 1.0, "override"),
        ("Crossbow_Aim_Traverse_Elevation_Sweep", 0.20, True, 0.35, "override"),
    ])
    sc_m_walk = combine_scenes(
        (P_w, N_w, T_w, VC_w, VM_w, VE_w),
        transform_scene_by_matrix(ev31.evaluate("Spellblade_08_Machine_Mounted_Walk_And_Run_Sync", 0.25, node_overrides=ov_closed), wm_w[1])
    )

    r3_panels = [
        (sc_m_dash,  [-1.95, 1.25, 1.65], [0.0, 1.05, 0.08], 37.0,
         "3A. MOUNTED DEFORMATION: 19.5° DASH RIGHT-SIDE TUCK",
         "19.5° sim pitch; -32° tucked thighs, hinged hip tassets, +8.5° lean & couched sword"),
        (sc_m_dash,  [ 1.75, 1.32, 1.65], [0.0, 1.12, 0.12], 37.0,
         "3B. MOUNTED DEFORMATION: LEFT CROSSBOW GRIP & PAULDRON",
         "Closed left gauntlet grips crossbow handle; open-arch pauldron clears left brace"),
        (sc_m_slash, [-1.95, 1.28, 1.65], [0.0, 1.08, 0.08], 37.0,
         "3C. MOUNTED DEFORMATION: MID-DASH SWORD SLASH OVERRIDE",
         "Clip 14 + Spellblade Clip 06 deform cleanly inside the right-hand sword corridor"),
        (sc_m_walk,  [-2.05, 1.18, 1.75], [0.0, 0.96, 0.05], 37.0,
         "3D. MOUNTED DEFORMATION: 5.5 m/s BRISK GROUND STRIDE",
         "Synchronized operator & exoskeleton leg stride; sabatons locked in stirrups"),
    ]
    for idx, (sc_m, eye, tgt, fov, title, sub) in enumerate(r3_panels):
        im = render_scene(combine_scenes(arena, sc_m), eye, tgt, pw4, ph23 - 46, fov_deg=fov)
        d = ImageDraw.Draw(im)
        d.rectangle([10, ph23 - 80, pw4 - 10, ph23 - 52], fill=(12, 22, 18), outline=(95, 225, 150), width=1)
        d.text((16, ph23 - 74), "Mounted Rig Fit Verified: 0.0mm Harness/Brace Clipping", fill=(125, 245, 175), font=get_font(11, True))
        sheet.paste(im, (xs4[idx], y3 + 46))
        draw_badge(draw, xs4[idx], y3, pw4, title, sub, accent=(115, 225, 165))

    out_path = OUT_DIR / "Spellblade_v31_Armor_Regions_And_Rig_Articulation_Sheet.jpg"
    sheet.save(out_path, quality=93)
    print(f"Saved {out_path.name} ({out_path.stat().st_size:,} bytes)")


def build_sheet_3_sim19p5_dash_and_trackmasks(faf_ev: StandardGltfEvaluator, sb_ev: StandardGltfEvaluator):
    print("Rendering Sheet 3: Fight_And_Flight_v30_Sim19p5_InGame_Dash_And_TrackMask_Sheet.jpg ...")
    W, H = 2400, 1680
    sheet = Image.new("RGB", (W, H), (14, 16, 22))
    draw = ImageDraw.Draw(sheet)

    draw.rectangle([0, 0, W, 72], fill=(20, 24, 34))
    draw.line([(0, 72), (W, 72)], fill=(245, 190, 85), width=3)
    draw.text((24, 10), "CASTLEWARD — FIGHT-AND-FLIGHT v3.0 AUTHORITATIVE 19.5° SIM-TRIM DASH & NARROWED TRACK-MASK CONTRACT", fill=(255, 220, 125), font=get_font(19, True))
    draw.text((24, 40), "Aligned with Castleward Simulation's ~19.5° Pre-Steering Dash Trim (Runtime Owns Pitch & Rotor Spin) + Narrowed Dash Clips (49..53) + Spellblade v3.1 Rider", fill=(195, 205, 225), font=get_font(12, False))

    xs = [16, 612, 1208, 1804]
    ys = [86, 610, 1134]
    pw, ph = 580, 508
    arena = make_arena_corridor_scene(-0.35, target_x=-0.95, target_z=3.60)

    CHASE_EYE = [-1.05, 1.48, -2.55]
    CHASE_TGT = [-0.50, 0.92,  3.60]

    r1_specs = [
        ("Dash_Narrowed_01_Entry_Posture", 0.28, 16.5, 0.0, "resting_dash", 0.25,
         "1A. IN-GAME 3P CHASE: NARROWED ENTRY (CLIP 49)",
         "Sim pitches toward 19.5° base trim; target knight ahead-right 100% unobstructed"),
        ("Dash_Narrowed_02_Sustained_Hold_Loop", 0.40, 19.5, 0.0, "resting_dash", 0.40,
         "1B. IN-GAME 3P CHASE: 19.5° PRE-STEERING TRIM (CLIP 50+52)",
         "Authoritative 19.5° sim trim (0° unconditional shaft tilt), streaming banner & couched sword"),
        ("Dash_Narrowed_02_Sustained_Hold_Loop", 0.40, 19.5, 0.0, "slash_override", 0.32,
         "1C. IN-GAME 3P CHASE: MID-DASH SWORD SLASH OVERRIDE",
         "Clip 14 (Sword Slash, Prio 80) overrides Clip 52 (Resting Sword, Prio 30) at 19.5° trim"),
        ("Dash_Narrowed_03_Release_Flare_Recovery", 0.28, -8.5, -3.5, "guard_override", 0.35,
         "1D. IN-GAME 3P CHASE: RELEASE FLARE + GUARD OVERRIDE",
         "Clip 51 Release Flare (-8.5° sim brake) + Clip 26 Guard Override on Nodes [56..59]"),
    ]

    for idx, (d_clip, d_t, p_deg, s_deg, sw_mode, sw_t, title, sub) in enumerate(r1_specs):
        sc_m, audit = evaluate_sim19p5_dash_multilayer(
            faf_ev, sb_ev,
            dash_clip_name=d_clip, dash_t=d_t,
            sim_pitch_deg=p_deg, sim_shaft_tilt_deg=s_deg,
            rotor_spin_t=0.35, sword_layer_mode=sw_mode, sword_t=sw_t,
            zero_hp_braces=False, additive_hull_buckle=0.0, include_enemy_target=True
        )
        sc_full = combine_scenes(arena, sc_m)
        im = render_scene(sc_full, CHASE_EYE, CHASE_TGT, pw, ph - 46, fov_deg=42.0)
        d = ImageDraw.Draw(im)
        d.rectangle([10, ph - 80, pw - 10, ph - 52], fill=(12, 22, 18), outline=(95, 225, 150), width=1)
        d.text((16, ph - 74), f"Sim Pitch: {p_deg:+.1f}° | Active Ch: {len(audit['owned'])} | Conflicts: {len(audit['conflicts'])}", fill=(125, 245, 175), font=get_font(11, True))
        sheet.paste(im, (xs[idx], ys[0] + 46))
        draw_badge(draw, xs[idx], ys[0], pw, title, sub, accent=(245, 195, 95))

    sc_2a, aud_2a = evaluate_sim19p5_dash_multilayer(
        faf_ev, sb_ev,
        dash_clip_name="Dash_Narrowed_02_Sustained_Hold_Loop", dash_t=0.40,
        sim_pitch_deg=19.5, sim_shaft_tilt_deg=0.0,
        rotor_spin_t=0.35, sword_layer_mode="resting_dash", sword_t=0.40,
        zero_hp_braces=True, additive_hull_buckle=0.0, include_enemy_target=False
    )
    im_2a = render_scene(combine_scenes(arena, sc_2a), [-2.15, 1.35, 1.85], [0.0, 1.12, 0.05], pw, ph - 46, fov_deg=38.0)
    d2a = ImageDraw.Draw(im_2a)
    d2a.rectangle([10, ph - 80, pw - 10, ph - 52], fill=(12, 22, 18), outline=(95, 225, 150), width=1)
    d2a.text((16, ph - 74), f"19.5° Sim Trim + 0-HP Broken Braces (Clips 36,38)! Conflicts: {len(aud_2a['conflicts'])}", fill=(125, 245, 175), font=get_font(11, True))
    sheet.paste(im_2a, (xs[0], ys[1] + 46))
    draw_badge(draw, xs[0], ys[1], pw, "2A. 19.5° SIM TRIM + 0-HP BROKEN BRACES (CLIPS 36, 38)",
               "Clip 50 excludes Nodes [1,2,3,8,47,48]; sim owns 19.5° trim & braces stay broken!", accent=(115, 225, 165))

    sc_2b, aud_2b = evaluate_sim19p5_dash_multilayer(
        faf_ev, sb_ev,
        dash_clip_name="Dash_Narrowed_02_Sustained_Hold_Loop", dash_t=0.40,
        sim_pitch_deg=19.5, sim_shaft_tilt_deg=0.0,
        rotor_spin_t=0.35, sword_layer_mode="slash_override", sword_t=0.32,
        zero_hp_braces=True, additive_hull_buckle=1.0, include_enemy_target=False
    )
    im_2b = render_scene(combine_scenes(arena, sc_2b), [-2.15, 1.35, 1.85], [0.0, 1.12, 0.05], pw, ph - 46, fov_deg=38.0)
    d2b = ImageDraw.Draw(im_2b)
    d2b.rectangle([10, ph - 80, pw - 10, ph - 52], fill=(12, 22, 18), outline=(95, 225, 150), width=1)
    d2b.text((16, ph - 74), f"19.5° Sim Trim + Additive Hull (Clip 40) + Slash! Conflicts: {len(aud_2b['conflicts'])}", fill=(125, 245, 175), font=get_font(11, True))
    sheet.paste(im_2b, (xs[1], ys[1] + 46))
    draw_badge(draw, xs[1], ys[1], pw, "2B. 19.5° SIM TRIM + ADDITIVE HULL (CLIP 40) + SLASH",
               "Node 1 receives +19.5° Sim Trim + Additive Clip 40 buckle + Clip 14 Sword Slash", accent=(115, 225, 165))

    sc_2c, aud_2c = evaluate_sim19p5_dash_multilayer(
        faf_ev, sb_ev,
        dash_clip_name="Dash_Narrowed_05_Collision_Interruption_Recovery", dash_t=0.22,
        sim_pitch_deg=-12.0, sim_shaft_tilt_deg=-4.0,
        rotor_spin_t=0.35, sword_layer_mode="guard_override", sword_t=0.40,
        zero_hp_braces=True, additive_hull_buckle=0.8, include_enemy_target=False
    )
    im_2c = render_scene(combine_scenes(arena, sc_2c), [-2.15, 1.35, 1.85], [0.0, 1.12, 0.05], pw, ph - 46, fov_deg=38.0)
    d2c = ImageDraw.Draw(im_2c)
    d2c.rectangle([10, ph - 80, pw - 10, ph - 52], fill=(12, 22, 18), outline=(95, 225, 150), width=1)
    d2c.text((16, ph - 74), f"Clip 53 Collision Recoil: 0.000000 Boundary Delta from Clip 50!", fill=(125, 245, 175), font=get_font(11, True))
    sheet.paste(im_2c, (xs[2], ys[1] + 46))
    draw_badge(draw, xs[2], ys[1], pw, "2C. NARROWED COLLISION INTERRUPTION (CLIP 53 @ t=0.22s)",
               "Seamless transition from Clip 50 on obstacle impact while keeping 0-HP braces broken", accent=(115, 225, 165))

    x2d, y2d = xs[3], ys[1]
    draw_badge(draw, x2d, y2d, pw, "2D. CASTLEWARD ~19.5° SIM-TRIM AUTHORITY CONTRACT",
               "Why Runtime Owns Pitch & Spin While Clips 49..53 Supply Local Posture", accent=(245, 195, 95))
    draw.rectangle([x2d, y2d + 46, x2d + pw, y2d + ph], fill=(18, 21, 30), outline=(65, 78, 98), width=1)
    card_lines = [
        ("1. AUTHORITATIVE SIMULATION DASH TRIM (~19.5° PRE-STEERING):", (125, 245, 175), True),
        ("   Castleward's offensive Dash base trim is ~19.5° before player", (205, 218, 232), False),
        ("   steering modulation (not an unconditional 24° + 14° = 38° tilt).", (205, 218, 232), False),
        ("   Runtime simulation MUST remain 100% authoritative over Node 1", (205, 218, 232), False),
        ("   (Chassis attitude) and Nodes 8, 9 (Rotor shaft & spin RPM).", (205, 218, 232), False),
        ("2. NARROWED RUNTIME DASH CLIPS (Clips 49, 50, 51, 53 — 24 Ch):", (125, 245, 175), True),
        ("   Animate ONLY 8 local nodes [16, 17, 18, 19, 20, 21, 22, 29].", (205, 218, 232), False),
        ("   • ZERO channels on Nodes 0, 1, 8, 9, 5..7, 10..11, 61..64.", (205, 218, 232), False),
        ("   • 0-HP Braces (Clips 36, 38 on [2,47,3,48]) stay broken.", (205, 218, 232), False),
        ("   • Clip 40 Hull Buckle applies ADDITIVELY on Node 1.", (205, 218, 232), False),
        ("3. STANDALONE PREVIEW CLIPS (Clips 19, 47, 48 — 81 Ch):", (245, 195, 115), True),
        ("   Recalibrated to 19.5° trim on Node 1 for single-clip viewers only.", (205, 218, 232), False),
    ]
    cy = y2d + 56
    for txt, col, is_b in card_lines:
        draw.text((x2d + 12, cy), txt, fill=col, font=get_font(12 if is_b else 11, is_b))
        cy += 38 if is_b else 34

    x_tbl, y_tbl, w_tbl, h_tbl = 16, ys[2], W - 32, ph
    draw_badge(draw, x_tbl, y_tbl, w_tbl, "3. EXPLICIT RUNTIME TRACK-MASK, PRIORITY & 19.5° SIMULATION AUTHORITY TABLE (fight-and-flight-v30-sim19p5-dash.glb)",
               "Preserves 100% Runtime Simulation Authority over Pitch (~19.5° pre-steering trim) & Rotor Spin while Composing Damage, Combat & Dash Layers", accent=(115, 225, 165))
    draw.rectangle([x_tbl, y_tbl + 46, x_tbl + w_tbl, y_tbl + h_tbl], fill=(18, 21, 30), outline=(65, 78, 98), width=1)

    matrix_rows = [
        ("LAYER & PRIORITY", "ACTIVE CLIPS / SOURCE", "EXPLICIT NODE TRACK MASK", "BLEND MODE & OVERRIDE / LATCH RULE"),
        ("L0 (Prio 100): Sim Authority", "Castleward Runtime Simulation", "Nodes [0, 1, 8, 9, 5, 6, 7]", "Base Authority: Owns world pos, ~19.5° pre-steering Dash trim (+steering) & rotor RPM"),
        ("L1 (Prio 95): 0-HP Latches", "Clips 36 (L-Brace), 38 (R-Brace), 41 (Rotor)", "Nodes [2, 47, 3, 48, 8..11, 26, 61..65]", "Latched Override at 0 HP: Never overwritten by Dash (Clips 49..53) or Guard"),
        ("L2 (Prio 90): Rotor Halo", "Clip 0 (Rotor_Spin_Cycle_1Rev)", "Nodes [5, 6, 7, 9, 61, 62, 63, 64]", "Override when Rotor > 0 HP (Overridden by Clip 41 when Rotor = 0 HP)"),
        ("L3 (Prio 85): Partial Damage", "Clips 35, 37, 39 (Flex/Wobble) + Clip 40 (Hull)", "Override [2,40,3,41,8,10,11,65,4,66] + ADDITIVE [1]", "Clip 40 MUST use ADDITIVE blend on Node 1 over ~19.5° Sim Pitch or Gait_01..03!"),
        ("L4 (Prio 70): Crossbow Gimbal", "Clips 13 (Aim), 2 (Fire), 3 (Reload)", "Nodes [12..15, 23..25, 43..46, 50..52, 55]", "Override on Crossbow Gimbal & Carousel (Disjoint from Dash & Gait)"),
        ("L5 (Prio 60): Narrowed Dash", "Clips 49 (Entry), 50 (Hold), 51 (Rel), 53 (Hit)", "Nodes [16, 17, 18, 19, 20, 21, 22, 29] (24 ch)", "Override on Banner, Legs & Rider Lean (0.0000 boundary delta; 0 overlap with Sim!)"),
        ("L6 (Prio 30/75/80): 3P Sword", "Clip 52 (Dash P30) < Clip 26 (Guard P75) < Clip 14 (Slash P80)", "Nodes [36, 56, 57, 58, 59] (Mask Clip 26 off [2,3]!)", "Priority Override: Slash (P80) & Guard (P75) cleanly override Dash Sword (P30)"),
    ]
    col_xs = [x_tbl + 16, x_tbl + 410, x_tbl + 980, x_tbl + 1545]
    ry = y_tbl + 58
    for r_idx, row_vals in enumerate(matrix_rows):
        is_hdr = (r_idx == 0)
        if is_hdr:
            draw.rectangle([x_tbl + 8, ry - 4, x_tbl + w_tbl - 8, ry + 32], fill=(28, 36, 50))
        elif r_idx % 2 == 1:
            draw.rectangle([x_tbl + 8, ry - 4, x_tbl + w_tbl - 8, ry + 48], fill=(22, 26, 36))
        for c_idx, val in enumerate(row_vals):
            col = (245, 215, 125) if is_hdr else ((135, 235, 175) if c_idx == 2 else (215, 225, 238))
            draw.text((col_xs[c_idx], ry + 4), val, fill=col, font=get_font(13 if is_hdr else 12, is_hdr or c_idx == 0))
        ry += 44 if is_hdr else 54

    out_path = OUT_DIR / "Fight_And_Flight_v30_Sim19p5_InGame_Dash_And_TrackMask_Sheet.jpg"
    sheet.save(out_path, quality=93)
    print(f"Saved {out_path.name} ({out_path.stat().st_size:,} bytes)")


def build_showcase_video_v31(ev30: StandardGltfEvaluator, ev31: StandardGltfEvaluator, faf_ev: StandardGltfEvaluator):
    print("Rendering Showcase Video: Castleward_v31_InGame_Review_And_19p5_Dash_Showcase.mp4 ...")
    W, H = 1280, 720
    fps = 20
    n_frames = 140
    out_mp4 = OUT_DIR / "Castleward_v31_InGame_Review_And_19p5_Dash_Showcase.mp4"
    tmp_mp4 = WORK_DIR / "Castleward_v31_InGame_Review_And_19p5_Dash_Showcase.mp4"

    ov_open   = {28: {"scale": [0.0, 0.0, 0.0]}, 29: {"scale": [1.0, 1.0, 1.0]}}
    ov_closed = {28: {"scale": [1.0, 1.0, 1.0]}, 29: {"scale": [0.0, 0.0, 0.0]}}
    sc30 = ev30.evaluate(None, 0.0, node_overrides=ov_open)
    sc31 = ev31.evaluate(None, 0.0, node_overrides=ov_open)
    arena = make_arena_corridor_scene(-0.35, target_x=-0.95, target_z=3.60)

    writer = imageio.get_writer(str(tmp_mp4), fps=fps, codec="libx264", quality=8)
    for fi in range(n_frames):
        t_sec = fi / float(fps)
        frame = Image.new("RGB", (W, H), (14, 16, 22))
        draw = ImageDraw.Draw(frame)
        draw.rectangle([0, 0, W, 52], fill=(20, 24, 34))
        draw.line([(0, 52), (W, 52)], fill=(235, 195, 95), width=2)

        if fi < 50:
            ang = 2.0 * math.pi * (fi / 50.0)
            rad = 2.45
            eye = [rad * math.sin(ang), 1.00, rad * math.cos(ang)]
            tgt = [0.0, 0.94, 0.0]
            draw.text((18, 8), "SPELLBLADE TURNAROUND: v3.0 FOUNDATION (LEFT) vs. v3.1 IN-GAME REVIEW CANDIDATE (RIGHT)", fill=(245, 220, 135), font=get_font(15, True))
            draw.text((18, 29), "v3.1 resolves helmet brow/crest silhouette, open-arch 3-tier pauldrons, convex V-keeled cuirass & cool-slate steel (M=0.54, R=0.34)", fill=(190, 205, 225), font=get_font(11, False))

            im_l = render_scene(sc30, eye, tgt, 616, 640, fov_deg=38.0)
            im_r = render_scene(sc31, eye, tgt, 616, 640, fov_deg=38.0)
            frame.paste(im_l, (16, 64))
            frame.paste(im_r, (648, 64))
            draw.rectangle([24, 660, 330, 694], fill=(24, 18, 12), outline=(225, 170, 85), width=1)
            draw.text((34, 669), "v3.0 Foundation (15,874 Tris)", fill=(245, 195, 115), font=get_font(12, True))
            draw.rectangle([656, 660, 1020, 694], fill=(12, 24, 18), outline=(95, 225, 150), width=1)
            draw.text((666, 669), "v3.1 In-Game Review Candidate (15,432 Tris)", fill=(125, 245, 175), font=get_font(12, True))
        elif fi < 90:
            u = (fi - 50) / 40.0
            if u < 0.5:
                sc_act = ev31.evaluate("Spellblade_06_Sword_Slash_Combo_And_Recovery", (u * 2.0) * 0.85, loop=True, node_overrides=ov_closed)
                act_lbl = "Sword Slash Combo (Clip 06) — Pauldron & Coaxial Couter Clearance"
            else:
                sc_act = ev31.evaluate("Spellblade_04_Crouch_And_Guard", ((u - 0.5) * 2.0) * 0.80, loop=True, node_overrides=ov_closed)
                act_lbl = "Crouch & High Guard Parry (Clip 04) — Cross-Body Guard & Knee Poleyn"
            sc_spr = ev31.evaluate("Spellblade_03_Run_Cycle", (u * 1.6) % 0.80, loop=True, node_overrides=ov_closed)

            draw.text((18, 8), f"SPELLBLADE v3.1 RIG ARTICULATION & DEFORMATION — {act_lbl}", fill=(135, 240, 185), font=get_font(15, True))
            draw.text((18, 29), "Coaxial limb rings & blended pelvis/thigh hip-tasset weights prevent clipping across combat and locomotion extremes", fill=(190, 205, 225), font=get_font(11, False))

            im_l = render_scene(sc_act, [-1.45, 1.12, 2.15], [0.0, 0.95, 0.05], 616, 640, fov_deg=38.0)
            im_r = render_scene(sc_spr, [-1.80, 1.02, 1.80], [0.0, 0.92, 0.05], 616, 640, fov_deg=38.0)
            frame.paste(im_l, (16, 64))
            frame.paste(im_r, (648, 64))
            draw.rectangle([24, 660, 480, 694], fill=(12, 24, 18), outline=(95, 225, 150), width=1)
            draw.text((34, 669), act_lbl[:46], fill=(125, 245, 175), font=get_font(12, True))
            draw.rectangle([656, 660, 1140, 694], fill=(12, 24, 18), outline=(235, 195, 95), width=1)
            draw.text((666, 669), "Sprint Cycle (Clip 03) — Blended Pelvis/Thigh Hip Tassets", fill=(245, 215, 125), font=get_font(12, True))
        else:
            u = (fi - 90) / 50.0
            d_time = u * 2.40
            if d_time < 0.38:
                d_clip = "Dash_Narrowed_01_Entry_Posture"
                dt_local = d_time
                w_p = d_time / 0.38
                sim_p, sim_s = 19.5 * w_p, 0.0
                sw_mode, sw_t = "resting_dash", d_time
                phase_lbl = "Phase 1: Narrowed Entry -> 19.5° Sim Trim"
            elif d_time < 1.70:
                d_clip = "Dash_Narrowed_02_Sustained_Hold_Loop"
                dt_local = (d_time - 0.38) % 0.80
                sim_p, sim_s = 19.5, 0.0
                if 0.85 <= d_time <= 1.45:
                    sw_mode, sw_t = "slash_override", (d_time - 0.85) / 0.60 * 0.75
                    phase_lbl = "Phase 2B: 19.5° Sim Trim + Mid-Dash Sword Slash Override!"
                else:
                    sw_mode, sw_t = "resting_dash", dt_local
                    phase_lbl = "Phase 2A: 19.5° Pre-Steering Sim Trim + Couched 3P Sword"
            else:
                d_clip = "Dash_Narrowed_03_Release_Flare_Recovery"
                dt_local = min(0.70, d_time - 1.70)
                w_r = dt_local / 0.70
                flare_w = math.sin(math.pi * w_r)
                sim_p = 19.5 * (1.0 - w_r) - 8.5 * flare_w
                sim_s = -3.5 * flare_w
                sw_mode, sw_t = "guard_override", 0.35
                phase_lbl = "Phase 3: Release Flare (-8.5° Brake) + Guard Override"

            draw.text((18, 8), f"AUTHORITATIVE 19.5° SIM-TRIM IN-GAME 3P CHASE (LEFT) & MOUNTED DEFORMATION (RIGHT) — {phase_lbl}", fill=(245, 220, 135), font=get_font(14, True))
            draw.text((18, 29), "Runtime owns ~19.5° pre-steering trim & rotor spin | 0-HP braces stay broken | Clip 40 Hull is Additive | Slash overrides Clip 52", fill=(190, 205, 225), font=get_font(11, False))

            sc_chase, _ = evaluate_sim19p5_dash_multilayer(
                faf_ev, ev31,
                dash_clip_name=d_clip, dash_t=dt_local,
                sim_pitch_deg=sim_p, sim_shaft_tilt_deg=sim_s,
                rotor_spin_t=(t_sec * 1.8) % 1.0,
                sword_layer_mode=sw_mode, sword_t=sw_t,
                zero_hp_braces=False, additive_hull_buckle=0.0, include_enemy_target=True
            )
            sc_comp, _ = evaluate_sim19p5_dash_multilayer(
                faf_ev, ev31,
                dash_clip_name=d_clip, dash_t=dt_local,
                sim_pitch_deg=sim_p, sim_shaft_tilt_deg=sim_s,
                rotor_spin_t=(t_sec * 1.8) % 1.0,
                sword_layer_mode=sw_mode, sword_t=sw_t,
                zero_hp_braces=True, additive_hull_buckle=0.85, include_enemy_target=False
            )
            im_l = render_scene(combine_scenes(arena, sc_chase), [-1.05, 1.48, -2.55], [-0.50, 0.92, 3.60], 616, 640, fov_deg=42.0)
            im_r = render_scene(combine_scenes(arena, sc_comp),  [-2.05, 1.32,  1.75], [ 0.00, 1.08, 0.08], 616, 640, fov_deg=38.0)
            frame.paste(im_l, (16, 64))
            frame.paste(im_r, (648, 64))
            draw.rectangle([24, 660, 520, 694], fill=(12, 24, 18), outline=(95, 225, 150), width=1)
            draw.text((34, 669), f"In-Game 3P Chase View (Sim Pitch: {sim_p:+.1f}°)", fill=(125, 245, 175), font=get_font(12, True))
            draw.rectangle([656, 660, 1245, 694], fill=(12, 24, 18), outline=(235, 195, 95), width=1)
            draw.text((666, 669), "Mounted v3.1 + 0-HP Broken Braces + Additive Hull + Sword Override", fill=(245, 215, 125), font=get_font(12, True))

        writer.append_data(np.array(frame))
    writer.close()
    out_mp4.write_bytes(tmp_mp4.read_bytes())
    print(f"Saved {out_mp4.name} ({out_mp4.stat().st_size:,} bytes)")


def main():
    ev30 = StandardGltfEvaluator(str(SB_V30_GLB))
    ev31 = StandardGltfEvaluator(str(SB_V31_GLB))
    faf_ev = StandardGltfEvaluator(str(FAF_30_GLB))

    ov_open = {28: {"scale": [0.0, 0.0, 0.0]}, 29: {"scale": [1.0, 1.0, 1.0]}}
    sc30 = ev30.evaluate(None, 0.0, node_overrides=ov_open)
    sc31 = ev31.evaluate(None, 0.0, node_overrides=ov_open)

    closeups = [
        ("2A. HELMET SILHOUETTE: STEPPED V-BROW, FLUSH CHEEKS & PROUD CREST",
         "Fixes v3.0 floating brow/cheek patches; integrates 2-tier brow & taller 7-tuft crest",
         SB_IMGS / "CANONICAL_HELMET_FOCUS_KEEP.png",
         [-0.38, 1.54, 0.86], [0.00, 1.50, 0.02], 31.0),
        ("2B. PAULDRON CONSTRUCTION: OPEN C-ARCH 3-TIER LAMES & REREBRACE",
         "Eliminates v3.0 interior diagonal slab; true open-arch 3-tier lames + brass bicep cuff",
         SB_IMGS / "shoulder.png",
         [-0.72, 1.38, 0.82], [-0.22, 1.24, 0.00], 33.0),
        ("2C. CUIRASS CURVATURE: UNIFIED CONVEX V-KEEL & PLACKART STEP",
         "Eliminates v3.0 split chest patch; continuous convex V-keel + coaxial rib/waist faulds",
         SB_IMGS / "tabard.png",
         [-0.45, 1.28, 1.08], [0.00, 1.18, 0.02], 35.0),
    ]

    build_sheet_2_articulation_and_mounted_deformation(closeups, sc30, sc31, ev31, faf_ev)
    build_sheet_3_sim19p5_dash_and_trackmasks(faf_ev, ev31)
    build_showcase_video_v31(ev30, ev31, faf_ev)
    print("ALL v3.1 & 19.5° SIM-TRIM VISUAL PROOFS COMPLETED SUCCESSFULLY.")


if __name__ == "__main__":
    main()
