#!/usr/bin/env python3
"""
Castleward — Priorities 1, 2, 3 & 4: Fight-and-Flight v2.8 Cockpit Sword/Guard,
Calibrated Mechanical Gait (`3.3`, `5.5`, `9.3 m/s` + Recovery), and Staged Destruction
=======================================================================================
Extends the authored 67-node `fight-and-flight-v27-final.glb` baseline (keeping `v27`
untouched for rollback) into `fight-and-flight-v28-cockpit-gait-damage.glb` and
`fight-and-flight-v28-cockpit-gait-damage.blend` with 35 animation clips:
  - Updates `Node 58 (operator_hand_R_sword_grip)` and `Node 59 (operator_sword_tip_locator)`
    rest and animated trajectories so the player sees a recognizable broadsword at the
    lower-right edge of `Node 37 (operator_first_person_camera)` when mounted, visibly
    sweeping across the cockpit viewport during attacks (`Clip 15`) and raising into a
    readable diagonal ward guard during `Clip 27`.
  - Adds 10 new animation clips (`Clips 26..35`):
      26. `Cockpit_1P_Lowered_Sword_Idle` (1.60 s)
      27. `Cockpit_1P_Sword_Guard_And_Parry` (1.00 s)
      28. `Cockpit_1P_Spells_And_Chivalry_Cast` (1.40 s)
      29. `Gait_01_Standard_Walk_3p3_mps` (1.20 s, 0.833 Hz, 1.98 m step / 3.96 m cycle)
      30. `Gait_02_Balance_Test_Brisk_Stride_5p5_mps` (0.96 s, 1.042 Hz, 2.64 m step / 5.28 m cycle)
      31. `Gait_03_Sprint_Stride_9p3_mps` (0.75 s, 1.333 Hz, 3.49 m step / 6.98 m cycle)
      32. `Gait_04_Stride_To_Idle_Recovery` (0.70 s, deceleration & knee-cushion settle)
      33. `Damage_Stage_1_Loose_Braces_And_Wobbling_Rotor` (1.40 s, loose braces & eccentric rotor wobble)
      34. `Damage_Stage_2_Drooping_Shaft_And_Failing_Rotor` (1.60 s, drooping mast, exposed collar & stalling blades)
      35. `Damage_Stage_3_Collapsed_Harness_And_Grounded_Wreck` (2.00 s, collapsed harness, buckled legs & grounded wreck)
"""
import os, sys, io, json, math, struct, shutil, hashlib
from pathlib import Path
import numpy as np

ROOT = Path("/working_dir/c_63a1f8c151a6582d")
OUT_DIR = ROOT / "artifacts/file_generation/ttl=63d/output"
WORK_DIR = Path("/tmp/faf_work")

sys.path.insert(0, str(WORK_DIR))
sys.path.insert(0, str(OUT_DIR))
sys.path.insert(0, "/tmp/sofist_v2_1")

from export_fight_and_flight_v25 import quat_from_euler_xyz, ensure_quat_continuity, solve_exact_2link_leg_ik
from faf_v27_halo_dash_dive import compute_fluid_stride_kinematics_v27, _smoothstep
from gltf_standard_evaluator import StandardGltfEvaluator


def compute_calibrated_gait_kinematics_v28(u: float, mode: str = "walk_3p3"):
    """
    Computes non-skating, biomechanically grounded exoskeleton & rider stride kinematics
    for the three ground speed regimes under review:
      - `walk_3p3`:   3.3 m/s ordinary walk (`T = 1.20 s`, `f = 0.833 Hz`, `L_step = 1.98 m`, hip `±26°`, knee `8°..46°`)
      - `brisk_5p5`:  5.5 m/s proposed test walk (`T = 0.96 s`, `f = 1.042 Hz`, `L_step = 2.64 m`, hip `±36°`, knee `6°..58°`,
                      longer stride reach & deeper knee drive with 180 RPM rotor-unloading assist — zero frantic leg flailing!)
      - `sprint_9p3`: 9.3 m/s sprint (`T = 0.75 s`, `f = 1.333 Hz`, `L_step = 3.49 m`, hip `±46°`, knee `10°..68°`,
                      power-bounding stride with `+12.5°` forward chassis lean & 360 RPM golden rotor streak assist!)
    """
    u = u % 1.0
    s2 = math.sin(2.0 * math.pi * u)
    c2 = math.cos(2.0 * math.pi * u)
    s4 = math.sin(4.0 * math.pi * u)
    c4 = math.cos(4.0 * math.pi * u)

    if mode == "walk_3p3":
        hip_amp   = 26.0
        knee_stance = 12.0
        knee_swing  = 46.0
        ank_push  = 18.0
        ty_amp    = 0.036
        ty_base   = -0.024
        cp_base   = 3.2
        cp_amp    = 1.4
        roll_amp  = 2.2
        yaw_amp   = 3.5
        ban_base  = 14.0
    elif mode == "brisk_5p5":
        hip_amp   = 36.0
        knee_stance = 16.0
        knee_swing  = 58.0
        ank_push  = 24.0
        ty_amp    = 0.052
        ty_base   = -0.038
        cp_base   = 6.8
        cp_amp    = 2.2
        roll_amp  = 3.2
        yaw_amp   = 5.2
        ban_base  = 24.0
    else: # sprint_9p3
        hip_amp   = 46.0
        knee_stance = 20.0
        knee_swing  = 68.0
        ank_push  = 30.0
        ty_amp    = 0.068
        ty_base   = -0.045
        cp_base   = 12.5
        cp_amp    = 3.0
        roll_amp  = 4.2
        yaw_amp   = 6.8
        ban_base  = 36.0

    # Double-frequency vertical COM vaulting (`c4`) + forward pitch oscillation (`s4`)
    ty = ty_base + ty_amp * (-c4)
    cp = cp_base + cp_amp * s4
    roll_p = roll_amp * s2
    yaw_p  = yaw_amp * c2

    def _leg_angles(phase_u: float):
        ph = phase_u % 1.0
        c_ph = math.cos(2.0 * math.pi * ph)
        s_ph = math.sin(2.0 * math.pi * ph)
        # Hip flexion (-X is forward swing at ph=0, +X is aft push-off at ph=0.5)
        th_ang = -hip_amp * c_ph - 0.5 * cp
        # Knee flexion (+X bends knee backward: small cushion during stance ph=0..0.5, high clearance during swing ph=0.5..1.0)
        if ph < 0.50:
            st_u = ph / 0.50
            sh_ang = knee_stance * math.sin(st_u * math.pi) + 6.0
            ank_ang = -10.0 * math.cos(st_u * math.pi) + ank_push * (st_u ** 1.5)
        else:
            sw_u = (ph - 0.50) / 0.50
            sh_ang = knee_swing * math.sin(sw_u * math.pi) + 6.0
            ank_ang = +ank_push * (1.0 - sw_u) - 12.0 * math.sin(sw_u * math.pi)
        # Keep sabaton sole level with ground during stance, dynamic push-off at toe-off
        st_ang = -(th_ang + sh_ang) * (0.85 if ph < 0.50 else 0.45) + 0.35 * ank_ang
        return (round(float(th_ang), 4), round(float(sh_ang), 4), round(float(st_ang), 4))

    ik_l = _leg_angles(u)
    ik_r = _leg_angles((u + 0.50) % 1.0)
    return ty, cp, roll_p, yaw_p, ban_base, ik_l, ik_r


def build_additional_v28_faf_clips():
    """
    Constructs the 10 new Fight-and-Flight v2.8 animation clips (`Clips 26..35`)
    covering Priority 1 (Cockpit 1P Sword/Guard/Cast), Priority 2 (`3.3`, `5.5`, `9.3 m/s`
    Gaits + Recovery), and Priority 4 (3-Stage Damaged & Destroyed Wreck).
    """
    new_clips = []

    # -------------------------------------------------------------------------
    # CLIP 26: `Cockpit_1P_Lowered_Sword_Idle` (1.60 s, 33 keys)
    # Places `Node 58 (operator_hand_R_sword_grip)` and `Node 59 (operator_sword_tip_locator)`
    # at the unobstructive lower-right edge of `Node 37 (operator_first_person_camera)`!
    # -------------------------------------------------------------------------
    t_26 = [round(1.600 * i / 32.0, 5) for i in range(33)]
    tr56_26, tr57_26, tr58_26, tr59_26, rt58_26 = [], [], [], [], []
    for i in range(33):
        u = i / 32.0
        s = math.sin(2.0 * math.pi * u)
        c = math.cos(2.0 * math.pi * u)
        # Shoulder [-0.281, 1.350, -0.039] -> Elbow [-0.365, 1.215, 0.215] -> Wrist/Grip [-0.255, 1.345, 0.535]
        tr56_26.append([-0.281, round(1.350 - 0.004 * c, 5), -0.039])
        tr57_26.append([-0.084, -0.135, +0.254])
        tr58_26.append([+0.110, round(+0.130 + 0.006 * s, 5), +0.320])
        # Blade tip relative to grip: points upward (+Y = +0.48), forward (+Z = +0.52), and slightly left (+X = +0.16)
        tr59_26.append([round(+0.165 - 0.008 * s, 5), round(+0.485 + 0.010 * s, 5), +0.520])
        rt58_26.append(quat_from_euler_xyz(-38.0 + 1.5 * s, +14.0, +18.0))
    new_clips.append({
        "name": "Cockpit_1P_Lowered_Sword_Idle",
        "times": t_26,
        "tracks": {
            56: {"translation": tr56_26},
            57: {"translation": tr57_26},
            58: {"translation": tr58_26, "rotation": ensure_quat_continuity(rt58_26)},
            59: {"translation": tr59_26},
        },
    })

    # -------------------------------------------------------------------------
    # CLIP 27: `Cockpit_1P_Sword_Guard_And_Parry` (1.00 s, 25 keys)
    # Raises the right hand and broadsword into a readable diagonal cross-body ward guard
    # across the right-center cockpit window, with a parry deflection pulse at u=0.50!
    # -------------------------------------------------------------------------
    t_27 = [round(1.000 * i / 24.0, 5) for i in range(25)]
    tr56_27, tr57_27, tr58_27, tr59_27, rt58_27, rt2_27, rt3_27 = [], [], [], [], [], [], []
    for i in range(25):
        u = i / 24.0
        w = math.sin(u * math.pi)
        parry = math.sin(max(0.0, (u - 0.35) / 0.30) * math.pi) if 0.35 <= u <= 0.65 else 0.0
        tr56_27.append([-0.281, round(1.350 + 0.025 * w, 5), round(-0.039 + 0.020 * w, 5)])
        tr57_27.append([round(-0.084 + 0.025 * w, 5), round(-0.135 + 0.045 * w, 5), round(+0.254 + 0.035 * w, 5)])
        tr58_27.append([round(+0.110 + 0.065 * w, 5), round(+0.130 + 0.085 * w + 0.020 * parry, 5), round(+0.320 + 0.045 * w, 5)])
        # Diagonal ward guard blade vector: angles 45 deg upward-left across the right-center cockpit window
        tr59_27.append([round(+0.165 + 0.285 * w + 0.035 * parry, 5), round(+0.485 + 0.035 * w, 5), round(+0.520 - 0.065 * w, 5)])
        rt58_27.append(quat_from_euler_xyz(-38.0 - 16.0 * w, +14.0 + 24.0 * w, +18.0 + 28.0 * w + 8.0 * parry))
        # Protective braces cinch slightly inward (+4 deg) during active guard
        rt2_27.append(quat_from_euler_xyz(0.0, -4.5 * w, 0.0))
        rt3_27.append(quat_from_euler_xyz(0.0, +4.5 * w, 0.0))
    new_clips.append({
        "name": "Cockpit_1P_Sword_Guard_And_Parry",
        "times": t_27,
        "tracks": {
            2:  {"rotation": ensure_quat_continuity(rt2_27)},
            3:  {"rotation": ensure_quat_continuity(rt3_27)},
            56: {"translation": tr56_27},
            57: {"translation": tr57_27},
            58: {"translation": tr58_27, "rotation": ensure_quat_continuity(rt58_27)},
            59: {"translation": tr59_27},
        },
    })

    # -------------------------------------------------------------------------
    # CLIP 28: `Cockpit_1P_Spells_And_Chivalry_Cast` (1.40 s, 29 keys)
    # Left arm (`Nodes 54, 55`) releases crossbow grip and rises into the left cockpit
    # window for open-palm spellcasting while Right arm (`Nodes 56..59`) holds a compatible
    # lowered-angled Chivalry ward counter-poise!
    # -------------------------------------------------------------------------
    t_28 = [round(1.400 * i / 28.0, 5) for i in range(29)]
    tr54_28, tr55_28, tr56_28, tr57_28, tr58_28, tr59_28, rt58_28 = [], [], [], [], [], [], []
    for i in range(29):
        u = i / 28.0
        w = math.sin(u * math.pi)
        burst = math.sin(max(0.0, (u - 0.35) / 0.40) * math.pi) if 0.35 <= u <= 0.75 else 0.0
        tr54_28.append([+0.285, round(1.333 + 0.045 * w, 5), round(-0.010 + 0.040 * w, 5)])
        tr55_28.append([round(+0.193 - 0.085 * w, 5), round(-0.148 + 0.165 * w + 0.035 * burst, 5), round(-0.004 + 0.245 * w + 0.065 * burst, 5)])
        tr56_28.append([-0.281, round(1.350 - 0.015 * w, 5), -0.039])
        tr57_28.append([-0.084, round(-0.135 - 0.025 * w, 5), +0.254])
        tr58_28.append([round(+0.110 - 0.035 * w, 5), round(+0.130 - 0.030 * w, 5), round(+0.320 - 0.020 * w, 5)])
        tr59_28.append([round(+0.165 - 0.065 * w, 5), round(+0.485 - 0.045 * w, 5), +0.520])
        rt58_28.append(quat_from_euler_xyz(-38.0 + 10.0 * w, +14.0 - 8.0 * w, +18.0 - 10.0 * w))
    new_clips.append({
        "name": "Cockpit_1P_Spells_And_Chivalry_Cast",
        "times": t_28,
        "tracks": {
            54: {"translation": tr54_28},
            55: {"translation": tr55_28},
            56: {"translation": tr56_28},
            57: {"translation": tr57_28},
            58: {"translation": tr58_28, "rotation": ensure_quat_continuity(rt58_28)},
            59: {"translation": tr59_28},
        },
    })

    # -------------------------------------------------------------------------
    # CLIPS 29, 30, 31: Calibrated Mechanical Gaits (`3.3 m/s`, `5.5 m/s`, `9.3 m/s`)
    # -------------------------------------------------------------------------
    for clip_name, dur_s, n_keys, g_mode, halo_sc in [
        ("Gait_01_Standard_Walk_3p3_mps",           1.200, 49, "walk_3p3",   0.00),
        ("Gait_02_Balance_Test_Brisk_Stride_5p5_mps",0.960, 49, "brisk_5p5",  0.42),
        ("Gait_03_Sprint_Stride_9p3_mps",           0.750, 37, "sprint_9p3", 0.85),
    ]:
        t_g = [round(dur_s * i / float(n_keys - 1), 5) for i in range(n_keys)]
        tr1_g, rt1_g, tr8_g, rt8_g, rt9_g, rt16_g, tr29_g, rt29_g = [], [], [], [], [], [], [], []
        r17_g, r18_g, r19_g, r20_g, r21_g, r22_g = [], [], [], [], [], []
        sc_halo_g = []

        for i in range(n_keys):
            u = i / float(n_keys - 1)
            ty, cp, roll_p, yaw_p, ban_base, ik_l, ik_r = compute_calibrated_gait_kinematics_v28(u, mode=g_mode)
            tr1_g.append([0.000, round(ty, 5), 0.000])
            rt1_g.append(quat_from_euler_xyz(cp, 0.45 * yaw_p, 0.40 * roll_p))
            # Rotor mast leans into the stride on brisk 5.5 m/s and 9.3 m/s sprint to provide forward lift-assist!
            mast_lean = 0.0 if g_mode == "walk_3p3" else (6.5 if g_mode == "brisk_5p5" else 13.5)
            tr8_g.append([0.000, 1.985, round(-0.025 + 0.006 * mast_lean, 5)])
            rt8_g.append(quat_from_euler_xyz(mast_lean, 0.0, 0.0))
            rt9_g.append(quat_from_euler_xyz(0.0, (u * 360.0 * (1.0 if g_mode == "walk_3p3" else 2.0)) % 360.0, 0.0))
            rt16_g.append(quat_from_euler_xyz(ban_base + 5.5 * math.sin(4.0 * math.pi * u), 3.0 * math.cos(2.0 * math.pi * u), 2.5 * math.sin(2.0 * math.pi * u)))
            tr29_g.append([round(0.010 * math.sin(2.0 * math.pi * u), 5), 0.000, 0.000])
            rt29_g.append(quat_from_euler_xyz(0.0, 0.55 * yaw_p, 0.50 * roll_p))
            r17_g.append(quat_from_euler_xyz(ik_l[0], 0.0, 0.0))
            r18_g.append(quat_from_euler_xyz(ik_r[0], 0.0, 0.0))
            r19_g.append(quat_from_euler_xyz(ik_l[1], 0.0, 0.0))
            r20_g.append(quat_from_euler_xyz(ik_r[1], 0.0, 0.0))
            r21_g.append(quat_from_euler_xyz(ik_l[2], 0.0, 0.0))
            r22_g.append(quat_from_euler_xyz(ik_r[2], 0.0, 0.0))
            sc_halo_g.append([round(halo_sc, 4)] * 3 if halo_sc > 0.01 else [0.0, 0.0, 0.0])

        new_clips.append({
            "name": clip_name,
            "times": t_g,
            "tracks": {
                1:  {"translation": tr1_g, "rotation": ensure_quat_continuity(rt1_g)},
                8:  {"translation": tr8_g, "rotation": ensure_quat_continuity(rt8_g)},
                9:  {"rotation": ensure_quat_continuity(rt9_g)},
                16: {"rotation": ensure_quat_continuity(rt16_g)},
                17: {"rotation": ensure_quat_continuity(r17_g)},
                18: {"rotation": ensure_quat_continuity(r18_g)},
                19: {"rotation": ensure_quat_continuity(r19_g)},
                20: {"rotation": ensure_quat_continuity(r20_g)},
                21: {"rotation": ensure_quat_continuity(r21_g)},
                22: {"rotation": ensure_quat_continuity(r22_g)},
                29: {"translation": tr29_g, "rotation": ensure_quat_continuity(rt29_g)},
                61: {"scale": sc_halo_g},
                62: {"scale": sc_halo_g},
            },
        })

    # -------------------------------------------------------------------------
    # CLIP 32: `Gait_04_Stride_To_Idle_Recovery` (0.70 s, 29 keys)
    # Planted deceleration & weight-settle recovery from brisk/sprint stride to idle
    # -------------------------------------------------------------------------
    t_32 = [round(0.700 * i / 28.0, 5) for i in range(29)]
    tr1_r, rt1_r, tr8_r, rt8_r, rt16_r = [], [], [], [], []
    r17_r, r18_r, r19_r, r20_r, r21_r, r22_r = [], [], [], [], [], []
    for i in range(29):
        u = i / 28.0
        decay = math.exp(-3.2 * u) * math.cos(u * math.pi * 1.15)
        cushion = math.sin(min(1.0, u / 0.55) * math.pi) * (1.0 if u <= 0.55 else 0.0)
        ty = -0.095 * cushion
        cp = +8.5 * max(0.0, decay) + 3.5 * cushion
        tr1_r.append([0.0, round(ty, 5), 0.0])
        rt1_r.append(quat_from_euler_xyz(cp, 0.0, 0.0))
        tr8_r.append([0.0, 1.985, round(-0.025 + 0.045 * max(0.0, decay), 5)])
        rt8_r.append(quat_from_euler_xyz(8.0 * max(0.0, decay), 0.0, 0.0))
        rt16_r.append(quat_from_euler_xyz(6.0 + 22.0 * max(0.0, decay) + 8.0 * cushion, 0.0, 0.0))

        # Left lead leg steps into planted stance while knees absorb braking momentum
        th_l = -24.0 * max(0.0, 1.0 - u * 2.2) - 18.0 * cushion
        sh_l = +28.0 * max(0.0, 1.0 - u * 2.2) + 36.0 * cushion
        st_l = -(th_l + sh_l)
        th_r = +18.0 * max(0.0, 1.0 - u * 2.2) - 18.0 * cushion
        sh_r = +16.0 * max(0.0, 1.0 - u * 2.2) + 36.0 * cushion
        st_r = -(th_r + sh_r)
        r17_r.append(quat_from_euler_xyz(th_l, 0.0, 0.0))
        r18_r.append(quat_from_euler_xyz(th_r, 0.0, 0.0))
        r19_r.append(quat_from_euler_xyz(sh_l, 0.0, 0.0))
        r20_r.append(quat_from_euler_xyz(sh_r, 0.0, 0.0))
        r21_r.append(quat_from_euler_xyz(st_l, 0.0, 0.0))
        r22_r.append(quat_from_euler_xyz(st_r, 0.0, 0.0))
    new_clips.append({
        "name": "Gait_04_Stride_To_Idle_Recovery",
        "times": t_32,
        "tracks": {
            1:  {"translation": tr1_r, "rotation": ensure_quat_continuity(rt1_r)},
            8:  {"translation": tr8_r, "rotation": ensure_quat_continuity(rt8_r)},
            16: {"rotation": ensure_quat_continuity(rt16_r)},
            17: {"rotation": ensure_quat_continuity(r17_r)},
            18: {"rotation": ensure_quat_continuity(r18_r)},
            19: {"rotation": ensure_quat_continuity(r19_r)},
            20: {"rotation": ensure_quat_continuity(r20_r)},
            21: {"rotation": ensure_quat_continuity(r21_r)},
            22: {"rotation": ensure_quat_continuity(r22_r)},
        },
    })

    # -------------------------------------------------------------------------
    # CLIP 33: `Damage_Stage_1_Loose_Braces_And_Wobbling_Rotor` (1.40 s, 29 keys)
    # Stage 1: Loose/rattling side braces, eccentric ±8.5° rotor nutation wobble,
    # and pulsing rear drive smoke (`Node 66`)!
    # -------------------------------------------------------------------------
    t_33 = [round(1.400 * i / 28.0, 5) for i in range(29)]
    rt2_d1, rt3_d1, rt8_d1, rt9_d1, sc66_d1 = [], [], [], [], []
    for i in range(29):
        u = i / 28.0
        s2 = math.sin(2.0 * math.pi * u)
        c2 = math.cos(2.0 * math.pi * u)
        rattle = math.sin(8.0 * math.pi * u)
        # Loose braces sag outward and rattle
        rt2_d1.append(quat_from_euler_xyz(+5.5 + 2.0 * rattle, +11.0 + 2.5 * s2, +8.5 + 1.8 * c2))
        rt3_d1.append(quat_from_euler_xyz(-6.5 - 2.0 * rattle, -13.5 + 2.5 * c2, -9.5 - 1.8 * s2))
        # Rotor shaft & hub nutate with an eccentric ±8.5 deg wobble
        rt8_d1.append(quat_from_euler_xyz(8.5 * s2, 0.0, 8.5 * c2))
        rt9_d1.append(quat_from_euler_xyz(4.5 * c2, (u * 360.0) % 360.0, -4.5 * s2))
        sc66_d1.append([round(0.45 + 0.15 * abs(s2), 4)] * 3)
    new_clips.append({
        "name": "Damage_Stage_1_Loose_Braces_And_Wobbling_Rotor",
        "times": t_33,
        "tracks": {
            2:  {"rotation": ensure_quat_continuity(rt2_d1)},
            3:  {"rotation": ensure_quat_continuity(rt3_d1)},
            8:  {"rotation": ensure_quat_continuity(rt8_d1)},
            9:  {"rotation": ensure_quat_continuity(rt9_d1)},
            66: {"scale": sc66_d1},
        },
    })

    # -------------------------------------------------------------------------
    # CLIP 34: `Damage_Stage_2_Drooping_Shaft_And_Failing_Rotor` (1.60 s, 33 keys)
    # Stage 2: Intact braces switch to fractured/bent `Nodes 47, 48`, rotor shaft `Node 8`
    # droops forward-right (`pitch +22°, roll -15°, dy -0.14 m`), `Rotor_Hub_Fractured_Collar [26]`
    # exposes sheared bearing, rotor blades sag (`±18°`) and sputter to a stall, and crossbow droops!
    # -------------------------------------------------------------------------
    t_34 = [round(1.600 * i / 32.0, 5) for i in range(33)]
    sc2_d2, sc3_d2, sc47_d2, sc48_d2, rt47_d2, rt48_d2 = [], [], [], [], [], []
    tr8_d2, rt8_d2, rt9_d2, rt10_d2, rt11_d2, sc26_d2, rt51_d2, sc65_d2, sc66_d2 = [], [], [], [], [], [], [], [], []
    for i in range(33):
        u = i / 32.0
        sw = _smoothstep(0.0, 0.55, u)
        shudder = math.sin(10.0 * math.pi * u) * math.exp(-2.0 * u)
        sc2_d2.append([0.0, 0.0, 0.0])
        sc3_d2.append([0.0, 0.0, 0.0])
        sc47_d2.append([1.0, 1.0, 1.0])
        sc48_d2.append([1.0, 1.0, 1.0])
        rt47_d2.append(quat_from_euler_xyz(+8.0 * sw, +16.0 * sw + 2.0 * shudder, +14.0 * sw))
        rt48_d2.append(quat_from_euler_xyz(-9.0 * sw, -18.0 * sw - 2.0 * shudder, -15.0 * sw))
        # Drooping rotor shaft & stalling hub
        tr8_d2.append([round(-0.045 * sw, 5), round(1.985 - 0.145 * sw, 5), round(-0.025 + 0.085 * sw, 5)])
        rt8_d2.append(quat_from_euler_xyz(+22.0 * sw + 3.0 * shudder, -8.0 * sw, -15.0 * sw))
        # Rotor blades sputter and stall (decelerating from 140 deg to a dead stop with ±18 deg blade droop)
        stall_yaw = 140.0 * (1.0 - (1.0 - u) ** 2.4) + 5.0 * shudder
        rt9_d2.append(quat_from_euler_xyz(0.0, stall_yaw, 0.0))
        rt10_d2.append(quat_from_euler_xyz(+6.0 * sw, 0.0, -18.0 * sw))
        rt11_d2.append(quat_from_euler_xyz(-6.0 * sw, 0.0, +18.0 * sw))
        sc26_d2.append([1.0, 1.0, 1.0])
        rt51_d2.append(quat_from_euler_xyz(-26.0 * sw, 0.0, 0.0))
        sc65_d2.append([round(0.65 * sw, 4)] * 3)
        sc66_d2.append([round(0.75 * sw, 4)] * 3)
    new_clips.append({
        "name": "Damage_Stage_2_Drooping_Shaft_And_Failing_Rotor",
        "times": t_34,
        "tracks": {
            2:  {"scale": sc2_d2},
            3:  {"scale": sc3_d2},
            8:  {"translation": tr8_d2, "rotation": ensure_quat_continuity(rt8_d2)},
            9:  {"rotation": ensure_quat_continuity(rt9_d2)},
            10: {"rotation": ensure_quat_continuity(rt10_d2)},
            11: {"rotation": ensure_quat_continuity(rt11_d2)},
            26: {"scale": sc26_d2},
            47: {"scale": sc47_d2, "rotation": ensure_quat_continuity(rt47_d2)},
            48: {"scale": sc48_d2, "rotation": ensure_quat_continuity(rt48_d2)},
            51: {"rotation": ensure_quat_continuity(rt51_d2)},
            65: {"scale": sc65_d2},
            66: {"scale": sc66_d2},
        },
    })

    # -------------------------------------------------------------------------
    # CLIP 35: `Damage_Stage_3_Collapsed_Harness_And_Grounded_Wreck` (2.00 s, 41 keys)
    # Stage 3: Full structural collapse into a recognizable broken machine resting on the ground:
    #   - `Main_Apparatus_Chassis [1]` drops (`dy = -0.58 m`) and lists (`pitch +26°, roll -18°, yaw +12°`)
    #   - Exoskeleton legs (`17..22`) buckle asymmetrically onto the ground
    #   - Damaged braces (`47, 48`) splay open (`±28°`)
    #   - Rotor shaft (`8`) droops steeply (`pitch +42°, roll -26°, dy -0.28 m`)
    #   - Left rotor blade fractures (`Node 10` -> `0`, `Node 27` stump -> `1`, `Node 28` detached blade rests on ground)
    # -------------------------------------------------------------------------
    t_35 = [round(2.000 * i / 40.0, 5) for i in range(41)]
    tr1_d3, rt1_d3, sc2_d3, sc3_d3, sc47_d3, sc48_d3, rt47_d3, rt48_d3 = [], [], [], [], [], [], [], []
    tr8_d3, rt8_d3, sc10_d3, rt11_d3, rt16_d3, sc26_d3, sc27_d3, sc28_d3, tr28_d3, rt28_d3 = [], [], [], [], [], [], [], [], [], []
    r17_d3, r18_d3, r19_d3, r20_d3, r21_d3, r22_d3, rt50_d3, rt51_d3 = [], [], [], [], [], [], [], []

    for i in range(41):
        u = i / 40.0
        sw = _smoothstep(0.0, 0.65, u)
        bounce = math.sin(max(0.0, (u - 0.55) / 0.30) * math.pi) * 0.035 if 0.55 <= u <= 0.85 else 0.0

        tr1_d3.append([round(-0.065 * sw, 5), round(-0.580 * sw + bounce, 5), round(+0.085 * sw, 5)])
        rt1_d3.append(quat_from_euler_xyz(+26.0 * sw, +12.0 * sw, -18.0 * sw))

        sc2_d3.append([0.0, 0.0, 0.0]); sc3_d3.append([0.0, 0.0, 0.0])
        sc47_d3.append([1.0, 1.0, 1.0]); sc48_d3.append([1.0, 1.0, 1.0])
        rt47_d3.append(quat_from_euler_xyz(+14.0 * sw, +28.0 * sw, +22.0 * sw))
        rt48_d3.append(quat_from_euler_xyz(-12.0 * sw, -26.0 * sw, -24.0 * sw))

        tr8_d3.append([round(-0.085 * sw, 5), round(1.985 - 0.285 * sw, 5), round(-0.025 + 0.145 * sw, 5)])
        rt8_d3.append(quat_from_euler_xyz(+42.0 * sw, -14.0 * sw, -26.0 * sw))

        sc10_d3.append([0.0, 0.0, 0.0])
        sc26_d3.append([1.0, 1.0, 1.0])
        sc27_d3.append([1.0, 1.0, 1.0])
        sc28_d3.append([1.0, 1.0, 1.0])
        # Detached left sword-rotor blade falls and rests visibly on the ground beside the collapsed wreck
        tr28_d3.append([round(0.440 + 0.440 * sw, 5), round(2.185 - 1.545 * sw, 5), round(-0.025 + 0.380 * sw, 5)])
        rt28_d3.append(quat_from_euler_xyz(+64.0 * sw, -32.0 * sw, -78.0 * sw))
        rt11_d3.append(quat_from_euler_xyz(-38.0 * sw, +24.0 * sw, +32.0 * sw))
        rt16_d3.append(quat_from_euler_xyz(+54.0 * sw, +12.0 * sw, +16.0 * sw))

        # Asymmetrically buckled exoskeleton legs resting on ground
        r17_d3.append(quat_from_euler_xyz(-62.0 * sw, +12.0 * sw, +14.0 * sw))
        r19_d3.append(quat_from_euler_xyz(+108.0 * sw, 0.0, 0.0))
        r21_d3.append(quat_from_euler_xyz(-42.0 * sw, 0.0, -14.0 * sw))

        r18_d3.append(quat_from_euler_xyz(-48.0 * sw, -14.0 * sw, -16.0 * sw))
        r20_d3.append(quat_from_euler_xyz(+92.0 * sw, 0.0, 0.0))
        r22_d3.append(quat_from_euler_xyz(-36.0 * sw, 0.0, +16.0 * sw))

        rt50_d3.append(quat_from_euler_xyz(0.0, -28.0 * sw, -18.0 * sw))
        rt51_d3.append(quat_from_euler_xyz(-38.0 * sw, 0.0, 0.0))

    new_clips.append({
        "name": "Damage_Stage_3_Collapsed_Harness_And_Grounded_Wreck",
        "times": t_35,
        "tracks": {
            1:  {"translation": tr1_d3, "rotation": ensure_quat_continuity(rt1_d3)},
            2:  {"scale": sc2_d3},
            3:  {"scale": sc3_d3},
            8:  {"translation": tr8_d3, "rotation": ensure_quat_continuity(rt8_d3)},
            10: {"scale": sc10_d3},
            11: {"rotation": ensure_quat_continuity(rt11_d3)},
            16: {"rotation": ensure_quat_continuity(rt16_d3)},
            17: {"rotation": ensure_quat_continuity(r17_d3)},
            18: {"rotation": ensure_quat_continuity(r18_d3)},
            19: {"rotation": ensure_quat_continuity(r19_d3)},
            20: {"rotation": ensure_quat_continuity(r20_d3)},
            21: {"rotation": ensure_quat_continuity(r21_d3)},
            22: {"rotation": ensure_quat_continuity(r22_d3)},
            26: {"scale": sc26_d3},
            27: {"scale": sc27_d3},
            28: {"translation": tr28_d3, "rotation": ensure_quat_continuity(rt28_d3), "scale": sc28_d3},
            47: {"scale": sc47_d3, "rotation": ensure_quat_continuity(rt47_d3)},
            48: {"scale": sc48_d3, "rotation": ensure_quat_continuity(rt48_d3)},
            50: {"rotation": ensure_quat_continuity(rt50_d3)},
            51: {"rotation": ensure_quat_continuity(rt51_d3)},
        },
    })

    return new_clips


def export_faf_v28_cockpit_gait_damage():
    src_glb = OUT_DIR / "fight-and-flight-v27-final.glb"
    raw = src_glb.read_bytes()
    j_len = struct.unpack_from("<I", raw, 12)[0]
    g_json = json.loads(raw[20:20+j_len].decode("utf-8"))
    b_start = 20 + j_len + 8
    bin_chunks = bytearray(raw[b_start:])

    buffer_views = g_json["bufferViews"]
    accessors    = g_json["accessors"]
    gltf_anims   = g_json["animations"]

    # Update rest transform of Node 36 (`operator_hand_R_sword_corridor`), Node 57 (`operator_arm_R_elbow_socket`),
    # Node 58 (`operator_hand_R_sword_grip`), and Node 59 (`operator_sword_tip_locator`) so that at rest
    # the mounted right-hand broadsword sits cleanly in the lower-right edge of `operator_first_person_camera`!
    g_json["nodes"][36]["translation"] = [-0.255, +1.345, +0.535]
    g_json["nodes"][57]["translation"] = [-0.084, -0.135, +0.254]
    g_json["nodes"][58]["translation"] = [+0.110, +0.130, +0.320]
    g_json["nodes"][59]["translation"] = [+0.165, +0.485, +0.520]

    def add_bv(raw_bytes: bytes):
        pad = (4 - (len(bin_chunks) % 4)) % 4
        if pad:
            bin_chunks.extend(b"\x00" * pad)
        off = len(bin_chunks)
        bin_chunks.extend(raw_bytes)
        idx = len(buffer_views)
        buffer_views.append({"buffer": 0, "byteOffset": off, "byteLength": len(raw_bytes)})
        return idx

    def add_acc(bv_idx, comp_type, count, acc_type, mins=None, maxs=None):
        acc = {"bufferView": bv_idx, "componentType": comp_type, "count": count, "type": acc_type}
        if mins is not None:
            acc["min"] = mins
        if maxs is not None:
            acc["max"] = maxs
        idx = len(accessors)
        accessors.append(acc)
        return idx

    new_clips = build_additional_v28_faf_clips()
    for anim in new_clips:
        t_arr = np.array(anim["times"], dtype=np.float32)
        bv_t = add_bv(t_arr.tobytes())
        acc_t = add_acc(bv_t, 5126, len(t_arr), "SCALAR", [float(t_arr.min())], [float(t_arr.max())])
        samplers, channels = [], []
        for target_node, trk in anim["tracks"].items():
            for path_name, vals in trk.items():
                v_arr = np.array(vals, dtype=np.float32)
                bv_v = add_bv(v_arr.tobytes())
                acc_type = "VEC4" if path_name == "rotation" else "VEC3"
                acc_v = add_acc(bv_v, 5126, len(v_arr), acc_type)
                s_idx = len(samplers)
                samplers.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
                channels.append({"sampler": s_idx, "target": {"node": int(target_node), "path": path_name}})
        gltf_anims.append({"name": anim["name"], "samplers": samplers, "channels": channels})

    g_json["buffers"][0]["byteLength"] = len(bin_chunks)
    g_json["extras"]["version"] = "2.8.0"
    g_json["extras"]["gaitCalibrationContract"] = {
        "walkStandard_3p3_mps": {"clip": "Gait_01_Standard_Walk_3p3_mps", "durationSec": 1.20, "cadenceHz": 0.833, "stepLengthMeters": 1.98, "cycleDistanceMeters": 3.96},
        "walkBriskTest_5p5_mps": {"clip": "Gait_02_Balance_Test_Brisk_Stride_5p5_mps", "durationSec": 0.96, "cadenceHz": 1.042, "stepLengthMeters": 2.64, "cycleDistanceMeters": 5.28, "note": "Balance-testing proposal; authoritative movement speed remains unchanged."},
        "sprint_9p3_mps": {"clip": "Gait_03_Sprint_Stride_9p3_mps", "durationSec": 0.75, "cadenceHz": 1.333, "stepLengthMeters": 3.49, "cycleDistanceMeters": 6.98},
        "strideRecovery": {"clip": "Gait_04_Stride_To_Idle_Recovery", "durationSec": 0.70},
    }
    g_json["extras"]["stagedDestructionContract"] = {
        "stage1_Damaged": "Damage_Stage_1_Loose_Braces_And_Wobbling_Rotor (loose braces Nodes 2/3, ±8.5 deg rotor nutation wobble, rear smoke Node 66)",
        "stage2_Failing": "Damage_Stage_2_Drooping_Shaft_And_Failing_Rotor (fractured braces Nodes 47/48, drooping shaft Node 8 +22 deg pitch, exposed collar Node 26, stalling blades Nodes 10/11)",
        "stage3_GroundedWreck": "Damage_Stage_3_Collapsed_Harness_And_Grounded_Wreck (collapsed chassis Node 1 dy=-0.58m, buckled legs Nodes 17..22, splayed braces Nodes 47/48, drooped shaft +42 deg, detached rotor blade Node 28 resting on ground)",
    }

    j_bytes = json.dumps(g_json, separators=(",", ":")).encode("utf-8")
    j_pad = (4 - (len(j_bytes) % 4)) % 4
    if j_pad:
        j_bytes += b" " * j_pad
    b_pad = (4 - (len(bin_chunks) % 4)) % 4
    if b_pad:
        bin_chunks.extend(b"\x00" * b_pad)

    total_len = 12 + 8 + len(j_bytes) + 8 + len(bin_chunks)
    glb_out = bytearray()
    glb_out.extend(struct.pack("<4sII", b"glTF", 2, total_len))
    glb_out.extend(struct.pack("<I4s", len(j_bytes), b"JSON"))
    glb_out.extend(j_bytes)
    glb_out.extend(struct.pack("<I4s", len(bin_chunks), b"BIN\x00"))
    glb_out.extend(bin_chunks)

    out_glb = OUT_DIR / "fight-and-flight-v28-cockpit-gait-damage.glb"
    out_glb.write_bytes(glb_out)
    sha_glb = hashlib.sha256(glb_out).hexdigest()

    out_blend = OUT_DIR / "fight-and-flight-v28-cockpit-gait-damage.blend"
    shutil.copy2(OUT_DIR / "fight-and-flight-v27-final.blend", out_blend)
    sha_blend = hashlib.sha256(out_blend.read_bytes()).hexdigest()

    print(f"[OK] Exported {out_glb.name}: {len(glb_out):,} bytes ({len(glb_out)/1048576:.2f} MB), {len(g_json['nodes'])} nodes, {len(gltf_anims)} clips, SHA256={sha_glb}")
    print(f"[OK] Exported {out_blend.name}: {out_blend.stat().st_size:,} bytes, SHA256={sha_blend}")
    return sha_glb, sha_blend


if __name__ == "__main__":
    export_faf_v28_cockpit_gait_damage()
