# Castleward — Reproducible Blender Source & GLB Export Pipeline (v3.1 In-Game Review & 19.5° Sim-Trim Dash)

Repository: [Swords & Sorcery: Castleward](https://github.com/CaptainFredric/swords-and-sorcery)

This archive contains the complete, self-contained Python mesh-construction, Blender DNA `.blend` updater, 6-material glTF 2.0 primitive splitter, and 19.5° Sim-Trim narrowed-Dash animation exporter scripts that deterministically generate the exact `.blend` and `.glb` deliverables.

## 1. Exact Output Hashes & Byte Sizes

| File | Size (Bytes) | SHA-256 |
| :--- | :---: | :--- |
| `spellblade-v31-ingame-review-candidate.glb` | `3,107,952` | `4fddfe876fb2067a1b60d633c4e1fad77a1379568dfa2d7ead1a7f998015c97b` |
| `spellblade-v31-ingame-review-candidate.blend` | `4,375,387` | `14c81e6037f1012f4b1e3b02001625379ecc3f298da4c4b4ad24ccf3986c0fe3` |
| `spellblade-v30-refined-candidate.glb` (v3.0 Foundation) | `3,170,352` | `b87eb19f7f22b7dc542f8c5f2806a923518ff58e16e87d6cba76982cf0007738` |
| `spellblade-v30-refined-candidate.blend` (v3.0 Foundation) | `4,383,471` | `ae5ef8bc7738f46a53a7cdbdecb7408c4a24cbde8656bf7b224880d6afc359ec` |
| `spellblade-v29-artistic-refinement.glb` (v2.9 Baseline) | `2,880,204` | `a1d4e3e63412fe13ac2fc4f254e455499bed075d32f8f9422c9ccf86b0801d1c` |
| `fight-and-flight-v30-sim19p5-dash.glb` | `3,949,716` | `b7967ba87ffa0f4ad6f1ee54d7e6897eb8e993e8407dc567817c4a2725fc0d6b` |
| `fight-and-flight-v30-sim19p5-dash.blend` | `456,990` | `c520bb107fdf726851ed7632244c2b334761f07451160ea5c7c8569f6caebb20` |
| `fight-and-flight-v29-narrowed-dash.glb` | `3,940,332` | `4a561f15ec277fa3d49cbdd49becd1eef4f5921030c2e6d6cdd301f9936bacb3` |
| `fight-and-flight-v29-narrowed-dash.blend` | `456,652` | `e5f630a09f15e2ea8b16c4280f09dc39c40f33e3484a6ce0b1329129cccd3d40` |

## 2. Reproducible Build Commands

```bash
# 1. Build Spellblade v3.0 Foundation & Narrowed Dash v2.9 baseline:
python3 build_spellblade_v30_refined_candidate.py
python3 build_faf_v29_narrowed_dash_and_blend.py

# 2. Build Spellblade v3.1 In-Game Review Candidate & Fight-and-Flight v3.0 (~19.5° Sim-Trim Dash):
python3 build_spellblade_v31_and_faf_sim19p5.py

# 3. Render all turnaround, armor-region, rig-articulation, mounted-deformation & 19.5° Dash proof sheets:
python3 render_v31_and_sim19p5_proofs.py
```
