#!/usr/bin/env python3
"""
Castleward — Part A: Spellblade v2.9 Focused Artistic Refinement Builder & Exporter
===================================================================================
Produces distinct reviewable outputs (preserving all v2.8 files untouched):
  - `spellblade-v29-artistic-refinement.glb`
  - `spellblade-v29-artistic-refinement.blend`
  - `spellblade-v29-first-person-rigged.glb`
  - `spellblade-v29-first-person-production.blend`

Addresses every artistic critique in Part A (A1–A6):
  - A1 (Proportions & Silhouette): Narrows upper torso & lateral rib lames by ~20% for an
    athletic V-taper (`rx_waist = 0.148 -> rx_chest = 0.196`), replaces puffy horizontal
    shoulder domes with a 34° descending shoulder silhouette, tapers cylindrical arms into
    anatomical bicep/forearm/narrow-wrist profiles (`r_wrist = 0.062`), slims heavy knee
    bands, and replaces blocky feet with sleek, wedged 5-facet sabatons.
  - A2 (Helmet & Visor): Eliminates the stacked-box forehead groove; sculpts a unified
    forward-cantilevered scowling V-brow box-helm, inward-tapered cheek plates (`jaw taper`),
    slender integrated champagne-brass nasal bar (`hx = 0.018`), crisp edge bevels, deep
    dark visor recess with cyan L-visor slits, and a cohesive swept Spartan crimson crest.
  - A3 (Shoulders & Cuirass): Mechanically & anatomically connects the 3-tier pauldrons
    with overlapping descending lames over a dark core; reduces the overly prominent pale
    V-shaped breastplate trim from 42 mm to a restrained 13 mm beveled brass edge framing
    a keeled slate-steel plastron, dark upper gorget, underarm gussets, and inward-tapering
    dark-steel lateral lames.
  - A4 (Arms, Legs & Equipment): Sculpts the Hero Broadsword with a true recessed dark-slate
    central fuller table, wide bright-steel razor bevels, and notched fishtail brass quillons
    (eliminating the uniform gray slab look); refines gauntlets, wrist taper, belt, side
    pouches, sleek hip tassets, anchored crimson tabard, fitted thigh cuisses over dark
    gambeson, chiseled steel knee poleyns (no thick yellow band), tapered shin greaves,
    and sleek articulated sabatons.
  - A5 (Material Hierarchy — Dark Core, Bright Edges): Enforces deep charcoal/dark-iron
    recesses and undersuit core (`UNDERSUIT_DARK`, `STEEL_DARK`) contrasted with restrained
    mid-slate armor planes and crisp bright edge highlights.
"""
import os, sys, io, json, math, struct, hashlib, shutil
from pathlib import Path
import numpy as np

ROOT = Path("/working_dir/c_63a1f8c151a6582d")
OUT_DIR = ROOT / "artifacts/file_generation/ttl=63d/output"
WORK_DIR = Path("/tmp/faf_work")
C_PREV_INTER = Path("/working_dir/c_bc1ba559921be6b9/artifacts/file_generation/ttl=63d/intermediate")
C_PREV_WORK  = Path("/working_dir/c_bc1ba559921be6b9/work")

sys.path.insert(0, str(C_PREV_INTER))
sys.path.insert(0, str(WORK_DIR))
sys.path.insert(0, str(OUT_DIR))
sys.path.insert(0, "/tmp/sofist_v2_1")

from blend_io import BlendFile
from mesh_builder import MeshBuilder, BoneFrame, PALETTE
import reconstruct_spellblade as rs_prev
import build_spellblade_v28_fidelity as b28
import update_v28_sculpt as u28
import export_spellblade_v28_production as exp28
from export_fight_and_flight_v25 import zstd_compress_blend
from gltf_standard_evaluator import StandardGltfEvaluator


def transform_helmet_v29(mb: MeshBuilder) -> MeshBuilder:
    piv_y, piv_z = 0.04, 1.76
    rad_p = math.radians(4.8)
    cp, sp = math.cos(rad_p), math.sin(rad_p)
    for i, (x, y, z) in enumerate(mb.verts):
        dy = y - piv_y
        dz = z - piv_z
        ny = piv_y + dy * cp + dz * sp - 0.020
        nz = piv_z - dy * sp + dz * cp - 0.006
        mb.verts[i] = (float(x), float(ny), float(nz))
    return mb


def build_v29_helmet_parts():
    """
    A2. Helmet and Visor Refinement (`CANONICAL_HELMET_FOCUS_KEEP.png`):
      - Eliminates the horizontal black groove across the forehead so the brow and crown read
        as a single forged architectural helm with a sharp, bright upper-brow bevel ridge.
      - Tapers the cheek plates inward toward the chin (`x = ±0.106` at temple -> `±0.074` at jaw)
        and forward to a keeled chin point, with a dark stepped recess in front of the ear-guards.
      - Narrows the champagne-brass nasal bar (`hx = 0.017`) so it integrates into the brow keel
        and tapers cleanly to a sharp V-point (`z = 1.844`) between the cyan L-visor slits.
      - Sculpts a cohesive, forward-leaning Spartan crimson crest fin without blocky staircase gaps.
    """
    w = "head"
    mb_shell = MeshBuilder(["MAKitMetal", "MAKitMatte"])

    def helm_ring(rx_front, yf_c, yf_corner, rx_side, yb_side, rx_back, yb_back, yb_c, z_c, z_corner, z_side, z_back):
        return [
            ( 0.000,     yf_c,      z_c),      # 0: Front center V-brow keel
            (-rx_front,  yf_corner, z_corner), # 1: Left Front-Outer Brow Corner
            (-rx_side,   yb_side,   z_side),   # 2: Left Rear-Side Temple Corner
            (-rx_back,   yb_back,   z_back),   # 3: Left Back Corner
            ( 0.000,     yb_c,      z_back),   # 4: Back center keel
            ( rx_back,   yb_back,   z_back),   # 5: Right Back Corner
            ( rx_side,   yb_side,   z_side),   # 6: Right Rear-Side Temple Corner
            ( rx_front,  yf_corner, z_corner), # 7: Right Front-Outer Brow Corner
        ]

    # Continuous forged brow-to-crown loft (no dark horizontal split groove!)
    r0_under = helm_ring(0.100, 0.232, 0.198, 0.122, 0.018, 0.102, -0.078, -0.114, 1.868, 1.902, 1.896, 1.882)
    r1_brow  = helm_ring(0.104, 0.244, 0.208, 0.126, 0.018, 0.106, -0.080, -0.118, 1.870, 1.906, 1.900, 1.886)
    r2_ridge = helm_ring(0.102, 0.238, 0.202, 0.124, 0.016, 0.104, -0.078, -0.116, 1.944, 1.958, 1.952, 1.938)
    r3_bevel = helm_ring(0.092, 0.222, 0.188, 0.114, 0.014, 0.096, -0.072, -0.108, 1.964, 1.972, 1.966, 1.952)
    r4_crown = helm_ring(0.056, 0.178, 0.148, 0.074, 0.008, 0.064, -0.052, -0.088, 2.016, 2.012, 2.004, 1.992)

    cols_under = ["FACE_DARK"] * 8
    cols_brow  = ["STEEL_LIGHT", "STEEL_MAIN",  "STEEL_FACET", "STEEL_DARK",  "STEEL_DARK",  "STEEL_FACET", "STEEL_MAIN",  "STEEL_BRIGHT"]
    cols_bevel = ["STEEL_BRIGHT","STEEL_LIGHT", "STEEL_MAIN",  "STEEL_FACET", "STEEL_FACET", "STEEL_MAIN",  "STEEL_LIGHT", "STEEL_BRIGHT"]
    cols_crown = ["STEEL_MAIN",  "STEEL_FACET", "STEEL_DARK",  "STEEL_DARK",  "STEEL_DARK",  "STEEL_FACET", "STEEL_MAIN",  "STEEL_LIGHT"]

    mb_shell.add_loft(
        [r0_under, r1_brow, r2_ridge, r3_bevel, r4_crown],
        weights=w, mat="METAL",
        colors=[cols_under, cols_brow, cols_bevel, cols_crown],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_MAIN",
    )

    # Sleek, integrated champagne-brass nasal bar & crown ridge (`hx = 0.017`, tapering to a sharp V-tip at z=1.842)
    def nasal_ring(hx_out, hx_in, yf_face, yf_base, z_face, z_base):
        return [
            ( 0.000,   yf_face + 0.003, z_face),
            (-hx_in,   yf_face,         z_face),
            (-hx_out,  yf_base,         z_base),
            ( 0.000,   yf_base,         z_base),
            ( hx_out,  yf_base,         z_base),
            ( hx_in,   yf_face,         z_face),
        ]

    nb0 = nasal_ring(0.002, 0.001, 0.248, 0.232, 1.842, 1.845) # Sharp V-tip between eyes
    nb1 = nasal_ring(0.018, 0.014, 0.252, 0.236, 1.876, 1.876) # Brow bridge
    nb2 = nasal_ring(0.017, 0.013, 0.244, 0.228, 1.946, 1.944) # Upper forehead ridge
    nb3 = nasal_ring(0.018, 0.014, 0.208, 0.184, 2.018, 2.008) # Crown prow in front of crest
    nb4 = nasal_ring(0.018, 0.014, 0.042, 0.042, 2.016, 2.006)

    n_cols_main = ["BRASS_BRIGHT", "BRASS_MAIN", "BRASS_SHADE", "BRASS_DARK", "BRASS_MAIN", "BRASS_BRIGHT"]
    n_cols_top  = ["BRASS_BRIGHT", "BRASS_EDGE", "BRASS_SHADE", "BRASS_DARK", "BRASS_EDGE", "BRASS_BRIGHT"]
    mb_shell.add_loft(
        [nb0, nb1, nb2, nb3, nb4],
        weights=w, mat="METAL",
        colors=[n_cols_main, n_cols_main, n_cols_top, n_cols_top],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT"
    )

    # Framed Side Ear-Guards recessed cleanly into the temple/jaw profile (`CANONICAL_HELMET_FOCUS_KEEP.png`)
    for sign in (-1.0, 1.0):
        x_eb = sign * 0.118
        if sign > 0:
            eb_corners = [
                (x_eb - 0.004, 0.098, 1.882),
                (x_eb + 0.002, 0.016, 1.878),
                (x_eb - 0.004, 0.020, 1.768),
                (x_eb - 0.010, 0.100, 1.764),
            ]
        else:
            eb_corners = [
                (x_eb - 0.002, 0.016, 1.878),
                (x_eb + 0.004, 0.098, 1.882),
                (x_eb + 0.010, 0.100, 1.764),
                (x_eb + 0.004, 0.020, 1.768),
            ]
        rs_prev.add_framed_rect_plate(
            mb_shell, eb_corners, normal_dir=(sign * 0.96, 0.18, -0.08),
            thickness=0.014, border_frac=0.30, weights=w,
            mat_border="METAL", col_border="STEEL_LIGHT" if sign > 0 else "STEEL_MAIN", col_border_edge="STEEL_BRIGHT",
            mat_inner="MATTE", col_inner="FACE_DARK", open_top=False
        )

    # 2. MEHelmetJawCanonical: Inward-Tapered Cheek Plates, Dark Recessed Visor Cavity & Central Steel Divider
    mb_jaw = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    def cav_ring(z):
        return [
            ( 0.000,  0.194, z),
            (-0.028,  0.192, z),
            (-0.088,  0.168, z),
            (-0.096,  0.112, z),
            ( 0.000, -0.062, z),
            ( 0.096,  0.112, z),
            ( 0.088,  0.168, z),
            ( 0.028,  0.192, z),
        ]
    mb_jaw.add_loft([cav_ring(1.720), cav_ring(1.928)], weights=w, mat="MATTE", colors="FACE_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    # Recessed dark-steel vertical faceplate divider pillar
    mb_jaw.add_beveled_box(
        center=(0.000, 0.204, 1.792),
        half_extents=(0.0055, 0.007, 0.058),
        bevel=0.18, weights=w, mat="METAL",
        col_main="STEEL_DARK", col_edge="STEEL_FACET", col_dark="FACE_DARK",
    )

    def jaw_shell_ring(x_in, yf_in, x_step, yf_step, x_cheek, yf_cheek, x_temp, yf_temp, rx_side, yb_side, rx_back, yb_back, yb_c, z_in, z_cheek, z_temp, z_side, z_back):
        return [
            (-x_in,     yf_in,    z_in),
            (-x_step,   yf_step,  z_in),
            (-x_cheek,  yf_cheek, z_cheek),
            (-x_temp,   yf_temp,  z_temp),
            (-rx_side,  yb_side,  z_side),
            (-rx_back,  yb_back,  z_back),
            ( 0.000,    yb_c,     z_back),
            ( rx_back,  yb_back,  z_back),
            ( rx_side,  yb_side,  z_side),
            ( x_temp,   yf_temp,  z_temp),
            ( x_cheek,  yf_cheek, z_cheek),
            ( x_step,   yf_step,  z_in),
            ( x_in,     yf_in,    z_in),
        ]

    # Note the deliberate inward jaw taper: x_cheek tapers from 0.094 at top (z=1.862) down to 0.074 at chin (z=1.732),
    # and rx_side tapers from 0.122 at temple down to 0.102 at lower jaw!
    j_under   = jaw_shell_ring(0.026, 0.206, 0.038, 0.222, 0.072, 0.204, 0.076, 0.198, 0.100, 0.018, 0.092, -0.072, -0.108, 1.724, 1.736, 1.740, 1.750, 1.744)
    j_bot_lip = jaw_shell_ring(0.027, 0.210, 0.040, 0.226, 0.075, 0.208, 0.079, 0.202, 0.103, 0.018, 0.095, -0.074, -0.110, 1.734, 1.748, 1.752, 1.762, 1.756)
    j_mid     = jaw_shell_ring(0.029, 0.208, 0.043, 0.224, 0.084, 0.208, 0.088, 0.202, 0.112, 0.018, 0.100, -0.076, -0.112, 1.792, 1.806, 1.824, 1.828, 1.820)
    j_top     = jaw_shell_ring(0.031, 0.204, 0.046, 0.220, 0.094, 0.206, 0.098, 0.200, 0.120, 0.018, 0.104, -0.078, -0.114, 1.844, 1.862, 1.900, 1.898, 1.886)
    j_sill    = jaw_shell_ring(0.031, 0.194, 0.044, 0.198, 0.090, 0.190, 0.094, 0.188, 0.114, 0.018, 0.098, -0.074, -0.110, 1.848, 1.866, 1.902, 1.900, 1.888)

    jaw_rim_cols  = ["STEEL_DARK", "STEEL_BRIGHT", "STEEL_MAIN",  "STEEL_DARK", "STEEL_FACET", "STEEL_DARK", "STEEL_DARK", "STEEL_FACET", "STEEL_DARK", "STEEL_LIGHT",  "STEEL_BRIGHT", "STEEL_DARK"]
    jaw_low_cols  = ["STEEL_DARK", "STEEL_LIGHT",  "STEEL_FACET", "STEEL_DARK", "STEEL_FACET", "STEEL_DARK", "STEEL_DARK", "STEEL_FACET", "STEEL_DARK", "STEEL_MAIN",   "STEEL_LIGHT",  "STEEL_DARK"]
    jaw_high_cols = ["STEEL_DARK", "STEEL_LIGHT",  "STEEL_MAIN",  "STEEL_DARK", "STEEL_FACET", "STEEL_DARK", "STEEL_DARK", "STEEL_FACET", "STEEL_DARK", "STEEL_LIGHT",  "STEEL_BRIGHT", "STEEL_DARK"]
    jaw_sill_cols = ["FACE_DARK",  "STEEL_BRIGHT", "STEEL_EDGE",  "FACE_DARK",  "STEEL_SHADE", "FACE_DARK",  "FACE_DARK",  "STEEL_SHADE", "FACE_DARK",  "STEEL_EDGE",   "STEEL_BRIGHT", "FACE_DARK"]

    mb_jaw.add_loft(
        [j_under, j_bot_lip, j_mid, j_top, j_sill],
        weights=w, mat="METAL",
        colors=[jaw_rim_cols, jaw_low_cols, jaw_high_cols, jaw_sill_cols],
        closed_ring=False,
    )

    # 3. MEVisorCanonical: Crisp Cyan L-Visor Bars (`MAVisorGlow`)
    mb_visor = MeshBuilder(["MAVisorGlow"])
    for sign in (-1.0, 1.0):
        eye_pts = [
            (sign * 0.0165, 0.224, 1.880),
            (sign * 0.0880, 0.208, 1.894),
            (sign * 0.0860, 0.208, 1.875),
            (sign * 0.0165, 0.224, 1.862),
        ]
        mb_visor.add_flat_beveled_plate(
            eye_pts, normal_dir=(sign * 0.18, 0.98, 0.0), thickness=0.007, bevel_inset=0.14, weights=w,
            mat="VISOR", col_face="WHITE", col_edge="WHITE", col_side="WHITE", col_back="WHITE"
        )
        vert_pts = [
            (sign * 0.0165, 0.224, 1.866),
            (sign * 0.0295, 0.220, 1.868),
            (sign * 0.0260, 0.212, 1.738),
            (sign * 0.0155, 0.215, 1.736),
        ]
        mb_visor.add_flat_beveled_plate(
            vert_pts, normal_dir=(sign * 0.12, 0.99, 0.0), thickness=0.007, bevel_inset=0.14, weights=w,
            mat="VISOR", col_face="WHITE", col_edge="WHITE", col_side="WHITE", col_back="WHITE"
        )

    # 4. MECrestCanonical: Cohesive Swept Spartan Crimson Plume Crest (`CANONICAL_HELMET_FOCUS_KEEP.png`)
    mb_crest = MeshBuilder(["MAKitMatte"])
    # Continuous 5-section swept fin + subtle V-notches along the top profile
    crest_sections = [
        # (y_bot, z_bot, y_top, z_top, hw_bot, hw_top)
        ( 0.152, 2.008,  0.172, 2.118, 0.024, 0.019), # Forward-leaning prow face
        ( 0.048, 2.012,  0.042, 2.112, 0.024, 0.019), # Main crest peak
        (-0.036, 1.988, -0.056, 2.064, 0.022, 0.018), # Mid-crest sweep
        (-0.102, 1.926, -0.142, 1.988, 0.020, 0.016), # Rear-upper tail
        (-0.124, 1.812, -0.174, 1.858, 0.018, 0.014), # Lower nape tail
    ]
    for idx in range(len(crest_sections) - 1):
        yfb, zfb, yft, zft, hwb, hwt = crest_sections[idx]
        ybb, zbb, ybt, zbt, hwbb, hwbt = crest_sections[idx + 1]
        def c_ring(yf, zf, yb, zb, hw_f, hw_b):
            return [
                ( 0.000,       yf + 0.003, zf),
                (-hw_f,        yf,         zf),
                (-hw_b,        yb,         zb),
                ( 0.000,       yb - 0.003, zb),
                ( hw_b,        yb,         zb),
                ( hw_f,        yf,         zf),
            ]
        r_b = c_ring(yfb, zfb, ybb, zbb, hwb, hwbb)
        r_m = c_ring(0.15*yfb+0.85*yft, 0.15*zfb+0.85*zft, 0.15*ybb+0.85*ybt, 0.15*zbb+0.85*zbt, hwt, hwbt)
        r_t = c_ring(yft, zft, ybt, zbt, hwt*0.78, hwbt*0.78)
        cols_side = ["CLOTH_LIGHT", "CLOTH_SHADE", "CLOTH_MAIN", "CLOTH_SHADE", "CLOTH_MAIN", "CLOTH_BRIGHT"]
        cols_top  = ["CLOTH_BRIGHT","CLOTH_MAIN",  "CLOTH_LIGHT","CLOTH_MAIN",  "CLOTH_LIGHT","CLOTH_BRIGHT"]
        mb_crest.add_loft([r_b, r_m, r_t], weights=w, mat="MATTE", colors=[cols_side, cols_top], closed_ring=True, cap_start=(idx==0), cap_end=(idx==len(crest_sections)-2), cap_color="CLOTH_BRIGHT")

    return (
        transform_helmet_v29(mb_shell),
        transform_helmet_v29(mb_jaw),
        transform_helmet_v29(mb_visor),
        transform_helmet_v29(mb_crest),
    )


def build_v29_pauldron_pair():
    """
    A1 & A3. Descending 3-Tier Shoulder Silhouette (`shoulder.png` & `CANONICAL_SPELLBLADE_KEEP.png`):
      - Reshapes the chiseled multi-planar slate-steel pauldron & champagne-brass perimeter frame
        by narrowing its lateral bulk (`0.85x` in X) and rotating it `-9.5 deg` downward from the
        collar pivot `(-0.175, 0.0, 1.665)` so it follows a sleek descending deltoid line rather
        than puffing out horizontally.
      - Mechanically and anatomically connects two overlapping dark-steel lower deltoid/bicep lames
        underneath over the dark charcoal arming core.
    """
    pauldron_l = rs_prev.build_pauldron_left()
    piv_x, piv_z = -0.175, 1.665
    rad = math.radians(9.5) # Rotate outer wing downward along deltoid!
    cs, ss = math.cos(rad), math.sin(rad)
    for i, (x, y, z) in enumerate(pauldron_l.verts):
        dx = (x - piv_x) * 0.84
        dz = (z - piv_z) * 0.88
        nx = piv_x + dx * cs - dz * ss + 0.018
        nz = piv_z + dx * ss + dz * cs - 0.018
        ny = y * 0.88 - 0.016
        pauldron_l.verts[i] = (float(nx), float(ny), float(nz))

    # Add 2 overlapping articulated deltoid/bicep lames stepping down cleanly from under the pauldron rim
    ua_h, ua_t = (-0.255, -0.020, 1.545), (-0.345, 0.095, 1.255)
    ua_frame = BoneFrame(ua_h, ua_t, up_hint=(0.0, 1.0, 0.0))
    def r_ring(t, ru, rv):
        d = 0.74
        pts = [(0, rv), (ru*d, rv*d), (ru, 0), (ru*d, -rv*d), (0, -rv), (-ru*d, -rv*d), (-ru, 0), (-ru*d, rv*d)]
        return [ua_frame.pt(u, v, t - 0.10 * (u / max(ru, 1e-4))) for (u, v) in pts]

    for t0, t1, t2, r_a, r_b in [(0.06, 0.34, 0.40, 0.098, 0.104), (0.38, 0.66, 0.72, 0.092, 0.096)]:
        pauldron_l.add_loft(
            [r_ring(t0, r_a, r_a), r_ring(t1, r_b, r_b), r_ring(t2, r_b - 0.005, r_b - 0.005)],
            weights="upper_arm.L", mat="METAL",
            colors=[["STEEL_DARK", "UNDERSUIT_DARK", "UNDERSUIT_DARK", "STEEL_DARK", "STEEL_SHADE", "STEEL_MAIN", "STEEL_LIGHT", "STEEL_FACET"], "STEEL_BRIGHT"],
            closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK"
        )

    pauldron_r = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    pauldron_r.mirror_from(pauldron_l)
    return pauldron_l, pauldron_r


def build_v29_breastplate_scarf_and_belt():
    """
    A1, A3, A4 & A5. Athletic V-Tapered Cuirass, Restrained Breastplate Trim, Dark Core Underarm
    Gussets, Fitted War-Belt & Side Utility Pouches (`CANONICAL_SPELLBLADE_KEEP.png`):
      - Narrows the waist (`rx = 0.146`) and ribcage (`rx = 0.162 -> 0.188`) by ~20% vs v2.8,
        eliminating the barrel-chested corset look.
      - Reduces the pale V-shaped breastplate trim from 42 mm wide down to a crisp 13 mm beveled
        champagne-brass edge rim around a sharply keeled mid-slate steel plastron.
      - Exposes the deep charcoal-black undersuit core (`UNDERSUIT_DARK`) under the arms and
        between the lateral abdominal lames for strong "dark core, bright edges" depth.
      - Adds sculpted leather side-hip utility pouches and a fitted silver-buckled war-belt.
    """
    mb = MeshBuilder(["MAKitMatte", "MAKitMetal"])

    def core_ring(rx, yf, yb, z):
        return [
            ( 0.000,      yf,        z),
            (-rx * 0.72,  yf * 0.75, z),
            (-rx,         0.000,     z),
            (-rx * 0.72,  yb * 0.75, z),
            ( 0.000,      yb,        z),
            ( rx * 0.72,  yb * 0.75, z),
            ( rx,         0.000,     z),
            ( rx * 0.72,  yf * 0.75, z),
        ]

    # Slimmer, athletic dark charcoal undersuit core (`UNDERSUIT_DARK`)
    c_rings = [
        core_ring(0.148, 0.128, -0.120, 0.950),
        core_ring(0.142, 0.142, -0.128, 1.170),
        core_ring(0.146, 0.154, -0.134, 1.300),
        core_ring(0.178, 0.172, -0.148, 1.520),
        core_ring(0.114, 0.148, -0.106, 1.800),
    ]
    mb.add_loft(c_rings, weights=["pelvis", "pelvis", "spine", "chest", "chest"], mat="MATTE", colors="UNDERSUIT_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK")

    # Fitted, inward-tapering lateral abdominal & back lames (`rx = 0.154` at waist -> `0.194` at chest)
    def torso_ring(rx, yf_c, yf_s, yb_c, yb_s, z):
        return [
            ( 0.000,      yf_c,   z),
            (-rx * 0.86,  yf_s,   z),
            (-rx,        -0.012,  z),
            (-rx * 0.92,  yb_s,   z),
            ( 0.000,      yb_c,   z),
            ( rx * 0.92,  yb_s,   z),
            ( rx,        -0.012,  z),
            ( rx * 0.86,  yf_s,   z),
        ]

    for z_bot, z_top, rx_b, rx_t, yf_b, yf_t, yb_b, yb_t, w_tag in [
        (1.265, 1.365, 0.154, 0.170, 0.184, 0.196, -0.146, -0.154, "spine"),
        (1.360, 1.468, 0.168, 0.186, 0.194, 0.208, -0.152, -0.160, "chest"),
        (1.462, 1.560, 0.184, 0.198, 0.204, 0.214, -0.158, -0.166, "chest"),
    ]:
        tr0 = torso_ring(rx_b, yf_b, yf_b - 0.022, yb_b, yb_b + 0.014, z_bot)
        tr1 = torso_ring(rx_t, yf_t, yf_t - 0.018, yb_t, yb_t + 0.014, z_top - 0.008)
        tr2 = torso_ring(rx_t - 0.006, yf_t - 0.006, yf_t - 0.022, yb_t + 0.005, yb_t + 0.016, z_top)
        # Dark core lateral plates with subtle steel edge highlight
        lame_c = ["STEEL_DARK",  "STEEL_DARK",  "FACE_DARK",   "STEEL_DARK",  "STEEL_DARK",  "FACE_DARK",   "STEEL_DARK",  "STEEL_SHADE"]
        top_c  = ["STEEL_FACET", "STEEL_MAIN",  "STEEL_SHADE", "STEEL_FACET", "STEEL_FACET", "STEEL_SHADE", "STEEL_MAIN",  "STEEL_LIGHT"]
        mb.add_loft([tr0, tr1, tr2], weights=w_tag, mat="METAL", colors=[lame_c, top_c], closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    # Keeled Slate-Steel Breastplate with Restrained 13mm Champagne-Brass Edge Trim (`CANONICAL_SPELLBLADE_KEEP.png`)
    def plackart_row(x_gold_out, x_gold_in, y_side, y_keel, z):
        y_back = y_side - 0.028
        return [
            (-x_gold_out, y_back,           z),
            (-x_gold_out, y_side + 0.008,   z),
            (-x_gold_in,  y_side + 0.011,   z),
            (-x_gold_in,  y_side + 0.002,   z),
            ( 0.000,      y_keel,           z),
            ( x_gold_in,  y_side + 0.002,   z),
            ( x_gold_in,  y_side + 0.011,   z),
            ( x_gold_out, y_side + 0.008,   z),
            ( x_gold_out, y_back,           z),
        ]

    # Note: x_gold_out - x_gold_in is now a sleek, restrained 0.013 m (13 mm) instead of 0.042 m!
    pr0 = plackart_row(0.018, 0.004, 0.198, 0.218, 1.272) # Crisp V-point above belt buckle
    pr1 = plackart_row(0.118, 0.104, 0.220, 0.262, 1.418) # Lower pectoral keel
    pr2 = plackart_row(0.148, 0.134, 0.218, 0.256, 1.528) # Upper pectoral swell
    pr3 = plackart_row(0.138, 0.125, 0.198, 0.226, 1.592) # Recessed dark upper gorget under scarf

    row_cols_low = ["BRASS_SHADE", "BRASS_MAIN",  "BRASS_EDGE", "STEEL_SHADE", "STEEL_MAIN",  "BRASS_EDGE", "BRASS_MAIN",  "BRASS_SHADE", "FACE_DARK"]
    row_cols_mid = ["BRASS_MAIN",  "BRASS_LIGHT", "BRASS_EDGE", "STEEL_MAIN",  "STEEL_BRIGHT","BRASS_EDGE", "BRASS_LIGHT", "BRASS_MAIN",  "FACE_DARK"]
    row_cols_top = ["BRASS_SHADE", "BRASS_MAIN",  "BRASS_DARK", "FACE_DARK",   "STEEL_DARK",  "BRASS_DARK", "BRASS_MAIN",  "BRASS_SHADE", "FACE_DARK"]

    mb.add_loft(
        [pr0, pr1, pr2, pr3],
        weights=["spine", "chest", "chest", "chest"],
        mat="METAL",
        colors=[row_cols_low, row_cols_mid, row_cols_top],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK",
    )

    # Compact, Snug 2-Fold V-Notched Crimson Neck Scarf + Rear Cape Collar (`CANONICAL_SPELLBLADE_KEEP.png`)
    def scarf_ring(rx, yf_v, yf_side, yb_v, yb_side, z_front_v, z_side, z_back):
        return [
            ( 0.000,      yf_v,     z_front_v),
            (-rx * 0.62,  yf_side,  z_side),
            (-rx,         0.010,    z_side + 0.010),
            (-rx * 0.82,  yb_side,  z_back + 0.006),
            ( 0.000,      yb_v,     z_back),
            ( rx * 0.82,  yb_side,  z_back + 0.006),
            ( rx,         0.010,    z_side + 0.010),
            ( rx * 0.62,  yf_side,  z_side),
        ]

    s0     = scarf_ring(0.142, 0.228, 0.194, -0.168, -0.152, 1.532, 1.604, 1.548)
    s1_out = scarf_ring(0.178, 0.240, 0.204, -0.184, -0.166, 1.592, 1.664, 1.614)
    s1_in  = scarf_ring(0.164, 0.222, 0.190, -0.170, -0.152, 1.602, 1.672, 1.622)
    s2_out = scarf_ring(0.182, 0.230, 0.196, -0.182, -0.164, 1.660, 1.744, 1.712)
    s3     = scarf_ring(0.140, 0.184, 0.168, -0.142, -0.128, 1.706, 1.768, 1.748)

    scarf_cols_bright = ["CLOTH_BRIGHT", "CLOTH_LIGHT", "CLOTH_MAIN", "CLOTH_LIGHT", "CLOTH_BRIGHT", "CLOTH_MAIN", "CLOTH_LIGHT", "CLOTH_BRIGHT"]
    scarf_cols_mid    = ["CLOTH_LIGHT",  "CLOTH_MAIN",  "CLOTH_SHADE","CLOTH_MAIN",  "CLOTH_LIGHT",  "CLOTH_SHADE","CLOTH_MAIN",  "CLOTH_LIGHT"]
    scarf_cols_crev   = ["CLOTH_DARK"] * 8

    mb.add_loft(
        [s0, s1_out, s1_in, s2_out, s3],
        weights="chest", mat="MATTE",
        colors=[scarf_cols_mid, scarf_cols_crev, scarf_cols_bright, scarf_cols_mid],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="CLOTH_DARK"
    )

    # Trapezoidal Upper-Back Crimson Collar Drape (`back.png`)
    collar_pts = [
        (-0.148, -0.162, 1.648),
        ( 0.148, -0.162, 1.648),
        ( 0.164, -0.174, 1.510),
        (-0.164, -0.174, 1.510),
    ]
    mb.add_flat_beveled_plate(
        collar_pts, normal_dir=(0.0, -0.98, 0.16), thickness=0.016, bevel_inset=0.14,
        weights="chest", mat="MATTE", col_face="CLOTH_MAIN", col_edge="CLOTH_BRIGHT", col_side="CLOTH_DARK"
    )

    # Fitted Saddle-Leather War-Belt (`rx = 0.162`), Silver-Steel Buckle, Diamond Studs & Side Utility Pouches
    def belt_ring(rx, yf, yb, z):
        return [
            ( 0.000,      yf,        z),
            (-rx * 0.78,  yf * 0.84, z),
            (-rx,        -0.010,     z),
            (-rx * 0.84,  yb * 0.88, z),
            ( 0.000,      yb,        z),
            ( rx * 0.84,  yb * 0.88, z),
            ( rx,        -0.010,     z),
            ( rx * 0.78,  yf * 0.84, z),
        ]
    b_r0 = belt_ring(0.164, 0.194, -0.154, 1.186)
    b_r1 = belt_ring(0.166, 0.198, -0.156, 1.266)
    b_r2 = belt_ring(0.156, 0.186, -0.148, 1.272)
    belt_cols = ["LEATHER_MAIN", "LEATHER_LIGHT", "LEATHER_SHADE", "LEATHER_DARK", "LEATHER_MAIN", "LEATHER_DARK", "LEATHER_SHADE", "LEATHER_LIGHT"]
    mb.add_loft([b_r0, b_r1, b_r2], weights="pelvis", mat="MATTE", colors=[belt_cols, "LEATHER_DARK"], closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_DARK")

    # Framed Silver-Steel Center Belt Buckle + Prong
    bk_corners = [(-0.044, 0.200, 1.274), (0.044, 0.200, 1.274), (0.044, 0.198, 1.178), (-0.044, 0.198, 1.178)]
    rs_prev.add_framed_rect_plate(
        mb, bk_corners, normal_dir=(0.0, 1.0, 0.04), thickness=0.016, border_frac=0.28, weights="pelvis",
        mat_border="METAL", col_border="STEEL_LIGHT", col_border_edge="STEEL_BRIGHT",
        mat_inner="MATTE", col_inner="LEATHER_DARK", open_top=False
    )
    mb.add_beveled_box(
        center=(0.010, 0.208, 1.226), half_extents=(0.018, 0.006, 0.007),
        bevel=0.18, weights="pelvis", mat="METAL", col_main="STEEL_BRIGHT", col_edge="STEEL_LIGHT", col_dark="STEEL_DARK"
    )

    # Two Diamond Champagne-Brass Belt Bosses flanking the buckle
    for sign in (-1.0, 1.0):
        mb.add_diamond_boss(
            center=(sign * 0.098, 0.184, 1.226), normal=(sign * 0.42, 0.90, 0.0), up_vec=(0.0, 0.0, 1.0),
            radius_u=0.028, radius_v=0.032, height=0.018, weights="pelvis", mat="METAL",
            col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_base="BRASS_SHADE"
        )
        # Side-hip sculpted leather utility pouches with brass flap clasps (`A4`)
        pouch_c = (sign * 0.166, -0.020, 1.195)
        mb.add_beveled_box(
            center=pouch_c, half_extents=(0.018, 0.042, 0.046),
            axes=((sign, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)),
            bevel=0.20, weights="pelvis", mat="MATTE", col_main="LEATHER_MAIN", col_edge="LEATHER_LIGHT", col_dark="LEATHER_DARK"
        )
        mb.add_beveled_box(
            center=(sign * 0.182, -0.020, 1.212), half_extents=(0.006, 0.012, 0.012),
            bevel=0.18, weights="pelvis", mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
        )

    return mb


def build_v29_arm_and_gauntlet(is_right=False, closed_left_grip=False):
    """
    A1, A4 & A5. Tapered Anatomical Arms, Elbow Articulation, Wrist Taper & Sleek Gauntlets:
      - Replaces thick cylindrical stove-pipe arms with a dark charcoal undersuit core (`r = 0.068`),
        two fitted outer-bicep steel lames (`leaving inner bicep dark`), a crisp V-winged brass/steel
        elbow couter with a dark inner elbow crease, and a strongly tapered octagonal vambrace
        (`r = 0.096` at upper forearm tapering to `r = 0.062` at wrist!).
      - Flares the brass-trimmed gauntlet cuff backward over the narrow wrist and sculpts a
        2-piece beveled dorsal hand plate + 5 articulated 3-segment armored digits.
    """
    mb = MeshBuilder(["MAKitMatte", "MAKitMetal"])
    suffix = ".R" if is_right else ".L"
    sign = 1.0 if is_right else -1.0

    if not is_right:
        ua_h, ua_t = (-0.245, -0.020, 1.565), (-0.345,  0.095, 1.255)
        fa_h, fa_t = (-0.345,  0.095, 1.255), (-0.428,  0.455, 1.185)
        ha_h, ha_t = (-0.428,  0.455, 1.185), (-0.472,  0.565, 1.182)
    else:
        ua_h, ua_t = ( 0.265, -0.045, 1.575), ( 0.385, -0.128, 1.335)
        fa_h, fa_t = ( 0.385, -0.128, 1.335), ( 0.465,  0.005, 1.060)
        ha_h, ha_t = ( 0.465,  0.005, 1.060), ( 0.495,  0.035, 0.940)

    ua_frame = BoneFrame(ua_h, ua_t, up_hint=(0.0, 1.0, 0.0))
    fa_frame = BoneFrame(fa_h, fa_t, up_hint=(0.0, 1.0, 0.0))
    ua_w = f"upper_arm{suffix}"
    fa_w = f"forearm{suffix}"
    ha_w = f"hand{suffix}"
    out_u = -sign

    def oct_ring(frame, t, ru, rv, ridge_u=0.0, ridge_v=0.0, tilt_u=0.0, tilt_v=0.0):
        d = 0.74
        pts_uv = [
            ( 0.0,          rv + ridge_v),
            ( ru * d,       rv * d),
            ( ru + ridge_u, 0.0),
            ( ru * d,      -rv * d),
            ( 0.0,         -rv - ridge_v * 0.5),
            (-ru * d,      -rv * d),
            (-ru - ridge_u, 0.0),
            (-ru * d,       rv * d),
        ]
        return [frame.pt(u, v, t + tilt_u * (u / max(ru, 1e-4)) + tilt_v * (v / max(rv, 1e-4))) for (u, v) in pts_uv]

    # 1. Slim Dark-Charcoal Upper-Arm Undersuit Core (`r = 0.068 -> 0.062`)
    mb.add_loft(
        [oct_ring(ua_frame, 0.00, 0.068, 0.068), oct_ring(ua_frame, 0.85, 0.064, 0.064), oct_ring(ua_frame, 1.05, 0.060, 0.060)],
        weights=ua_w, mat="MATTE", colors="UNDERSUIT_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK"
    )

    # Two Fitted Upper-Arm Rerebrace Plates (Outer lateral faces lit steel, inner medial faces dark core!)
    tilt_u_val = -sign * 0.12
    for t_a, t_m, t_b, r_top, r_bot in [(0.16, 0.48, 0.54, 0.088, 0.094), (0.54, 0.84, 0.90, 0.084, 0.088)]:
        if not is_right:
            lame_cols = ["STEEL_DARK", "UNDERSUIT_DARK", "UNDERSUIT_DARK", "STEEL_DARK", "STEEL_SHADE", "STEEL_MAIN", "STEEL_LIGHT", "STEEL_FACET"]
            edge_cols = ["STEEL_FACET","UNDERSUIT_DARK", "UNDERSUIT_DARK", "STEEL_FACET","STEEL_MAIN",  "STEEL_LIGHT","STEEL_BRIGHT","STEEL_LIGHT"]
        else:
            lame_cols = ["STEEL_DARK", "STEEL_FACET", "STEEL_LIGHT", "STEEL_MAIN", "STEEL_SHADE", "STEEL_DARK", "UNDERSUIT_DARK", "UNDERSUIT_DARK"]
            edge_cols = ["STEEL_FACET","STEEL_LIGHT", "STEEL_BRIGHT","STEEL_LIGHT","STEEL_MAIN",  "STEEL_FACET","UNDERSUIT_DARK", "UNDERSUIT_DARK"]
        mb.add_loft(
            [
                oct_ring(ua_frame, t_a, r_top, r_top, ridge_u=0.008, ridge_v=0.008, tilt_u=tilt_u_val),
                oct_ring(ua_frame, t_m, r_bot, r_bot, ridge_u=0.010, ridge_v=0.010, tilt_u=tilt_u_val),
                oct_ring(ua_frame, t_b, r_bot - 0.004, r_bot - 0.004, ridge_u=0.008, ridge_v=0.008, tilt_u=tilt_u_val),
            ],
            weights=ua_w, mat="METAL", colors=[lame_cols, edge_cols], closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK"
        )

    # 2. Slim Dark-Charcoal Forearm Undersuit & Elbow Crease Core (`r = 0.058 -> 0.048`)
    mb.add_loft(
        [oct_ring(fa_frame, -0.04, 0.060, 0.060), oct_ring(fa_frame, 1.04, 0.048, 0.048)],
        weights=fa_w, mat="MATTE", colors="UNDERSUIT_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK"
    )

    # Articulated V-Peaked Elbow Couter (`t = -0.02 .. 0.18`) with dark inner elbow crease
    fa_tilt_u = -sign * 0.09
    c0 = oct_ring(fa_frame, -0.02, 0.088, 0.084, ridge_u=0.014, ridge_v=0.010, tilt_u=fa_tilt_u)
    c1 = oct_ring(fa_frame,  0.14, 0.096, 0.092, ridge_u=0.016, ridge_v=0.012, tilt_u=fa_tilt_u)
    c2 = oct_ring(fa_frame,  0.18, 0.086, 0.082, ridge_u=0.010, ridge_v=0.008, tilt_u=fa_tilt_u)
    if not is_right:
        couter_cols = ["UNDERSUIT_DARK", "UNDERSUIT_DARK", "BRASS_SHADE", "BRASS_MAIN", "BRASS_BRIGHT", "BRASS_BRIGHT", "BRASS_MAIN", "UNDERSUIT_DARK"]
    else:
        couter_cols = ["UNDERSUIT_DARK", "BRASS_MAIN", "BRASS_BRIGHT", "BRASS_BRIGHT", "BRASS_MAIN", "BRASS_SHADE", "UNDERSUIT_DARK", "UNDERSUIT_DARK"]
    mb.add_loft([c0, c1, c2], weights=fa_w, mat="METAL", colors=[couter_cols, "FACE_DARK"], closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    # Strongly Tapered Octagonal Forearm Vambrace (`r = 0.094` at t=0.18 tapering down to `r = 0.062` at wrist t=0.80!)
    v0 = oct_ring(fa_frame, 0.18, 0.094, 0.090, ridge_u=0.012, ridge_v=0.012, tilt_u=fa_tilt_u)
    v1 = oct_ring(fa_frame, 0.50, 0.080, 0.076, ridge_u=0.010, ridge_v=0.010)
    v2 = oct_ring(fa_frame, 0.80, 0.062, 0.058, ridge_u=0.007, ridge_v=0.007)
    vam_cols = ["STEEL_MAIN", "LEATHER_DARK", "LEATHER_MAIN", "STEEL_FACET", "STEEL_LIGHT", "STEEL_BRIGHT", "STEEL_LIGHT", "STEEL_MAIN"]
    mb.add_loft([v0, v1, v2], weights=fa_w, mat="METAL", colors=[vam_cols, vam_cols], closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK")

    # Recessed dark fuller groove on outer vambrace face
    mb.add_beveled_box(
        center=fa_frame.pt(out_u * 0.078, 0.012, 0.46),
        half_extents=(0.006, 0.010, 0.095),
        axes=(fa_frame.u, fa_frame.v, fa_frame.w),
        bevel=0.16, weights=fa_w, mat="MATTE", col_main="FACE_DARK", col_edge="STEEL_DARK", col_dark="FACE_DARK"
    )

    # Flared Champagne-Brass Gauntlet Wrist Cuff (`r = 0.060` at t=0.79 flaring to `0.074` at t=0.95)
    wc0 = oct_ring(fa_frame, 0.79, 0.062, 0.058, ridge_u=0.006, ridge_v=0.006)
    wc1 = oct_ring(fa_frame, 0.94, 0.074, 0.068, ridge_u=0.009, ridge_v=0.009)
    wc2 = oct_ring(fa_frame, 1.00, 0.064, 0.058, ridge_u=0.006, ridge_v=0.006)
    cuff_cols = ["BRASS_MAIN", "BRASS_SHADE", "BRASS_DARK", "BRASS_MAIN", "BRASS_BRIGHT", "BRASS_BRIGHT", "BRASS_MAIN", "BRASS_SHADE"]
    mb.add_loft([wc0, wc1, wc2], weights=fa_w, mat="METAL", colors=[cuff_cols, "FACE_DARK"], closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    # 3. Right Hand (`hand.R`) Closed Sword Grip (`CANONICAL_HAND_DETAIL_KEEP.png`)
    if is_right:
        wrist_pt = np.array(fa_t, dtype=np.float32)
        b_dir = np.array([0.54, 0.67, -0.508], dtype=np.float32)
        b_dir /= np.linalg.norm(b_dir)
        f_out = np.array([0.48, 0.76, 0.44], dtype=np.float32)
        f_out -= np.dot(f_out, b_dir) * b_dir
        f_out /= np.linalg.norm(f_out)
        f_perp = np.cross(b_dir, f_out)
        if f_perp[2] > 0:
            f_perp = -f_perp
        f_perp /= np.linalg.norm(f_perp)
        hand_root = wrist_pt + 0.024 * fa_frame.w - 0.010 * f_out

        # Dark leather palm core
        mb.add_beveled_box(
            center=hand_root + 0.036 * f_perp,
            half_extents=(0.046, 0.026, 0.040),
            axes=(b_dir, f_out, f_perp),
            bevel=0.18, weights=ha_w, mat="MATTE", col_main="LEATHER_DARK", col_edge="LEATHER_SHADE", col_dark="FACE_DARK"
        )
        # 2-Piece Beveled Dorsal Gauntlet Plate (Steel metacarpal + Champagne-Brass knuckle guard)
        mb.add_beveled_box(
            center=hand_root + 0.020 * f_perp + 0.024 * f_out,
            half_extents=(0.050, 0.012, 0.022),
            axes=(b_dir, f_out, f_perp),
            bevel=0.18, weights=ha_w, mat="METAL", col_main="STEEL_MAIN", col_edge="STEEL_BRIGHT", col_dark="STEEL_DARK"
        )
        mb.add_beveled_box(
            center=hand_root + 0.056 * f_perp + 0.026 * f_out,
            half_extents=(0.052, 0.014, 0.018),
            axes=(b_dir, f_out, f_perp),
            bevel=0.18, weights=ha_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
        )
        # 4 Articulated 3-Segment Curled Fingers wrapping around the leather hilt (`CANONICAL_HAND_DETAIL_KEEP.png`)
        for f_idx, s_off in enumerate([-0.036, -0.012, 0.012, 0.036]):
            knuckle = hand_root + s_off * b_dir + 0.072 * f_perp + 0.018 * f_out
            p1 = knuckle + 0.034 * f_perp - 0.008 * f_out
            p2 = p1      + 0.012 * f_perp - 0.036 * f_out
            p3 = p2      - 0.028 * f_perp - 0.014 * f_out
            for sa, sb, col_m in [(knuckle, p1, "STEEL_LIGHT"), (p1, p2, "STEEL_MAIN"), (p2, p3, "STEEL_DARK")]:
                sf = BoneFrame(sa, sb, up_hint=f_out)
                mb.add_beveled_box(
                    center=0.5 * (sa + sb),
                    half_extents=(0.011, 0.010, 0.52 * sf.length),
                    axes=(b_dir, sf.v, sf.w),
                    bevel=0.16, weights=ha_w, mat="METAL", col_main=col_m, col_edge="STEEL_BRIGHT", col_dark="FACE_DARK"
                )
        # Articulated 2-Segment Armored Thumb locking over the grip
        t0 = hand_root + 0.048 * b_dir + 0.018 * f_perp - 0.012 * f_out
        t1 = t0 + 0.022 * b_dir + 0.034 * f_perp - 0.010 * f_out
        t2 = t1 - 0.008 * b_dir + 0.028 * f_perp + 0.016 * f_out
        for sa, sb, col_m in [(t0, t1, "STEEL_LIGHT"), (t1, t2, "STEEL_FACET")]:
            sf = BoneFrame(sa, sb, up_hint=f_out)
            mb.add_beveled_box(
                center=0.5 * (sa + sb),
                half_extents=(0.014, 0.012, 0.48 * sf.length),
                axes=(b_dir, sf.v, sf.w),
                bevel=0.18, weights=ha_w, mat="METAL", col_main=col_m, col_edge="STEEL_BRIGHT", col_dark="FACE_DARK"
            )
    else:
        # Left hand open/closed is attached via `build_v29_left_hand_only` in GLB, or embedded for `.blend`
        lh = b28.build_v28_left_hand_only(closed_grip=closed_left_grip)
        for vi, (pos, wdict) in enumerate(zip(lh.verts, lh.weights)):
            mb.add_vert(pos, wdict)
        # For `.blend` MEArm.L, we use `build_v28_left_hand_only` polygons directly
    return mb


def build_v29_hero_broadsword(first_person=False):
    """
    A4 & A5. Refined Spellblade Broadsword (`CANONICAL_HAND_DETAIL_KEEP.png` — "CHUNKY. ELEGANT. READABLE."):
      - Eliminates the uniformly thick gray slab appearance of v2.8!
      - Sculpts a true recessed dark-slate central fuller table (`thick_fuller = 0.006 m`, `STEEL_DARK`)
        flanked by wide, sharply sloped bright-steel cutting bevels (`STEEL_LIGHT` / `STEEL_BRIGHT`)
        tapering to a 1.2 mm razor edge (`w_half = 0.098 m`) and a chiseled diamond spear-point tip.
      - Sculpts notched fishtail V-tipped champagne-brass crossguard quillons, a raised diamond
        ricasso with a faceted deep-crimson ruby, a 4-ribbed leather grip, and a faceted brass pommel.
    """
    mb = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    w = "hand.R"

    if not first_person:
        fa_h, fa_t = (0.385, -0.128, 1.335), (0.465, 0.005, 1.060)
        fa_frame = BoneFrame(fa_h, fa_t, up_hint=(0.55, 0.72, 0.42))
        wrist_pt = np.array(fa_t, dtype=np.float32)
        w_fa = fa_frame.w.copy()

        b_dir = np.array([0.54, 0.67, -0.508], dtype=np.float32)
        b_dir /= np.linalg.norm(b_dir)
        v_dir = np.array([0.48, 0.76, 0.44], dtype=np.float32)
        v_dir -= np.dot(v_dir, b_dir) * b_dir
        v_dir /= np.linalg.norm(v_dir)
        u_dir = np.cross(v_dir, b_dir)
        u_dir /= np.linalg.norm(u_dir)

        f_perp = np.cross(b_dir, v_dir)
        if f_perp[2] > 0:
            f_perp = -f_perp
        f_perp /= np.linalg.norm(f_perp)
        hand_root = wrist_pt + 0.024 * w_fa - 0.010 * v_dir
        grip_c = hand_root + 0.096 * f_perp
        blade_end = 1.010
    else:
        grip_c = np.array([0.2913, 0.6893, -0.2932], dtype=np.float32)
        b_dir = np.array([0.2897, 0.7677, 0.5715], dtype=np.float32)
        b_dir /= np.linalg.norm(b_dir)
        u_dir = np.array([0.9754, -0.1610, -0.1509], dtype=np.float32)
        u_dir -= np.dot(u_dir, b_dir) * b_dir
        u_dir /= np.linalg.norm(u_dir)
        v_dir = np.cross(b_dir, u_dir)
        v_dir /= np.linalg.norm(v_dir)
        blade_end = 0.820

    def s_pt(u, v, s):
        return grip_c + s * b_dir + u * u_dir + v * v_dir

    # 1. Faceted Polyhedral Champagne-Brass Pommel
    p_rings = [
        [s_pt(0.006*np.cos(a), 0.006*np.sin(a), -0.285) for a in np.linspace(0, 2*np.pi, 8, endpoint=False)],
        [s_pt(0.052*np.cos(a), 0.044*np.sin(a), -0.240) for a in np.linspace(0, 2*np.pi, 8, endpoint=False)],
        [s_pt(0.048*np.cos(a), 0.040*np.sin(a), -0.195) for a in np.linspace(0, 2*np.pi, 8, endpoint=False)],
        [s_pt(0.028*np.cos(a), 0.024*np.sin(a), -0.172) for a in np.linspace(0, 2*np.pi, 8, endpoint=False)],
    ]
    p_c1 = ["BRASS_BRIGHT", "BRASS_MAIN", "BRASS_SHADE", "BRASS_DARK", "BRASS_SHADE", "BRASS_MAIN", "BRASS_BRIGHT", "BRASS_EDGE"]
    mb.add_loft(p_rings, weights=w, mat="METAL", colors=[p_c1, p_c1, p_c1], closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT")

    # 2. Ribbed Saddle-Leather Hilt Grip (`4 distinct cord ribs`)
    g_rings, g_cols = [], []
    for i, s_val in enumerate(np.linspace(-0.168, 0.076, 9)):
        rad_u = 0.021 if i % 2 == 0 else 0.026
        rad_v = 0.018 if i % 2 == 0 else 0.022
        g_rings.append([s_pt(rad_u*np.cos(a), rad_v*np.sin(a), s_val) for a in np.linspace(0, 2*np.pi, 8, endpoint=False)])
        if i < 8:
            g_cols.append("LEATHER_LIGHT" if i % 2 == 0 else "LEATHER_DARK")
    mb.add_loft(g_rings, weights=w, mat="MATTE", colors=g_cols, closed_ring=True)

    # 3. Raised Diamond Ricasso + Faceted Deep-Crimson Ruby + Notched Fishtail Brass Quillons
    s_guard = 0.098
    for n_sign, col_e in [(1.0, "BRASS_BRIGHT"), (-1.0, "BRASS_EDGE")]:
        mb.add_diamond_boss(
            center=s_pt(0.0, 0.0, s_guard), normal=n_sign * v_dir, up_vec=b_dir,
            radius_u=0.078, radius_v=0.076, height=0.040, weights=w, mat="METAL",
            col_main="BRASS_MAIN", col_edge=col_e, col_base="BRASS_SHADE"
        )
        mb.add_diamond_boss(
            center=s_pt(0.0, n_sign * 0.032, s_guard), normal=n_sign * v_dir, up_vec=b_dir,
            radius_u=0.032, radius_v=0.034, height=0.022, weights=w, mat="MATTE",
            col_main="RUBY_MAIN", col_edge="RUBY_BRIGHT", col_base="RUBY_SHADE"
        )

    for q_sign in (-1.0, 1.0):
        def quillon_ring(u_dist, hs, hv, s_shift=s_guard):
            return [
                s_pt(q_sign * u_dist,  0.0, s_shift + hs),
                s_pt(q_sign * u_dist,  hv,  s_shift),
                s_pt(q_sign * u_dist,  0.0, s_shift - hs),
                s_pt(q_sign * u_dist, -hv,  s_shift),
            ]
        qr0 = quillon_ring(0.038, 0.034, 0.028)
        qr1 = quillon_ring(0.125, 0.024, 0.020, s_shift=s_guard + 0.008)
        qr2 = quillon_ring(0.175, 0.044, 0.032, s_shift=s_guard + 0.022)
        mb.add_loft([qr0, qr1, qr2], weights=w, mat="METAL", colors=["BRASS_MAIN", "BRASS_BRIGHT"], closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_SHADE")
        # Twin V-notched fishtail points at each quillon tip (`CANONICAL_HAND_DETAIL_KEEP.png`)
        for prong_sign in (-1.0, 1.0):
            p_base = quillon_ring(0.172, 0.018, 0.024, s_shift=s_guard + 0.022 + prong_sign * 0.022)
            p_tip  = quillon_ring(0.204, 0.004, 0.005, s_shift=s_guard + 0.028 + prong_sign * 0.030)
            mb.add_loft([p_base, p_tip], weights=w, mat="METAL", colors=["BRASS_BRIGHT"], closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT")

    # 4. Sleek Fullered & Razor-Beveled Broadsword Blade (Eliminates thick gray slab!)
    # 10-vertex cross-section with a deep dark-slate central fuller table and bright razor bevels:
    def blade_section_v29(w_half, t_ridge, t_fuller, s_val, fuller_frac=0.44):
        u_f = w_half * fuller_frac
        u_r = w_half * (fuller_frac + 0.08)
        t_edge = 0.0012
        return [
            s_pt( w_half, 0.0,       s_val), # 0: Top/Right razor cutting edge
            s_pt( u_r,    t_ridge,   s_val), # 1: Front upper bevel ridge (bright specular line)
            s_pt( u_f,    t_fuller,  s_val), # 2: Front upper fuller wall
            s_pt(-u_f,    t_fuller,  s_val), # 3: Front lower fuller wall (wide dark central table: 2 -> 3)
            s_pt(-u_r,    t_ridge,   s_val), # 4: Front lower bevel ridge
            s_pt(-w_half, 0.0,       s_val), # 5: Bottom/Left razor cutting edge
            s_pt(-u_r,   -t_ridge,   s_val), # 6: Back lower bevel ridge
            s_pt(-u_f,   -t_fuller,  s_val), # 7: Back lower fuller wall
            s_pt( u_f,   -t_fuller,  s_val), # 8: Back upper fuller wall
            s_pt( u_r,   -t_ridge,   s_val), # 9: Back upper bevel ridge
        ]

    b0 = blade_section_v29(0.096, 0.013, 0.0055, 0.118, fuller_frac=0.44)
    b1 = blade_section_v29(0.094, 0.012, 0.0050, 0.450, fuller_frac=0.42)
    b2 = blade_section_v29(0.092, 0.011, 0.0050, 0.760, fuller_frac=0.36)
    # At b3 (spear-point transition), the central fuller closes into a sharp central diamond keel!
    b3 = blade_section_v29(0.052, 0.009, 0.0100, 0.895, fuller_frac=0.04)
    b4 = blade_section_v29(0.002, 0.001, 0.0010, blade_end, fuller_frac=0.02)

    # Faces around the 10-vertex ring:
    # 0 (0->1): Upper cutting bevel (STEEL_BRIGHT!)
    # 1 (1->2): Upper fuller step wall (STEEL_LIGHT)
    # 2 (2->3): Wide central fuller table (STEEL_DARK — dark core!)
    # 3 (3->4): Lower fuller step wall (STEEL_SHADE)
    # 4 (4->5): Lower cutting bevel (STEEL_MAIN / STEEL_LIGHT)
    # 5..9: Back side mirror
    cols_fuller = [
        "STEEL_BRIGHT", "STEEL_LIGHT", "STEEL_DARK",  "STEEL_SHADE", "STEEL_LIGHT",
        "STEEL_LIGHT",  "STEEL_SHADE", "STEEL_DARK",  "STEEL_LIGHT", "STEEL_BRIGHT"
    ]
    cols_spear = [
        "STEEL_BRIGHT", "STEEL_BRIGHT","STEEL_LIGHT", "STEEL_MAIN",  "STEEL_LIGHT",
        "STEEL_LIGHT",  "STEEL_MAIN",  "STEEL_LIGHT", "STEEL_BRIGHT","STEEL_BRIGHT"
    ]
    mb.add_loft(
        [b0, b1, b2, b3, b4],
        weights=w, mat="METAL",
        colors=[cols_fuller, cols_fuller, cols_spear, cols_spear],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_BRIGHT"
    )
    return mb


def build_v29_legs_greaves_and_boots(is_right=False):
    """
    A1, A4 & A5. Fitted Thigh Armor, Chiseled Steel Knee Poleyns (No Heavy Yellow Band!),
    Anatomical Tapered Shin Greaves, Sleek Hip Tassets & Wedged 5-Facet Sabatons (`boot.png`):
      - Preserves high-contrast dark charcoal gambeson thighs (`UNDERSUIT_DARK`) with fitted
        outer-front dark-steel cuisse plates (`STEEL_DARK` / `STEEL_FACET`).
      - Replaces the heavy horizontal yellow-gold knee band of v2.8 with a sleek, unified
        chiseled steel knee poleyn (`boot.png`) featuring a dark stepped upper recess, a thin
        8mm champagne-brass top bevel highlight, a 3-plane mid-slate steel shield face with
        L-stepped bevel recess, and a dark articulation gap behind and below the knee.
      - Tapers the front-keeled shin greave from `rx = 0.112` at the upper calf down to a
        fitted ankle (`rx = 0.082`), wrapped by the 38° V-angled dark-leather ankle strap.
      - Replaces the wide (`rx = 0.152`) blocky rectangular boot with a sleek, forward-tapered
        wedged sabaton (`rx_heel = 0.098`, `rx_mid = 0.112`, `fw_prow = 0.044`) with a dark
        treaded sole and stepped dorsal plates.
    """
    mb = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    suffix = ".R" if is_right else ".L"
    sign = 1.0 if is_right else -1.0
    yaw_deg = -7.5 if is_right else 7.5

    th_h = (sign * 0.168,  0.012, 1.060)
    th_t = (sign * 0.218,  0.042, 0.635)
    sh_h = (sign * 0.218,  0.042, 0.635)
    sh_t = (sign * 0.248, -0.010, 0.225)

    rad = math.radians(yaw_deg)
    up_out = (float(-math.sin(rad)), float(np.cos(rad)), 0.0)
    th_frame = BoneFrame(th_h, th_t, up_hint=up_out)
    sh_frame = BoneFrame(sh_h, sh_t, up_hint=up_out)
    th_w = f"thigh{suffix}"
    sh_w = f"shin{suffix}"
    ft_w = f"foot{suffix}"

    def leg_ring(frame, t, rx, yf, yb, ridge_y=0.0):
        return [
            frame.pt( 0.0,       yf + ridge_y, t),
            frame.pt(-rx * 0.76, yf * 0.78,    t),
            frame.pt(-rx,        0.0,          t),
            frame.pt(-rx * 0.78,-yb * 0.78,    t),
            frame.pt( 0.0,      -yb,           t),
            frame.pt( rx * 0.78,-yb * 0.78,    t),
            frame.pt( rx,        0.0,          t),
            frame.pt( rx * 0.76, yf * 0.78,    t),
        ]

    # 1. Deep Dark-Charcoal Quilted Gambeson Core (`UNDERSUIT_DARK`) + Fitted Outer-Thigh Cuisse Plate
    mb.add_loft(
        [leg_ring(th_frame, -0.06, 0.112, 0.108, 0.108), leg_ring(th_frame, 1.12, 0.092, 0.092, 0.092)],
        weights=th_w, mat="MATTE", colors="UNDERSUIT_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK"
    )
    tc0 = leg_ring(th_frame, 0.10, 0.122, 0.118, 0.110, ridge_y=0.012)
    tc1 = leg_ring(th_frame, 0.52, 0.116, 0.114, 0.106, ridge_y=0.014)
    tc2 = leg_ring(th_frame, 0.86, 0.102, 0.102, 0.096, ridge_y=0.010)
    # Dark inner thigh (`UNDERSUIT_DARK`), dark-iron outer cuisse (`STEEL_DARK` / `STEEL_SHADE`)
    if not is_right:
        th_cols = ["STEEL_DARK", "STEEL_SHADE", "STEEL_DARK", "UNDERSUIT_DARK", "UNDERSUIT_DARK", "UNDERSUIT_DARK", "STEEL_DARK", "STEEL_SHADE"]
    else:
        th_cols = ["STEEL_DARK", "STEEL_SHADE", "STEEL_DARK", "UNDERSUIT_DARK", "UNDERSUIT_DARK", "UNDERSUIT_DARK", "STEEL_DARK", "STEEL_SHADE"]
    mb.add_loft([tc0, tc1, tc2], weights=th_w, mat="METAL", colors=th_cols, closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK")

    # 2. Sleek A-Line Hip Tassets (`tabard.png` — fitted closer to the hip/thigh)
    inner_strap = [
        (sign * 0.104, 0.192, 1.186),
        (sign * 0.142, 0.184, 1.186),
        (sign * 0.168, 0.170, 0.835),
        (sign * 0.130, 0.180, 0.835),
    ]
    mb.add_flat_beveled_plate(
        inner_strap, normal_dir=(sign * 0.22, 0.96, 0.08), thickness=0.012, bevel_inset=0.14, weights=th_w,
        mat="MATTE", col_face="LEATHER_MAIN", col_edge="LEATHER_LIGHT", col_side="LEATHER_DARK"
    )
    outer_tasset = [
        (sign * 0.132, 0.188, 1.186),
        (sign * 0.194, 0.158, 1.186),
        (sign * 0.218, 0.142, 0.968),
        (sign * 0.156, 0.172, 0.968),
    ]
    mb.add_flat_beveled_plate(
        outer_tasset, normal_dir=(sign * 0.38, 0.91, 0.10), thickness=0.014, bevel_inset=0.15, weights=th_w,
        mat="MATTE", col_face="LEATHER_LIGHT", col_edge="LEATHER_MAIN", col_side="LEATHER_DARK"
    )
    sq_mount = [
        (sign * 0.154, 0.182, 1.076),
        (sign * 0.194, 0.164, 1.076),
        (sign * 0.204, 0.156, 1.012),
        (sign * 0.164, 0.174, 1.012),
    ]
    rs_prev.add_framed_rect_plate(
        mb, sq_mount, normal_dir=(sign * 0.38, 0.91, 0.10), thickness=0.010, border_frac=0.30, weights=th_w,
        mat_border="METAL", col_border="STEEL_LIGHT", col_border_edge="STEEL_BRIGHT",
        mat_inner="MATTE", col_inner="LEATHER_DARK", open_top=False
    )

    # 3. Chiseled Hexagonal Steel Knee Poleyn (`boot.png` — NO heavy yellow band!)
    def knee_row(t_side, t_mid, u_side, u_mid, v_side, v_mid):
        return [
            sh_frame.pt(-u_side, v_side, t_side),
            sh_frame.pt(-u_mid,  v_mid,  t_mid),
            sh_frame.pt( u_mid,  v_mid,  t_mid),
            sh_frame.pt( u_side, v_side, t_side),
        ]

    # Subtle, thin top bevel lip (dark steel side, thin champagne-brass center highlight, only 0.04 t-span instead of 0.18!)
    k_lip_grid = [
        knee_row(-0.04, -0.08, 0.118, 0.076, -0.008, 0.132),
        knee_row( 0.00, -0.02, 0.122, 0.080, -0.006, 0.138),
    ]
    mb.add_faceted_shield_plate(
        k_lip_grid, outward_hint=sh_frame.v, thickness=0.022, bevel_inset=0.16, weights=sh_w,
        mat="METAL", col_faces=[["STEEL_FACET", "BRASS_MAIN", "STEEL_LIGHT"]], col_bevel="BRASS_BRIGHT", col_side="FACE_DARK"
    )

    # Compact, Chiseled 3-Plane Steel Knee Shield (`t = -0.02 .. +0.38` on `sh_frame` — `boot.png`)
    k_face_grid = [
        knee_row( 0.00, -0.02, 0.122, 0.080, -0.006, 0.138),
        knee_row( 0.20,  0.18, 0.118, 0.076, -0.008, 0.134),
        knee_row( 0.36,  0.39, 0.106, 0.068, -0.012, 0.122),
    ]
    mb.add_faceted_shield_plate(
        k_face_grid, outward_hint=sh_frame.v, thickness=0.026, bevel_inset=0.16, weights=sh_w,
        mat="METAL",
        col_faces=[
            ["STEEL_FACET", "STEEL_MAIN",  "STEEL_BRIGHT"],
            ["STEEL_DARK",  "STEEL_FACET", "STEEL_LIGHT"],
        ],
        col_bevel="STEEL_BRIGHT", col_side="FACE_DARK"
    )

    # Stepped dark-steel bevel recess on the knee face (`boot.png`)
    c_notch = [
        sh_frame.pt(-0.044, 0.142, 0.09),
        sh_frame.pt( 0.034, 0.142, 0.09),
        sh_frame.pt( 0.034, 0.140, 0.22),
        sh_frame.pt(-0.044, 0.140, 0.22),
    ]
    mb.add_flat_beveled_plate(
        c_notch, normal_dir=sh_frame.v, thickness=0.006, bevel_inset=0.22, weights=sh_w,
        mat="METAL", col_face="STEEL_DARK", col_edge="STEEL_SHADE", col_side="FACE_DARK"
    )

    # Dark behind-the-knee articulation core + leather knee strap
    mb.add_loft(
        [leg_ring(sh_frame, -0.04, 0.088, 0.084, 0.088), leg_ring(sh_frame, 1.04, 0.068, 0.068, 0.068)],
        weights=sh_w, mat="MATTE", colors="UNDERSUIT_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK"
    )
    st_r0 = leg_ring(sh_frame, 0.12, 0.106, 0.098, 0.114)
    st_r1 = leg_ring(sh_frame, 0.26, 0.104, 0.096, 0.112)
    mb.add_loft([st_r0, st_r1], weights=sh_w, mat="MATTE", colors="LEATHER_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_MAIN")

    # 4. Anatomically Tapered Front-Keeled Shin Greave (`rx = 0.110` at calf tapering to `rx = 0.082` at ankle!)
    ls0 = leg_ring(sh_frame, 0.34, 0.110, 0.112, 0.116, ridge_y=0.022)
    ls1 = leg_ring(sh_frame, 0.56, 0.104, 0.106, 0.108, ridge_y=0.024)
    ls2 = leg_ring(sh_frame, 0.82, 0.090, 0.094, 0.092, ridge_y=0.020)
    ls3 = leg_ring(sh_frame, 1.04, 0.082, 0.086, 0.082, ridge_y=0.016)
    ls_cols = ["STEEL_BRIGHT", "STEEL_LIGHT", "STEEL_FACET", "STEEL_DARK", "FACE_DARK", "STEEL_DARK", "STEEL_MAIN", "STEEL_BRIGHT"]
    mb.add_loft([ls0, ls1, ls2, ls3], weights=sh_w, mat="METAL", colors=[ls_cols, ls_cols, ls_cols], closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    # 5. Sleek, Tapered 5-Facet Wedged Sabaton Boot & 38° V-Angled Leather Ankle Strap (`boot.png`)
    cx, cy = sh_t[0], sh_t[1]

    def boot_ring_sleek(fw, rx, y_front, y_corner, y_back, z, dorsal_lift=0.0, front_peak=0.0, back_peak=0.0):
        ym = 0.32 * y_front + 0.68 * y_back
        pts = [
            (cx - fw,      cy + y_front,        z + dorsal_lift + front_peak),
            (cx - rx*0.82, cy + y_corner,       z + dorsal_lift*0.4 + front_peak*0.45),
            (cx - rx,      cy + ym,             z),
            (cx - rx*0.84, cy + y_back + 0.022, z + back_peak * 0.5),
            (cx - fw*0.76, cy + y_back,         z + back_peak),
            (cx + fw*0.76, cy + y_back,         z + back_peak),
            (cx + rx*0.84, cy + y_back + 0.022, z + back_peak * 0.5),
            (cx + rx,      cy + ym,             z),
            (cx + rx*0.82, cy + y_corner,       z + dorsal_lift*0.4 + front_peak*0.45),
            (cx + fw,      cy + y_front,        z + dorsal_lift + front_peak),
        ]
        return rs_prev.rot_z(pts, yaw_deg, pivot=(cx, cy))

    # Dark treaded sole (`fw = 0.044`, `rx = 0.112` — ~26% sleeker width than v2.8's blocky `rx = 0.152`!)
    s0 = boot_ring_sleek(0.042, 0.110, 0.296, 0.246, -0.142, 0.000)
    s1 = boot_ring_sleek(0.044, 0.112, 0.300, 0.250, -0.144, 0.022)
    mb.add_loft([s0, s1], weights=ft_w, mat="MATTE", colors="FACE_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    b0      = boot_ring_sleek(0.042, 0.108, 0.294, 0.244, -0.140, 0.022, dorsal_lift=0.002)
    b1      = boot_ring_sleek(0.038, 0.104, 0.272, 0.224, -0.136, 0.072, dorsal_lift=0.012, back_peak=0.010)
    b1_back = boot_ring_sleek(0.036, 0.100, 0.198, 0.158, -0.136, 0.098, dorsal_lift=0.016, back_peak=0.014)
    b1_step = boot_ring_sleek(0.034, 0.094, 0.192, 0.152, -0.136, 0.088, dorsal_lift=0.014, back_peak=0.014)
    b2      = boot_ring_sleek(0.035, 0.096, 0.148, 0.114, -0.138, 0.118, dorsal_lift=0.018, back_peak=0.020)
    b3      = boot_ring_sleek(0.032, 0.086, 0.096, 0.072, -0.132, 0.232, dorsal_lift=0.014, back_peak=0.024)

    cols_prow = ["STEEL_MAIN",  "STEEL_FACET", "STEEL_DARK",  "FACE_DARK", "STEEL_MAIN",  "FACE_DARK", "STEEL_DARK", "STEEL_FACET", "STEEL_LIGHT", "STEEL_BRIGHT"]
    cols_deck = ["STEEL_LIGHT", "STEEL_MAIN",  "STEEL_DARK",  "FACE_DARK", "STEEL_LIGHT", "FACE_DARK", "STEEL_DARK", "STEEL_MAIN",  "STEEL_BRIGHT","STEEL_BRIGHT"]
    cols_step = ["FACE_DARK"] * 10
    cols_inst = ["STEEL_FACET", "STEEL_MAIN",  "FACE_DARK",   "STEEL_DARK","STEEL_LIGHT", "STEEL_DARK","FACE_DARK",  "STEEL_MAIN",  "STEEL_LIGHT", "STEEL_BRIGHT"]

    mb.add_loft(
        [b0, b1, b1_back, b1_step, b2, b3],
        weights=ft_w, mat="METAL",
        colors=[cols_prow, cols_deck, cols_step, cols_inst, cols_step],
        closed_ring=True, cap_start=False, cap_end=True, cap_color="FACE_DARK"
    )

    # 38-deg V-Angled Saddle-Leather Ankle Strap with subtle brass side keepers (`boot.png`)
    ac0 = boot_ring_sleek(0.034, 0.098, 0.146, 0.106, -0.146, 0.078, dorsal_lift=0.014, front_peak=0.096, back_peak=0.020)
    ac1 = boot_ring_sleek(0.036, 0.102, 0.152, 0.110, -0.148, 0.128, dorsal_lift=0.016, front_peak=0.104, back_peak=0.024)
    ac2 = boot_ring_sleek(0.032, 0.092, 0.132, 0.096, -0.142, 0.140, dorsal_lift=0.012, front_peak=0.094, back_peak=0.020)
    ac_cols = ["LEATHER_LIGHT", "LEATHER_MAIN", "LEATHER_DARK", "FACE_DARK", "LEATHER_MAIN", "FACE_DARK", "LEATHER_DARK", "LEATHER_MAIN", "LEATHER_LIGHT", "BRASS_MAIN"]
    mb.add_loft([ac0, ac1, ac2], weights=ft_w, mat="MATTE", colors=[ac_cols, "LEATHER_DARK"], closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_DARK")

    return mb


def build_v29_arm_only_without_left_hand():
    full_arm_l = build_v29_arm_and_gauntlet(is_right=False, closed_left_grip=False)
    mb_arm = MeshBuilder(["MAKitMatte", "MAKitMetal"])
    off = 0
    for pi, poly in enumerate(full_arm_l.polys):
        plen = len(poly)
        w0 = full_arm_l.weights[poly[0]]
        if "hand.L" not in w0 and "socket_sorcery" not in w0:
            mat_name = full_arm_l.mat_names[full_arm_l.mat_indices[pi]]
            new_vis = [mb_arm.add_vert(full_arm_l.verts[vi], full_arm_l.weights[vi]) for vi in poly]
            mb_arm.polys.append(new_vis)
            mb_arm.mat_indices.append(mb_arm._resolve_mat(mat_name))
            mb_arm.loop_colors.extend(full_arm_l.loop_colors[off:off+plen])
            mb_arm.loop_uvs.extend(full_arm_l.loop_uvs[off:off+plen])
        off += plen
    mb_arm.bake_loop_shading()
    return mb_arm



def classify_poly_material_v29(mat_name: str, raw_rgba) -> int:
    """
    Maps every polygon of the v2.9 Spellblade to one of 6 distinct glTF 2.0 PBR materials:
      0: MA_Spellblade_Forged_Steel          (metallic=0.86, roughness=0.28)
      1: MA_Spellblade_Champagne_Brass       (metallic=0.92, roughness=0.22)
      2: MA_Spellblade_Saddle_Leather        (metallic=0.04, roughness=0.64)
      3: MA_Spellblade_Dark_Undersuit        (metallic=0.02, roughness=0.90)
      4: MA_Spellblade_Crimson_Cloth         (metallic=0.03, roughness=0.82)
      5: MA_Spellblade_Arcane_Cyan_Emissive  (metallic=0.12, roughness=0.14, emissive=[0.35, 0.92, 1.00])
    """
    r, g, b = float(raw_rgba[0]), float(raw_rgba[1]), float(raw_rgba[2])
    if mat_name in ("MAVisorGlow", "MASorceryAccent"):
        return 5
    if mat_name == "MAKitMatte":
        if max(r, g, b) < 0.020:
            return 3 # UNDERSUIT_DARK or FACE_DARK
        if r > 2.4 * max(g, 1e-5):
            return 4 # CLOTH_* or RUBY_*
        return 2     # LEATHER_*
    # MAKitMetal: distinguish BRASS_* (r/b >= 1.85) from STEEL_* (r/b <= 1.30) and dark recesses
    if max(r, g, b) < 0.015:
        return 3
    if r > 1.42 * max(b, 1e-5) and g > 1.15 * max(b, 1e-5):
        return 1     # BRASS_*
    return 0         # STEEL_*


def compile_meshbuilder_to_multimat_arrays(mb: MeshBuilder, default_joint_idx: int = 3):
    verts_w = exp28.b_to_gltf_pos(np.array(mb.verts, dtype=np.float32))
    pos_list, nrm_list, vc_list, uv_list, j0_list, w0_list, tri_list, tmat_list = [], [], [], [], [], [], [], []

    v_j0 = np.zeros((len(mb.verts), 4), dtype=np.uint16)
    v_w0 = np.zeros((len(mb.verts), 4), dtype=np.float32)
    for vi, wdict in enumerate(mb.weights):
        items = sorted(
            [(exp28.JOINT_INDEX_MAP.get(k, default_joint_idx), float(val)) for k, val in wdict.items() if float(val) > 1e-5],
            key=lambda x: -x[1]
        )[:4]
        if not items:
            items = [(default_joint_idx, 1.0)]
        tot = sum(x[1] for x in items)
        for c, (j_idx, w_val) in enumerate(items):
            v_j0[vi, c] = int(j_idx)
            v_w0[vi, c] = float(w_val / max(tot, 1e-6))

    l_off = 0
    v_cur = 0
    for pi, poly in enumerate(mb.polys):
        plen = len(poly)
        if plen < 3:
            l_off += plen
            continue
        pts = verts_w[poly]
        fn = np.cross(pts[1] - pts[0], pts[2] - pts[0])
        fn_len = float(np.linalg.norm(fn))
        fn = (fn / fn_len).astype(np.float32) if fn_len >= 1e-9 else np.array([0.0, 1.0, 0.0], dtype=np.float32)

        mat_name = mb.mat_names[mb.mat_indices[pi]] if pi < len(mb.mat_indices) else "MAKitMetal"
        is_glow = mat_name in ("MAVisorGlow", "MASorceryAccent")
        poly_mat_id = classify_poly_material_v29(mat_name, mb.loop_colors[l_off])

        for k, vi in enumerate(poly):
            pos_list.append(verts_w[vi])
            nrm_list.append(fn)
            rgba = list(mb.loop_colors[l_off + k])
            if is_glow:
                is_core = (k < plen - 2) if plen == 4 else True
                rgba = [0.22, 0.96, 1.00, 1.0] if is_core else [0.78, 0.99, 1.00, 1.0]
            else:
                rgba = [
                    float(np.clip(rgba[0] ** (1.0 / 1.85), 0.0, 1.0)),
                    float(np.clip(rgba[1] ** (1.0 / 1.85), 0.0, 1.0)),
                    float(np.clip(rgba[2] ** (1.0 / 1.85), 0.0, 1.0)),
                    1.0,
                ]
            vc_list.append(rgba)
            uv_list.append(mb.loop_uvs[l_off + k])
            j0_list.append(v_j0[vi])
            w0_list.append(v_w0[vi])

        for t_i in range(1, plen - 1):
            tri_list.append([v_cur, v_cur + t_i, v_cur + t_i + 1])
            tmat_list.append(poly_mat_id)

        v_cur += plen
        l_off += plen

    return (
        np.array(pos_list, dtype=np.float32),
        np.array(nrm_list, dtype=np.float32),
        np.array(vc_list,  dtype=np.float32),
        np.array(uv_list,  dtype=np.float32),
        np.array(j0_list,  dtype=np.uint16),
        np.array(w0_list,  dtype=np.float32),
        np.array(tri_list, dtype=np.uint32),
        np.array(tmat_list, dtype=np.int32),
    )


def export_spellblade_v29_multimat_glb(uncomp_blend_path: Path, replacements_tp: dict, out_glb_path: Path):
    j_nodes, WM_REST, IBMS = exp28.build_v28_27joint_skeleton()
    anims = exp28.build_spellblade_v28_skeletal_animations(WM_REST, j_nodes)

    # Upgrade Clip 10 (`Spellblade_10_Machine_Offensive_Dash_Posture`) to a 1.80s (55-key)
    # attack-flight clip synchronized with Fight-and-Flight Clip 19 (`Posture_12_Offensive_Dash_Entry_Hold_Recovery`):
    # Genuine forward rider lean (+16 deg torso), counter-elevated head sighting the target (-14 deg),
    # billowing rear/front tabard, and a commanding, readable third-person couched/poised right-hand broadsword pose!
    for idx_a, a in enumerate(anims):
        if a["name"] == "Spellblade_10_Machine_Offensive_Dash_Posture":
            n_od = 55
            t_od = [round(1.800 * i / float(n_od - 1), 5) for i in range(n_od)]
            kw_od = []
            for i in range(n_od):
                t_sec = t_od[i]
                if t_sec <= 0.38:
                    w = t_sec / 0.38
                    dash_w = exp28._smoothstep(0.0, 1.0, w) + 0.10 * math.sin(w * math.pi)
                    flare = 0.0
                elif t_sec <= 1.15:
                    dash_w = 1.0
                    flare = 0.0
                else:
                    w = (t_sec - 1.15) / 0.65
                    dash_w = 1.0 - exp28._smoothstep(0.0, 1.0, w)
                    flare = math.sin(w * math.pi)
                s_osc = math.sin(2.0 * math.pi * 2.5 * t_sec) * dash_w
                c_osc = math.cos(2.0 * math.pi * 2.5 * t_sec) * dash_w
                kw_od.append(dict(
                    pelvis_tr_delta=(0.0, 0.016 * dash_w - 0.012 * flare, 0.042 * dash_w - 0.018 * flare),
                    pelvis_euler_xyz=(+10.5 * dash_w - 5.5 * flare + 0.8 * s_osc, +4.0 * dash_w, 0.0),
                    spine_euler_xyz=(+6.5 * dash_w - 3.5 * flare, +5.0 * dash_w, -2.5 * dash_w),
                    chest_euler_xyz=(+8.0 * dash_w - 4.0 * flare + 1.0 * c_osc, +6.5 * dash_w, -3.0 * dash_w),
                    neck_euler_xyz=(-8.0 * dash_w + 3.0 * flare, -5.0 * dash_w, 0.0),
                    head_euler_xyz=(-12.0 * dash_w + 4.5 * flare - 0.8 * s_osc, -8.5 * dash_w, +3.0 * dash_w),
                    # Left arm braced firmly on the repeating crossbow grip
                    arm_l_euler_xyz=(-18.0 * dash_w + 6.0 * flare, +12.0 * dash_w, +8.0 * dash_w),
                    forearm_l_euler_xyz=(-14.0 * dash_w, +6.0 * dash_w, 0.0),
                    # Right arm & broadsword swept forward-outward into a readable 3P attack-flight couched charge pose!
                    arm_r_euler_xyz=(-48.0 * dash_w + 18.0 * flare + 2.0 * s_osc, +24.0 * dash_w - 8.0 * flare, -28.0 * dash_w + 10.0 * flare),
                    forearm_r_euler_xyz=(-26.0 * dash_w + 12.0 * flare, +12.0 * dash_w, -10.0 * dash_w),
                    hand_r_euler_xyz=(+16.0 * dash_w - 8.0 * flare, -8.0 * dash_w, +6.0 * dash_w),
                    leg_ik_l=(-30.0 * dash_w + 12.0 * flare + 1.8 * s_osc, +54.0 * dash_w - 16.0 * flare + 2.2 * c_osc, +22.0 * dash_w - 8.0 * flare),
                    leg_ik_r=(-28.0 * dash_w + 12.0 * flare - 1.8 * s_osc, +52.0 * dash_w - 16.0 * flare - 2.2 * c_osc, +20.0 * dash_w - 8.0 * flare),
                ))
            # Pack via exp28 helper logic
            tr_1 = []
            q_by_j = {j: [] for j in range(1, 27)}
            for i in range(n_od):
                t1, q_map = exp28.solve_spellblade_pose_quats_v28(WM_REST, j_nodes, **kw_od[i])
                tr_1.append([round(float(x), 5) for x in t1])
                for j in range(1, 27):
                    q_by_j[j].append(q_map[j])
            tracks = {1: {"translation": tr_1, "rotation": exp28.ensure_quat_continuity(q_by_j[1])}}
            for j in range(2, 27):
                tracks[j] = {"rotation": exp28.ensure_quat_continuity(q_by_j[j])}
            anims[idx_a] = {"name": "Spellblade_10_Machine_Offensive_Dash_Posture", "times": t_od, "tracks": tracks}

    body_builders = [
        (replacements_tp["MEHelmetShellCanonical"], 5),
        (replacements_tp["MEHelmetJawCanonical"],   5),
        (replacements_tp["MEVisorCanonical"],       5),
        (replacements_tp["MECrestCanonical"],       5),
        (replacements_tp["MEPauldron.L"],           6),
        (replacements_tp["MEPauldron.R"],           11),
        (replacements_tp["MEBreastplate"],          3),
        (build_v29_arm_only_without_left_hand(),    7),
        (replacements_tp["MEGauntlet.R.001"],       12),
        (replacements_tp["MEGreave.L"],             21),
        (replacements_tp["MEGreave.R"],             24),
        (replacements_tp["MEBoot.L"],               23),
        (replacements_tp["MEBoot.R"],               26),
    ]
    P_b, N_b, VC_b, UV_b, J_b, W_b, T_b, M_b = [], [], [], [], [], [], [], []
    v_off = 0
    for mb_i, def_j in body_builders:
        vp, vn, vc, uv, j0, w0, tri, tmat = compile_meshbuilder_to_multimat_arrays(mb_i, default_joint_idx=def_j)
        P_b.append(vp); N_b.append(vn); VC_b.append(vc); UV_b.append(uv); J_b.append(j0); W_b.append(w0)
        T_b.append(tri + v_off); M_b.append(tmat)
        v_off += len(vp)

    tvp, tvn, tvc, tuv, tj0, tw0, ttri = exp28.extract_tabards_centroid_subdivided(uncomp_blend_path)
    # Classify subdivided tabard triangles into Mat 1 (Champagne Brass heraldry/border) vs Mat 4 (Crimson Cloth field)
    tc_tri = tvc[ttri[:, 0], :3]
    ttmat = np.where((tc_tri[:, 0] > 0.35) & (tc_tri[:, 1] > 0.22), 1, 4).astype(np.int32)
    P_b.append(tvp); N_b.append(tvn); VC_b.append(tvc); UV_b.append(tuv); J_b.append(tj0); W_b.append(tw0)
    T_b.append(ttri + v_off); M_b.append(ttmat)
    v_off += len(tvp)

    mb_hand_l_closed = b28.build_v28_left_hand_only(closed_grip=True)
    mb_hand_l_closed.bake_loop_shading()
    hc_vp, hc_vn, hc_vc, hc_uv, hc_j0, hc_w0, hc_tri, hc_tmat = compile_meshbuilder_to_multimat_arrays(mb_hand_l_closed, default_joint_idx=9)

    mb_hand_l_open = b28.build_v28_left_hand_only(closed_grip=False)
    mb_hand_l_open.bake_loop_shading()
    ho_vp, ho_vn, ho_vc, ho_uv, ho_j0, ho_w0, ho_tri, ho_tmat = compile_meshbuilder_to_multimat_arrays(mb_hand_l_open, default_joint_idx=9)

    sw_vp, sw_vn, sw_vc, sw_uv, sw_j0, sw_w0, sw_tri, sw_tmat = compile_meshbuilder_to_multimat_arrays(replacements_tp["MEHeroSword"], default_joint_idx=15)

    bin_chunks = bytearray()
    buffer_views, accessors = [], []

    def add_bv(raw_bytes: bytes, target=None):
        pad = (4 - (len(bin_chunks) % 4)) % 4
        if pad:
            bin_chunks.extend(b"\x00" * pad)
        off = len(bin_chunks)
        bin_chunks.extend(raw_bytes)
        bv = {"buffer": 0, "byteOffset": off, "byteLength": len(raw_bytes)}
        if target is not None:
            bv["target"] = target
        idx = len(buffer_views)
        buffer_views.append(bv)
        return idx

    def add_acc(bv_idx, comp_type, count, acc_type, mins=None, maxs=None):
        acc = {"bufferView": bv_idx, "componentType": comp_type, "count": count, "type": acc_type}
        if mins is not None:
            acc["min"] = mins
        if maxs is not None:
            acc["max"] = maxs
        idx = len(accessors)
        accessors.append(acc)
        return idx

    def pack_multimat_prims(vp, vn, vc, uv, j0, w0, tris, tmat):
        prims = []
        for mat_id in range(6):
            mask = (tmat == mat_id)
            if not np.any(mask):
                continue
            tris_m = tris[mask]
            u_verts, inv_idx = np.unique(tris_m.ravel(), return_inverse=True)
            vp_m = vp[u_verts]
            vn_m = vn[u_verts]
            vc_m = vc[u_verts]
            j0_m = j0[u_verts]
            w0_m = w0[u_verts]
            idx_flat = inv_idx.astype(np.uint32)

            bv_p = add_bv(vp_m.tobytes(), 34962)
            bv_n = add_bv(vn_m.tobytes(), 34962)
            bv_c = add_bv(vc_m.tobytes(), 34962)
            bv_j = add_bv(j0_m.tobytes(), 34962)
            bv_w = add_bv(w0_m.tobytes(), 34962)
            bv_i = add_bv(idx_flat.tobytes(), 34963)

            acc_p = add_acc(bv_p, 5126, len(vp_m), "VEC3", [float(x) for x in vp_m.min(axis=0)], [float(x) for x in vp_m.max(axis=0)])
            acc_n = add_acc(bv_n, 5126, len(vn_m), "VEC3")
            acc_c = add_acc(bv_c, 5126, len(vc_m), "VEC4")
            acc_j = add_acc(bv_j, 5123, len(j0_m), "VEC4")
            acc_w = add_acc(bv_w, 5126, len(w0_m), "VEC4")
            acc_i = add_acc(bv_i, 5125, len(idx_flat), "SCALAR", [int(idx_flat.min())], [int(idx_flat.max())])

            prims.append({
                "attributes": {
                    "POSITION":  acc_p,
                    "NORMAL":    acc_n,
                    "COLOR_0":   acc_c,
                    "JOINTS_0":  acc_j,
                    "WEIGHTS_0": acc_w,
                },
                "indices": acc_i,
                "material": mat_id,
                "mode": 4,
            })
        return prims

    ibms_col = np.transpose(IBMS.astype(np.float32), (0, 2, 1)).copy()
    bv_ibm = add_bv(ibms_col.tobytes())
    acc_ibm = add_acc(bv_ibm, 5126, 27, "MAT4")

    body_vp   = np.vstack(P_b).astype(np.float32)
    body_vn   = np.vstack(N_b).astype(np.float32)
    body_vc   = np.vstack(VC_b).astype(np.float32)
    body_uv   = np.vstack(UV_b).astype(np.float32)
    body_j0   = np.vstack(J_b).astype(np.uint16)
    body_w0   = np.vstack(W_b).astype(np.float32)
    body_tri  = np.vstack(T_b).astype(np.uint32)
    body_tmat = np.concatenate(M_b).astype(np.int32)

    gltf_meshes = [
        {
            "name": "Spellblade_Armor_And_Body_Mesh",
            "primitives": pack_multimat_prims(body_vp, body_vn, body_vc, body_uv, body_j0, body_w0, body_tri, body_tmat),
        },
        {
            "name": "Spellblade_Hand_L_Closed_Grip_Mesh",
            "primitives": pack_multimat_prims(hc_vp, hc_vn, hc_vc, hc_uv, hc_j0, hc_w0, hc_tri, hc_tmat),
        },
        {
            "name": "Spellblade_Hand_L_Open_Sorcery_And_Rune_Mesh",
            "primitives": pack_multimat_prims(ho_vp, ho_vn, ho_vc, ho_uv, ho_j0, ho_w0, ho_tri, ho_tmat),
        },
        {
            "name": "Spellblade_Hero_Broadsword_Mesh",
            "primitives": pack_multimat_prims(sw_vp, sw_vn, sw_vc, sw_uv, sw_j0, sw_w0, sw_tri, sw_tmat),
        },
    ]

    gltf_nodes = []
    for idx in range(27):
        nd = dict(j_nodes[idx])
        if not nd["children"]:
            del nd["children"]
        gltf_nodes.append(nd)

    mesh_node_specs = [
        ("Spellblade_Armor_And_Body",               0, [1.0, 1.0, 1.0]),
        ("Spellblade_Hand_L_Closed_Grip",           1, [1.0, 1.0, 1.0]),
        ("Spellblade_Hand_L_Open_Sorcery_And_Rune", 2, [0.0, 0.0, 0.0]),
        ("Spellblade_Hero_Broadsword",              3, [1.0, 1.0, 1.0]),
    ]
    for m_name, m_idx, def_sc in mesh_node_specs:
        gltf_nodes.append({
            "name": m_name,
            "mesh": m_idx,
            "skin": 0,
            "translation": [0.0, 0.0, 0.0],
            "rotation": [0.0, 0.0, 0.0, 1.0],
            "scale": def_sc,
        })

    gltf_nodes.append({
        "name": "SpellbladeRig",
        "children": [0, 27, 28, 29, 30],
        "translation": [0.0, 0.0, 0.0],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "scale": [1.0, 1.0, 1.0],
    })

    gltf_anims = []
    for anim in anims:
        t_arr = np.array(anim["times"], dtype=np.float32)
        bv_t = add_bv(t_arr.tobytes())
        acc_t = add_acc(bv_t, 5126, len(t_arr), "SCALAR", [float(t_arr.min())], [float(t_arr.max())])
        samplers, channels = [], []
        for target_node, trk in anim["tracks"].items():
            for path_name, vals in trk.items():
                v_arr = np.array(vals, dtype=np.float32)
                bv_v = add_bv(v_arr.tobytes())
                acc_type = "VEC4" if path_name == "rotation" else "VEC3"
                acc_v = add_acc(bv_v, 5126, len(v_arr), acc_type)
                s_idx = len(samplers)
                samplers.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
                channels.append({"sampler": s_idx, "target": {"node": int(target_node), "path": path_name}})
        gltf_anims.append({"name": anim["name"], "samplers": samplers, "channels": channels})

    gltf_materials = [
        {
            "name": "MA_Spellblade_Forged_Steel",
            "doubleSided": True,
            "pbrMetallicRoughness": {
                "baseColorFactor": [1.0, 1.0, 1.0, 1.0],
                "metallicFactor": 0.86,
                "roughnessFactor": 0.28,
            },
        },
        {
            "name": "MA_Spellblade_Champagne_Brass",
            "doubleSided": True,
            "pbrMetallicRoughness": {
                "baseColorFactor": [1.0, 1.0, 1.0, 1.0],
                "metallicFactor": 0.92,
                "roughnessFactor": 0.22,
            },
        },
        {
            "name": "MA_Spellblade_Saddle_Leather",
            "doubleSided": True,
            "pbrMetallicRoughness": {
                "baseColorFactor": [1.0, 1.0, 1.0, 1.0],
                "metallicFactor": 0.04,
                "roughnessFactor": 0.64,
            },
        },
        {
            "name": "MA_Spellblade_Dark_Undersuit",
            "doubleSided": True,
            "pbrMetallicRoughness": {
                "baseColorFactor": [1.0, 1.0, 1.0, 1.0],
                "metallicFactor": 0.02,
                "roughnessFactor": 0.90,
            },
        },
        {
            "name": "MA_Spellblade_Crimson_Cloth",
            "doubleSided": True,
            "pbrMetallicRoughness": {
                "baseColorFactor": [1.0, 1.0, 1.0, 1.0],
                "metallicFactor": 0.03,
                "roughnessFactor": 0.82,
            },
        },
        {
            "name": "MA_Spellblade_Arcane_Cyan_Emissive",
            "doubleSided": True,
            "emissiveFactor": [0.35, 0.92, 1.00],
            "pbrMetallicRoughness": {
                "baseColorFactor": [1.0, 1.0, 1.0, 1.0],
                "metallicFactor": 0.12,
                "roughnessFactor": 0.14,
            },
        },
    ]

    gltf_json = {
        "asset": {
            "version": "2.0",
            "generator": "Castleward Spellblade v2.9 Multi-Material Artistic Refinement Pipeline",
        },
        "scene": 0,
        "scenes": [{"name": "Spellblade_v29_Artistic_Refinement_Scene", "nodes": [31]}],
        "nodes": gltf_nodes,
        "skins": [{
            "name": "SpellbladeRig",
            "skeleton": 0,
            "joints": list(range(27)),
            "inverseBindMatrices": acc_ibm,
        }],
        "meshes": gltf_meshes,
        "materials": gltf_materials,
        "animations": gltf_anims,
        "buffers": [{"byteLength": len(bin_chunks)}],
        "bufferViews": buffer_views,
        "accessors": accessors,
        "extras": {
            "version": "2.9.1-multimat",
            "materialCount": 6,
            "materialBreakdown": {
                "0_MA_Spellblade_Forged_Steel": {"metallicFactor": 0.86, "roughnessFactor": 0.28},
                "1_MA_Spellblade_Champagne_Brass": {"metallicFactor": 0.92, "roughnessFactor": 0.22},
                "2_MA_Spellblade_Saddle_Leather": {"metallicFactor": 0.04, "roughnessFactor": 0.64},
                "3_MA_Spellblade_Dark_Undersuit": {"metallicFactor": 0.02, "roughnessFactor": 0.90},
                "4_MA_Spellblade_Crimson_Cloth": {"metallicFactor": 0.03, "roughnessFactor": 0.82},
                "5_MA_Spellblade_Arcane_Cyan_Emissive": {"metallicFactor": 0.12, "roughnessFactor": 0.14, "emissiveFactor": [0.35, 0.92, 1.00]},
            },
        },
    }

    j_bytes = json.dumps(gltf_json, separators=(",", ":")).encode("utf-8")
    j_pad = (4 - (len(j_bytes) % 4)) % 4
    if j_pad:
        j_bytes += b" " * j_pad
    b_pad = (4 - (len(bin_chunks) % 4)) % 4
    if b_pad:
        bin_chunks.extend(b"\x00" * b_pad)

    total_len = 12 + 8 + len(j_bytes) + 8 + len(bin_chunks)
    glb_out = bytearray()
    glb_out.extend(struct.pack("<4sII", b"glTF", 2, total_len))
    glb_out.extend(struct.pack("<I4s", len(j_bytes), b"JSON"))
    glb_out.extend(j_bytes)
    glb_out.extend(struct.pack("<I4s", len(bin_chunks), b"BIN\x00"))
    glb_out.extend(bin_chunks)

    out_glb_path.write_bytes(glb_out)


def export_spellblade_v29():
    """
    Monkey-patches `u28` and `b28` with our v2.9 refined builders, exports the Blender 4.05
    source (`spellblade-v29-artistic-refinement.blend`) and 27-joint rigged GLB
    (`spellblade-v29-artistic-refinement.glb`), while leaving all v2.8 files untouched!
    """
    # 1. Save editable Blender 4.05 file `spellblade-v29-artistic-refinement.blend`
    tp_src = C_PREV_WORK / "Spellblade-production-third-person.blend"
    bf_tp = BlendFile(str(tp_src))
    rs_prev.upgrade_banner_texture(bf_tp)

    mb_shell, mb_jaw, mb_visor, mb_crest = build_v29_helmet_parts()
    mb_pl, mb_pr = build_v29_pauldron_pair()
    mb_bp = build_v29_breastplate_scarf_and_belt()
    mb_arm_l = build_v29_arm_and_gauntlet(is_right=False, closed_left_grip=False)
    mb_arm_r = build_v29_arm_and_gauntlet(is_right=True,  closed_left_grip=False)
    mb_sorc = rs_prev.build_sorcery_cluster(first_person=False)
    mb_sword = build_v29_hero_broadsword(first_person=False)
    leg_l = build_v29_legs_greaves_and_boots(is_right=False)
    leg_r = build_v29_legs_greaves_and_boots(is_right=True)
    mb_grv_l, mb_bt_l = exp28.split_greave_and_boot(leg_l, is_right=False)
    mb_grv_r, mb_bt_r = exp28.split_greave_and_boot(leg_r, is_right=True)
    mb_tab_f = u28.build_v28_sculpted_3d_tabard(is_front=True)
    mb_tab_b = u28.build_v28_sculpted_3d_tabard(is_front=False)
    # Tuck front tabard top slightly inward to y=0.194 so it anchors cleanly under the slimmed v2.9 belt buckle
    for i, (x, y, z) in enumerate(mb_tab_f.verts):
        mb_tab_f.verts[i] = (float(x * 0.92), float(y - 0.018), float(z))
    for i, (x, y, z) in enumerate(mb_tab_b.verts):
        mb_tab_b.verts[i] = (float(x * 0.92), float(y + 0.016), float(z))

    all_tp = [
        ("MEHelmetShellCanonical", mb_shell),
        ("MEHelmetJawCanonical",   mb_jaw),
        ("MEVisorCanonical",       mb_visor),
        ("MECrestCanonical",       mb_crest),
        ("MEPauldron.L",           mb_pl),
        ("MEPauldron.R",           mb_pr),
        ("MEBreastplate",          mb_bp),
        ("MEGauntlet.L.001",       mb_arm_l),
        ("MEGauntlet.R.001",       mb_arm_r),
        ("MEPalmRune.001",         mb_sorc),
        ("MEHeroSword",            mb_sword),
        ("MEGreave.L",             mb_grv_l),
        ("MEBoot.L",               mb_bt_l),
        ("MEGreave.R",             mb_grv_r),
        ("MEBoot.R",               mb_bt_r),
        ("METabardFront",          mb_tab_f),
        ("METabardBack",           mb_tab_b),
    ]
    for name, mb in all_tp:
        mb.bake_loop_shading()
        bf_tp.replace_mesh(name, mb)

    raw_tp_path = WORK_DIR / "Spellblade-v29-preview.blend"
    bf_tp.save(str(raw_tp_path))
    out_tp_blend = OUT_DIR / "spellblade-v29-artistic-refinement.blend"
    zstd_compress_blend(raw_tp_path.read_bytes(), out_tp_blend)
    sha_blend = hashlib.sha256(out_tp_blend.read_bytes()).hexdigest()
    print(f"[OK] Saved {out_tp_blend.name}: {out_tp_blend.stat().st_size:,} bytes, SHA256={sha_blend}")

    # 2. Build 27-joint rigged GLB `spellblade-v29-artistic-refinement.glb` using exp28 pipeline
    # Temporarily bind our v2.9 builders into u28 / b28 / exp28 and write to `spellblade-v29-artistic-refinement.glb`
    u28.build_v28_refined_helmet_parts = build_v29_helmet_parts
    u28.build_v28_refined_pauldron_pair = build_v29_pauldron_pair
    u28.build_v28_refined_breastplate_scarf_and_belt = build_v29_breastplate_scarf_and_belt
    u28.build_v28_refined_legs_greaves_and_boots = build_v29_legs_greaves_and_boots
    b28.build_v28_arm_and_gauntlet = build_v29_arm_and_gauntlet
    exp28.build_v28_arm_only_without_left_hand = build_v29_arm_only_without_left_hand
    rs_prev.build_hero_sword = build_v29_hero_broadsword

    for i in range(len(mb_sword.weights)):
        mb_sword.weights[i] = {"socket_sword": 1.0}
    bf_glb_tab = BlendFile(str(tp_src))
    rs_prev.upgrade_banner_texture(bf_glb_tab)
    rs_prev.polish_original_tabards(bf_glb_tab)
    glb_tab_path = WORK_DIR / "Spellblade-v29-glb-tabard.blend"
    bf_glb_tab.save(str(glb_tab_path))
    out_v29_glb = OUT_DIR / "spellblade-v29-artistic-refinement.glb"
    rep_no_tab = {k: v for k, v in all_tp if k not in ("METabardFront", "METabardBack")}
    export_spellblade_v29_multimat_glb(glb_tab_path, rep_no_tab, out_v29_glb)
    ev29 = StandardGltfEvaluator(str(out_v29_glb))
    P0, _, _, _, _, _, _ = ev29.evaluate_scene_meshes(None, 0.0)
    print(f"[OK] Saved {out_v29_glb.name}: {out_v29_glb.stat().st_size:,} bytes, V={len(P0)}, Clips={len(ev29.gltf['animations'])}, SHA256={hashlib.sha256(out_v29_glb.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    export_spellblade_v29()
