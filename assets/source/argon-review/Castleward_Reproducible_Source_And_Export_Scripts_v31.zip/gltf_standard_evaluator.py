#!/usr/bin/env python3
"""
Independent, Specification-Compliant glTF 2.0 Hierarchical & Skeletal Animation Evaluator
=========================================================================================
Parses any exported `.glb` binary from scratch (without importing any mesh-generation or
custom Python rigging helpers) and evaluates:
  1. Hierarchical node transforms (`translation`, `rotation` with spherical linear interpolation
     `slerp`, `scale` with linear interpolation) at any time `t` of any glTF animation clip,
     plus optional procedural node overrides (e.g., gimbal yaw/pitch or RPM halo scaling).
  2. Standard glTF 2.0 Linear Blend Skinning (`JOINTS_0`, `WEIGHTS_0`, `skins[si].inverseBindMatrices`,
     `skins[si].joints`) on all skinned mesh primitives:
       `M_skin[j] = M_world(joint_node[j]) @ IBM[j]`
       `v_world = sum_{k=0..3} WEIGHTS_0[k] * (M_skin[JOINTS_0[k]] @ [v_bind, 1])`
  3. Structural integrity checks:
     - Valid glTF 2.0 header, JSON chunk, BIN chunk, bufferViews, accessors
     - Valid node parent-child tree (acyclic, single root per scene)
     - Valid `skins`: `inverseBindMatrices` count == `len(joints)`, non-singular IBMs,
       `M_rest(joint) @ IBM == I_4` check
     - Valid `JOINTS_0` (all indices in `0 .. len(joints)-1`) and `WEIGHTS_0` (no NaNs, no negative
       weights, `|sum(w) - 1.0| < 1e-4` for every vertex!)
"""
import io, json, math, struct
from pathlib import Path
import numpy as np
from PIL import Image


def quat_norm(q):
    q = np.asarray(q, dtype=np.float64)
    n = np.linalg.norm(q)
    return q / n if n > 1e-12 else np.array([0.0, 0.0, 0.0, 1.0], dtype=np.float64)


def quat_slerp(q0, q1, u: float):
    q0 = quat_norm(q0)
    q1 = quat_norm(q1)
    dot = float(np.dot(q0, q1))
    if dot < 0.0:
        q1 = -q1
        dot = -dot
    if dot > 0.9995:
        return quat_norm(q0 + u * (q1 - q0))
    theta_0 = math.acos(max(-1.0, min(1.0, dot)))
    sin_0 = math.sin(theta_0)
    theta = theta_0 * u
    s0 = math.cos(theta) - dot * math.sin(theta) / sin_0
    s1 = math.sin(theta) / sin_0
    return quat_norm(s0 * q0 + s1 * q1)


def quat_to_mat3(q):
    x, y, z, w = quat_norm(q)
    return np.array([
        [1.0 - 2.0*(y*y + z*z), 2.0*(x*y - z*w),       2.0*(x*z + y*w)],
        [2.0*(x*y + z*w),       1.0 - 2.0*(x*x + z*z), 2.0*(y*z - x*w)],
        [2.0*(x*z - y*w),       2.0*(y*z + x*w),       1.0 - 2.0*(x*x + y*y)],
    ], dtype=np.float64)


class StandardGltfEvaluator:
    """
    Loads a `.glb` file purely from its binary representation and evaluates standard
    glTF 2.0 node hierarchies, animations, and `JOINTS_0` / `WEIGHTS_0` Linear Blend Skinning.
    """
    def __init__(self, glb_path: Path):
        self.glb_path = Path(glb_path)
        raw = self.glb_path.read_bytes()
        magic, version, total_len = struct.unpack_from("<4sII", raw, 0)
        assert magic == b"glTF" and version == 2 and total_len == len(raw), f"Invalid GLB header in {glb_path}"
        j_len, j_type = struct.unpack_from("<I4s", raw, 12)
        assert j_type == b"JSON"
        self.gltf = json.loads(raw[20:20 + j_len].decode("utf-8"))
        b_off = 20 + j_len
        b_len, b_type = struct.unpack_from("<I4s", raw, b_off)
        assert b_type == b"BIN\x00"
        self.bin_buf = raw[b_off + 8:b_off + 8 + b_len]

        # Build parent map
        self.nodes = self.gltf.get("nodes", [])
        self.parent_map = {}
        for idx, nd in enumerate(self.nodes):
            for ch in nd.get("children", []):
                assert ch not in self.parent_map, f"Node {ch} has multiple parents!"
                self.parent_map[ch] = idx

        # Decode embedded images if present
        self.images_rgba = []
        for im_def in self.gltf.get("images", []):
            bv = self.gltf["bufferViews"][im_def["bufferView"]]
            im_bytes = self.bin_buf[bv["byteOffset"]:bv["byteOffset"] + bv["byteLength"]]
            pil_im = Image.open(io.BytesIO(im_bytes)).convert("RGBA")
            self.images_rgba.append(np.array(pil_im, dtype=np.float32) / 255.0)

        # Decode skins
        self.skins = []
        for sk in self.gltf.get("skins", []):
            joints = sk["joints"]
            ibm_acc = self.read_accessor(sk["inverseBindMatrices"])
            # glTF MAT4 is stored column-major (16 floats per matrix); transpose to row-major 4x4
            ibms_col = ibm_acc.reshape(len(joints), 4, 4)
            ibms_row = np.transpose(ibms_col, (0, 2, 1)).astype(np.float64)
            self.skins.append({
                "name": sk.get("name", "Skin"),
                "joints": joints,
                "skeleton": sk.get("skeleton", joints[0]),
                "ibms": ibms_row,
            })

        # Decode mesh primitives
        self.meshes = []
        for m_def in self.gltf.get("meshes", []):
            prims = []
            for p_def in m_def.get("primitives", []):
                attrs = p_def["attributes"]
                pos = self.read_accessor(attrs["POSITION"]).astype(np.float32)
                nrm = self.read_accessor(attrs["NORMAL"]).astype(np.float32) if "NORMAL" in attrs else np.zeros_like(pos)
                uv  = self.read_accessor(attrs["TEXCOORD_0"]).astype(np.float32) if "TEXCOORD_0" in attrs else None
                col = self.read_accessor(attrs["COLOR_0"]).astype(np.float32) if "COLOR_0" in attrs else None
                j0  = self.read_accessor(attrs["JOINTS_0"]).astype(np.int32) if "JOINTS_0" in attrs else None
                w0  = self.read_accessor(attrs["WEIGHTS_0"]).astype(np.float32) if "WEIGHTS_0" in attrs else None
                idx = self.read_accessor(p_def["indices"]).astype(np.int32).reshape(-1, 3)
                mat_idx = p_def.get("material", 0)
                prims.append({
                    "pos": pos, "nrm": nrm, "uv": uv, "col": col,
                    "joints_0": j0, "weights_0": w0, "tris": idx, "material": mat_idx,
                })
            self.meshes.append({"name": m_def.get("name", ""), "primitives": prims})

    def read_accessor(self, acc_idx: int) -> np.ndarray:
        acc = self.gltf["accessors"][acc_idx]
        bv  = self.gltf["bufferViews"][acc["bufferView"]]
        offset = bv.get("byteOffset", 0) + acc.get("byteOffset", 0)
        count  = acc["count"]
        comp_t = acc["componentType"]
        acc_t  = acc["type"]
        n_comp = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}[acc_t]
        dtype  = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}[comp_t]
        arr = np.frombuffer(self.bin_buf, dtype=dtype, count=count * n_comp, offset=offset)
        return arr.reshape(count, n_comp).copy() if n_comp > 1 else arr.copy()

    def sample_animation(self, clip_name: str = None, t_sec: float = 0.0, loop: bool = True):
        """
        Returns `(local_tr, local_rt, local_sc)` dicts for all nodes at time `t_sec` of `clip_name`.
        """
        local_tr, local_rt, local_sc = {}, {}, {}
        for idx, nd in enumerate(self.nodes):
            local_tr[idx] = np.array(nd.get("translation", [0.0, 0.0, 0.0]), dtype=np.float64)
            local_rt[idx] = np.array(nd.get("rotation", [0.0, 0.0, 0.0, 1.0]), dtype=np.float64)
            local_sc[idx] = np.array(nd.get("scale", [1.0, 1.0, 1.0]), dtype=np.float64)

        if clip_name is None:
            return local_tr, local_rt, local_sc

        anim = next((a for a in self.gltf.get("animations", []) if a["name"] == clip_name), None)
        if anim is None:
            raise KeyError(f"Animation clip '{clip_name}' not found in {self.glb_path.name}")

        for ch in anim["channels"]:
            s_def = anim["samplers"][ch["sampler"]]
            times = self.read_accessor(s_def["input"]).astype(np.float64)
            vals  = self.read_accessor(s_def["output"]).astype(np.float64)
            dur   = float(times[-1]) if len(times) > 0 else 0.0
            t_eval = (t_sec % dur) if (loop and dur > 1e-6 and t_sec > dur) else max(0.0, min(t_sec, dur))

            if len(times) == 1 or t_eval <= times[0]:
                v_interp = vals[0]
            elif t_eval >= times[-1]:
                v_interp = vals[-1]
            else:
                k = int(np.searchsorted(times, t_eval, side="right")) - 1
                k = max(0, min(k, len(times) - 2))
                dt = max(float(times[k + 1] - times[k]), 1e-8)
                u = float((t_eval - times[k]) / dt)
                if s_def.get("interpolation", "LINEAR") == "STEP":
                    v_interp = vals[k]
                elif ch["target"]["path"] == "rotation":
                    v_interp = quat_slerp(vals[k], vals[k + 1], u)
                else:
                    v_interp = (1.0 - u) * vals[k] + u * vals[k + 1]

            t_node = ch["target"]["node"]
            path   = ch["target"]["path"]
            if path == "translation":
                local_tr[t_node] = np.array(v_interp, dtype=np.float64)
            elif path == "rotation":
                local_rt[t_node] = quat_norm(v_interp)
            elif path == "scale":
                local_sc[t_node] = np.array(v_interp, dtype=np.float64)

        return local_tr, local_rt, local_sc

    def compute_world_matrices(self, local_tr, local_rt, local_sc):
        world_m = {}
        def _get_w(idx):
            if idx in world_m:
                return world_m[idx]
            M = np.eye(4, dtype=np.float64)
            R = quat_to_mat3(local_rt[idx])
            S = local_sc[idx]
            M[:3, :3] = R @ np.diag(S)
            M[:3, 3]  = local_tr[idx]
            if idx in self.parent_map:
                M = _get_w(self.parent_map[idx]) @ M
            world_m[idx] = M
            return M
        for i in range(len(self.nodes)):
            _get_w(i)
        return world_m

    def evaluate_scene_meshes(
        self,
        clip_name: str = None,
        t_sec: float = 0.0,
        loop: bool = True,
        node_overrides: dict = None,
        hidden_nodes: set = None,
        hidden_joints: set = None,
    ):
        """
        Evaluates all visible meshes in the `.glb` at `(clip_name, t_sec)` using pure glTF 2.0
        node hierarchy traversal and `JOINTS_0`/`WEIGHTS_0` Linear Blend Skinning.
        `node_overrides` can supply `{node_idx: {"translation": ..., "rotation": ..., "scale": ...}}`.
        Returns `(P_world, N_world, T_all, VC_all, VM_all, VE_all, world_m)`.
        """
        local_tr, local_rt, local_sc = self.sample_animation(clip_name, t_sec, loop=loop)
        if node_overrides:
            for n_idx, ov in node_overrides.items():
                if "translation" in ov:
                    local_tr[n_idx] = np.array(ov["translation"], dtype=np.float64)
                if "rotation" in ov:
                    local_rt[n_idx] = quat_norm(ov["rotation"])
                if "scale" in ov:
                    local_sc[n_idx] = np.array(ov["scale"], dtype=np.float64)

        world_m = self.compute_world_matrices(local_tr, local_rt, local_sc)

        # Precompute skinning matrices for each skin
        skin_matrices = []
        for sk in self.skins:
            joints = sk["joints"]
            ibms   = sk["ibms"]
            s_mats = np.empty((len(joints), 4, 4), dtype=np.float32)
            for j_slot, j_node in enumerate(joints):
                s_mats[j_slot] = (world_m[j_node] @ ibms[j_slot]).astype(np.float32)
            skin_matrices.append(s_mats)

        P_out, N_out, T_out, VC_out, VM_out, VE_out = [], [], [], [], [], []
        v_off = 0

        for n_idx, nd in enumerate(self.nodes):
            if hidden_nodes and n_idx in hidden_nodes:
                continue
            if "mesh" not in nd:
                continue
            M_node = world_m[n_idx].astype(np.float32)
            if np.linalg.norm(M_node[:3, :3]) < 1e-5:
                continue # Scaled to [0,0,0]

            m_def = self.meshes[nd["mesh"]]
            sk_idx = nd.get("skin", None)

            for prim in m_def["primitives"]:
                pos = prim["pos"]
                nrm = prim["nrm"]
                tris = prim["tris"]
                N_v = len(pos)

                if sk_idx is not None and prim["joints_0"] is not None and prim["weights_0"] is not None:
                    # Pure glTF 2.0 Linear Blend Skinning!
                    s_mats = skin_matrices[sk_idx]
                    j0 = prim["joints_0"]
                    w0 = prim["weights_0"]
                    p_h = np.column_stack([pos, np.ones(N_v, dtype=np.float32)])
                    p_w = np.zeros((N_v, 3), dtype=np.float32)
                    n_w = np.zeros((N_v, 3), dtype=np.float32)
                    for c in range(4):
                        jc = j0[:, c]
                        wc = w0[:, c][:, None]
                        Mc = s_mats[jc]
                        p_w += wc * np.einsum("nij,nj->ni", Mc[:, :3, :], p_h)
                        n_w += wc * np.einsum("nij,nj->ni", Mc[:, :3, :3], nrm)
                    if hidden_joints:
                        dom_j = j0[np.arange(N_v), np.argmax(w0, axis=1)]
                        keep_v = ~np.isin(dom_j, list(hidden_joints))
                        t_mask = keep_v[tris[:, 0]] & keep_v[tris[:, 1]] & keep_v[tris[:, 2]]
                        tris = tris[t_mask]
                else:
                    # Rigid node transform
                    p_w = (pos @ M_node[:3, :3].T) + M_node[:3, 3]
                    n_w = nrm @ M_node[:3, :3].T

                if len(tris) == 0:
                    continue
                n_len = np.linalg.norm(n_w, axis=1, keepdims=True)
                n_w = n_w / np.maximum(n_len, 1e-8)

                # Resolve vertex colors & metallic-roughness from COLOR_0 and glTF material definition
                if prim["col"] is not None:
                    vc = prim["col"][:, :3].copy()
                    mat_idx = prim.get("material", 0)
                    gltf_mats = self.gltf.get("materials", [])
                    mat_def = gltf_mats[mat_idx] if mat_idx < len(gltf_mats) else {}
                    pbr_def = mat_def.get("pbrMetallicRoughness", {})
                    m_fac = float(pbr_def.get("metallicFactor", 0.45))
                    r_fac = float(pbr_def.get("roughnessFactor", 0.46))
                    e_fac = np.array(mat_def.get("emissiveFactor", [0.0, 0.0, 0.0]), dtype=np.float32)
                    vm = np.column_stack([
                        np.ones(N_v, dtype=np.float32),
                        np.full(N_v, r_fac, dtype=np.float32),
                        np.full(N_v, m_fac, dtype=np.float32),
                    ])
                    ve = np.tile(e_fac, (N_v, 1))
                    # Fallback for legacy single-material GLBs where cyan visor/rune was only marked by vertex color
                    if len(gltf_mats) <= 1:
                        is_cyan = (vc[:, 2] > vc[:, 0] + 0.25) & (vc[:, 1] > vc[:, 0] + 0.20)
                        if np.any(is_cyan):
                            vm[is_cyan] = [1.0, 0.14, 0.12]
                            ve[is_cyan] = [0.25, 0.65, 0.75]
                elif prim["uv"] is not None and len(self.images_rgba) >= 2:
                    uv = prim["uv"]
                    mat_i = prim["material"]
                    if mat_i in (1, 2) and len(self.images_rgba) >= 4:
                        im_h = self.images_rgba[3]
                        H_i, W_i, _ = im_h.shape
                        ux = np.clip(uv[:, 0] * (W_i - 1), 0, W_i - 1).astype(np.int32)
                        vy = np.clip(uv[:, 1] * (H_i - 1), 0, H_i - 1).astype(np.int32)
                        vc = im_h[vy, ux, :3]
                        vm = np.column_stack([np.ones(N_v, dtype=np.float32), np.full(N_v, 0.22, dtype=np.float32), np.full(N_v, 0.90, dtype=np.float32)])
                        ve = vc * (0.28 if mat_i == 1 else 0.34)
                    else:
                        im_bc = self.images_rgba[0]
                        im_mr = self.images_rgba[1]
                        H_i, W_i, _ = im_bc.shape
                        ux = np.clip((uv[:, 0] % 1.0) * (W_i - 1), 0, W_i - 1).astype(np.int32)
                        vy = np.clip((uv[:, 1] % 1.0) * (H_i - 1), 0, H_i - 1).astype(np.int32)
                        vc = im_bc[vy, ux, :3]
                        mr = im_mr[vy, ux]
                        vm = np.column_stack([np.ones(N_v, dtype=np.float32), mr[:, 1], mr[:, 2]])
                        ve = (vc * np.array([0.85, 0.38, 0.08], dtype=np.float32)) if mat_i == 3 else np.zeros((N_v, 3), dtype=np.float32)
                else:
                    vc = np.full((N_v, 3), 0.5, dtype=np.float32)
                    vm = np.column_stack([np.ones(N_v, dtype=np.float32), np.full(N_v, 0.5, dtype=np.float32), np.full(N_v, 0.5, dtype=np.float32)])
                    ve = np.zeros((N_v, 3), dtype=np.float32)

                P_out.append(p_w); N_out.append(n_w); T_out.append(tris + v_off)
                VC_out.append(vc); VM_out.append(vm); VE_out.append(ve)
                v_off += N_v

        return (
            np.vstack(P_out).astype(np.float32),
            np.vstack(N_out).astype(np.float32),
            np.vstack(T_out).astype(np.int32),
            np.vstack(VC_out).astype(np.float32),
            np.vstack(VM_out).astype(np.float32),
            np.vstack(VE_out).astype(np.float32),
            world_m,
        )

    def sample_multilayer_animations(self, layers: list):
        """
        Composes multiple animation layers `[(clip_name, t_sec, loop, weight, mode), ...]`.
        - `mode == "override"`: applies channel transform directly (weighted against rest if weight < 1.0)
          and records the `(node_idx, path)` in `owned_channels` to verify zero unintentional overwrites.
        - `mode == "additive"`: applies `(tr_clip - tr_rest) * weight` and `slerp(I, q_rest^-1 * q_clip, weight)`
          on top of the current transform so layers like `Damage_Comp_Chassis_Buckle_And_Compression` compose
          cleanly with `Gait_01..03` on `Node 1 (Main_Apparatus_Chassis)`.
        Returns `(local_tr, local_rt, local_sc, channel_audit)`.
        """
        rest_tr, rest_rt, rest_sc = self.sample_animation(None, 0.0)
        local_tr = {k: v.copy() for k, v in rest_tr.items()}
        local_rt = {k: v.copy() for k, v in rest_rt.items()}
        local_sc = {k: v.copy() for k, v in rest_sc.items()}

        owned_channels = {}
        conflicts = []

        for layer_spec in layers:
            clip_name = layer_spec[0]
            t_sec     = float(layer_spec[1])
            loop      = bool(layer_spec[2]) if len(layer_spec) > 2 else True
            weight    = float(layer_spec[3]) if len(layer_spec) > 3 else 1.0
            mode      = str(layer_spec[4])   if len(layer_spec) > 4 else "override"
            if clip_name is None or weight <= 1e-6:
                continue

            c_tr, c_rt, c_sc = self.sample_animation(clip_name, t_sec, loop=loop)
            anim = next((a for a in self.gltf.get("animations", []) if a["name"] == clip_name), None)
            touched = set((ch["target"]["node"], ch["target"]["path"]) for ch in anim["channels"])

            for (n_idx, path) in touched:
                if mode == "override":
                    if (n_idx, path) in owned_channels and owned_channels[(n_idx, path)] != clip_name:
                        conflicts.append((n_idx, path, owned_channels[(n_idx, path)], clip_name))
                    owned_channels[(n_idx, path)] = clip_name
                    if path == "translation":
                        local_tr[n_idx] = (1.0 - weight) * rest_tr[n_idx] + weight * c_tr[n_idx]
                    elif path == "rotation":
                        local_rt[n_idx] = quat_slerp(rest_rt[n_idx], c_rt[n_idx], weight)
                    elif path == "scale":
                        local_sc[n_idx] = (1.0 - weight) * rest_sc[n_idx] + weight * c_sc[n_idx]
                elif mode == "additive":
                    if path == "translation":
                        delta_t = c_tr[n_idx] - rest_tr[n_idx]
                        local_tr[n_idx] = local_tr[n_idx] + weight * delta_t
                    elif path == "rotation":
                        R_rest = quat_to_mat3(rest_rt[n_idx])
                        R_clip = quat_to_mat3(c_rt[n_idx])
                        R_cur  = quat_to_mat3(local_rt[n_idx])
                        R_delta = R_rest.T @ R_clip
                        # Convert R_cur @ R_delta back via slerp for weight
                        from faf_v27_kinematics import mat3_to_quat
                        q_full = quat_norm(mat3_to_quat(R_cur @ R_delta))
                        local_rt[n_idx] = quat_slerp(local_rt[n_idx], q_full, weight)
                    elif path == "scale":
                        local_sc[n_idx] = (1.0 - weight) * local_sc[n_idx] + weight * c_sc[n_idx]

        return local_tr, local_rt, local_sc, {"owned": owned_channels, "conflicts": conflicts}

    def evaluate_multilayer_scene_meshes(self, layers: list, node_overrides: dict = None):
        local_tr, local_rt, local_sc, audit = self.sample_multilayer_animations(layers)
        ov_all = {}
        for idx in range(len(self.nodes)):
            ov_all[idx] = {
                "translation": local_tr[idx],
                "rotation":    local_rt[idx],
                "scale":       local_sc[idx],
            }
        if node_overrides:
            for k, v in node_overrides.items():
                ov_all[k].update(v)
        P, N, T, VC, VM, VE, wm = self.evaluate_scene_meshes(clip_name=None, t_sec=0.0, node_overrides=ov_all)
        return P, N, T, VC, VM, VE, wm, audit
