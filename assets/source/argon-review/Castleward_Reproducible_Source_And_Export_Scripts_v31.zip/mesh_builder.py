import numpy as np


# Calibrated directly against percentile RGB measurements of /tmp/ref_IM*.png (Linear Rec.709):
# Warm-weathered dark charcoal gunmetal steel, antique bronze-gold trim, deep crimson battle-cloth, and rich saddle leather.
PALETTE = {
    # Calibrated directly to Concept Art pixel patches:
    # Warm-weathered gunmetal pewter on lit/mid steel (R > G >= B), deep charcoal-slate iron on shadow/under-armor plates!
    "STEEL_BRIGHT":   (0.275, 0.220, 0.212, 1.0),
    "STEEL_EDGE":     (0.220, 0.176, 0.172, 1.0),
    "STEEL_LIGHT":    (0.168, 0.136, 0.136, 1.0),
    "STEEL_MAIN":     (0.125, 0.102, 0.105, 1.0),
    "STEEL_FACET":    (0.086, 0.072, 0.076, 1.0),
    "STEEL_DARK":     (0.038, 0.033, 0.038, 1.0),
    "STEEL_SHADE":    (0.020, 0.018, 0.022, 1.0),
    "UNDERSUIT_DARK": (0.009, 0.008, 0.011, 1.0),
    "FACE_DARK":      (0.004, 0.005, 0.008, 1.0),

    # Creamy, luminous warm antique gold / champagne-brass (matching Pauldron Gold Rim sRGB ~(172, 140, 121) & Helmet Gold Bar)
    "BRASS_BRIGHT":   (0.560, 0.405, 0.295, 1.0),
    "BRASS_EDGE":     (0.450, 0.320, 0.230, 1.0),
    "BRASS_MAIN":     (0.350, 0.242, 0.172, 1.0),
    "BRASS_SHADE":    (0.195, 0.130, 0.092, 1.0),
    "BRASS_DARK":     (0.105, 0.068, 0.048, 1.0),

    # Weathered burgundy-crimson battle-cloth (matching Scarf & Plume sRGB ~(112, 50, 54))
    "CLOTH_BRIGHT":   (0.235, 0.048, 0.052, 1.0),
    "CLOTH_LIGHT":    (0.180, 0.035, 0.039, 1.0),
    "CLOTH_MAIN":     (0.135, 0.025, 0.029, 1.0),
    "CLOTH_SHADE":    (0.082, 0.015, 0.018, 1.0),
    "CLOTH_DARK":     (0.042, 0.008, 0.010, 1.0),

    # Rich dark saddle leather
    "LEATHER_LIGHT":  (0.145, 0.076, 0.044, 1.0),
    "LEATHER_MAIN":   (0.098, 0.050, 0.028, 1.0),
    "LEATHER_SHADE":  (0.054, 0.026, 0.015, 1.0),
    "LEATHER_DARK":   (0.024, 0.012, 0.008, 1.0),

    "RUBY_BRIGHT":    (0.620, 0.070, 0.088, 1.0),
    "RUBY_MAIN":      (0.380, 0.028, 0.040, 1.0),
    "RUBY_SHADE":     (0.180, 0.012, 0.018, 1.0),

    "WHITE":          (1.000, 1.000, 1.000, 1.0),}


class BoneFrame:
    def __init__(self, head, tail, up_hint=(0.0, 1.0, 0.0)):
        self.head = np.array(head, dtype=np.float32)
        self.tail = np.array(tail, dtype=np.float32)
        vec = self.tail - self.head
        self.length = float(np.linalg.norm(vec))
        self.w = vec / max(self.length, 1e-6)
        uh = np.array(up_hint, dtype=np.float32)
        uh = uh - np.dot(uh, self.w) * self.w
        if np.linalg.norm(uh) < 1e-5:
            uh = np.array([1.0, 0.0, 0.0], dtype=np.float32)
            uh = uh - np.dot(uh, self.w) * self.w
        self.v = uh / np.linalg.norm(uh)
        self.u = np.cross(self.v, self.w)
        self.u /= np.linalg.norm(self.u)

    def pt(self, u, v, t):
        return self.head + (t * self.length) * self.w + u * self.u + v * self.v


class MeshBuilder:
    def __init__(self, mat_names):
        self.mat_names = list(mat_names)
        self.verts = []
        self.weights = []
        self.polys = []
        self.mat_indices = []
        self.loop_colors = []
        self.loop_uvs = []

    def _resolve_mat(self, mat_key):
        if isinstance(mat_key, int):
            return max(0, min(len(self.mat_names) - 1, mat_key))
        key_Map = {
            "METAL": "MAKitMetal",
            "MATTE": "MAKitMatte",
            "VISOR": "MAVisorGlow",
            "SORCERY": "MASorceryAccent",
            "BANNER": "MABannerCloth",
        }
        target = key_Map.get(mat_key, mat_key)
        if target in self.mat_names:
            return self.mat_names.index(target)
        return 0

    def _resolve_col(self, col_key):
        if isinstance(col_key, str):
            return PALETTE.get(col_key, PALETTE["STEEL_FACET"])
        return tuple(float(x) for x in col_key)

    def add_vert(self, pos, weights):
        idx = len(self.verts)
        self.verts.append((float(pos[0]), float(pos[1]), float(pos[2])))
        if isinstance(weights, str):
            wdict = {weights: 1.0}
        elif isinstance(weights, dict):
            wdict = dict(weights)
        else:
            wdict = {}
        self.weights.append(wdict)
        return idx

    def add_poly(self, v_indices, mat="METAL", color="STEEL_FACET", uvs=None, outward_ref=None):
        v_list = [int(i) for i in v_indices]
        if len(v_list) < 3:
            return
        if outward_ref is not None:
            pts = np.array([self.verts[i] for i in v_list], dtype=np.float32)
            p0, p1, p2 = pts[0], pts[1], pts[2]
            n = np.cross(p1 - p0, p2 - p0)
            center = pts.mean(axis=0)
            ref = np.array(outward_ref, dtype=np.float32)
            if np.dot(n, center - ref) < 0.0:
                v_list = v_list[::-1]
                if uvs is not None:
                    uvs = uvs[::-1]

        self.polys.append(v_list)
        self.mat_indices.append(self._resolve_mat(mat))
        rgba = self._resolve_col(color)
        for k in range(len(v_list)):
            self.loop_colors.append(rgba)
            if uvs is not None and k < len(uvs):
                self.loop_uvs.append((float(uvs[k][0]), float(uvs[k][1])))
            else:
                self.loop_uvs.append((0.0, 0.0))

    def add_quad(self, i0, i1, i2, i3, mat="METAL", color="STEEL_FACET", uvs=None, outward_ref=None):
        self.add_poly([i0, i1, i2, i3], mat=mat, color=color, uvs=uvs, outward_ref=outward_ref)

    def add_tri(self, i0, i1, i2, mat="METAL", color="STEEL_FACET", uvs=None, outward_ref=None):
        self.add_poly([i0, i1, i2], mat=mat, color=color, uvs=uvs, outward_ref=outward_ref)

    def add_loft(self, rings, weights, mat="METAL", colors="STEEL_FACET", closed_ring=True, cap_start=False, cap_end=False, cap_color=None):
        n_rings = len(rings)
        n_pts = len(rings[0])
        ring_v_indices = []
        all_pts = []
        for r_i, ring in enumerate(rings):
            w_r = weights[r_i] if isinstance(weights, list) else weights
            v_row = []
            for p in ring:
                v_row.append(self.add_vert(p, w_r))
                all_pts.append(p)
            ring_v_indices.append(v_row)

        all_pts_arr = np.array(all_pts, dtype=np.float32)
        centroid = all_pts_arr.mean(axis=0)

        n_segs = n_pts if closed_ring else (n_pts - 1)
        for r_i in range(n_rings - 1):
            r0 = ring_v_indices[r_i]
            r1 = ring_v_indices[r_i + 1]
            c_band = colors[r_i] if (isinstance(colors, list) and not isinstance(colors[0], (int, float))) else colors
            ring0_pts = np.array(rings[r_i], dtype=np.float32)
            ring1_pts = np.array(rings[r_i + 1], dtype=np.float32)
            seg_ref = 0.5 * (ring0_pts.mean(axis=0) + ring1_pts.mean(axis=0))

            for s_i in range(n_segs):
                s_next = (s_i + 1) % n_pts
                c_quad = c_band[s_i] if (isinstance(c_band, list) and not isinstance(c_band[0], (int, float))) else c_band
                self.add_quad(r0[s_i], r0[s_next], r1[s_next], r1[s_i], mat=mat, color=c_quad, outward_ref=seg_ref)

        c_cap = cap_color if cap_color is not None else (colors if isinstance(colors, str) else "STEEL_DARK")
        if cap_start and closed_ring:
            self.add_poly(ring_v_indices[0][::-1], mat=mat, color=c_cap, outward_ref=centroid)
        if cap_end and closed_ring:
            self.add_poly(ring_v_indices[-1], mat=mat, color=c_cap, outward_ref=centroid)
        return ring_v_indices

    def add_flat_beveled_plate(self, corners_3d, normal_dir, thickness, bevel_inset, weights,
                               mat="METAL", col_face="STEEL_FACET", col_edge="STEEL_LIGHT", col_side="STEEL_DARK", col_back="UNDERSUIT_DARK"):
        pts = [np.array(p, dtype=np.float32) for p in corners_3d]
        n = np.array(normal_dir, dtype=np.float32)
        n /= max(np.linalg.norm(n), 1e-6)
        c = np.mean(pts, axis=0)

        inner_pts = [p * (1.0 - bevel_inset) + c * bevel_inset for p in pts]

        v_back  = [self.add_vert(p - 0.30 * thickness * n, weights) for p in pts]
        v_outer = [self.add_vert(p + 0.45 * thickness * n, weights) for p in pts]
        v_inner = [self.add_vert(ip + 0.85 * thickness * n, weights) for ip in inner_pts]

        ref_back = c - 0.5 * thickness * n
        ref_front = c + 1.5 * thickness * n
        N = len(pts)
        for i in range(N):
            inext = (i + 1) % N
            self.add_quad(v_back[i], v_back[inext], v_outer[inext], v_outer[i], mat=mat, color=col_side, outward_ref=ref_back)
            b_col = col_edge if i in (0, N - 1) else col_face
            self.add_quad(v_outer[i], v_outer[inext], v_inner[inext], v_inner[i], mat=mat, color=b_col, outward_ref=ref_back)

        self.add_poly(v_inner, mat=mat, color=col_face, outward_ref=ref_back)
        self.add_poly(v_back[::-1], mat=mat, color=col_back, outward_ref=ref_front)

    def add_faceted_shield_plate(self, grid_pts, outward_hint, thickness, bevel_inset, weights,
                                 mat="METAL", col_faces="STEEL_FACET", col_bevel="STEEL_EDGE",
                                 col_side="STEEL_SHADE", col_back="UNDERSUIT_DARK"):
        G = np.array(grid_pts, dtype=np.float32)
        R, C, _ = G.shape
        n_hint = np.array(outward_hint, dtype=np.float32)
        n_hint /= max(np.linalg.norm(n_hint), 1e-6)

        N_grid = np.zeros_like(G)
        for r in range(R):
            for c in range(C):
                r0, r1 = max(0, r - 1), min(R - 1, r + 1)
                c0, c1 = max(0, c - 1), min(C - 1, c + 1)
                du = G[r, c1] - G[r, c0]
                dv = G[r1, c] - G[r0, c]
                n = np.cross(du, dv)
                norm = np.linalg.norm(n)
                if norm < 1e-6:
                    n = n_hint
                else:
                    n /= norm
                    if np.dot(n, n_hint) < 0.0:
                        n = -n
                N_grid[r, c] = 0.65 * n + 0.35 * n_hint
                N_grid[r, c] /= max(np.linalg.norm(N_grid[r, c]), 1e-6)

        center = G.mean(axis=(0, 1))
        G_inset = G * (1.0 - bevel_inset) + center[None, None, :] * bevel_inset

        v_back = np.zeros((R, C), dtype=np.int32)
        v_mid  = np.zeros((R, C), dtype=np.int32)
        v_top  = np.zeros((R, C), dtype=np.int32)

        for r in range(R):
            w_r = weights[r] if isinstance(weights, list) else weights
            for c in range(C):
                p = G[r, c]
                pin = G_inset[r, c]
                n = N_grid[r, c]
                v_back[r, c] = self.add_vert(p - 0.30 * thickness * n, w_r)
                v_mid[r, c]  = self.add_vert(p + 0.45 * thickness * n, w_r)
                v_top[r, c]  = self.add_vert(pin + 0.90 * thickness * n, w_r)

        ref_behind = center - 0.8 * thickness * n_hint
        ref_front  = center + 1.5 * thickness * n_hint

        for r in range(R - 1):
            for c in range(C - 1):
                if isinstance(col_faces, list):
                    row_c = col_faces[min(r, len(col_faces) - 1)]
                    c_cell = row_c[min(c, len(row_c) - 1)] if isinstance(row_c, list) else row_c
                else:
                    c_cell = col_faces
                cell_ref = G[r:r+2, c:c+2].mean(axis=(0, 1)) - 0.5 * thickness * n_hint
                self.add_quad(v_top[r, c], v_top[r, c+1], v_top[r+1, c+1], v_top[r+1, c], mat=mat, color=c_cell, outward_ref=cell_ref)
                self.add_quad(v_back[r, c], v_back[r+1, c], v_back[r+1, c+1], v_back[r, c+1], mat=mat, color=col_back, outward_ref=ref_front)

        perim = []
        for c in range(C - 1):
            perim.append(((0, c), (0, c+1), True))
        for r in range(R - 1):
            perim.append(((r, C-1), (r+1, C-1), False))
        for c in range(C - 1, 0, -1):
            perim.append(((R-1, c), (R-1, c-1), False))
        for r in range(R - 1, 0, -1):
            perim.append(((r, 0), (r-1, 0), True))

        for (r0, c0), (r1, c1), is_hi in perim:
            self.add_quad(v_back[r0, c0], v_back[r1, c1], v_mid[r1, c1], v_mid[r0, c0], mat=mat, color=col_side, outward_ref=ref_behind)
            b_col = col_bevel if is_hi else col_side
            self.add_quad(v_mid[r0, c0], v_mid[r1, c1], v_top[r1, c1], v_top[r0, c0], mat=mat, color=b_col, outward_ref=ref_behind)

    def add_beveled_box(self, center, half_extents, axes=None, bevel=0.16, weights="pelvis",
                        mat="METAL", col_main="STEEL_FACET", col_edge="STEEL_LIGHT", col_dark="STEEL_DARK"):
        cx, cy, cz = center
        hx, hy, hz = half_extents
        if axes is None:
            ux, uy, uz = np.array([1,0,0], dtype=np.float32), np.array([0,1,0], dtype=np.float32), np.array([0,0,1], dtype=np.float32)
        else:
            ux, uy, uz = [np.array(a, dtype=np.float32) / max(np.linalg.norm(a), 1e-6) for a in axes]

        c = np.array([cx, cy, cz], dtype=np.float32)
        b = 1.0 - bevel

        def pt(sx, sy, sz):
            return c + (sx * hx) * ux + (sy * hy) * uy + (sz * hz) * uz

        r0 = [pt(-b,  b, -1.0), pt( b,  b, -1.0), pt( b, -b, -1.0), pt(-b, -b, -1.0)]
        r1 = [pt(-1,  1, -b),   pt( 1,  1, -b),   pt( 1, -1, -b),   pt(-1, -1, -b)]
        r2 = [pt(-1,  1,  b),   pt( 1,  1,  b),   pt( 1, -1,  b),   pt(-1, -1,  b)]
        r3 = [pt(-b,  b,  1.0), pt( b,  b,  1.0), pt( b, -b,  1.0), pt(-b, -b,  1.0)]

        self.add_loft(
            [r0, r1, r2, r3],
            weights=weights,
            mat=mat,
            colors=[col_dark, [col_main, col_edge, col_dark, col_main], col_edge],
            closed_ring=True,
            cap_start=True,
            cap_end=True,
            cap_color=col_edge,
        )

    def add_diamond_boss(self, center, normal, up_vec, radius_u, radius_v, height, weights,
                         mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_base="BRASS_SHADE"):
        c = np.array(center, dtype=np.float32)
        n = np.array(normal, dtype=np.float32)
        n /= max(np.linalg.norm(n), 1e-6)
        up = np.array(up_vec, dtype=np.float32)
        up = up - np.dot(up, n) * n
        up /= max(np.linalg.norm(up), 1e-6)
        rt = np.cross(up, n)
        rt /= max(np.linalg.norm(rt), 1e-6)

        r0 = [
            c + radius_v * up,
            c + radius_u * rt,
            c - radius_v * up,
            c - radius_u * rt,
        ]
        r1 = [
            c + 0.14 * radius_v * up + height * n,
            c + 0.14 * radius_u * rt + height * n,
            c - 0.14 * radius_v * up + height * n,
            c - 0.14 * radius_u * rt + height * n,
        ]
        self.add_loft(
            [r0, r1],
            weights=weights,
            mat=mat,
            colors=[[col_edge, col_main, col_base, col_edge]],
            closed_ring=True,
            cap_start=True,
            cap_end=True,
            cap_color=col_edge,
        )


    def bake_loop_shading(self):
        """
        Bakes 3D per-vertex Ambient Occlusion, Convex/Concave Curvature, and Vertical Gradient
        directly into self.loop_colors (ArmorColor) so each polygon has smooth painterly gradients
        both inside Blender and in the software rasterizer!
        """
        n_v = len(self.verts)
        n_p = len(self.polys)
        if n_v == 0 or n_p == 0:
            return

        verts = np.array(self.verts, dtype=np.float32)
        # Compute face normals and centers
        f_norms = np.zeros((n_p, 3), dtype=np.float32)
        f_centers = np.zeros((n_p, 3), dtype=np.float32)
        v_faces = [[] for _ in range(n_v)]

        for pi, poly in enumerate(self.polys):
            pts = verts[poly]
            f_centers[pi] = pts.mean(axis=0)
            if len(poly) >= 3:
                fn = np.cross(pts[1] - pts[0], pts[2] - pts[0])
                norm = np.linalg.norm(fn)
                if norm > 1e-8:
                    f_norms[pi] = fn / norm
            for vi in poly:
                v_faces[vi].append(pi)

        # Compute smooth vertex normals and local convexity/AO per vertex
        v_norms = np.zeros((n_v, 3), dtype=np.float32)
        for vi in range(n_v):
            if v_faces[vi]:
                vn = f_norms[v_faces[vi]].mean(axis=0)
                nrm = np.linalg.norm(vn)
                if nrm > 1e-8:
                    v_norms[vi] = vn / nrm

        # Build adjacency for curvature & local cavity AO
        v_nbrs = [set() for _ in range(n_v)]
        for poly in self.polys:
            m = len(poly)
            for k in range(m):
                a, b = poly[k], poly[(k + 1) % m]
                v_nbrs[a].add(b)
                v_nbrs[b].add(a)

        v_curv = np.zeros(n_v, dtype=np.float32)
        for vi in range(n_v):
            nbrs = list(v_nbrs[vi])
            if not nbrs:
                continue
            diff = verts[nbrs] - verts[vi]
            dist = np.linalg.norm(diff, axis=1, keepdims=True) + 1e-6
            dirs = diff / dist
            # Positive dot(v_norm, -dirs) means neighbors bend away behind the normal (CONVEX ridge)
            # Negative dot(v_norm, -dirs) means neighbors rise in front of the normal (CONCAVE cavity)
            curv = float(np.mean(np.sum(-dirs * v_norms[vi], axis=1)))
            v_curv[vi] = np.clip(curv * 1.6, -1.0, 1.0)

        z_min, z_max = float(verts[:, 2].min()), float(verts[:, 2].max())
        z_span = max(0.08, z_max - z_min)

        l_idx = 0
        for pi, poly in enumerate(self.polys):
            fn = f_norms[pi]
            for k, vi in enumerate(poly):
                rgba = list(self.loop_colors[l_idx])
                if not (rgba[0] > 0.92 and rgba[1] > 0.92 and rgba[2] > 0.92):
                    local_z = (verts[vi, 2] - z_min) / z_span
                    v_grad = 0.93 + 0.14 * local_z
                    c_val = v_curv[vi]
                    curv_mod = 1.0 + (0.12 * c_val if c_val > 0 else 0.18 * c_val)
                    vn = v_norms[vi]
                    up_bias = 1.0 + 0.05 * float(vn[2] - fn[2])
                    mult = float(np.clip(v_grad * curv_mod * up_bias, 0.75, 1.22))
                    self.loop_colors[l_idx] = (
                        float(np.clip(rgba[0] * mult, 0.0, 1.0)),
                        float(np.clip(rgba[1] * mult, 0.0, 1.0)),
                        float(np.clip(rgba[2] * mult, 0.0, 1.0)),
                        rgba[3],
                    )
                l_idx += 1

    def mirror_from(self, other):
        self.verts = [(-x, y, z) for (x, y, z) in other.verts]
        self.weights = []
        for wd in other.weights:
            nwd = {}
            for k, val in wd.items():
                if k.endswith(".L"):
                    nk = k[:-2] + ".R"
                elif k.endswith(".R"):
                    nk = k[:-2] + ".L"
                else:
                    nk = k
                nwd[nk] = val
            self.weights.append(nwd)
        self.polys = [p[::-1] for p in other.polys]
        self.mat_indices = list(other.mat_indices)
        self.loop_colors = []
        self.loop_uvs = []
        offset = 0
        for p in other.polys:
            plen = len(p)
            cols = other.loop_colors[offset:offset+plen][::-1]
            uvs = other.loop_uvs[offset:offset+plen][::-1]
            self.loop_colors.extend(cols)
            self.loop_uvs.extend(uvs)
            offset += plen

    def compile(self, vg_names):
        vg_map = {name: i for i, name in enumerate(vg_names)}
        positions = np.array(self.verts, dtype=np.float32)
        totvert = len(self.verts)
        totpoly = len(self.polys)

        poly_offsets = [0]
        corner_verts = []
        edge_map = {}
        edges = []
        corner_edges = []

        for poly in self.polys:
            n = len(poly)
            poly_offsets.append(poly_offsets[-1] + n)
            for k in range(n):
                va = int(poly[k])
                vb = int(poly[(k + 1) % n])
                corner_verts.append(va)
                ekey = (va, vb) if va < vb else (vb, va)
                eidx = edge_map.get(ekey)
                if eidx is None:
                    eidx = len(edges)
                    edge_map[ekey] = eidx
                    edges.append(ekey)
                corner_edges.append(eidx)

        totedge = len(edges)
        totloop = len(corner_verts)

        compiled_weights = []
        for wdict in self.weights:
            wlist = []
            for k, val in wdict.items():
                if k in vg_map and val > 1e-5:
                    wlist.append((vg_map[k], float(val)))
            if not wlist and vg_names:
                wlist.append((0, 1.0))
            compiled_weights.append(wlist)

        return {
            "totvert": totvert,
            "totedge": totedge,
            "totpoly": totpoly,
            "totloop": totloop,
            "positions": positions,
            "edges": np.array(edges, dtype=np.int32),
            "poly_offsets": np.array(poly_offsets, dtype=np.int32),
            "corner_verts": np.array(corner_verts, dtype=np.int32),
            "corner_edges": np.array(corner_edges, dtype=np.int32),
            "armor_color": np.array(self.loop_colors, dtype=np.float32),
            "uv_map": np.array(self.loop_uvs, dtype=np.float32),
            "material_index": np.array(self.mat_indices, dtype=np.int32),
            "weights": compiled_weights,
        }
