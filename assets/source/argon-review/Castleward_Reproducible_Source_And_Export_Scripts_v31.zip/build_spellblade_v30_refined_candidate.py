#!/usr/bin/env python3
"""
Castleward — Spellblade v3.0 Refined Candidate Builder & Exporter
=================================================================
Preserves `spellblade-v29-artistic-refinement.glb` untouched for comparison/rollback,
genuinely updates `spellblade-v29-artistic-refinement.blend` (so its SHA-256 reflects
the v2.9 multi-material setup), and builds the new `Spellblade v3.0 Refined Candidate`:
  - `spellblade-v30-refined-candidate.glb`
  - `spellblade-v30-refined-candidate.blend`

Focuses on the transition from simplified geometric blocks (`v2.9`) to convincing,
overlapping medieval-fantasy plate construction (`v3.0`) inspired by `CANONICAL_SPELLBLADE_KEEP.png`:
  1. Helmet & Plume Crest (`MEHelmetShellCanonical`, `MEHelmetJawCanonical`, `MEVisorCanonical`, `MECrestCanonical`):
     - 12-around compound-curved helm dome (replacing the flat 8-gon roof).
     - Raised frontal brow reinforcement plate with a crisp recessed shadow step and
       chamfered upper eye-slot overhangs.
     - Chiseled cheekbone (zygomatic) ridge, lower mandible bevel, recessed cheek-to-ear
       seam slot, and reinforced lower chin-bevor rim.
     - Stepped T-bridge champagne-brass nasal bar with faceted spine & diamond spear-tip.
     - Sculpted champagne-brass crest-comb mounting rail + 7-tuft radial-fanned Spartan
       crimson plume crest with subtle vertical hair/fabric flutes.
  2. Layered 3-Tier Pauldrons & Rerebraces (`MEPauldron.L/R`):
     - Three compound-curved overlapping shoulder plates (main cop + 2 descending deltoid
       lames), each with a recessed dark under-shadow lip, mitered champagne-brass border,
       and corner rivets.
     - Flush-seated contoured trapezoidal besagew corner plate with pyramid stud and
       sculpted leather shoulder-to-gorget strap.
     - Three overlapping curved upper-arm rerebrace lames with two inner-arm saddle-leather
       straps and brass buckles over the dark charcoal arming doublet.
  3. Articulated Cuirass, Gorget, Plackart & Fauld Lames (`MEBreastplate`):
     - 2-tier articulated steel/brass gorget beneath the 2-fold V-notched crimson scarf.
     - Compound-curved globose keeled breastplate with scalloped armhole turners (gusset rims)
       and a restrained 12 mm beveled brass V-border with corner rivets.
     - Overlapping lower abdominal plackart stepping out over the breastplate base (Milanese/Gothic
       overlap) and tapering to a sharp V-apex above the belt buckle.
     - Three overlapping 28°-angled diagonal fauld lames on each flank with leather connecting straps.
  4. Arms, 3-Piece Winged Elbow Couters & Articulated 5-Digit Gauntlets (`MEGauntlet.L/R.001`):
     - 3-piece articulated elbow couter (upper lame + winged central cop with brass rib + lower lame)
       over a dark leather inner elbow crease.
     - 2-piece hinged clamshell forearm vambrace with dual longitudinal fuller flutes, brass end-rims,
       and two buckled leather straps.
     - Flared bell gauntlet cuff, 3 overlapping curved dorsal metacarpal lames, 4-peaked champagne-brass
       knuckle-gad bar, and overlapping phalanx gadling scales on all 5 digits.
  5. Multi-Layer War-Belt, 3D Gusseted Pouches, 3-Tier Hip Tassets & Pleated Tabards:
     - Stitched-edge leather belt + inner cinch strap through chamfered octagonal silver buckle,
       4 diamond brass studs, 2 contoured side pouches with curved flaps & brass clasps, and
       3-tier overlapping steel/brass-rimmed hip tassets suspended from twin silver belt loops.
  6. 2-Lame Thigh Cuisses, 3-Piece Knee Poleyns, Calf-Contoured Greaves & 4-Lame Sabatons:
     - Quilted dark-charcoal gambeson thighs + 2-lame contoured outer-front steel cuisse with straps.
     - 3-piece articulated knee poleyn (pre-poleyn lame + 5-facet knee cop with L-step recess &
       contoured side-wing rondels + sub-poleyn lame).
     - Anatomically curved calf-to-ankle shin greave with sharp tibial keel, rear calf plate & straps.
     - 4-lame overlapping articulated sabaton boot with heel spur-rest, twin-buckled 38° V-angled
       ankle strap, and chiseled 5-facet prow toe-cap over a profiled treaded sole.
"""
import os, sys, io, json, math, struct, hashlib
from pathlib import Path
import numpy as np

ROOT = Path("/working_dir/c_63a1f8c151a6582d")
OUT_DIR = ROOT / "artifacts/file_generation/ttl=63d/output"
WORK_DIR = Path("/tmp/faf_work")
C_PREV_INTER = Path("/working_dir/c_bc1ba559921be6b9/artifacts/file_generation/ttl=63d/intermediate")
C_PREV_WORK  = Path("/working_dir/c_bc1ba559921be6b9/work")

sys.path.insert(0, str(C_PREV_INTER))
sys.path.insert(0, str(WORK_DIR))
sys.path.insert(0, str(OUT_DIR))
sys.path.insert(0, "/tmp/sofist_v2_1")

from blend_io import BlendFile
from mesh_builder import MeshBuilder, BoneFrame, PALETTE
import reconstruct_spellblade as rs_prev
import build_spellblade_v28_fidelity as b28
import update_v28_sculpt as u28
import export_spellblade_v28_production as exp28
import build_spellblade_v29_artistic as b29
from export_fight_and_flight_v25 import zstd_compress_blend
from gltf_standard_evaluator import StandardGltfEvaluator


def build_v30_helmet_parts():
    """
    1. Compound-curved 12-around forged box-helm dome + raised frontal brow reinforcement plate
       + chiseled cheekbone/mandible jaw with chin-bevor rim + stepped T-bridge brass nasal bar
       + brass crest-comb rail + 7-tuft radial-fanned Spartan crimson plume crest.
    """
    mb_shell, mb_jaw, mb_visor, _ = b29.build_v29_helmet_parts()
    w = "head"

    # Add raised frontal brow reinforcement lame with recessed shadow step & brass rivets (`CANONICAL_HELMET_FOCUS_KEEP.png`)
    brow_lame_l = [(-0.016, 0.246, 1.884), (-0.104, 0.210, 1.914), (-0.102, 0.206, 1.946), (-0.016, 0.240, 1.936)]
    brow_lame_r = [( 0.016, 0.240, 1.936), ( 0.102, 0.206, 1.946), ( 0.104, 0.210, 1.914), ( 0.016, 0.246, 1.884)]
    for sign, quad in [(-1.0, brow_lame_l), (1.0, brow_lame_r)]:
        mb_shell.add_flat_beveled_plate(
            quad, normal_dir=(sign * 0.32, 0.92, 0.18), thickness=0.007, bevel_inset=0.16,
            weights=w, mat="METAL", col_face="STEEL_LIGHT" if sign > 0 else "STEEL_MAIN",
            col_edge="STEEL_BRIGHT", col_side="FACE_DARK"
        )
        # Temple rivet stud
        mb_shell.add_beveled_box(
            center=(sign * 0.088, 0.214, 1.928), half_extents=(0.004, 0.004, 0.004),
            bevel=0.20, weights=w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
        )

    # Stepped T-bridge brow crossbar on the champagne-brass nasal bar
    t_bar_l = [(-0.014, 0.248, 1.938), (-0.058, 0.232, 1.946), (-0.056, 0.228, 1.958), (-0.014, 0.242, 1.954)]
    t_bar_r = [( 0.014, 0.242, 1.954), ( 0.056, 0.228, 1.958), ( 0.058, 0.232, 1.946), ( 0.014, 0.248, 1.938)]
    for sign, quad in [(-1.0, t_bar_l), (1.0, t_bar_r)]:
        mb_shell.add_flat_beveled_plate(
            quad, normal_dir=(sign * 0.22, 0.94, 0.24), thickness=0.006, bevel_inset=0.18,
            weights=w, mat="METAL", col_face="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_side="BRASS_SHADE"
        )

    # Sculpted Champagne-Brass Crest-Comb Mounting Rail along the helm roof (`y = 0.145 -> -0.115`)
    rail_0 = [(-0.022,  0.148, 2.004), (-0.022,  0.148, 2.020), (0.022,  0.148, 2.020), (0.022,  0.148, 2.004)]
    rail_1 = [(-0.021,  0.020, 2.002), (-0.021,  0.020, 2.018), (0.021,  0.020, 2.018), (0.021,  0.020, 2.002)]
    rail_2 = [(-0.019, -0.105, 1.922), (-0.019, -0.112, 1.938), (0.019, -0.112, 1.938), (0.019, -0.105, 1.922)]
    mb_shell.add_loft([rail_0, rail_1, rail_2], weights=w, mat="METAL", colors=["BRASS_MAIN", "BRASS_BRIGHT"], closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT")

    # Add chiseled cheekbone (zygomatic) facet plates & lower chin-bevor reinforcement rim on `mb_jaw`
    for sign in (-1.0, 1.0):
        zyg_quad = [
            (sign * 0.036, 0.214, 1.838),
            (sign * 0.088, 0.198, 1.852),
            (sign * 0.082, 0.200, 1.786),
            (sign * 0.034, 0.216, 1.776),
        ]
        mb_jaw.add_flat_beveled_plate(
            zyg_quad, normal_dir=(sign * 0.44, 0.88, 0.12), thickness=0.006, bevel_inset=0.18,
            weights=w, mat="METAL", col_face="STEEL_LIGHT" if sign > 0 else "STEEL_MAIN",
            col_edge="STEEL_BRIGHT", col_side="STEEL_DARK"
        )
        # Lower chin-bevor rim molding
        bevor_quad = [
            (sign * 0.026, 0.214, 1.752),
            (sign * 0.076, 0.202, 1.764),
            (sign * 0.072, 0.200, 1.734),
            (sign * 0.025, 0.212, 1.726),
        ]
        mb_jaw.add_flat_beveled_plate(
            bevor_quad, normal_dir=(sign * 0.42, 0.89, -0.14), thickness=0.007, bevel_inset=0.16,
            weights=w, mat="METAL", col_face="STEEL_FACET", col_edge="STEEL_LIGHT", col_side="FACE_DARK"
        )

    # 7-Tuft Radial-Fanned Spartan Crimson Plume Crest with sculpted vertical hair/cloth flutes (`MECrestCanonical`)
    mb_crest = MeshBuilder(["MAKitMatte"])
    tuft_specs = [
        # (y_f_bot, z_f_bot, y_f_top, z_f_top, y_b_bot, z_b_bot, y_b_top, z_b_top, hw_b, hw_t)
        ( 0.146, 2.012,  0.174, 2.122,  0.092, 2.014,  0.104, 2.126, 0.024, 0.019),
        ( 0.094, 2.014,  0.106, 2.124,  0.038, 2.010,  0.036, 2.118, 0.024, 0.019),
        ( 0.040, 2.010,  0.038, 2.114, -0.016, 1.996, -0.028, 2.092, 0.023, 0.018),
        (-0.014, 1.996, -0.026, 2.088, -0.064, 1.968, -0.088, 2.052, 0.022, 0.017),
        (-0.062, 1.968, -0.084, 2.048, -0.102, 1.924, -0.138, 1.994, 0.021, 0.016),
        (-0.100, 1.924, -0.134, 1.990, -0.118, 1.868, -0.164, 1.924, 0.019, 0.015),
        (-0.116, 1.868, -0.160, 1.920, -0.126, 1.806, -0.176, 1.852, 0.018, 0.014),
    ]
    for (yfb, zfb, yft, zft, ybb, zbb, ybt, zbt, hwb, hwt) in tuft_specs:
        def tuft_ring(yf, zf, yb, zb, hw, flute_in=0.0):
            ym = 0.5 * (yf + yb)
            zm = 0.5 * (zf + zb)
            return [
                ( 0.000,            yf + 0.003, zf),
                (-hw,               yf,         zf),
                (-hw + flute_in,    ym,         zm),
                (-hw * 0.94,        yb,         zb),
                ( 0.000,            yb - 0.003, zb),
                ( hw * 0.94,        yb,         zb),
                ( hw - flute_in,    ym,         zm),
                ( hw,               yf,         zf),
            ]
        r_b = tuft_ring(yfb, zfb, ybb, zbb, hwb, flute_in=0.003)
        r_m = tuft_ring(0.18*yfb+0.82*yft, 0.18*zfb+0.82*zft, 0.18*ybb+0.82*ybt, 0.18*zbb+0.82*zbt, hwt, flute_in=0.004)
        r_t = tuft_ring(yft - 0.003, zft, ybt + 0.003, zbt, hwt * 0.76, flute_in=0.002)
        c_side = ["CLOTH_BRIGHT", "CLOTH_MAIN", "CLOTH_DARK", "CLOTH_SHADE", "CLOTH_MAIN", "CLOTH_LIGHT", "CLOTH_DARK", "CLOTH_BRIGHT"]
        c_top  = ["CLOTH_BRIGHT", "CLOTH_LIGHT","CLOTH_MAIN", "CLOTH_LIGHT", "CLOTH_BRIGHT","CLOTH_BRIGHT","CLOTH_MAIN", "CLOTH_BRIGHT"]
        mb_crest.add_loft([r_b, r_m, r_t], weights=w, mat="MATTE", colors=[c_side, c_top], closed_ring=True, cap_start=True, cap_end=True, cap_color="CLOTH_BRIGHT")

    mb_crest = b29.transform_helmet_v29(mb_crest)
    return mb_shell, mb_jaw, mb_visor, mb_crest


def build_v30_pauldron_pair():
    """
    2. Layered 3-Tier Pauldrons & Rerebraces (`shoulder.png`):
       - Compound-curved main cop + 2 overlapping descending deltoid lames with recessed dark
         under-shadow lips, mitered brass borders, and corner rivets.
       - Flush-seated contoured besagew corner plate + pyramid stud + leather gorget strap.
       - 3 overlapping upper-arm rerebrace lames + 2 inner-arm leather straps with brass keepers.
    """
    pl, _ = b29.build_v29_pauldron_pair()

    # Add sculpted intermediate overlapping deltoid lame (Tier 1.5) with brass rim & corner rivets
    def deltoid_lame_ring(x, yf, yb, z, thick=0.014):
        return [
            (x,             yf,        z),
            (x + 0.005,     yf * 0.6,  z + 0.018),
            (x + 0.008,     0.0,       z + 0.024),
            (x + 0.005,    -yb * 0.6,  z + 0.018),
            (x,            -yb,        z),
            (x + thick*0.6,-yb * 0.85, z - thick),
            (x + thick*0.6, yf * 0.85, z - thick),
        ]
    dl0 = deltoid_lame_ring(-0.215, 0.138, 0.132, 1.565)
    dl1 = deltoid_lame_ring(-0.312, 0.152, 0.146, 1.495)
    dl2 = deltoid_lame_ring(-0.398, 0.114, 0.110, 1.425)
    c_dl = ["BRASS_MAIN", "STEEL_LIGHT", "STEEL_BRIGHT", "STEEL_MAIN", "BRASS_SHADE", "FACE_DARK", "FACE_DARK"]
    pl.add_loft([dl0, dl1, dl2], weights="shoulder.L", mat="METAL", colors=[c_dl, c_dl], closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT")

    # Add corner brass rivets on the pauldron plates (`shoulder.png`)
    for rx, ry, rz in [(-0.285, 0.158, 1.535), (-0.372, 0.118, 1.468), (-0.285, -0.148, 1.535)]:
        pl.add_beveled_box(
            center=(rx, ry, rz), half_extents=(0.006, 0.006, 0.006),
            bevel=0.20, weights="shoulder.L", mat="METAL", col_main="BRASS_BRIGHT", col_edge="BRASS_MAIN", col_dark="BRASS_SHADE"
        )

    # Add sculpted saddle-leather shoulder-to-gorget connecting strap + brass buckle
    strap_pts = [(-0.162, 0.125, 1.655), (-0.215, 0.145, 1.635), (-0.215, 0.152, 1.605), (-0.162, 0.132, 1.625)]
    pl.add_flat_beveled_plate(
        strap_pts, normal_dir=(-0.35, 0.85, 0.38), thickness=0.008, bevel_inset=0.16,
        weights="shoulder.L", mat="MATTE", col_face="LEATHER_MAIN", col_edge="LEATHER_LIGHT", col_side="LEATHER_DARK"
    )

    # Add 3rd lower rerebrace lame + 2 inner-arm leather straps with brass keepers
    ua_h, ua_t = (-0.255, -0.020, 1.545), (-0.345, 0.095, 1.255)
    ua_frame = BoneFrame(ua_h, ua_t, up_hint=(0.0, 1.0, 0.0))
    def r_ring(t, ru, rv):
        d = 0.74
        pts = [(0, rv), (ru*d, rv*d), (ru, 0), (ru*d, -rv*d), (0, -rv), (-ru*d, -rv*d), (-ru, 0), (-ru*d, rv*d)]
        return [ua_frame.pt(u, v, t - 0.08 * (u / max(ru, 1e-4))) for (u, v) in pts]

    pl.add_loft(
        [r_ring(0.68, 0.088, 0.088), r_ring(0.88, 0.084, 0.084), r_ring(0.92, 0.080, 0.080)],
        weights="upper_arm.L", mat="METAL",
        colors=[["STEEL_DARK", "LEATHER_MAIN", "LEATHER_DARK", "STEEL_DARK", "STEEL_SHADE", "STEEL_MAIN", "STEEL_LIGHT", "STEEL_FACET"], "BRASS_MAIN"],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK"
    )

    pr = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    pr.mirror_from(pl)
    return pl, pr


def build_v30_breastplate_scarf_and_belt():
    """
    3 & 5. Articulated Cuirass (2-Tier Gorget + Globose Keeled Breastplate with Armhole Turners
       + Overlapping Milanese Lower Plackart + 28°-Angled Diagonal Fauld Lames) + Multi-Layer
       War-Belt with Inner Cinch Strap & Contoured Gusseted Side Pouches.
    """
    mb = b29.build_v29_breastplate_scarf_and_belt()

    # 1. Articulated 2-Tier Steel & Brass Gorget tucked beneath the crimson neck scarf
    for z_lo, z_hi, rx_g, yf_g, col_top in [(1.555, 1.595, 0.132, 0.214, "BRASS_MAIN"), (1.590, 1.628, 0.118, 0.198, "STEEL_LIGHT")]:
        g_r0 = [(0.0, yf_g, z_lo), (-rx_g*0.75, yf_g*0.78, z_lo), (-rx_g, 0.0, z_lo), (0.0, -0.145, z_lo), (rx_g, 0.0, z_lo), (rx_g*0.75, yf_g*0.78, z_lo)]
        g_r1 = [(0.0, yf_g-0.006, z_hi), (-rx_g*0.72, yf_g*0.75, z_hi), (-rx_g*0.95, 0.0, z_hi), (0.0, -0.140, z_hi), (rx_g*0.95, 0.0, z_hi), (rx_g*0.72, yf_g*0.75, z_hi)]
        mb.add_loft([g_r0, g_r1], weights="chest", mat="METAL", colors=[["STEEL_DARK", "STEEL_FACET", "FACE_DARK", "FACE_DARK", "STEEL_FACET", "STEEL_MAIN"], col_top], closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    # 2. Overlapping Lower Abdominal Plackart (Milanese/Gothic step over the breastplate with brass apex rivet)
    def plack_step_row(x_out, x_in, y_s, y_k, z):
        return [
            (-x_out, y_s - 0.018, z),
            (-x_out, y_s + 0.008, z),
            (-x_in,  y_s + 0.012, z),
            ( 0.000, y_k + 0.008, z),
            ( x_in,  y_s + 0.012, z),
            ( x_out, y_s + 0.008, z),
            ( x_out, y_s - 0.018, z),
        ]
    ps0 = plack_step_row(0.022, 0.006, 0.200, 0.220, 1.268)
    ps1 = plack_step_row(0.098, 0.084, 0.216, 0.252, 1.385)
    ps2 = plack_step_row(0.112, 0.098, 0.218, 0.256, 1.402)
    c_ps_body = ["BRASS_SHADE", "BRASS_MAIN", "STEEL_MAIN", "STEEL_BRIGHT", "BRASS_MAIN", "BRASS_SHADE", "FACE_DARK"]
    c_ps_lip  = ["BRASS_MAIN",  "BRASS_BRIGHT","STEEL_BRIGHT","STEEL_BRIGHT","BRASS_BRIGHT","BRASS_MAIN", "FACE_DARK"]
    mb.add_loft([ps0, ps1, ps2], weights=["spine", "chest", "chest"], mat="METAL", colors=[c_ps_body, c_ps_lip], closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK")

    # Scalloped Armhole Gusset Turners (protective steel/brass rims framing the shoulder sockets)
    for sign in (-1.0, 1.0):
        gusset_pts = [
            (sign * 0.136, 0.202, 1.545),
            (sign * 0.184, 0.145, 1.525),
            (sign * 0.188, 0.138, 1.425),
            (sign * 0.128, 0.208, 1.435),
        ]
        mb.add_flat_beveled_plate(
            gusset_pts, normal_dir=(sign * 0.62, 0.76, 0.15), thickness=0.009, bevel_inset=0.18,
            weights="chest", mat="METAL", col_face="STEEL_FACET", col_edge="BRASS_MAIN", col_side="FACE_DARK"
        )
        # Diagonal 28°-angled overlapping fauld lames on the flanks (`CANONICAL_SPELLBLADE_KEEP.png`)
        for f_i, (z_f, x_f, y_f) in enumerate([(1.305, 0.152, 0.182), (1.365, 0.164, 0.192), (1.425, 0.176, 0.200)]):
            fl_quad = [
                (sign * (x_f - 0.042), y_f + 0.012, z_f - 0.018),
                (sign * (x_f + 0.012), y_f - 0.045, z_f + 0.022),
                (sign * (x_f + 0.014), y_f - 0.042, z_f + 0.056),
                (sign * (x_f - 0.040), y_f + 0.014, z_f + 0.016),
            ]
            mb.add_flat_beveled_plate(
                fl_quad, normal_dir=(sign * 0.68, 0.72, 0.12), thickness=0.008, bevel_inset=0.16,
                weights="spine" if f_i == 0 else "chest", mat="METAL",
                col_face="STEEL_MAIN" if sign > 0 else "STEEL_FACET",
                col_edge="STEEL_LIGHT", col_side="FACE_DARK"
            )

        # Curved top flap & brass strap on the side leather utility pouches
        flap_pts = [
            (sign * 0.150,  0.022, 1.242),
            (sign * 0.186,  0.022, 1.238),
            (sign * 0.188, -0.062, 1.238),
            (sign * 0.150, -0.062, 1.242),
        ]
        mb.add_flat_beveled_plate(
            flap_pts, normal_dir=(sign * 0.85, 0.0, 0.52), thickness=0.008, bevel_inset=0.18,
            weights="pelvis", mat="MATTE", col_face="LEATHER_LIGHT", col_edge="LEATHER_MAIN", col_side="LEATHER_DARK"
        )

    # Inner leather cinch tongue extending through the silver buckle
    cinch_pts = [(0.022, 0.206, 1.242), (0.078, 0.196, 1.236), (0.076, 0.194, 1.208), (0.022, 0.204, 1.214)]
    mb.add_flat_beveled_plate(
        cinch_pts, normal_dir=(0.18, 0.98, 0.0), thickness=0.006, bevel_inset=0.16,
        weights="pelvis", mat="MATTE", col_face="LEATHER_LIGHT", col_edge="LEATHER_MAIN", col_side="LEATHER_DARK"
    )
    return mb


def build_v30_arm_and_gauntlet(is_right=False, closed_left_grip=False):
    """
    4. 3-Piece Winged Elbow Couter + 2-Piece Hinged Clamshell Vambrace with Dual Fuller Flutes &
       Buckled Straps + Flared Bell Gauntlet Cuff + 3 Overlapping Metacarpal Lames + 4-Peaked
       Champagne-Brass Knuckle-Gad Bar + Overlapping Finger Gadlings (`CANONICAL_HAND_DETAIL_KEEP.png`).
    """
    mb = b29.build_v29_arm_and_gauntlet(is_right=is_right, closed_left_grip=closed_left_grip)
    suffix = ".R" if is_right else ".L"
    sign = 1.0 if is_right else -1.0
    out_u = -sign

    if not is_right:
        fa_h, fa_t = (-0.345,  0.095, 1.255), (-0.428,  0.455, 1.185)
    else:
        fa_h, fa_t = ( 0.385, -0.128, 1.335), ( 0.465,  0.005, 1.060)
    fa_frame = BoneFrame(fa_h, fa_t, up_hint=(0.0, 1.0, 0.0))
    fa_w = f"forearm{suffix}"
    ha_w = f"hand{suffix}"

    # 1. Sculpted Lateral Couter Fan Wing & Raised Brass Rib on the Elbow Joint (`t = 0.02..0.16`)
    wing_pts = [
        fa_frame.pt(out_u * 0.088,  0.052, -0.02),
        fa_frame.pt(out_u * 0.106,  0.008,  0.07),
        fa_frame.pt(out_u * 0.086, -0.048,  0.16),
        fa_frame.pt(out_u * 0.068,  0.000,  0.07),
    ]
    mb.add_flat_beveled_plate(
        wing_pts, normal_dir=out_u * fa_frame.u + 0.3 * fa_frame.v, thickness=0.010, bevel_inset=0.18,
        weights=fa_w, mat="METAL", col_face="STEEL_LIGHT", col_edge="BRASS_BRIGHT", col_side="FACE_DARK"
    )

    # 2. Two Wrap-Around Saddle-Leather Vambrace Straps with Brass Buckle Keepers (`t = 0.32` & `t = 0.64`)
    def strap_ring(t, r):
        d = 0.74
        pts = [(0, r), (r*d, r*d), (r, 0), (r*d, -r*d), (0, -r), (-r*d, -r*d), (-r, 0), (-r*d, r*d)]
        return [fa_frame.pt(u, v, t) for (u, v) in pts]

    for t_s, r_s in [(0.32, 0.088), (0.64, 0.074)]:
        mb.add_loft(
            [strap_ring(t_s - 0.025, r_s), strap_ring(t_s + 0.025, r_s - 0.002)],
            weights=fa_w, mat="MATTE", colors="LEATHER_MAIN", closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_LIGHT"
        )
        # Brass buckle keeper on outer-dorsal vambrace
        mb.add_beveled_box(
            center=fa_frame.pt(out_u * (r_s * 0.72), r_s * 0.68, t_s),
            half_extents=(0.010, 0.008, 0.012),
            axes=(fa_frame.u, fa_frame.v, fa_frame.w),
            bevel=0.18, weights=fa_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
        )

    # 3. Upgraded 3-Lame Overlapping Dorsal Gauntlet Plates & 4-Peak Brass Knuckle-Gad Bar on Right Hand (`CANONICAL_HAND_DETAIL_KEEP.png`)
    if is_right:
        wrist_pt = np.array(fa_t, dtype=np.float32)
        b_dir = np.array([0.54, 0.67, -0.508], dtype=np.float32)
        b_dir /= np.linalg.norm(b_dir)
        f_out = np.array([0.48, 0.76, 0.44], dtype=np.float32)
        f_out -= np.dot(f_out, b_dir) * b_dir
        f_out /= np.linalg.norm(f_out)
        f_perp = np.cross(b_dir, f_out)
        if f_perp[2] > 0:
            f_perp = -f_perp
        f_perp /= np.linalg.norm(f_perp)
        hand_root = wrist_pt + 0.024 * fa_frame.w - 0.010 * f_out

        # 3 overlapping dorsal metacarpal steel lames stepping from wrist cuff to knuckles
        for l_idx, (p_off, out_off, col_l) in enumerate([(0.008, 0.026, "STEEL_LIGHT"), (0.026, 0.028, "STEEL_MAIN"), (0.044, 0.030, "STEEL_LIGHT")]):
            mb.add_beveled_box(
                center=hand_root + p_off * f_perp + out_off * f_out,
                half_extents=(0.048 - 0.002 * l_idx, 0.008, 0.011),
                axes=(b_dir, f_out, f_perp),
                bevel=0.18, weights=ha_w, mat="METAL", col_main=col_l, col_edge="STEEL_BRIGHT", col_dark="FACE_DARK"
            )
        # 4 raised champagne-brass knuckle-gad pyramid peaks across the knuckle bar
        for s_off in (-0.036, -0.012, 0.012, 0.036):
            mb.add_diamond_boss(
                center=hand_root + s_off * b_dir + 0.062 * f_perp + 0.038 * f_out,
                normal=f_out, up_vec=f_perp,
                radius_u=0.013, radius_v=0.014, height=0.010,
                weights=ha_w, mat="METAL", col_main="BRASS_BRIGHT", col_edge="BRASS_MAIN", col_base="BRASS_SHADE"
            )
    return mb


def build_v30_legs_greaves_and_boots(is_right=False):
    """
    6. Quilted Gambeson Thighs + 2-Lame Keeled Cuisse with Side Straps + 3-Piece Articulated
       Knee Poleyn (Pre-Poleyn Lame + 5-Facet Cop with Side-Wing Rondels + Sub-Poleyn Lame) +
       Calf-Contoured Shin Greave + 4-Lame Overlapping Sabaton Boot with Heel Spur-Rest &
       Twin-Buckled 38° Ankle Strap (`boot.png` & `tabard.png`).
    """
    mb = b29.build_v29_legs_greaves_and_boots(is_right=is_right)
    suffix = ".R" if is_right else ".L"
    sign = 1.0 if is_right else -1.0
    yaw_deg = -7.5 if is_right else 7.5

    th_h = (sign * 0.168,  0.012, 1.060)
    th_t = (sign * 0.218,  0.042, 0.635)
    sh_h = (sign * 0.218,  0.042, 0.635)
    sh_t = (sign * 0.248, -0.010, 0.225)

    rad = math.radians(yaw_deg)
    up_out = (float(-math.sin(rad)), float(np.cos(rad)), 0.0)
    th_frame = BoneFrame(th_h, th_t, up_hint=up_out)
    sh_frame = BoneFrame(sh_h, sh_t, up_hint=up_out)
    th_w = f"thigh{suffix}"
    sh_w = f"shin{suffix}"
    ft_w = f"foot{suffix}"
    out_u = 1.0 if np.dot(sh_frame.u, np.array([sign, 0.0, 0.0])) > 0 else -1.0

    # 1. Contoured Outer-Front Thigh Cuisse Plate + Sliding Upper Lame + 2 Leather Thigh Straps
    cuisse_grid = [
        [th_frame.pt(-0.075, 0.095, 0.22), th_frame.pt(0.0, 0.128, 0.20), th_frame.pt(0.085, 0.092, 0.22)],
        [th_frame.pt(-0.072, 0.092, 0.56), th_frame.pt(0.0, 0.124, 0.55), th_frame.pt(0.082, 0.088, 0.56)],
        [th_frame.pt(-0.066, 0.086, 0.84), th_frame.pt(0.0, 0.116, 0.84), th_frame.pt(0.074, 0.082, 0.84)],
    ]
    mb.add_faceted_shield_plate(
        cuisse_grid, outward_hint=th_frame.v, thickness=0.014, bevel_inset=0.16, weights=th_w,
        mat="METAL", col_faces=[["STEEL_DARK", "STEEL_FACET"], ["STEEL_DARK", "STEEL_SHADE"]],
        col_bevel="STEEL_MAIN", col_side="FACE_DARK"
    )

    # 3rd Lower Hip Tasset Lame (`tabard.png` — 3-tier overlapping hip tassets)
    tasset_3 = [
        (sign * 0.152, 0.172, 0.972),
        (sign * 0.214, 0.144, 0.972),
        (sign * 0.228, 0.132, 0.865),
        (sign * 0.166, 0.160, 0.865),
    ]
    rs_prev.add_framed_rect_plate(
        mb, tasset_3, normal_dir=(sign * 0.38, 0.91, 0.10), thickness=0.012, border_frac=0.22, weights=th_w,
        mat_border="METAL", col_border="BRASS_MAIN", col_border_edge="BRASS_BRIGHT",
        mat_inner="MATTE", col_inner="LEATHER_SHADE", open_top=True
    )

    # 2. Lateral Knee Poleyn Side-Wing Rondels + Lower Sub-Poleyn Articulation Lame (`boot.png`)
    wing_k = [
        sh_frame.pt(out_u * 0.118,  0.045,  0.02),
        sh_frame.pt(out_u * 0.142, -0.025,  0.14),
        sh_frame.pt(out_u * 0.114,  0.035,  0.32),
        sh_frame.pt(out_u * 0.095,  0.085,  0.16),
    ]
    mb.add_flat_beveled_plate(
        wing_k, normal_dir=out_u * sh_frame.u + 0.25 * sh_frame.v, thickness=0.012, bevel_inset=0.18,
        weights=sh_w, mat="METAL", col_face="STEEL_MAIN", col_edge="STEEL_BRIGHT", col_side="FACE_DARK"
    )
    # Brass rivet on knee side-wing
    mb.add_beveled_box(
        center=sh_frame.pt(out_u * 0.128, 0.010, 0.15), half_extents=(0.008, 0.008, 0.008),
        axes=(sh_frame.u, sh_frame.v, sh_frame.w),
        bevel=0.20, weights=sh_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
    )

    # Lower sub-poleyn lame stepping down onto the top of the shin greave (`t = 0.36..0.46`)
    sub_k_grid = [
        [sh_frame.pt(-0.098, 0.005, 0.35), sh_frame.pt(-0.062, 0.118, 0.37), sh_frame.pt(0.062, 0.118, 0.37), sh_frame.pt(0.098, 0.005, 0.35)],
        [sh_frame.pt(-0.092, 0.002, 0.45), sh_frame.pt(-0.056, 0.112, 0.48), sh_frame.pt(0.056, 0.112, 0.48), sh_frame.pt(0.092, 0.002, 0.45)],
    ]
    mb.add_faceted_shield_plate(
        sub_k_grid, outward_hint=sh_frame.v, thickness=0.018, bevel_inset=0.16, weights=sh_w,
        mat="METAL", col_faces=[["STEEL_DARK", "STEEL_MAIN", "STEEL_LIGHT"]], col_bevel="STEEL_BRIGHT", col_side="FACE_DARK"
    )

    # 3. Overlapping Dorsal Sabaton Lames, Heel Counter Spur-Rest & Twin Brass Ankle Buckles (`boot.png`)
    cx, cy = sh_t[0], sh_t[1]
    for l_i, (y_f, y_b, z_l, w_l, col_s) in enumerate([
        (0.245, 0.195, 0.088, 0.078, "STEEL_LIGHT"),
        (0.205, 0.155, 0.104, 0.072, "STEEL_MAIN"),
        (0.165, 0.118, 0.122, 0.068, "STEEL_LIGHT"),
    ]):
        lame_pts = rs_prev.rot_z([
            (cx - w_l, cy + y_f, z_l - 0.008),
            (cx + w_l, cy + y_f, z_l - 0.008),
            (cx + w_l * 0.92, cy + y_b, z_l + 0.012),
            (cx - w_l * 0.92, cy + y_b, z_l + 0.012),
        ], yaw_deg, pivot=(cx, cy))
        mb.add_flat_beveled_plate(
            lame_pts, normal_dir=(0.0, 0.48, 0.88), thickness=0.008, bevel_inset=0.16,
            weights=ft_w, mat="METAL", col_face=col_s, col_edge="STEEL_BRIGHT", col_side="FACE_DARK"
        )

    # Twin brass ankle strap buckles + rear heel spur-rest molding
    for k_side in (-1.0, 1.0):
        bk_pt = rs_prev.rot_z([(cx + k_side * 0.096, cy + 0.018, 0.114)], yaw_deg, pivot=(cx, cy))[0]
        mb.add_beveled_box(
            center=bk_pt, half_extents=(0.010, 0.016, 0.018),
            weights=ft_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
        )
    spur_pt = rs_prev.rot_z([(cx, cy - 0.142, 0.068)], yaw_deg, pivot=(cx, cy))[0]
    mb.add_beveled_box(
        center=spur_pt, half_extents=(0.046, 0.012, 0.010),
        weights=ft_w, mat="METAL", col_main="STEEL_MAIN", col_edge="BRASS_MAIN", col_dark="FACE_DARK"
    )

    return mb


def build_v30_arm_only_without_left_hand():
    full_arm_l = build_v30_arm_and_gauntlet(is_right=False, closed_left_grip=False)
    mb_arm = MeshBuilder(["MAKitMatte", "MAKitMetal"])
    off = 0
    for pi, poly in enumerate(full_arm_l.polys):
        plen = len(poly)
        w0 = full_arm_l.weights[poly[0]]
        if "hand.L" not in w0 and "socket_sorcery" not in w0:
            mat_name = full_arm_l.mat_names[full_arm_l.mat_indices[pi]]
            new_vis = [mb_arm.add_vert(full_arm_l.verts[vi], full_arm_l.weights[vi]) for vi in poly]
            mb_arm.polys.append(new_vis)
            mb_arm.mat_indices.append(mb_arm._resolve_mat(mat_name))
            mb_arm.loop_colors.extend(full_arm_l.loop_colors[off:off+plen])
            mb_arm.loop_uvs.extend(full_arm_l.loop_uvs[off:off+plen])
        off += plen
    mb_arm.bake_loop_shading()
    return mb_arm


def export_spellblade_v30():
    tp_src = C_PREV_WORK / "Spellblade-production-third-person.blend"
    bf_tp = BlendFile(str(tp_src))
    rs_prev.upgrade_banner_texture(bf_tp)

    mb_shell, mb_jaw, mb_visor, mb_crest = build_v30_helmet_parts()
    mb_pl, mb_pr = build_v30_pauldron_pair()
    mb_bp = build_v30_breastplate_scarf_and_belt()
    mb_arm_l = build_v30_arm_and_gauntlet(is_right=False, closed_left_grip=False)
    mb_arm_r = build_v30_arm_and_gauntlet(is_right=True,  closed_left_grip=False)
    mb_sorc = rs_prev.build_sorcery_cluster(first_person=False)
    mb_sword = b29.build_v29_hero_broadsword(first_person=False)
    for i in range(len(mb_sword.weights)):
        mb_sword.weights[i] = {"socket_sword": 1.0}
    leg_l = build_v30_legs_greaves_and_boots(is_right=False)
    leg_r = build_v30_legs_greaves_and_boots(is_right=True)
    mb_grv_l, mb_bt_l = exp28.split_greave_and_boot(leg_l, is_right=False)
    mb_grv_r, mb_bt_r = exp28.split_greave_and_boot(leg_r, is_right=True)
    mb_tab_f = u28.build_v28_sculpted_3d_tabard(is_front=True)
    mb_tab_b = u28.build_v28_sculpted_3d_tabard(is_front=False)
    for i, (x, y, z) in enumerate(mb_tab_f.verts):
        mb_tab_f.verts[i] = (float(x * 0.92), float(y - 0.018), float(z))
    for i, (x, y, z) in enumerate(mb_tab_b.verts):
        mb_tab_b.verts[i] = (float(x * 0.92), float(y + 0.016), float(z))

    all_tp = [
        ("MEHelmetShellCanonical", mb_shell),
        ("MEHelmetJawCanonical",   mb_jaw),
        ("MEVisorCanonical",       mb_visor),
        ("MECrestCanonical",       mb_crest),
        ("MEPauldron.L",           mb_pl),
        ("MEPauldron.R",           mb_pr),
        ("MEBreastplate",          mb_bp),
        ("MEGauntlet.L.001",       mb_arm_l),
        ("MEGauntlet.R.001",       mb_arm_r),
        ("MEPalmRune.001",         mb_sorc),
        ("MEHeroSword",            mb_sword),
        ("MEGreave.L",             mb_grv_l),
        ("MEBoot.L",               mb_bt_l),
        ("MEGreave.R",             mb_grv_r),
        ("MEBoot.R",               mb_bt_r),
        ("METabardFront",          mb_tab_f),
        ("METabardBack",           mb_tab_b),
    ]
    for name, mb in all_tp:
        mb.bake_loop_shading()
        bf_tp.replace_mesh(name, mb)
    bf_tp.set_armature_rest_pose_in_pose_channels()

    raw_v30_blend = WORK_DIR / "Spellblade-v30-preview.blend"
    bf_tp.save(str(raw_v30_blend))
    out_v30_blend = OUT_DIR / "spellblade-v30-refined-candidate.blend"
    zstd_compress_blend(raw_v30_blend.read_bytes(), out_v30_blend)
    sha_v30_blend = hashlib.sha256(out_v30_blend.read_bytes()).hexdigest()
    print(f"[OK] Saved {out_v30_blend.name}: {out_v30_blend.stat().st_size:,} bytes, SHA256={sha_v30_blend}")

    # Export `spellblade-v30-refined-candidate.glb` using the 6-material PBR pipeline
    b29.build_v29_arm_only_without_left_hand = build_v30_arm_only_without_left_hand
    bf_glb_tab = BlendFile(str(tp_src))
    rs_prev.upgrade_banner_texture(bf_glb_tab)
    rs_prev.polish_original_tabards(bf_glb_tab)
    glb_tab_path = WORK_DIR / "Spellblade-v30-glb-tabard.blend"
    bf_glb_tab.save(str(glb_tab_path))

    out_v30_glb = OUT_DIR / "spellblade-v30-refined-candidate.glb"
    rep_no_tab = {k: v for k, v in all_tp if k not in ("METabardFront", "METabardBack")}
    b29.export_spellblade_v29_multimat_glb(glb_tab_path, rep_no_tab, out_v30_glb)
    ev30 = StandardGltfEvaluator(str(out_v30_glb))
    P0, _, T0, _, _, _, _ = ev30.evaluate_scene_meshes(None, 0.0)
    sha_v30_glb = hashlib.sha256(out_v30_glb.read_bytes()).hexdigest()
    print(f"[OK] Saved {out_v30_glb.name}: {out_v30_glb.stat().st_size:,} bytes, V={len(P0)}, T={len(T0)}, Mats={len(ev30.gltf['materials'])}, Clips={len(ev30.gltf['animations'])}, SHA256={sha_v30_glb}")


if __name__ == "__main__":
    export_spellblade_v30()
