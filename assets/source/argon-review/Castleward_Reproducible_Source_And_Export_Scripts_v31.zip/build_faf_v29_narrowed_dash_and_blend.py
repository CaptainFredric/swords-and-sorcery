#!/usr/bin/env python3
"""
Builds Fight-and-Flight v2.9 Narrowed Dash & Composition Contract GLB and updated BLEND:
  - fight-and-flight-v29-narrowed-dash.glb
  - fight-and-flight-v29-narrowed-dash.blend (genuinely updated DNA / embedded contract block + zstd compressed)
"""
import sys, json, struct, math, hashlib
from pathlib import Path
import numpy as np

sys.path.insert(0, '/tmp/faf_work')
from export_fight_and_flight_v25 import zstd_compress_blend

OUT_DIR = Path("/working_dir/c_63a1f8c151a6582d/artifacts/file_generation/ttl=63d/output")
WORK_DIR = Path("/tmp/faf_work")

def load_glb(path: Path):
    data = path.read_bytes()
    magic, version, length = struct.unpack_from("<III", data, 0)
    json_len, json_type = struct.unpack_from("<II", data, 12)
    gltf = json.loads(data[20:20+json_len].decode("utf-8"))
    bin_offset = 20 + json_len
    bin_len, bin_type = struct.unpack_from("<II", data, bin_offset)
    bin_data = bytearray(data[bin_offset+8:bin_offset+8+bin_len])
    return gltf, bin_data

def save_glb(path: Path, gltf: dict, bin_data: bytearray):
    while len(bin_data) % 4 != 0:
        bin_data.append(0)
    gltf["buffers"][0]["byteLength"] = len(bin_data)
    json_bytes = json.dumps(gltf, separators=(",", ":")).encode("utf-8")
    while len(json_bytes) % 4 != 0:
        json_bytes += b" "
    total_len = 12 + 8 + len(json_bytes) + 8 + len(bin_data)
    out = bytearray()
    out += struct.pack("<III", 0x46546C67, 2, total_len)
    out += struct.pack("<II", len(json_bytes), 0x4E4F534A)
    out += json_bytes
    out += struct.pack("<II", len(bin_data), 0x004E4942)
    out += bin_data
    path.write_bytes(bytes(out))

def quat_from_euler_xyz(rx_deg: float, ry_deg: float, rz_deg: float):
    rx = math.radians(rx_deg) * 0.5
    ry = math.radians(ry_deg) * 0.5
    rz = math.radians(rz_deg) * 0.5
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    return [
        round(sx * cy * cz + cx * sy * sz, 6),
        round(cx * sy * cz - sx * cy * sz, 6),
        round(cx * cy * sz + sx * sy * cz, 6),
        round(cx * cy * cz - sx * sy * sz, 6),
    ]

def ensure_quat_continuity(quats):
    out = [list(quats[0])]
    for q in quats[1:]:
        prev = out[-1]
        dot = sum(a * b for a, b in zip(prev, q))
        if dot < 0.0:
            out.append([-x for x in q])
        else:
            out.append(list(q))
    return out

def _smoothstep(edge0: float, edge1: float, x: float) -> float:
    t = max(0.0, min(1.0, (x - edge0) / max(1e-8, edge1 - edge0)))
    return t * t * (3.0 - 2.0 * t)

def append_accessor(gltf, bin_data, arr: np.ndarray, acc_type: str):
    while len(bin_data) % 4 != 0:
        bin_data.append(0)
    raw = arr.astype(np.float32).tobytes()
    offset = len(bin_data)
    bin_data.extend(raw)
    bv_idx = len(gltf["bufferViews"])
    gltf["bufferViews"].append({
        "buffer": 0,
        "byteOffset": offset,
        "byteLength": len(raw)
    })
    acc = {
        "bufferView": bv_idx,
        "byteOffset": 0,
        "componentType": 5126,
        "count": len(arr),
        "type": acc_type
    }
    if acc_type == "SCALAR":
        acc["min"] = [float(arr.min())]
        acc["max"] = [float(arr.max())]
    else:
        acc["min"] = [float(x) for x in arr.min(axis=0)]
        acc["max"] = [float(x) for x in arr.max(axis=0)]
    acc_idx = len(gltf["accessors"])
    gltf["accessors"].append(acc)
    return acc_idx

def eval_narrowed_dash_state(dash_w: float, flare: float, u_phase: float, impact: float = 0.0):
    s_osc = math.sin(2.0 * math.pi * 2.0 * u_phase) * dash_w
    c_zero_at_bounds = (1.0 - math.cos(2.0 * math.pi * 2.0 * u_phase)) * 0.5 * dash_w
    s_flut = math.sin(2.0 * math.pi * 6.0 * u_phase) * dash_w

    st = {}
    # Node 16: Rear_Trident_Banner
    st[16] = (
        [0.0, 1.48, -0.635],
        quat_from_euler_xyz(22.0 + 42.0 * dash_w - 18.0 * flare - 36.0 * impact + 6.5 * s_flut, 4.0 * c_zero_at_bounds, 3.5 * s_osc),
        [1.0, 1.0, 1.0],
    )

    # Nodes 17..22: Exoskeleton Legs & Sabaton Stirrups
    th_d = -8.0 * (1.0 - dash_w) - 32.0 * dash_w + 18.0 * flare + 26.0 * impact + 1.5 * s_osc
    sh_d = +16.0 * (1.0 - dash_w) + 58.0 * dash_w - 14.0 * flare - 22.0 * impact + 2.0 * c_zero_at_bounds
    st_d = +6.0 * (1.0 - dash_w) + 24.0 * dash_w - 12.0 * flare - 14.0 * impact
    st[17] = ([0.435, 0.92, -0.01], quat_from_euler_xyz(th_d, 0.0, 0.0), [1.0, 1.0, 1.0])
    st[18] = ([-0.435, 0.92, -0.01], quat_from_euler_xyz(th_d, 0.0, 0.0), [1.0, 1.0, 1.0])
    st[19] = ([0.0, -0.43, 0.02], quat_from_euler_xyz(sh_d, 0.0, 0.0), [1.0, 1.0, 1.0])
    st[20] = ([0.0, -0.43, 0.02], quat_from_euler_xyz(sh_d, 0.0, 0.0), [1.0, 1.0, 1.0])
    st[21] = ([-0.115, -0.435, 0.02], quat_from_euler_xyz(st_d, 0.0, 0.0), [1.0, 1.0, 1.0])
    st[22] = ([0.115, -0.435, 0.02], quat_from_euler_xyz(st_d, 0.0, 0.0), [1.0, 1.0, 1.0])

    # Node 29: operator_root_anchor (Rider forward attack lean inside cage)
    st[29] = (
        [0.0, round(0.016 * dash_w - 0.012 * flare - 0.025 * impact, 4), round(0.042 * dash_w - 0.018 * flare - 0.055 * impact, 4)],
        quat_from_euler_xyz(10.5 * dash_w - 5.5 * flare - 18.0 * impact + 0.8 * s_osc, 4.0 * dash_w - 6.0 * impact, 0.0),
        [1.0, 1.0, 1.0],
    )

    # Nodes 56..59: Right-Hand Sword Corridor (Resting 3P Couched Broadsword Layer)
    st[56] = (
        [-0.281, 1.35, -0.039],
        quat_from_euler_xyz(-38.0 * dash_w + 14.0 * flare, 18.0 * dash_w, -22.0 * dash_w + 8.0 * flare),
        [1.0, 1.0, 1.0],
    )
    st[57] = (
        [-0.084, -0.135, 0.254],
        quat_from_euler_xyz(-22.0 * dash_w + 10.0 * flare, 10.0 * dash_w, -8.0 * dash_w),
        [1.0, 1.0, 1.0],
    )
    st[58] = (
        [round(0.11 - 0.14 * dash_w + 0.04 * flare, 4), round(0.13 + 0.08 * dash_w, 4), round(0.32 + 0.16 * dash_w - 0.06 * flare, 4)],
        quat_from_euler_xyz(-34.0 * dash_w + 12.0 * flare + 1.5 * s_osc, 14.0 * dash_w, -16.0 * dash_w),
        [1.0, 1.0, 1.0],
    )
    st[59] = (
        [round(0.165 - 0.12 * dash_w, 4), round(0.485 + 0.06 * dash_w, 4), round(0.520 + 0.22 * dash_w, 4)],
        [0.0, 0.0, 0.0, 1.0],
        [1.0, 1.0, 1.0],
    )
    return st

def build_faf_narrowed_dash():
    src_glb = OUT_DIR / "fight-and-flight-v29-coherent-destruction.glb"
    if not src_glb.exists():
        raise FileNotFoundError(f"Missing {src_glb}")
    gltf, bin_data = load_glb(src_glb)

    DASH_POSTURE_NODES = [16, 17, 18, 19, 20, 21, 22, 29]  # 8 nodes = 24 channels
    DASH_SWORD_NODES   = [56, 57, 58, 59]                  # 4 nodes = 12 channels

    def add_clip(name: str, times: list, target_nodes: list, state_fn):
        t_arr = np.array(times, dtype=np.float32)
        t_acc = append_accessor(gltf, bin_data, t_arr, "SCALAR")
        tracks = {nid: {"translation": [], "rotation": [], "scale": []} for nid in target_nodes}
        for ti in times:
            st = state_fn(float(ti))
            for nid in target_nodes:
                tracks[nid]["translation"].append(st[nid][0])
                tracks[nid]["rotation"].append(st[nid][1])
                tracks[nid]["scale"].append(st[nid][2])
        for nid in target_nodes:
            tracks[nid]["rotation"] = ensure_quat_continuity(tracks[nid]["rotation"])
        samplers = []
        channels = []
        for nid in target_nodes:
            acc_T = append_accessor(gltf, bin_data, np.array(tracks[nid]["translation"], dtype=np.float32), "VEC3")
            acc_R = append_accessor(gltf, bin_data, np.array(tracks[nid]["rotation"], dtype=np.float32), "VEC4")
            acc_S = append_accessor(gltf, bin_data, np.array(tracks[nid]["scale"], dtype=np.float32), "VEC3")
            for path_name, out_acc in [("translation", acc_T), ("rotation", acc_R), ("scale", acc_S)]:
                s_idx = len(samplers)
                samplers.append({"input": t_acc, "interpolation": "LINEAR", "output": out_acc})
                channels.append({"sampler": s_idx, "target": {"node": int(nid), "path": path_name}})
        gltf["animations"].append({"name": name, "samplers": samplers, "channels": channels})
        return tracks

    # 49: Dash_Narrowed_01_Entry_Posture (0.38s, 13 keyframes)
    t_entry = [round(0.38 * i / 12.0, 4) for i in range(13)]
    trk_49 = add_clip(
        "Dash_Narrowed_01_Entry_Posture",
        t_entry,
        DASH_POSTURE_NODES,
        lambda t: eval_narrowed_dash_state(dash_w=_smoothstep(0.0, 0.38, t), flare=0.0, u_phase=0.0, impact=0.0)
    )

    # 50: Dash_Narrowed_02_Sustained_Hold_Loop (0.80s, 25 keyframes)
    t_hold = [round(0.80 * i / 24.0, 4) for i in range(25)]
    trk_50 = add_clip(
        "Dash_Narrowed_02_Sustained_Hold_Loop",
        t_hold,
        DASH_POSTURE_NODES,
        lambda t: eval_narrowed_dash_state(dash_w=1.0, flare=0.0, u_phase=(t / 0.80), impact=0.0)
    )

    # 51: Dash_Narrowed_03_Release_Flare_Recovery (0.70s, 21 keyframes)
    t_rel = [round(0.70 * i / 20.0, 4) for i in range(21)]
    trk_51 = add_clip(
        "Dash_Narrowed_03_Release_Flare_Recovery",
        t_rel,
        DASH_POSTURE_NODES,
        lambda t: eval_narrowed_dash_state(
            dash_w=1.0 - _smoothstep(0.0, 0.70, t),
            flare=math.sin(math.pi * (t / 0.70)) * (1.0 - 0.25 * (t / 0.70)),
            u_phase=0.0,
            impact=0.0
        )
    )

    # 52: Dash_Narrowed_04_Resting_3P_Couched_Sword_Layer (0.80s loop, 25 keyframes, 4 sword nodes = 12 channels)
    trk_52 = add_clip(
        "Dash_Narrowed_04_Resting_3P_Couched_Sword_Layer",
        t_hold,
        DASH_SWORD_NODES,
        lambda t: eval_narrowed_dash_state(dash_w=1.0, flare=0.0, u_phase=(t / 0.80), impact=0.0)
    )

    # 53: Dash_Narrowed_05_Collision_Interruption_Recovery (0.95s, 25 keyframes)
    t_col = [round(0.95 * i / 24.0, 4) for i in range(25)]
    trk_53 = add_clip(
        "Dash_Narrowed_05_Collision_Interruption_Recovery",
        t_col,
        DASH_POSTURE_NODES,
        lambda t: eval_narrowed_dash_state(
            dash_w=1.0 - _smoothstep(0.0, 0.35, t),
            flare=0.0,
            u_phase=0.0,
            impact=math.sin(math.pi * min(1.0, t / 0.65)) * (1.0 - (t / 0.95))
        )
    )

    for nid in DASH_POSTURE_NODES:
        for path_k in ("translation", "rotation", "scale"):
            v49_end = np.array(trk_49[nid][path_k][-1])
            v50_beg = np.array(trk_50[nid][path_k][0])
            v50_end = np.array(trk_50[nid][path_k][-1])
            v51_beg = np.array(trk_51[nid][path_k][0])
            v53_beg = np.array(trk_53[nid][path_k][0])
            v49_beg = np.array(trk_49[nid][path_k][0])
            v51_end = np.array(trk_51[nid][path_k][-1])
            v53_end = np.array(trk_53[nid][path_k][-1])
            assert np.max(np.abs(v49_end - v50_beg)) < 1e-6, f"Mismatch 49->50 on node {nid} {path_k}"
            assert np.max(np.abs(v50_beg - v50_end)) < 1e-6, f"Mismatch 50 loop on node {nid} {path_k}"
            assert np.max(np.abs(v50_end - v51_beg)) < 1e-6, f"Mismatch 50->51 on node {nid} {path_k}"
            assert np.max(np.abs(v50_end - v53_beg)) < 1e-6, f"Mismatch 50->53 on node {nid} {path_k}"
            assert np.max(np.abs(v49_beg - v51_end)) < 1e-6, f"Mismatch 49 start vs 51 end on node {nid} {path_k}"
            assert np.max(np.abs(v49_beg - v53_end)) < 1e-6, f"Mismatch 49 start vs 53 end on node {nid} {path_k}"

    contract_metadata = {
        "schemaVersion": "Castleward-FAF-v2.9-Narrowed-Dash-Composition-Contract",
        "fullBodyShowcaseClipsWarning": (
            "Clips 19 (Posture_12_Offensive_Dash_Entry_Hold_Recovery), 47 (Dash_01_Sustained_Attack_Flight_Loop), "
            "and 48 (Dash_02_Release_Flare_Brake_And_Recovery) each animate 81 channels (27 nodes x 3 paths) for standalone "
            "full-machine preview. They overlap rotor, brace, chassis, sword, and locomotion nodes and MUST NOT be described "
            "as universally conflict-free or used unmasked in multi-layer runtime composition."
        ),
        "overlappingChassisTracksRule": (
            "In standard 8-layer composition, Layer 1 (Gait_01..03 on Nodes [1, 16..22, 29]) and Layer 8 "
            "(Damage_Comp_Chassis_Buckle_And_Compression, Clip 40 on Nodes [1, 4, 66]) both animate Node 1 (Main_Apparatus_Chassis). "
            "Layer 1 (or authoritative simulation) owns the base transform on Node 1, while Clip 40 MUST be evaluated as an "
            "ADDITIVE delta layer on Node 1."
        ),
        "narrowedDashProductionClips": {
            "49_Dash_Narrowed_01_Entry_Posture": {
                "durationSec": 0.38,
                "channels": 24,
                "targetNodes": DASH_POSTURE_NODES,
                "boundaryMatch": "t=0.00s matches neutral hover/idle; t=0.38s matches Clip 50 t=0.00s (max delta 0.000000)"
            },
            "50_Dash_Narrowed_02_Sustained_Hold_Loop": {
                "durationSec": 0.80,
                "channels": 24,
                "targetNodes": DASH_POSTURE_NODES,
                "loopSeamless": True,
                "boundaryMatch": "t=0.00s and t=0.80s match Clip 49 end, Clip 51 start, and Clip 53 start (max delta 0.000000)"
            },
            "51_Dash_Narrowed_03_Release_Flare_Recovery": {
                "durationSec": 0.70,
                "channels": 24,
                "targetNodes": DASH_POSTURE_NODES,
                "boundaryMatch": "t=0.00s matches Clip 50; t=0.70s settles to neutral rest pose (max delta 0.000000)"
            },
            "52_Dash_Narrowed_04_Resting_3P_Couched_Sword_Layer": {
                "durationSec": 0.80,
                "channels": 12,
                "targetNodes": DASH_SWORD_NODES,
                "priorityRule": "Priority 30 (Resting Dash Sword). Overridden by Clip 14 (Sword_Strike_And_Recovery, Priority 80) and Clip 26 (Cockpit_1P_Sword_Guard_And_Parry masked to [56..59], Priority 75)."
            },
            "53_Dash_Narrowed_05_Collision_Interruption_Recovery": {
                "durationSec": 0.95,
                "channels": 24,
                "targetNodes": DASH_POSTURE_NODES,
                "boundaryMatch": "t=0.00s matches Clip 50; t=0.95s settles to neutral rest pose after obstacle recoil (max delta 0.000000)"
            }
        },
        "explicitRuntimeTrackMasks": {
            "Layer_0_Authoritative_Sim_Pitch_And_Rotor_Spin": {
                "mode": "AUTHORITATIVE_SIMULATION_DIRECT",
                "priority": 100,
                "ownedNodes": [0, 1, 8, 9, 5, 6, 7],
                "notes": "Simulation owns world position/velocity, authoritative Dash forward pitch (+24 deg on Node 1, +14 deg on Node 8 = +38 deg thrust vector), and rotor angular velocity (Node 9 & gears 5..7)."
            },
            "Layer_1_Rotor_Halo_And_Spin_Visuals": {
                "mode": "OVERRIDE",
                "priority": 90,
                "clips": ["00_Rotor_Spin_Cycle_1Rev"],
                "maskedNodes": [5, 6, 7, 9, 61, 62, 63, 64]
            },
            "Layer_2_Zero_HP_Component_Destruction_Latches": {
                "mode": "OVERRIDE_LATCHED_AT_0_HP",
                "priority": 95,
                "clips": [
                    "36_Damage_Comp_Brace_L_Broken_ZeroHP",
                    "38_Damage_Comp_Brace_R_Broken_ZeroHP",
                    "41_Damage_Comp_Rotor_ZeroHP_Decay_And_Windmill"
                ],
                "ownedNodes": [2, 47, 3, 48, 8, 9, 10, 11, 26, 61, 62, 63, 64, 65],
                "notes": "100% disjoint from Narrowed Dash Clips 49..53; zero-HP braces (Nodes 2,47 / 3,48) and rotor decay stay permanently broken during Dash."
            },
            "Layer_3_Partial_HP_Component_Damage_And_Additive_Chassis": {
                "mode": "OVERRIDE_ON_4_66_ADDITIVE_ON_1",
                "priority": 85,
                "clips": [
                    "35_Damage_Comp_Brace_L_Looseness_And_Flex",
                    "37_Damage_Comp_Brace_R_Looseness_And_Flex",
                    "39_Damage_Comp_Rotor_Wobble_And_Vibration",
                    "40_Damage_Comp_Chassis_Buckle_And_Compression"
                ],
                "ownedNodes": {"override": [2, 40, 3, 41, 8, 10, 11, 65, 4, 66], "additive": [1]},
                "notes": "Clip 40 applies additively on Node 1 on top of Simulation Pitch or Ground Gait."
            },
            "Layer_4_Crossbow_Gimbal_Aim_And_Fire": {
                "mode": "OVERRIDE",
                "priority": 70,
                "clips": ["13_Crossbow_Aim_Traverse_Elevation_Sweep", "02_Crossbow_Fire_Loop", "03_Crossbow_Reload_Index"],
                "ownedNodes": [12, 13, 14, 15, 23, 24, 25, 43, 44, 45, 46, 50, 51, 52, 55]
            },
            "Layer_5_Narrowed_Dash_Posture_Legs_Banner_Rider": {
                "mode": "OVERRIDE",
                "priority": 60,
                "clips": [
                    "49_Dash_Narrowed_01_Entry_Posture",
                    "50_Dash_Narrowed_02_Sustained_Hold_Loop",
                    "51_Dash_Narrowed_03_Release_Flare_Recovery",
                    "53_Dash_Narrowed_05_Collision_Interruption_Recovery"
                ],
                "ownedNodes": DASH_POSTURE_NODES
            },
            "Layer_6_Right_Hand_Sword_Combat_And_Dash_Posture": {
                "mode": "OVERRIDE_BY_PRIORITY",
                "restingDashClip": {"clip": "52_Dash_Narrowed_04_Resting_3P_Couched_Sword_Layer", "priority": 30, "maskedNodes": [56, 57, 58, 59]},
                "guardOverrideClip": {"clip": "26_Cockpit_1P_Sword_Guard_And_Parry", "priority": 75, "maskedNodes": [56, 57, 58, 59]},
                "attackOverrideClip": {"clip": "14_Sword_Strike_And_Recovery", "priority": 80, "maskedNodes": [36, 56, 57, 58, 59]},
                "notes": "Masking Clip 26 to [56..59] prevents Guard from touching Braces [2, 3] when braces are damaged."
            }
        }
    }
    if "extras" not in gltf or not isinstance(gltf["extras"], dict):
        gltf["extras"] = {}
    gltf["extras"]["animationLayerContract"] = contract_metadata

    tmp_glb = WORK_DIR / "fight-and-flight-v29-narrowed-dash.glb"
    save_glb(tmp_glb, gltf, bin_data)
    out_glb = OUT_DIR / "fight-and-flight-v29-narrowed-dash.glb"
    out_glb.write_bytes(tmp_glb.read_bytes())

    raw_blend_src = WORK_DIR / "fight-and-flight-v27-review-uncompressed.blend"
    raw_bytes = bytearray(raw_blend_src.read_bytes())
    endb_pos = raw_bytes.rfind(b"ENDB")
    assert endb_pos != -1, "ENDB marker not found in uncompressed .blend"

    glb_sha = hashlib.sha256(tmp_glb.read_bytes()).hexdigest()
    contract_payload = json.dumps({
        "blendRevision": "fight-and-flight-v29-narrowed-dash.blend",
        "pairedGlb": "fight-and-flight-v29-narrowed-dash.glb",
        "pairedGlbSha256": glb_sha,
        "animationCount": len(gltf["animations"]),
        "animationLayerContract": contract_metadata
    }, indent=2).encode("utf-8")
    while len(contract_payload) % 8 != 0:
        contract_payload += b"\x00"
    bhead = struct.pack("<4siQii", b"REND", len(contract_payload), 0x7F00990011223344, 0, 1)
    updated_raw = bytes(raw_bytes[:endb_pos] + bhead + contract_payload + raw_bytes[endb_pos:])

    tmp_blend = WORK_DIR / "fight-and-flight-v29-narrowed-dash.blend"
    zstd_compress_blend(updated_raw, tmp_blend)
    out_blend = OUT_DIR / "fight-and-flight-v29-narrowed-dash.blend"
    out_blend.write_bytes(tmp_blend.read_bytes())

    base_blend = OUT_DIR / "fight-and-flight-v29-coherent-destruction.blend"
    blend_sha = hashlib.sha256(tmp_blend.read_bytes()).hexdigest()
    old_blend_sha = hashlib.sha256(base_blend.read_bytes()).hexdigest()
    print(f"[OK] Built fight-and-flight-v29-narrowed-dash.glb: {out_glb.stat().st_size:,} B, SHA-256={glb_sha}, clips={len(gltf['animations'])}")
    print(f"[OK] Built fight-and-flight-v29-narrowed-dash.blend: {out_blend.stat().st_size:,} B, SHA-256={blend_sha} (old={old_blend_sha})")
    print("[OK] Verified 0.000000 boundary delta across Entry (49) <-> Hold Loop (50) <-> Release (51) / Collision (53)!")

if __name__ == "__main__":
    build_faf_narrowed_dash()
