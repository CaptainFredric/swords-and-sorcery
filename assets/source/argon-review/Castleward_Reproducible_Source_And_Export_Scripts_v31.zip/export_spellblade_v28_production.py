#!/usr/bin/env python3
"""
Castleward — Spellblade v2.8 Production Exporter (`.blend` + Rigged `.glb` + Mounted Reference)
===============================================================================================
1. Builds and saves the editable Blender 4.05 source files:
   - `spellblade-v28-fidelity-production.blend` (all 15 Third-Person `ME*` meshes including
     the 3D sculpted pleated `METabardFront` and `METabardBack`, `SpellbladeRig` armature,
     vertex groups, PBR materials, and embedded `1024x1024` `SpellbladeBanner` texture)
   - `spellblade-v28-first-person-production.blend` (all 4 First-Person `ME*` arm/hand/rune/sword meshes)
2. Compiles the 27-joint glTF 2.0 `skins` character `spellblade-v28-fidelity-production.glb` directly
   from the `v2.8` chiseled sculpt with:
   - 27 canonical `SpellbladeRig` joints (`nodes[0..26]`) at the exact 0.000 mm geometric pivots
     of the sculpted armor segments (`S_V28 = 0.850`, true `1.800 m` stature),
   - 4 skinned mesh nodes (`skin: 0`):
     * `Node 27: Spellblade_Armor_And_Body`
     * `Node 28: Spellblade_Hand_L_Closed_Grip`
     * `Node 29: Spellblade_Hand_L_Open_Sorcery_And_Rune`
     * `Node 30: Spellblade_Hero_Broadsword` (bound to `socket_sword [15]`, coaxial with `hand.R [14]`)
   - 12 glTF 2.0 skeletal animation clips (`animations[0..11]`), verified by `StandardGltfEvaluator`.
3. Builds the combined mounted reference `fight-and-flight-v27-with-spellblade-v28-reference.glb`.
"""
import os, sys, io, json, math, struct, hashlib
from pathlib import Path
import numpy as np
from PIL import Image

ROOT = Path("/working_dir/c_63a1f8c151a6582d")
OUT_DIR = ROOT / "artifacts/file_generation/ttl=63d/output"
WORK_DIR = Path("/tmp/faf_work")
C_PREV_INTER = Path("/working_dir/c_bc1ba559921be6b9/artifacts/file_generation/ttl=63d/intermediate")
C_PREV_WORK  = Path("/working_dir/c_bc1ba559921be6b9/work")

sys.path.insert(0, str(C_PREV_INTER))
sys.path.insert(0, str(WORK_DIR))
sys.path.insert(0, str(OUT_DIR))
sys.path.insert(0, "/tmp/sofist_v2_1")

from blend_io import BlendFile
from mesh_builder import MeshBuilder, BoneFrame, PALETTE
import reconstruct_spellblade as rs_prev
import build_spellblade_v28_fidelity as b28
import update_v28_sculpt as u28
import renderer
from faf_v27_kinematics import rot_xyz, mat3_to_quat, solve_2bone_ik_world, rot_from_two_unit_vecs
from faf_v27_halo_dash_dive import compute_fluid_stride_kinematics_v27, _smoothstep
from export_fight_and_flight_v25 import ensure_quat_continuity, zstd_compress_blend
from gltf_standard_evaluator import StandardGltfEvaluator, quat_to_mat3

S_V28 = 0.850
Y_SOLE_OFFSET = 0.020

JOINT_NAMES_27 = b28.JOINT_NAMES_27
JOINT_INDEX_MAP = {name: idx for idx, name in enumerate(JOINT_NAMES_27)}
PARENT_MAP = {
    1: 0, 2: 1, 3: 2, 4: 3, 5: 4,
    6: 3, 7: 6, 8: 7, 9: 8, 10: 9,
    11: 3, 12: 11, 13: 12, 14: 13, 15: 14,
    16: 2, 17: 16, 18: 17, 19: 3, 20: 19,
    21: 1, 22: 21, 23: 22,
    24: 1, 25: 24, 26: 25,
}


def b_to_gltf_pos(verts_b: np.ndarray) -> np.ndarray:
    v = np.asarray(verts_b, dtype=np.float32)
    out = np.empty_like(v, dtype=np.float32)
    out[:, 0] = -v[:, 0] * S_V28
    out[:, 1] =  v[:, 2] * S_V28 + Y_SOLE_OFFSET
    out[:, 2] =  v[:, 1] * S_V28
    return out


def b_to_gltf_pt_single(pt_b) -> np.ndarray:
    return np.array([
        -float(pt_b[0]) * S_V28,
         float(pt_b[2]) * S_V28 + Y_SOLE_OFFSET,
         float(pt_b[1]) * S_V28,
    ], dtype=np.float64)


def split_greave_and_boot(leg_mb: MeshBuilder, is_right=False):
    ft_key = "foot.R" if is_right else "foot.L"
    mb_g = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    mb_b = MeshBuilder(["MAKitMatte", "MAKitMetal"])
    off = 0
    for pi, poly in enumerate(leg_mb.polys):
        plen = len(poly)
        w0 = leg_mb.weights[poly[0]]
        is_boot = (ft_key in w0)
        target = mb_b if is_boot else mb_g
        mat_name = leg_mb.mat_names[leg_mb.mat_indices[pi]]
        new_vis = [target.add_vert(leg_mb.verts[vi], leg_mb.weights[vi]) for vi in poly]
        target.polys.append(new_vis)
        target.mat_indices.append(target._resolve_mat(mat_name))
        target.loop_colors.extend(leg_mb.loop_colors[off:off+plen])
        target.loop_uvs.extend(leg_mb.loop_uvs[off:off+plen])
        off += plen
    return mb_g, mb_b


def build_v28_arm_only_without_left_hand():
    full_arm_l = b28.build_v28_arm_and_gauntlet(is_right=False, closed_left_grip=False)
    mb_arm = MeshBuilder(["MAKitMatte", "MAKitMetal"])
    off = 0
    for pi, poly in enumerate(full_arm_l.polys):
        plen = len(poly)
        w0 = full_arm_l.weights[poly[0]]
        if "hand.L" not in w0:
            mat_name = full_arm_l.mat_names[full_arm_l.mat_indices[pi]]
            new_vis = [mb_arm.add_vert(full_arm_l.verts[vi], full_arm_l.weights[vi]) for vi in poly]
            mb_arm.polys.append(new_vis)
            mb_arm.mat_indices.append(mb_arm._resolve_mat(mat_name))
            mb_arm.loop_colors.extend(full_arm_l.loop_colors[off:off+plen])
            mb_arm.loop_uvs.extend(full_arm_l.loop_uvs[off:off+plen])
        off += plen
    mb_arm.bake_loop_shading()
    return mb_arm


def build_and_save_v28_blend_files():
    """
    Saves both `spellblade-v28-fidelity-production.blend` (Third-Person, all 17 `ME*` meshes
    including `METabardFront` and `METabardBack` replaced with 3D sculpted pleated tabards!)
    and `spellblade-v28-first-person-production.blend` (First-Person, 4 `ME*` meshes).
    """
    tp_src = C_PREV_WORK / "Spellblade-production-third-person.blend"
    bf_tp = BlendFile(str(tp_src))
    rs_prev.upgrade_banner_texture(bf_tp)

    mb_shell, mb_jaw, mb_visor, mb_crest = u28.build_v28_refined_helmet_parts()
    pauldron_l, pauldron_r = u28.build_v28_refined_pauldron_pair()
    leg_l = u28.build_v28_refined_legs_greaves_and_boots(is_right=False)
    leg_r = u28.build_v28_refined_legs_greaves_and_boots(is_right=True)
    greave_l, boot_l = split_greave_and_boot(leg_l, is_right=False)
    greave_r, boot_r = split_greave_and_boot(leg_r, is_right=True)

    rs_prev.polish_original_tabards(bf_tp)

    sword_mb = rs_prev.build_hero_sword(first_person=False)
    for i in range(len(sword_mb.weights)):
        sword_mb.weights[i] = {"socket_sword": 1.0}

    replacements_tp = {
        "MEHelmetShellCanonical": mb_shell,
        "MEHelmetJawCanonical":   mb_jaw,
        "MEVisorCanonical":       mb_visor,
        "MECrestCanonical":       mb_crest,
        "MEPauldron.L":           pauldron_l,
        "MEPauldron.R":           pauldron_r,
        "MEBreastplate":          u28.build_v28_refined_breastplate_scarf_and_belt(),
        "MEGauntlet.L.001":       b28.build_v28_arm_and_gauntlet(is_right=False, closed_left_grip=False),
        "MEGauntlet.R.001":       b28.build_v28_arm_and_gauntlet(is_right=True,  closed_left_grip=False),
        "MEPalmRune.001":         rs_prev.build_sorcery_cluster(first_person=False),
        "MEHeroSword":            sword_mb,
        "MEGreave.L":             greave_l,
        "MEGreave.R":             greave_r,
        "MEBoot.L":               boot_l,
        "MEBoot.R":               boot_r,
    }

    for mname, builder in replacements_tp.items():
        builder.bake_loop_shading()
        bf_tp.replace_mesh(mname, builder)

    bf_tp.set_armature_rest_pose_in_pose_channels()
    uncomp_tp = WORK_DIR / "Spellblade-v28-preview.blend"
    bf_tp.save(str(uncomp_tp))
    out_tp = OUT_DIR / "spellblade-v28-fidelity-production.blend"
    c_sz = zstd_compress_blend(uncomp_tp.read_bytes(), out_tp)
    sha_tp = hashlib.sha256(out_tp.read_bytes()).hexdigest()
    print(f"[OK] Saved {out_tp.name}: {c_sz:,} bytes (uncompressed {uncomp_tp.stat().st_size:,} B), SHA256={sha_tp}")

    fp_src = C_PREV_WORK / "Spellblade-production-first-person.blend"
    if fp_src.exists():
        bf_fp = BlendFile(str(fp_src))
        replacements_fp = {
            "MEArm.L":         rs_prev.build_arm_and_gauntlet(is_right=False, first_person=True),
            "MEArm.R":         rs_prev.build_arm_and_gauntlet(is_right=True,  first_person=True),
            "MEPalmRune":      rs_prev.build_sorcery_cluster(first_person=True),
            "MEHeroSword.001": rs_prev.build_hero_sword(first_person=True),
        }
        for mname, builder in replacements_fp.items():
            builder.bake_loop_shading()
            bf_fp.replace_mesh(mname, builder)
        bf_fp.set_armature_rest_pose_in_pose_channels()
        uncomp_fp = WORK_DIR / "Spellblade-v28-fp-preview.blend"
        bf_fp.save(str(uncomp_fp))
        out_fp = OUT_DIR / "spellblade-v28-first-person-production.blend"
        zstd_compress_blend(uncomp_fp.read_bytes(), out_fp)

    return uncomp_tp, replacements_tp


def compile_meshbuilder_to_gltf_arrays(mb: MeshBuilder, default_joint_idx: int = 3):
    verts_w = b_to_gltf_pos(np.array(mb.verts, dtype=np.float32))
    pos_list, nrm_list, vc_list, uv_list, j0_list, w0_list, tri_list = [], [], [], [], [], [], []

    v_j0 = np.zeros((len(mb.verts), 4), dtype=np.uint16)
    v_w0 = np.zeros((len(mb.verts), 4), dtype=np.float32)
    for vi, wdict in enumerate(mb.weights):
        items = sorted(
            [(JOINT_INDEX_MAP.get(k, default_joint_idx), float(val)) for k, val in wdict.items() if float(val) > 1e-5],
            key=lambda x: -x[1]
        )[:4]
        if not items:
            items = [(default_joint_idx, 1.0)]
        tot = sum(x[1] for x in items)
        for c, (j_idx, w_val) in enumerate(items):
            v_j0[vi, c] = int(j_idx)
            v_w0[vi, c] = float(w_val / max(tot, 1e-6))

    l_off = 0
    v_cur = 0
    for pi, poly in enumerate(mb.polys):
        plen = len(poly)
        if plen < 3:
            l_off += plen
            continue
        pts = verts_w[poly]
        fn = np.cross(pts[1] - pts[0], pts[2] - pts[0])
        fn_len = float(np.linalg.norm(fn))
        if fn_len < 1e-9:
            fn = np.array([0.0, 1.0, 0.0], dtype=np.float32)
        else:
            fn = (fn / fn_len).astype(np.float32)

        mat_name = mb.mat_names[mb.mat_indices[pi]] if pi < len(mb.mat_indices) else "MAKitMetal"
        is_glow = mat_name in ("MAVisorGlow", "MASorceryAccent")

        for k, vi in enumerate(poly):
            pos_list.append(verts_w[vi])
            nrm_list.append(fn)
            rgba = list(mb.loop_colors[l_off + k])
            if is_glow:
                is_core = (k < plen - 2) if plen == 4 else True
                rgba = [0.22, 0.96, 1.00, 1.0] if is_core else [0.78, 0.99, 1.00, 1.0]
            else:
                rgba = [
                    float(np.clip(rgba[0] ** (1.0 / 1.85), 0.0, 1.0)),
                    float(np.clip(rgba[1] ** (1.0 / 1.85), 0.0, 1.0)),
                    float(np.clip(rgba[2] ** (1.0 / 1.85), 0.0, 1.0)),
                    1.0,
                ]
            vc_list.append(rgba)
            uv_list.append(mb.loop_uvs[l_off + k])
            j0_list.append(v_j0[vi])
            w0_list.append(v_w0[vi])

        for t_i in range(1, plen - 1):
            tri_list.append([v_cur, v_cur + t_i, v_cur + t_i + 1])

        v_cur += plen
        l_off += plen

    return (
        np.array(pos_list, dtype=np.float32),
        np.array(nrm_list, dtype=np.float32),
        np.array(vc_list,  dtype=np.float32),
        np.array(uv_list,  dtype=np.float32),
        np.array(j0_list,  dtype=np.uint16),
        np.array(w0_list,  dtype=np.float32),
        np.array(tri_list, dtype=np.uint32),
    )



def extract_tabards_centroid_subdivided(blend_path: Path):
    """
    Extracts `METabardFront` and `METabardBack` from `Spellblade-v28-preview.blend`,
    applies 3D vertical cloth pleat depth (`±0.008 m`), subdivides each triangle 3 times
    (`64x`), and samples `SpellbladeBanner.png` at the **centroid `(u_c, v_c)`** of each
    sub-triangle into `COLOR_0` so that vertex-based evaluators (`StandardGltfEvaluator`)
    render the Golden Spear-Trident and stepped gold border with zero Gouraud bleeding!
    """
    wm, mats, imgs = renderer.extract_meshes_from_blend(str(blend_path))
    banner_rgba = None
    for k, arr in imgs.items():
        if "Banner" in k:
            banner_rgba = np.clip(arr, 0.0, 1.0)
            break
    H_tex, W_tex, _ = banner_rgba.shape

    pos_list, nrm_list, uv_list, j0_list, w0_list, tri_list = [], [], [], [], [], []
    v_cur = 0

    for mname in ("METabardFront", "METabardBack"):
        m = wm[mname]
        verts_b = m["verts"].copy()
        is_front = (mname == "METabardFront")
        # Add subtle 3D vertical cloth pleat waves across X
        for vi in range(len(verts_b)):
            xb, yb, zb = verts_b[vi]
            t_z = np.clip((1.26 - zb) / 0.76, 0.0, 1.0) if is_front else np.clip((1.62 - zb) / 1.15, 0.0, 1.0)
            pleat = 0.007 * math.cos(xb * 42.0) * (0.3 + 0.7 * t_z)
            verts_b[vi, 1] += pleat if is_front else -pleat

        verts_w = b_to_gltf_pos(verts_b)
        po = m["poly_offsets"]
        cv = m["corner_verts"]
        uv = m["uv_map"]

        n_v = len(verts_b)
        v_j0 = np.zeros((n_v, 4), dtype=np.uint16)
        v_w0 = np.zeros((n_v, 4), dtype=np.float32)
        for vi in range(n_v):
            zb = float(verts_b[vi, 2])
            if is_front:
                if zb >= 1.05:
                    u = np.clip((1.26 - zb) / 0.21, 0.0, 1.0)
                    v_j0[vi] = [16, 1, 0, 0]; v_w0[vi] = [u, 1.0 - u, 0.0, 0.0]
                elif zb >= 0.78:
                    u = np.clip((1.05 - zb) / 0.27, 0.0, 1.0)
                    v_j0[vi] = [17, 16, 0, 0]; v_w0[vi] = [u, 1.0 - u, 0.0, 0.0]
                else:
                    u = np.clip((0.78 - zb) / 0.28, 0.0, 1.0)
                    v_j0[vi] = [18, 17, 0, 0]; v_w0[vi] = [u, 1.0 - u, 0.0, 0.0]
            else:
                if zb >= 1.35:
                    u = np.clip((1.62 - zb) / 0.27, 0.0, 1.0)
                    v_j0[vi] = [19, 3, 0, 0]; v_w0[vi] = [u, 1.0 - u, 0.0, 0.0]
                elif zb >= 0.90:
                    u = np.clip((1.35 - zb) / 0.45, 0.0, 1.0)
                    v_j0[vi] = [20, 19, 0, 0]; v_w0[vi] = [u, 1.0 - u, 0.0, 0.0]
                else:
                    v_j0[vi] = [20, 19, 0, 0]; v_w0[vi] = [0.90, 0.10, 0.0, 0.0]

        totpoly = len(po) - 1
        for pi in range(totpoly):
            lstart, lend = int(po[pi]), int(po[pi + 1])
            plen = lend - lstart
            if plen < 3:
                continue
            v_indices = cv[lstart:lend]
            pts = verts_w[v_indices]
            fn = np.cross(pts[1] - pts[0], pts[2] - pts[0])
            fn_len = float(np.linalg.norm(fn))
            fn = (fn / fn_len).astype(np.float32) if fn_len > 1e-9 else np.array([0.0, 0.0, 1.0], dtype=np.float32)

            for k in range(plen):
                vi = int(v_indices[k])
                u_coord, v_coord = float(uv[lstart + k, 0]), float(uv[lstart + k, 1])
                pos_list.append(verts_w[vi])
                nrm_list.append(fn)
                uv_list.append([u_coord, v_coord])
                j0_list.append(v_j0[vi])
                w0_list.append(v_w0[vi])

            for t_i in range(1, plen - 1):
                tri_list.append([v_cur, v_cur + t_i, v_cur + t_i + 1])
            v_cur += plen

    vp_arr  = np.array(pos_list, dtype=np.float32)
    vn_arr  = np.array(nrm_list, dtype=np.float32)
    uv_arr  = np.array(uv_list,  dtype=np.float32)
    j0_arr  = np.array(j0_list,  dtype=np.uint16)
    w0_arr  = np.array(w0_list,  dtype=np.float32)
    tri_arr = np.array(tri_list, dtype=np.uint32)

    # Subdivide 3 passes (64x)
    for _pass in range(2):
        i0, i1, i2 = tri_arr[:, 0], tri_arr[:, 1], tri_arr[:, 2]
        n_base = len(vp_arr)
        n_t = len(tri_arr)
        p01 = 0.5 * (vp_arr[i0] + vp_arr[i1])
        p12 = 0.5 * (vp_arr[i1] + vp_arr[i2])
        p20 = 0.5 * (vp_arr[i2] + vp_arr[i0])
        n01, n12, n20 = vn_arr[i0], vn_arr[i1], vn_arr[i2]
        u01 = 0.5 * (uv_arr[i0] + uv_arr[i1])
        u12 = 0.5 * (uv_arr[i1] + uv_arr[i2])
        u20 = 0.5 * (uv_arr[i2] + uv_arr[i0])
        j01, w01 = j0_arr[i0], w0_arr[i0]
        j12, w12 = j0_arr[i1], w0_arr[i1]
        j20, w20 = j0_arr[i2], w0_arr[i2]

        vp_arr = np.vstack([vp_arr, p01, p12, p20]).astype(np.float32)
        vn_arr = np.vstack([vn_arr, n01, n12, n20]).astype(np.float32)
        uv_arr = np.vstack([uv_arr, u01, u12, u20]).astype(np.float32)
        j0_arr = np.vstack([j0_arr, j01, j12, j20]).astype(np.uint16)
        w0_arr = np.vstack([w0_arr, w01, w12, w20]).astype(np.float32)

        m01 = np.arange(n_base,          n_base + n_t,     dtype=np.uint32)
        m12 = np.arange(n_base + n_t,    n_base + 2 * n_t, dtype=np.uint32)
        m20 = np.arange(n_base + 2 * n_t,n_base + 3 * n_t, dtype=np.uint32)
        tri_arr = np.vstack([
            np.column_stack([i0,  m01, m20]),
            np.column_stack([m01, i1,  m12]),
            np.column_stack([m20, m12, i2]),
            np.column_stack([m01, m12, m20]),
        ]).astype(np.uint32)

    # Unweld sub-triangles and assign each sub-triangle the exact CENTROID sample of SpellbladeBanner.png!
    n_sub = len(tri_arr)
    flat_idx = tri_arr.ravel()
    vp_out = vp_arr[flat_idx]
    vn_out = vn_arr[flat_idx]
    uv_out = uv_arr[flat_idx]
    j0_out = j0_arr[flat_idx]
    w0_out = w0_arr[flat_idx]

    uv_tri = uv_out.reshape(n_sub, 3, 2).mean(axis=1)
    gu = np.clip(uv_tri[:, 0], 0.0, 0.999)
    gv = np.clip(1.0 - uv_tri[:, 1], 0.0, 0.999)
    tx = (gu * W_tex).astype(np.int32)
    ty = (gv * H_tex).astype(np.int32)
    c_tri = banner_rgba[ty, tx, :3].astype(np.float32)

    vc_out = np.ones((n_sub * 3, 4), dtype=np.float32)
    vc_out[:, :3] = np.repeat(c_tri, 3, axis=0)
    tri_out = np.arange(n_sub * 3, dtype=np.uint32).reshape(n_sub, 3)

    return vp_out, vn_out, vc_out, uv_out, j0_out, w0_out, tri_out


def build_v28_27joint_skeleton():
    """
    Constructs the 27-joint `SpellbladeRig` hierarchy (`j_nodes[0..26]`, `WM_REST[0..26]`,
    `IBMS[0..26]`) at the exact 0.000 mm geometric pivots of `build_arm_and_gauntlet`,
    `build_v28_refined_legs_greaves_and_boots`, and `build_v28_sculpted_3d_tabard`!
    """
    pivots_b = {
        0:  ( 0.000,  0.000, 0.000), # root
        1:  ( 0.000,  0.015, 1.060), # pelvis
        2:  ( 0.000,  0.015, 1.250), # spine
        3:  ( 0.000,  0.015, 1.450), # chest
        4:  ( 0.000,  0.025, 1.650), # neck
        5:  ( 0.000,  0.040, 1.760), # head
        6:  (-0.180, -0.015, 1.565), # clavicle.L
        7:  (-0.245, -0.020, 1.565), # upper_arm.L (exact ua_h)
        8:  (-0.345,  0.095, 1.255), # forearm.L   (exact fa_h)
        9:  (-0.428,  0.455, 1.185), # hand.L      (exact ha_h)
        10: (-0.468,  0.555, 1.265), # socket_sorcery
        11: (+0.180, -0.015, 1.565), # clavicle.R
        12: (+0.265, -0.045, 1.575), # upper_arm.R (exact ua_h)
        13: (+0.385, -0.128, 1.335), # forearm.R   (exact fa_h)
        14: (+0.465,  0.005, 1.060), # hand.R      (exact ha_h)
        15: (+0.465,  0.005, 1.060), # socket_sword (coaxial with hand.R so sword & grip never separate!)
        16: ( 0.000,  0.238, 1.186), # tabard_root
        17: ( 0.000,  0.246, 0.960), # tabard_front_01
        18: ( 0.000,  0.246, 0.720), # tabard_front_02
        19: ( 0.000, -0.195, 1.420), # tabard_back_01
        20: ( 0.000, -0.240, 0.920), # tabard_back_02
        21: (-0.175,  0.015, 1.060), # thigh.L (exact th_h)
        22: (-0.232,  0.050, 0.635), # shin.L  (exact sh_h)
        23: (-0.268, -0.010, 0.225), # foot.L  (exact sh_t)
        24: (+0.175,  0.015, 1.060), # thigh.R (exact th_h)
        25: (+0.232,  0.050, 0.635), # shin.R  (exact sh_h)
        26: (+0.268, -0.010, 0.225), # foot.R  (exact sh_t)
    }

    WM_REST = {}
    for j in range(27):
        M = np.eye(4, dtype=np.float64)
        if j == 0:
            M[:3, 3] = [0.0, 0.0, 0.0]
        else:
            M[:3, 3] = b_to_gltf_pt_single(pivots_b[j])
        WM_REST[j] = M

    j_nodes = []
    IBMS = np.empty((27, 4, 4), dtype=np.float64)
    for j in range(27):
        if j in PARENT_MAP:
            p_j = PARENT_MAP[j]
            LM = np.linalg.inv(WM_REST[p_j]) @ WM_REST[j]
            tr = LM[:3, 3]
            rt = mat3_to_quat(LM[:3, :3])
        else:
            tr = WM_REST[j][:3, 3]
            rt = [0.0, 0.0, 0.0, 1.0]
        ch = sorted([c for c, p in PARENT_MAP.items() if p == j])
        j_nodes.append({
            "name": JOINT_NAMES_27[j],
            "translation": [round(float(x), 6) for x in tr],
            "rotation":    [round(float(x), 6) for x in rt],
            "scale":       [1.0, 1.0, 1.0],
            "children":    ch,
        })
        IBMS[j] = np.linalg.inv(WM_REST[j])

    return j_nodes, WM_REST, IBMS


def solve_v28_crouch_leg_ik(dy_pelvis: float, pelvis_pitch_deg: float = 0.0):
    """
    Calibrated specifically to the `v2.8` leg bind pose so that at standing height (`dy_pelvis == 0.0`),
    `leg_ik == (0.0, 0.0, 0.0)` (preserving the exact tall, unbuckled heroic A-stance!), and when
    crouching (`dy_pelvis < 0.0`), the thigh pitches forward (`-X`), the knee flexes (`+X`), and
    the foot counter-pitches (`-X`) so the sabaton soles remain planted flat at `Y = +0.020 m`.
    """
    if abs(dy_pelvis) < 1e-4 and abs(pelvis_pitch_deg) < 1e-4:
        return (0.0, 0.0, 0.0)
    crouch_amt = max(0.0, -float(dy_pelvis))
    th_deg = -135.0 * crouch_amt - 0.5 * pelvis_pitch_deg
    sh_deg = +260.0 * crouch_amt
    st_deg = -125.0 * crouch_amt - 0.5 * pelvis_pitch_deg
    return (th_deg, sh_deg, st_deg)


def solve_spellblade_pose_quats_v28(
    WM_REST: dict,
    j_nodes: list,
    pelvis_tr_delta=(0.0, 0.0, 0.0),
    pelvis_euler_xyz=(0.0, 0.0, 0.0),
    spine_euler_xyz=(0.0, 0.0, 0.0),
    chest_euler_xyz=(0.0, 0.0, 0.0),
    neck_euler_xyz=(0.0, 0.0, 0.0),
    head_euler_xyz=(0.0, 0.0, 0.0),
    arm_l_euler_xyz=None,
    forearm_l_euler_xyz=(0.0, 0.0, 0.0),
    hand_l_euler_xyz=(0.0, 0.0, 0.0),
    hand_l_target_w=None,
    sorcery_rune_spin_deg: float = 0.0,
    arm_r_euler_xyz=None,
    forearm_r_euler_xyz=(0.0, 0.0, 0.0),
    hand_r_euler_xyz=(0.0, 0.0, 0.0),
    sword_strike_u: float = None,
    leg_ik_l=(0.0, 0.0, 0.0),
    leg_ik_r=(0.0, 0.0, 0.0),
):
    R_torso_p = rot_xyz(*pelvis_euler_xyz)
    R_torso_s = R_torso_p @ rot_xyz(*spine_euler_xyz)
    R_torso_c = R_torso_s @ rot_xyz(*chest_euler_xyz)
    R_neck    = R_torso_c @ rot_xyz(*neck_euler_xyz)
    R_head    = R_neck    @ rot_xyz(*head_euler_xyz)

    th_l, sh_l, st_l = leg_ik_l
    th_r, sh_r, st_r = leg_ik_r

    R_th_l = R_torso_p @ rot_xyz(th_l, 0.0, 0.0)
    R_sh_l = R_torso_p @ rot_xyz(th_l + sh_l, 0.0, 0.0)
    R_ft_l = R_torso_p @ rot_xyz(th_l + sh_l + st_l, 0.0, 0.0)

    R_th_r = R_torso_p @ rot_xyz(th_r, 0.0, 0.0)
    R_sh_r = R_torso_p @ rot_xyz(th_r + sh_r, 0.0, 0.0)
    R_ft_r = R_torso_p @ rot_xyz(th_r + sh_r + st_r, 0.0, 0.0)

    th_fwd = min(0.0, th_l, th_r)
    th_aft = max(0.0, th_l, th_r)
    step_diff = th_l - th_r
    R_tb_f1 = R_torso_p @ rot_xyz(0.85 * th_fwd, 0.0, 0.10 * step_diff)
    R_tb_f2 = R_tb_f1   @ rot_xyz(0.25 * th_fwd, 0.0, 0.05 * step_diff)
    R_tb_b1 = R_torso_c @ rot_xyz(0.75 * th_aft, 0.0, -0.08 * step_diff)
    R_tb_b2 = R_tb_b1   @ rot_xyz(0.30 * th_aft, 0.0, -0.05 * step_diff)

    p7_b = WM_REST[7][:3, 3]
    p8_b = WM_REST[8][:3, 3]
    p9_b = WM_REST[9][:3, 3]
    L1_l = float(np.linalg.norm(p8_b - p7_b))
    L2_l = float(np.linalg.norm(p9_b - p8_b))
    u1_l_b = (p8_b - p7_b) / L1_l
    u2_l_b = (p9_b - p8_b) / L2_l

    if arm_l_euler_xyz is not None:
        R_cl_l = R_torso_c @ rot_xyz(0.0, 0.0, 0.25 * arm_l_euler_xyz[2])
        R_ua_l = R_torso_c @ rot_xyz(*arm_l_euler_xyz)
        R_fa_l = R_ua_l    @ rot_xyz(*forearm_l_euler_xyz)
        R_hd_l = R_fa_l    @ rot_xyz(*hand_l_euler_xyz)
    elif hand_l_target_w is not None:
        hand_l_target_w = np.asarray(hand_l_target_w, dtype=np.float64)
        elev_l = max(-10.0, min(16.0, (hand_l_target_w[1] - 1.05) * 32.0))
        R_cl_l = R_torso_c @ rot_xyz(0.0, 0.0, +elev_l)
        p6_b = WM_REST[6][:3, 3]
        p3_b = WM_REST[3][:3, 3]
        p6_cur = p3_b + R_torso_c @ (p6_b - p3_b) + np.asarray(pelvis_tr_delta, dtype=np.float64)
        p7_cur = p6_cur + R_cl_l @ (p7_b - p6_b)
        p8_solved = solve_2bone_ik_world(
            p7_cur, hand_l_target_w, L1_l, L2_l, np.array([+0.75, -0.30, -0.55], dtype=np.float64)
        )
        u1_l_w = (p8_solved - p7_cur) / max(float(np.linalg.norm(p8_solved - p7_cur)), 1e-8)
        u2_l_w = (hand_l_target_w - p8_solved) / max(float(np.linalg.norm(hand_l_target_w - p8_solved)), 1e-8)
        R_ua_l = rot_from_two_unit_vecs(u1_l_b, u1_l_w)
        R_fa_l = rot_from_two_unit_vecs(u2_l_b, u2_l_w)
        R_hd_l = R_fa_l @ rot_xyz(*hand_l_euler_xyz)
    else:
        R_cl_l = R_torso_c
        R_ua_l = R_torso_c
        R_fa_l = R_torso_c
        R_hd_l = R_torso_c

    R_so_l = R_hd_l @ rot_xyz(0.0, sorcery_rune_spin_deg, 0.0)

    if arm_r_euler_xyz is not None:
        R_cl_r = R_torso_c @ rot_xyz(0.0, 0.0, 0.25 * arm_r_euler_xyz[2])
        R_ua_r = R_torso_c @ rot_xyz(*arm_r_euler_xyz)
        R_fa_r = R_ua_r    @ rot_xyz(*forearm_r_euler_xyz)
        R_hd_r = R_fa_r    @ rot_xyz(*hand_r_euler_xyz)
    elif sword_strike_u is not None and sword_strike_u > 0.0:
        u = float(sword_strike_u)
        w1 = math.sin(u * math.pi)
        w2 = math.sin(u * 2.0 * math.pi)
        R_cl_r = R_torso_c @ rot_xyz(-10.0 * w1, 0.0, -8.0 * w1)
        R_ua_r = R_torso_c @ rot_xyz(-42.0 * w1 + 22.0 * w2, +18.0 * w1 - 14.0 * w2, -12.0 * w1)
        R_fa_r = R_ua_r    @ rot_xyz(-24.0 * w1 + 14.0 * w2, 0.0, 0.0)
        R_hd_r = R_fa_r    @ rot_xyz(+12.0 * w2, 0.0, 0.0)
    else:
        R_cl_r = R_torso_c
        R_ua_r = R_torso_c
        R_fa_r = R_torso_c
        R_hd_r = R_torso_c

    R_sw_r = R_hd_r

    R_w_map = {
        0:  np.eye(3),
        1:  R_torso_p,
        2:  R_torso_s,
        3:  R_torso_c,
        4:  R_neck,
        5:  R_head,
        6:  R_cl_l,
        7:  R_ua_l,
        8:  R_fa_l,
        9:  R_hd_l,
        10: R_so_l,
        11: R_cl_r,
        12: R_ua_r,
        13: R_fa_r,
        14: R_hd_r,
        15: R_sw_r,
        16: R_torso_s,
        17: R_tb_f1,
        18: R_tb_f2,
        19: R_tb_b1,
        20: R_tb_b2,
        21: R_th_l,
        22: R_sh_l,
        23: R_ft_l,
        24: R_th_r,
        25: R_sh_r,
        26: R_ft_r,
    }

    q_local_out = {}
    for j in range(27):
        R_pw = R_w_map[j]
        if j in PARENT_MAP:
            R_par = R_w_map[PARENT_MAP[j]]
            R_loc = R_par.T @ R_pw
        else:
            R_loc = R_pw
        q_local_out[j] = mat3_to_quat(R_loc)

    t1_rest = np.array(j_nodes[1]["translation"], dtype=np.float64)
    t1_posed = t1_rest + np.asarray(pelvis_tr_delta, dtype=np.float64)
    return t1_posed.tolist(), q_local_out


def build_spellblade_v28_skeletal_animations(WM_REST: dict, j_nodes: list):
    anims = []

    def _pack_clip(name: str, times: list, pose_kwargs_list: list, open_sorcery_flags: list = None):
        n_k = len(times)
        tr_1 = []
        q_by_j = {j: [] for j in range(1, 27)}
        sc_28, sc_29 = [], []

        for i in range(n_k):
            t1, q_map = solve_spellblade_pose_quats_v28(WM_REST, j_nodes, **pose_kwargs_list[i])
            tr_1.append([round(float(x), 5) for x in t1])
            for j in range(1, 27):
                q_by_j[j].append(q_map[j])
            is_open = (open_sorcery_flags[i] if open_sorcery_flags is not None else False)
            sc_28.append([0.0, 0.0, 0.0] if is_open else [1.0, 1.0, 1.0])
            sc_29.append([1.0, 1.0, 1.0] if is_open else [0.0, 0.0, 0.0])

        tracks = {
            1: {"translation": tr_1, "rotation": ensure_quat_continuity(q_by_j[1])},
        }
        for j in range(2, 27):
            tracks[j] = {"rotation": ensure_quat_continuity(q_by_j[j])}
        if open_sorcery_flags is not None:
            tracks[28] = {"scale": sc_28}
            tracks[29] = {"scale": sc_29}
        return {"name": name, "times": times, "tracks": tracks}

    # 1. `Spellblade_01_Grounded_Idle` (Tall heroic stance, subtle breathing, orbiting cyan rune)
    t_id = [round(1.600 * i / 32.0, 5) for i in range(33)]
    kw_id, flags_id = [], []
    for i in range(33):
        u = i / 32.0
        s = math.sin(2.0 * math.pi * u)
        c = math.cos(2.0 * math.pi * u)
        dy = -0.004 * (0.5 - 0.5 * c)
        ik_i = solve_v28_crouch_leg_ik(dy)
        kw_id.append(dict(
            pelvis_tr_delta=(0.0, dy, 0.0),
            chest_euler_xyz=(1.0 * s, 0.0, 0.0),
            head_euler_xyz=(-0.6 * s, 1.5 * s, 0.0),
            arm_l_euler_xyz=(1.5 * s, 0.0, 0.0),
            arm_r_euler_xyz=(-1.2 * s, 0.0, 0.0),
            sorcery_rune_spin_deg=360.0 * u,
            leg_ik_l=ik_i, leg_ik_r=ik_i,
        ))
        flags_id.append(True)
    anims.append(_pack_clip("Spellblade_01_Grounded_Idle", t_id, kw_id, flags_id))

    # 2. `Spellblade_02_Walk_Cycle`
    t_wk = [round(1.200 * i / 48.0, 5) for i in range(49)]
    kw_wk = []
    for i in range(49):
        u = i / 48.0
        ty, cp, ay_l, az_l, ay_r, az_r, ik_l, ik_r, roll_p, yaw_p, fp_l, fp_r = compute_fluid_stride_kinematics_v27(u, run_mode=False)
        sw_arm = math.cos(2.0 * math.pi * u)
        kw_wk.append(dict(
            pelvis_tr_delta=(0.0, ty * 0.65, 0.0),
            pelvis_euler_xyz=(cp * 0.65, 0.0, 0.0),
            spine_euler_xyz=(0.0, -0.45 * yaw_p, -0.35 * roll_p),
            chest_euler_xyz=(1.5, -0.35 * yaw_p, 0.0),
            arm_l_euler_xyz=(+14.0 * sw_arm, 0.0, 0.0),
            arm_r_euler_xyz=(-14.0 * sw_arm, 0.0, 0.0),
            leg_ik_l=(ik_l[0] * 0.72, ik_l[1] * 0.65, ik_l[2] * 0.65),
            leg_ik_r=(ik_r[0] * 0.72, ik_r[1] * 0.65, ik_r[2] * 0.65),
        ))
    anims.append(_pack_clip("Spellblade_02_Walk_Cycle", t_wk, kw_wk))

    # 3. `Spellblade_03_Run_Cycle`
    t_rn = [round(0.800 * i / 32.0, 5) for i in range(33)]
    kw_rn = []
    for i in range(33):
        u = i / 32.0
        ty, cp, ay_l, az_l, ay_r, az_r, ik_l, ik_r, roll_p, yaw_p, fp_l, fp_r = compute_fluid_stride_kinematics_v27(u, run_mode=True)
        sw_arm = math.cos(2.0 * math.pi * u)
        kw_rn.append(dict(
            pelvis_tr_delta=(0.0, ty * 0.75, 0.0),
            pelvis_euler_xyz=(cp * 0.75, 0.0, 0.0),
            spine_euler_xyz=(3.0, -0.45 * yaw_p, -0.35 * roll_p),
            chest_euler_xyz=(3.5, -0.40 * yaw_p, 0.0),
            arm_l_euler_xyz=(+24.0 * sw_arm, 0.0, 0.0),
            arm_r_euler_xyz=(-24.0 * sw_arm, 0.0, 0.0),
            leg_ik_l=(ik_l[0] * 0.78, ik_l[1] * 0.72, ik_l[2] * 0.72),
            leg_ik_r=(ik_r[0] * 0.78, ik_r[1] * 0.72, ik_r[2] * 0.72),
        ))
    anims.append(_pack_clip("Spellblade_03_Run_Cycle", t_rn, kw_rn))

    # 4. `Spellblade_04_Crouch_And_Guard` (Clean crouch + raised diagonal ward guard)
    t_cr = [round(1.200 * i / 24.0, 5) for i in range(25)]
    kw_cr = []
    for i in range(25):
        u = i / 24.0
        w = math.sin(u * math.pi)
        dy = -0.160 * w
        cp = +4.0 * w
        ik_c = solve_v28_crouch_leg_ik(dy, cp)
        kw_cr.append(dict(
            pelvis_tr_delta=(0.0, dy, 0.0),
            pelvis_euler_xyz=(cp, 0.0, 0.0),
            chest_euler_xyz=(+3.0 * w, +10.0 * w, 0.0),
            head_euler_xyz=(-3.0 * w, -8.0 * w, 0.0),
            arm_l_euler_xyz=(-14.0 * w, +10.0 * w, +6.0 * w),
            arm_r_euler_xyz=(-36.0 * w, +16.0 * w, -10.0 * w),
            forearm_r_euler_xyz=(-22.0 * w, 0.0, 0.0),
            leg_ik_l=ik_c, leg_ik_r=ik_c,
        ))
    anims.append(_pack_clip("Spellblade_04_Crouch_And_Guard", t_cr, kw_cr))

    # 5. `Spellblade_05_Jump_And_Land`
    t_jp = [round(0.900 * i / 24.0, 5) for i in range(25)]
    kw_jp = []
    for i in range(25):
        u = i / 24.0
        if u <= 0.22:
            w = math.sin((u / 0.22) * math.pi * 0.5)
            dy, cp = -0.120 * w, +3.0 * w
            ik_j = solve_v28_crouch_leg_ik(dy, cp)
        elif u <= 0.68:
            w = (u - 0.22) / 0.46
            arc = math.sin(w * math.pi)
            dy = -0.120 * max(0.0, 1.0 - w * 4.0) + 0.260 * arc
            cp = -2.0 * arc
            ik_j = (-18.0 * arc, +36.0 * arc, +12.0 * arc)
        else:
            w = (u - 0.68) / 0.32
            shk = math.sin(w * math.pi)
            dy, cp = -0.140 * shk, +3.5 * shk
            ik_j = solve_v28_crouch_leg_ik(dy, cp)
        kw_jp.append(dict(
            pelvis_tr_delta=(0.0, dy, 0.0),
            pelvis_euler_xyz=(cp, 0.0, 0.0),
            leg_ik_l=ik_j, leg_ik_r=ik_j,
        ))
    anims.append(_pack_clip("Spellblade_05_Jump_And_Land", t_jp, kw_jp))

    # 6. `Spellblade_06_Sword_Slash_Combo_And_Recovery`
    t_sw = [round(1.300 * i / 48.0, 5) for i in range(49)]
    kw_sw = []
    for i in range(49):
        u = i / 48.0
        sw_u = (u * 2.0) % 1.0 if u < 1.0 else 1.0
        turn = math.sin(sw_u * math.pi)
        ik_s = solve_v28_crouch_leg_ik(-0.020 * turn, +1.5 * turn)
        kw_sw.append(dict(
            pelvis_tr_delta=(0.0, -0.020 * turn, 0.0),
            spine_euler_xyz=(+2.0 * turn, +8.0 * turn, 0.0),
            chest_euler_xyz=(+2.0 * turn, +8.0 * turn, 0.0),
            head_euler_xyz=(0.0, -10.0 * turn, 0.0),
            sword_strike_u=sw_u,
            leg_ik_l=ik_s, leg_ik_r=ik_s,
        ))
    anims.append(_pack_clip("Spellblade_06_Sword_Slash_Combo_And_Recovery", t_sw, kw_sw))

    # 7. `Spellblade_07_Open_Palm_Sorcery_Cast_And_Release`
    t_cs = [round(1.500 * i / 48.0, 5) for i in range(49)]
    kw_cs, open_flags_cs = [], []
    for i in range(49):
        u = i / 48.0
        pulse = math.sin(u * math.pi)
        ik_c = solve_v28_crouch_leg_ik(-0.015 * pulse)
        kw_cs.append(dict(
            pelvis_tr_delta=(0.0, -0.015 * pulse, 0.0),
            spine_euler_xyz=(0.0, -5.0 * pulse, 0.0),
            chest_euler_xyz=(-2.5 * pulse, -8.0 * pulse, 0.0),
            head_euler_xyz=(-1.5 * pulse, +8.0 * pulse, 0.0),
            arm_l_euler_xyz=(-18.0 * pulse, +8.0 * pulse, +6.0 * pulse),
            forearm_l_euler_xyz=(-10.0 * pulse, 0.0, 0.0),
            sorcery_rune_spin_deg=360.0 * u,
            arm_r_euler_xyz=(+8.0 * pulse, 0.0, -4.0 * pulse),
            leg_ik_l=ik_c, leg_ik_r=ik_c,
        ))
        open_flags_cs.append(0.04 <= u <= 0.94)
    anims.append(_pack_clip("Spellblade_07_Open_Palm_Sorcery_Cast_And_Release", t_cs, kw_cs, open_flags_cs))

    # 8. `Spellblade_08_Machine_Mounted_Walk_And_Run_Sync`
    t_mw = [round(1.600 * i / 64.0, 5) for i in range(65)]
    kw_mw = []
    for i in range(65):
        t_sec = t_mw[i]
        is_run = (t_sec > 0.800)
        u_cyc = (t_sec / 0.800) % 1.0 if t_sec < 1.600 else 0.0
        ty, cp, ay_l, az_l, ay_r, az_r, ik_l, ik_r, roll_p, yaw_p, fp_l, fp_r = compute_fluid_stride_kinematics_v27(u_cyc, run_mode=is_run)
        kw_mw.append(dict(
            pelvis_tr_delta=(0.0, ty * 0.70, 0.0),
            pelvis_euler_xyz=(cp * 0.70, 0.0, 0.0),
            spine_euler_xyz=(0.0, 0.30 * yaw_p, 0.15 * roll_p),
            leg_ik_l=(ik_l[0] * 0.72, ik_l[1] * 0.65, ik_l[2] * 0.65),
            leg_ik_r=(ik_r[0] * 0.72, ik_r[1] * 0.65, ik_r[2] * 0.65),
        ))
    anims.append(_pack_clip("Spellblade_08_Machine_Mounted_Walk_And_Run_Sync", t_mw, kw_mw))

    # 9. `Spellblade_09_Machine_Crossbow_Aim_Envelope_Sweep`
    t_aim = [round(2.400 * i / 48.0, 5) for i in range(49)]
    aim_wps = [
        (0.00,   0.0,   0.0),
        (0.15, +50.0,   0.0),
        (0.32, -50.0,   0.0),
        (0.50,   0.0, +65.0),
        (0.68,   0.0, -65.0),
        (0.82, +50.0, +65.0),
        (0.92, -50.0, -65.0),
        (1.00,   0.0,   0.0),
    ]
    kw_aim = []
    for i in range(49):
        u = i / 48.0
        yaw_v, pitch_v = 0.0, 0.0
        for k in range(len(aim_wps) - 1):
            u0, y0, p0 = aim_wps[k]
            u1, y1, p1 = aim_wps[k + 1]
            if u <= u1 or k == len(aim_wps) - 2:
                f = (u - u0) / max(u1 - u0, 1e-6)
                sf = f * f * (3.0 - 2.0 * f)
                yaw_v = y0 + sf * (y1 - y0)
                pitch_v = p0 + sf * (p1 - p0)
                break
        kw_aim.append(dict(
            arm_l_euler_xyz=(-0.30 * pitch_v, +0.40 * yaw_v, 0.0),
            forearm_l_euler_xyz=(-0.20 * pitch_v, +0.20 * yaw_v, 0.0),
        ))
    anims.append(_pack_clip("Spellblade_09_Machine_Crossbow_Aim_Envelope_Sweep", t_aim, kw_aim))

    # 10. `Spellblade_10_Machine_Offensive_Dash_Posture`
    t_od = [round(1.000 * i / 24.0, 5) for i in range(25)]
    kw_od = []
    for i in range(25):
        u = i / 24.0
        s2 = math.sin(2.0 * math.pi * u)
        c2 = math.cos(2.0 * math.pi * u)
        kw_od.append(dict(
            pelvis_tr_delta=(0.0, 0.012 + 0.003 * s2, 0.028),
            pelvis_euler_xyz=(+5.5 + 0.6 * s2, 0.0, 0.0),
            leg_ik_l=(-20.0 + 1.5 * s2, +36.0 + 2.0 * c2, +14.0 - 1.0 * s2),
            leg_ik_r=(-20.0 + 1.5 * s2, +36.0 + 2.0 * c2, +14.0 - 1.0 * s2),
        ))
    anims.append(_pack_clip("Spellblade_10_Machine_Offensive_Dash_Posture", t_od, kw_od))

    # 11. `Spellblade_11_Machine_Valkyrie_Dive_And_Incapacitation`
    t_fl = [round(1.400 * i / 42.0, 5) for i in range(43)]
    kw_fl = []
    for i in range(43):
        u = i / 42.0
        slump_w = _smoothstep(0.45, 0.95, u)
        kw_fl.append(dict(
            pelvis_tr_delta=(0.0, 0.018 - 0.045 * slump_w, 0.036 + 0.035 * slump_w),
            pelvis_euler_xyz=(8.5 + 10.5 * slump_w, -4.0 * slump_w, -5.5 * slump_w),
            neck_euler_xyz=(14.0 * slump_w, -6.0 * slump_w, -8.0 * slump_w),
            head_euler_xyz=(12.0 * slump_w, 0.0, 0.0),
            leg_ik_l=(-26.0 + 14.0 * slump_w, +46.0 - 18.0 * slump_w, +18.0 - 10.0 * slump_w),
            leg_ik_r=(-26.0 + 14.0 * slump_w, +46.0 - 18.0 * slump_w, +18.0 - 10.0 * slump_w),
        ))
    anims.append(_pack_clip("Spellblade_11_Machine_Valkyrie_Dive_And_Incapacitation", t_fl, kw_fl))

    # 12. `Spellblade_12_Machine_Aerial_Ejection_Leap`
    t_ej = [round(1.200 * i / 24.0, 5) for i in range(25)]
    kw_ej = []
    for i in range(25):
        u = i / 24.0
        if u <= 0.15:
            w = u / 0.15
            dy, dz, cp = -0.080 * w, 0.0, +8.0 * w
            ik_e = (-16.0 * w, +32.0 * w, +10.0 * w)
        else:
            f = (u - 0.15) / 0.85
            sf = _smoothstep(0.0, 1.0, f)
            dy = -0.080 * (1.0 - f) + 0.520 * math.sin(f * math.pi * 0.65)
            dz = +0.820 * sf
            cp = +12.0 * (1.0 - sf)
            ik_e = (-20.0 * math.sin(f * math.pi), +38.0 * math.sin(f * math.pi), +14.0)
        kw_ej.append(dict(
            pelvis_tr_delta=(0.0, dy, dz),
            pelvis_euler_xyz=(cp, 0.0, 0.0),
            leg_ik_l=ik_e, leg_ik_r=ik_e,
        ))
    anims.append(_pack_clip("Spellblade_12_Machine_Aerial_Ejection_Leap", t_ej, kw_ej))

    return anims


def export_spellblade_v28_glb(uncomp_blend_path: Path, replacements_tp: dict, out_glb_path: Path):
    j_nodes, WM_REST, IBMS = build_v28_27joint_skeleton()
    anims = build_spellblade_v28_skeletal_animations(WM_REST, j_nodes)

    # Compile all 15 body/armor/tabard MeshBuilders directly into Node 27 (`Spellblade_Armor_And_Body`)!
    # Because `METabardFront` and `METabardBack` are now genuine 3D sculpted pleated cloth + 3D stepped gold trim
    # + 3D raised Golden Spear-Trident emblem, they compile with crisp 3D normals and baked `COLOR_0` shading!
    body_builders = [
        (replacements_tp["MEHelmetShellCanonical"], 5),
        (replacements_tp["MEHelmetJawCanonical"],   5),
        (replacements_tp["MEVisorCanonical"],       5),
        (replacements_tp["MECrestCanonical"],       5),
        (replacements_tp["MEPauldron.L"],           6),
        (replacements_tp["MEPauldron.R"],           11),
        (replacements_tp["MEBreastplate"],          3),
        (build_v28_arm_only_without_left_hand(),    7),
        (replacements_tp["MEGauntlet.R.001"],       12),
        (replacements_tp["MEGreave.L"],             21),
        (replacements_tp["MEGreave.R"],             24),
        (replacements_tp["MEBoot.L"],               23),
        (replacements_tp["MEBoot.R"],               26),
    ]
    P_b, N_b, VC_b, UV_b, J_b, W_b, T_b = [], [], [], [], [], [], []
    v_off = 0
    for mb_i, def_j in body_builders:
        vp, vn, vc, uv, j0, w0, tri = compile_meshbuilder_to_gltf_arrays(mb_i, default_joint_idx=def_j)
        P_b.append(vp); N_b.append(vn); VC_b.append(vc); UV_b.append(uv); J_b.append(j0); W_b.append(w0)
        T_b.append(tri + v_off)
        v_off += len(vp)

    tvp, tvn, tvc, tuv, tj0, tw0, ttri = extract_tabards_centroid_subdivided(uncomp_blend_path)
    P_b.append(tvp); N_b.append(tvn); VC_b.append(tvc); UV_b.append(tuv); J_b.append(tj0); W_b.append(tw0)
    T_b.append(ttri + v_off)
    v_off += len(tvp)

    mb_hand_l_closed = b28.build_v28_left_hand_only(closed_grip=True)
    mb_hand_l_closed.bake_loop_shading()
    hc_vp, hc_vn, hc_vc, hc_uv, hc_j0, hc_w0, hc_tri = compile_meshbuilder_to_gltf_arrays(mb_hand_l_closed, default_joint_idx=9)

    mb_hand_l_open = b28.build_v28_left_hand_only(closed_grip=False)
    mb_hand_l_open.bake_loop_shading()
    ho_vp, ho_vn, ho_vc, ho_uv, ho_j0, ho_w0, ho_tri = compile_meshbuilder_to_gltf_arrays(mb_hand_l_open, default_joint_idx=9)

    sw_vp, sw_vn, sw_vc, sw_uv, sw_j0, sw_w0, sw_tri = compile_meshbuilder_to_gltf_arrays(replacements_tp["MEHeroSword"], default_joint_idx=15)

    bin_chunks = bytearray()
    buffer_views, accessors = [], []

    def add_bv(raw_bytes: bytes, target=None):
        pad = (4 - (len(bin_chunks) % 4)) % 4
        if pad:
            bin_chunks.extend(b"\x00" * pad)
        off = len(bin_chunks)
        bin_chunks.extend(raw_bytes)
        bv = {"buffer": 0, "byteOffset": off, "byteLength": len(raw_bytes)}
        if target is not None:
            bv["target"] = target
        idx = len(buffer_views)
        buffer_views.append(bv)
        return idx

    def add_acc(bv_idx, comp_type, count, acc_type, mins=None, maxs=None):
        acc = {"bufferView": bv_idx, "componentType": comp_type, "count": count, "type": acc_type}
        if mins is not None:
            acc["min"] = mins
        if maxs is not None:
            acc["max"] = maxs
        idx = len(accessors)
        accessors.append(acc)
        return idx

    def pack_prim(vp, vn, vc, uv, j0, w0, tris, mat_idx=0):
        idx_flat = tris.ravel().astype(np.uint32)
        bv_p = add_bv(vp.tobytes(), 34962)
        bv_n = add_bv(vn.tobytes(), 34962)
        bv_c = add_bv(vc.tobytes(), 34962)
        bv_j = add_bv(j0.tobytes(), 34962)
        bv_w = add_bv(w0.tobytes(), 34962)
        bv_i = add_bv(idx_flat.tobytes(), 34963)

        acc_p = add_acc(bv_p, 5126, len(vp), "VEC3", [float(x) for x in vp.min(axis=0)], [float(x) for x in vp.max(axis=0)])
        acc_n = add_acc(bv_n, 5126, len(vn), "VEC3")
        acc_c = add_acc(bv_c, 5126, len(vc), "VEC4")
        acc_j = add_acc(bv_j, 5123, len(j0), "VEC4")
        acc_w = add_acc(bv_w, 5126, len(w0), "VEC4")
        acc_i = add_acc(bv_i, 5125, len(idx_flat), "SCALAR", [int(idx_flat.min())], [int(idx_flat.max())])

        return {
            "attributes": {
                "POSITION":  acc_p,
                "NORMAL":    acc_n,
                "COLOR_0":   acc_c,
                "JOINTS_0":  acc_j,
                "WEIGHTS_0": acc_w,
            },
            "indices": acc_i,
            "material": mat_idx,
            "mode": 4,
        }

    ibms_col = np.transpose(IBMS.astype(np.float32), (0, 2, 1)).copy()
    bv_ibm = add_bv(ibms_col.tobytes())
    acc_ibm = add_acc(bv_ibm, 5126, 27, "MAT4")

    body_vp  = np.vstack(P_b).astype(np.float32)
    body_vn  = np.vstack(N_b).astype(np.float32)
    body_vc  = np.vstack(VC_b).astype(np.float32)
    body_uv  = np.vstack(UV_b).astype(np.float32)
    body_j0  = np.vstack(J_b).astype(np.uint16)
    body_w0  = np.vstack(W_b).astype(np.float32)
    body_tri = np.vstack(T_b).astype(np.uint32)

    gltf_meshes = [
        {
            "name": "Spellblade_Armor_And_Body_Mesh",
            "primitives": [
                pack_prim(body_vp, body_vn, body_vc, body_uv, body_j0, body_w0, body_tri, mat_idx=0),
            ],
        },
        {
            "name": "Spellblade_Hand_L_Closed_Grip_Mesh",
            "primitives": [
                pack_prim(hc_vp, hc_vn, hc_vc, hc_uv, hc_j0, hc_w0, hc_tri, mat_idx=0),
            ],
        },
        {
            "name": "Spellblade_Hand_L_Open_Sorcery_And_Rune_Mesh",
            "primitives": [
                pack_prim(ho_vp, ho_vn, ho_vc, ho_uv, ho_j0, ho_w0, ho_tri, mat_idx=0),
            ],
        },
        {
            "name": "Spellblade_Hero_Broadsword_Mesh",
            "primitives": [
                pack_prim(sw_vp, sw_vn, sw_vc, sw_uv, sw_j0, sw_w0, sw_tri, mat_idx=0),
            ],
        },
    ]

    tot_verts = len(body_vp) + len(hc_vp) + len(ho_vp) + len(sw_vp)
    tot_tris  = len(body_tri) + len(hc_tri) + len(ho_tri) + len(sw_tri)

    gltf_nodes = []
    for idx in range(27):
        nd = dict(j_nodes[idx])
        if not nd["children"]:
            del nd["children"]
        gltf_nodes.append(nd)

    mesh_node_specs = [
        ("Spellblade_Armor_And_Body",              0, [1.0, 1.0, 1.0]),
        ("Spellblade_Hand_L_Closed_Grip",          1, [1.0, 1.0, 1.0]),
        ("Spellblade_Hand_L_Open_Sorcery_And_Rune",2, [0.0, 0.0, 0.0]),
        ("Spellblade_Hero_Broadsword",             3, [1.0, 1.0, 1.0]),
    ]
    for m_name, m_idx, def_sc in mesh_node_specs:
        gltf_nodes.append({
            "name": m_name,
            "mesh": m_idx,
            "skin": 0,
            "translation": [0.0, 0.0, 0.0],
            "rotation": [0.0, 0.0, 0.0, 1.0],
            "scale": def_sc,
        })

    gltf_nodes.append({
        "name": "SpellbladeRig",
        "children": [0, 27, 28, 29, 30],
        "translation": [0.0, 0.0, 0.0],
        "rotation": [0.0, 0.0, 0.0, 1.0],
        "scale": [1.0, 1.0, 1.0],
    })

    gltf_anims = []
    for anim in anims:
        t_arr = np.array(anim["times"], dtype=np.float32)
        bv_t = add_bv(t_arr.tobytes())
        acc_t = add_acc(bv_t, 5126, len(t_arr), "SCALAR", [float(t_arr.min())], [float(t_arr.max())])
        samplers, channels = [], []
        for target_node, trk in anim["tracks"].items():
            for path_name, vals in trk.items():
                v_arr = np.array(vals, dtype=np.float32)
                bv_v = add_bv(v_arr.tobytes())
                acc_type = "VEC4" if path_name == "rotation" else "VEC3"
                acc_v = add_acc(bv_v, 5126, len(v_arr), acc_type)
                s_idx = len(samplers)
                samplers.append({"input": acc_t, "interpolation": "LINEAR", "output": acc_v})
                channels.append({"sampler": s_idx, "target": {"node": int(target_node), "path": path_name}})
        gltf_anims.append({"name": anim["name"], "samplers": samplers, "channels": channels})

    gltf_json = {
        "asset": {
            "version": "2.0",
            "generator": "Castleward Spellblade v2.8 Fidelity Production GLB Pipeline",
        },
        "scene": 0,
        "scenes": [{"name": "Spellblade_v28_Fidelity_Scene", "nodes": [31]}],
        "nodes": gltf_nodes,
        "skins": [{
            "name": "SpellbladeRig",
            "skeleton": 0,
            "joints": list(range(27)),
            "inverseBindMatrices": acc_ibm,
        }],
        "meshes": gltf_meshes,
        "materials": [
            {
                "name": "Castleward_Spellblade_v28_Armor_PBR",
                "doubleSided": True,
                "pbrMetallicRoughness": {"metallicFactor": 0.45, "roughnessFactor": 0.46},
            },
        ],
        "accessors": accessors,
        "bufferViews": buffer_views,
        "buffers": [{"byteLength": len(bin_chunks)}],
        "animations": gltf_anims,
        "extras": {
            "assetId": "spellblade-v28-fidelity-production",
            "version": "2.8.0",
            "skeletonJointCount": 27,
            "skinnedMeshNodes": {
                "27": "Spellblade_Armor_And_Body (scowling V-brow box-helm, cyan L-visor, 4-block plume, 3-tier pauldrons, keeled V-chevron breastplate, 2-fold scarf, belt, arms, right gauntlet, 3D sculpted pleated Spear-Trident tabards, dark-charcoal thighs, leather tassets, tall knee poleyns, solid front-keeled greaves, trapezoidal sabatons)",
                "28": "Spellblade_Hand_L_Closed_Grip (default scale [1,1,1] for weapon & machine grips)",
                "29": "Spellblade_Hand_L_Open_Sorcery_And_Rune (switch to [1,1,1] and Node 28 to [0,0,0] for cupped open-palm spellcasting & 13-cube cyan arcane cluster)",
                "30": "Spellblade_Hero_Broadsword (chiseled knightly broadsword bound to socket_sword [15])",
            },
            "trueStatureHeightMeters": 1.800,
        },
    }

    j_bytes = json.dumps(gltf_json, separators=(",", ":")).encode("utf-8")
    j_pad = (4 - (len(j_bytes) % 4)) % 4
    if j_pad:
        j_bytes += b" " * j_pad
    b_pad = (4 - (len(bin_chunks) % 4)) % 4
    if b_pad:
        bin_chunks.extend(b"\x00" * b_pad)

    total_len = 12 + 8 + len(j_bytes) + 8 + len(bin_chunks)
    glb_out = bytearray()
    glb_out.extend(struct.pack("<4sII", b"glTF", 2, total_len))
    glb_out.extend(struct.pack("<I4s", len(j_bytes), b"JSON"))
    glb_out.extend(j_bytes)
    glb_out.extend(struct.pack("<I4s", len(bin_chunks), b"BIN\x00"))
    glb_out.extend(bin_chunks)

    out_glb_path.write_bytes(glb_out)
    sha = hashlib.sha256(glb_out).hexdigest()
    print(f"[OK] Exported {out_glb_path.name}: {len(glb_out):,} bytes ({len(glb_out)/1048576:.2f} MB), {len(gltf_nodes)} nodes, {len(gltf_meshes)} skinned meshes, 1 skin (27 joints), {tot_verts:,} verts, {tot_tris:,} tris, {len(gltf_anims)} clips, SHA256={sha}")

    ev = StandardGltfEvaluator(out_glb_path)
    trs_rest = ev.sample_animation(None, 0.0)
    w_rest = ev.compute_world_matrices(*trs_rest)
    max_ibm_err = 0.0
    for j in range(27):
        err = float(np.max(np.abs((w_rest[j] @ ev.skins[0]["ibms"][j]) - np.eye(4))))
        max_ibm_err = max(max_ibm_err, err)
    print(f"[VERIFY] StandardGltfEvaluator rest bind identity error: {max_ibm_err:.6f} (must be 0.000000)")
    assert max_ibm_err < 1e-4

    return sha, (body_vp, body_vn, body_vc, body_tri, hc_vp, hc_vn, hc_vc, hc_tri, sw_vp, sw_vn, sw_vc, sw_tri)


def export_combined_faf_v27_with_spellblade_v28(sb_arrays, out_glb_path: Path):
    from render_faf_v27_evidence import build_scene_v27
    P_faf, N_faf, T_faf, VC_faf, VM_faf, VE_faf = build_scene_v27(include_spellblade=False, include_floor_pedestal=False)
    rgba_faf = np.column_stack([np.clip(VC_faf, 0.0, 1.0), np.ones(len(P_faf), dtype=np.float32)]).astype(np.float32)

    body_vp, body_vn, body_vc, body_tri, hc_vp, hc_vn, hc_vc, hc_tri, sw_vp, sw_vn, sw_vc, sw_tri = sb_arrays

    P_all, N_all, C_all, T_all = [P_faf], [N_faf], [rgba_faf], [T_faf.astype(np.uint32)]
    v_off = len(P_faf)
    for vp_i, vn_i, vc_i, tri_i in [
        (body_vp, body_vn, body_vc, body_tri),
        (hc_vp,   hc_vn,   hc_vc,   hc_tri),
        (sw_vp,   sw_vn,   sw_vc,   sw_tri),
    ]:
        P_all.append(vp_i)
        N_all.append(vn_i)
        C_all.append(vc_i)
        T_all.append(tri_i.astype(np.uint32) + v_off)
        v_off += len(vp_i)

    P = np.vstack(P_all).astype(np.float32)
    N = np.vstack(N_all).astype(np.float32)
    C = np.vstack(C_all).astype(np.float32)
    T = np.vstack(T_all).astype(np.uint32)
    idx_flat = T.ravel()

    bin_chunks = bytearray()
    buffer_views, accessors = [], []

    def add_bv(raw_bytes: bytes, target=None):
        pad = (4 - (len(bin_chunks) % 4)) % 4
        if pad:
            bin_chunks.extend(b"\x00" * pad)
        off = len(bin_chunks)
        bin_chunks.extend(raw_bytes)
        bv = {"buffer": 0, "byteOffset": off, "byteLength": len(raw_bytes)}
        if target is not None:
            bv["target"] = target
        idx = len(buffer_views)
        buffer_views.append(bv)
        return idx

    def add_acc(bv_idx, comp_type, count, acc_type, mins=None, maxs=None):
        acc = {"bufferView": bv_idx, "componentType": comp_type, "count": count, "type": acc_type}
        if mins is not None:
            acc["min"] = mins
        if maxs is not None:
            acc["max"] = maxs
        idx = len(accessors)
        accessors.append(acc)
        return idx

    bv_p = add_bv(P.tobytes(), 34962)
    bv_n = add_bv(N.tobytes(), 34962)
    bv_c = add_bv(C.tobytes(), 34962)
    bv_i = add_bv(idx_flat.tobytes(), 34963)

    acc_p = add_acc(bv_p, 5126, len(P), "VEC3", [float(x) for x in P.min(axis=0)], [float(x) for x in P.max(axis=0)])
    acc_n = add_acc(bv_n, 5126, len(N), "VEC3")
    acc_c = add_acc(bv_c, 5126, len(C), "VEC4")
    acc_i = add_acc(bv_i, 5125, len(idx_flat), "SCALAR", [int(idx_flat.min())], [int(idx_flat.max())])

    g_json = {
        "asset": {"version": "2.0", "generator": "Castleward Fight-and-Flight v2.7 + Spellblade v2.8 Combined Reference GLB"},
        "scene": 0,
        "scenes": [{"name": "FightAndFlight_v27_With_Spellblade_v28", "nodes": [0]}],
        "nodes": [{"name": "FightAndFlight_v27_And_Spellblade_v28_Assembly", "mesh": 0}],
        "meshes": [{
            "name": "FightAndFlight_v27_And_Spellblade_v28_Mesh",
            "primitives": [{
                "attributes": {"POSITION": acc_p, "NORMAL": acc_n, "COLOR_0": acc_c},
                "indices": acc_i,
                "material": 0,
                "mode": 4,
            }]
        }],
        "materials": [{
            "name": "Castleward_Combined_v28_PBR",
            "doubleSided": True,
            "pbrMetallicRoughness": {"metallicFactor": 0.38, "roughnessFactor": 0.52},
        }],
        "accessors": accessors,
        "bufferViews": buffer_views,
        "buffers": [{"byteLength": len(bin_chunks)}],
    }

    j_bytes = json.dumps(g_json, separators=(",", ":")).encode("utf-8")
    j_pad = (4 - (len(j_bytes) % 4)) % 4
    if j_pad:
        j_bytes += b" " * j_pad
    b_pad = (4 - (len(bin_chunks) % 4)) % 4
    if b_pad:
        bin_chunks.extend(b"\x00" * b_pad)

    total_len = 12 + 8 + len(j_bytes) + 8 + len(bin_chunks)
    glb_out = bytearray()
    glb_out.extend(struct.pack("<4sII", b"glTF", 2, total_len))
    glb_out.extend(struct.pack("<I4s", len(j_bytes), b"JSON"))
    glb_out.extend(j_bytes)
    glb_out.extend(struct.pack("<I4s", len(bin_chunks), b"BIN\x00"))
    glb_out.extend(bin_chunks)
    out_glb_path.write_bytes(glb_out)
    sha = hashlib.sha256(glb_out).hexdigest()
    print(f"[OK] Exported {out_glb_path.name}: {len(glb_out):,} bytes ({len(glb_out)/1048576:.2f} MB), {len(P):,} verts, {len(T):,} tris, SHA256={sha}")
    return sha


if __name__ == "__main__":
    uncomp_tp, replacements_tp = build_and_save_v28_blend_files()
    out_glb = OUT_DIR / "spellblade-v28-fidelity-production.glb"
    sha_glb, sb_arrays = export_spellblade_v28_glb(uncomp_tp, replacements_tp, out_glb)
    comb_glb = OUT_DIR / "fight-and-flight-v27-with-spellblade-v28-reference.glb"
    export_combined_faf_v27_with_spellblade_v28(sb_arrays, comb_glb)
