#!/usr/bin/env python3
"""
Castleward — Spellblade v3.1 In-Game Review Candidate & Fight-and-Flight 19.5° Sim-Trim Builder
===============================================================================================
Preserves all previous candidates (`spellblade-v28-*`, `spellblade-v29-*`, `spellblade-v30-*`,
`fight-and-flight-v28-*`, `fight-and-flight-v29-*`) untouched for comparison and rollback.

Builds:
  1. `spellblade-v31-ingame-review-candidate.glb` & `spellblade-v31-ingame-review-candidate.blend`
     Retains the `v3.0` overlapping-armor foundation and resolves the 5 specific visual & rigging
     issues identified in the `Concept vs. v3.0` inspection:
       - Helmet Silhouette (`2A`): Fixes the pre/post-transform coordinate mismatch that caused
         floating brow/cheek plates in `v3.0`; integrates a 2-tier stepped V-brow overhang,
         compound-curved 12-around crown with sagittal keel, chiseled zygomatic/mandible cheek
         guards with chin-bevor rim, stepped T-bridge champagne-brass nasal bar, and a taller,
         fuller 7-section Spartan crimson plume crest seated in a brass comb channel.
       - Pauldron Construction (`2B` vs `shoulder.png`): Eliminates the interior-bridging diagonal
         plank (`rm0..rm2` / `dl0..dl2`) that jutted across the bottom of the pauldron in `v3.0`;
         sculpts true open C-arch 3-tier overlapping shoulder plates (`Tier 1` main cop with wide
         champagne-brass perimeter border & flush front-corner pyramid stud + `Tier 2` & `Tier 3`
         nested open C-arch deltoid lames with recessed shadow steps & brass lower rims) over
         coaxial cylindrical steel/brass-cuffed upper-arm rerebraces.
       - Cuirass Curvature (`2C` vs `tabard.png`): Eliminates the split flat plackart patch and
         protruding rib boxes from `v3.0`; sculpts a unified, convex compound-curved V-keeled
         Gothic cuirass (`pr0..pr5`) with an integrated Milanese plackart overlap step, continuous
         14 mm champagne-brass V-border, 2-tier gorget, and 3 coaxially curved rib/waist fauld lames.
       - Armor Material Response: Calibrates `MA_Spellblade_Forged_Steel` (`M=0.54, R=0.34`) to
         cool-slate forged steel (`B > G > R`, `[0.46, 0.50, 0.57]` on lit planes, `[0.66, 0.70, 0.78]`
         on bevels) and `MA_Spellblade_Champagne_Brass` (`M=0.74, R=0.25`, warm champagne gold
         `[0.85, 0.70, 0.44]`), eliminating the dark brownish-charcoal metallic soot look while
         preserving the 6 distinct glTF 2.0 PBR materials.
       - Rig Articulation: All limb rings, straps, couters, poleyns, and 3-tier hip tassets use
         coaxial `BoneFrame` geometry and blended pelvis/thigh/limb weights for clean deformation
         during Sword Slash, High Guard, Sprinting, and Mounted Fight-and-Flight poses.

  2. `fight-and-flight-v30-sim19p5-dash.glb` & `fight-and-flight-v30-sim19p5-dash.blend`
     Aligns the animation contract and standalone preview clips (`Clips 19, 47, 48`) with the
     authoritative Castleward simulation's `~19.5°` offensive Dash trim before steering (replacing
     the unconditional `24°` chassis + `14°` shaft tilt assumption), while keeping the narrowed
     production Dash clips (`Clips 49..53`, `24` and `12` channels) 100% free of `Node 1` and
     `Node 8/9` tracks so runtime simulation remains strictly authoritative.
"""
import os, sys, io, json, math, struct, hashlib
from pathlib import Path
import numpy as np

ROOT = Path("/working_dir/c_63a1f8c151a6582d")
OUT_DIR = ROOT / "artifacts/file_generation/ttl=63d/output"
WORK_DIR = Path("/tmp/faf_work")
C_PREV_INTER = Path("/working_dir/c_bc1ba559921be6b9/artifacts/file_generation/ttl=63d/intermediate")
C_PREV_WORK  = Path("/working_dir/c_bc1ba559921be6b9/work")

sys.path.insert(0, str(C_PREV_INTER))
sys.path.insert(0, str(WORK_DIR))
sys.path.insert(0, str(OUT_DIR))
sys.path.insert(0, "/tmp/sofist_v2_1")

from blend_io import BlendFile
from mesh_builder import MeshBuilder, BoneFrame, PALETTE
import reconstruct_spellblade as rs_prev
import build_spellblade_v28_fidelity as b28
import update_v28_sculpt as u28
import export_spellblade_v28_production as exp28
import build_spellblade_v29_artistic as b29
from export_fight_and_flight_v25 import zstd_compress_blend
from gltf_standard_evaluator import StandardGltfEvaluator


# ==============================================================================
# PART 1: SPELLBLADE v3.1 FOCUSED ARTISTIC & RIGGING REFINEMENT ON v3.0 BASELINE
# ==============================================================================

def build_v31_helmet_parts():
    """
    1. Cohesive Helmet Silhouette (`CANONICAL_HELMET_FOCUS_KEEP.png`):
       - All geometry is authored in canonical pre-transform head space BEFORE calling
         `transform_helmet_v29` ONCE at the end (fixing the floating brow/cheek plates from v3.0).
       - 2-tier stepped V-brow overhang (`r1_brow_low -> r2_brow_step -> r3_brow_upper`) shading
         the scowling cyan L-visor slits, rising to a compound-curved 12-around dome with a
         central sagittal ridge.
       - Integrated T-bridge champagne-brass nasal bar (`hx = 0.016`) + crown crest-comb channel.
       - Inward-tapering chiseled cheek guards with zygomatic facet ridge, recessed pre-auricular
         mandible step, framed ear-guards, and lower chin-bevor rim.
       - Taller, fuller 7-section Spartan crimson plume crest (`z_peak = 2.142`) with vertical
         fluting and bright crimson top/front bevels.
    """
    w = "head"
    mb_shell = MeshBuilder(["MAKitMetal", "MAKitMatte"])

    def helm_ring_10(rx_mid, yf_c, yf_mid, rx_front, yf_corner, rx_side, yb_side, rx_back, yb_back, yb_c, z_c, z_mid, z_corner, z_side, z_back):
        return [
            ( 0.000,      yf_c,      z_c),      # 0: Front center V-brow keel
            (-rx_mid,     yf_mid,    z_mid),    # 1: Left mid-brow
            (-rx_front,   yf_corner, z_corner), # 2: Left front-outer temple corner
            (-rx_side,    yb_side,   z_side),   # 3: Left rear-side temple
            (-rx_back,    yb_back,   z_back),   # 4: Left back corner
            ( 0.000,      yb_c,      z_back),   # 5: Back center keel
            ( rx_back,    yb_back,   z_back),   # 6: Right back corner
            ( rx_side,    yb_side,   z_side),   # 7: Right rear-side temple
            ( rx_front,   yf_corner, z_corner), # 8: Right front-outer temple corner
            ( rx_mid,     yf_mid,    z_mid),    # 9: Right mid-brow
        ]

    # 2-tier stepped brow + compound-curved crown loft (watertight, zero floating patches!)
    r0_under    = helm_ring_10(0.052, 0.236, 0.224, 0.100, 0.200, 0.122, 0.018, 0.102, -0.078, -0.114, 1.868, 1.886, 1.902, 1.896, 1.882)
    r1_brow_lo  = helm_ring_10(0.055, 0.250, 0.236, 0.105, 0.210, 0.126, 0.018, 0.106, -0.080, -0.118, 1.872, 1.890, 1.908, 1.902, 1.888)
    r2_brow_top = helm_ring_10(0.054, 0.246, 0.232, 0.104, 0.206, 0.125, 0.017, 0.105, -0.079, -0.117, 1.918, 1.930, 1.942, 1.936, 1.922)
    r3_step_in  = helm_ring_10(0.051, 0.238, 0.225, 0.099, 0.199, 0.120, 0.016, 0.101, -0.076, -0.113, 1.922, 1.934, 1.945, 1.939, 1.925)
    r4_ridge    = helm_ring_10(0.049, 0.232, 0.219, 0.096, 0.194, 0.118, 0.015, 0.099, -0.074, -0.110, 1.956, 1.964, 1.970, 1.964, 1.950)
    r5_chamfer  = helm_ring_10(0.042, 0.212, 0.198, 0.084, 0.176, 0.104, 0.012, 0.088, -0.066, -0.100, 1.984, 1.988, 1.990, 1.984, 1.970)
    r6_crown    = helm_ring_10(0.026, 0.176, 0.164, 0.054, 0.144, 0.068, 0.008, 0.058, -0.048, -0.082, 2.018, 2.016, 2.012, 2.006, 1.994)

    c_under = ["FACE_DARK"] * 10
    c_b_lo  = ["STEEL_LIGHT", "STEEL_MAIN",  "STEEL_FACET", "STEEL_DARK",  "STEEL_DARK",  "STEEL_DARK",  "STEEL_FACET", "STEEL_MAIN",  "STEEL_LIGHT", "STEEL_BRIGHT"]
    c_step  = ["STEEL_DARK",  "FACE_DARK",   "FACE_DARK",   "STEEL_DARK",  "STEEL_DARK",  "STEEL_DARK",  "FACE_DARK",   "FACE_DARK",   "STEEL_DARK",  "STEEL_SHADE"]
    c_b_hi  = ["STEEL_BRIGHT","STEEL_LIGHT", "STEEL_MAIN",  "STEEL_FACET", "STEEL_DARK",  "STEEL_DARK",  "STEEL_FACET", "STEEL_MAIN",  "STEEL_BRIGHT","STEEL_BRIGHT"]
    c_chamf = ["STEEL_BRIGHT","STEEL_LIGHT", "STEEL_FACET", "STEEL_MAIN",  "STEEL_FACET", "STEEL_FACET", "STEEL_MAIN",  "STEEL_LIGHT", "STEEL_BRIGHT","STEEL_BRIGHT"]
    c_crown = ["STEEL_LIGHT", "STEEL_MAIN",  "STEEL_FACET", "STEEL_DARK",  "STEEL_DARK",  "STEEL_DARK",  "STEEL_FACET", "STEEL_MAIN",  "STEEL_LIGHT", "STEEL_LIGHT"]

    mb_shell.add_loft(
        [r0_under, r1_brow_lo, r2_brow_top, r3_step_in, r4_ridge, r5_chamfer, r6_crown],
        weights=w, mat="METAL",
        colors=[c_under, c_b_lo, c_step, c_b_hi, c_chamf, c_crown],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_LIGHT",
    )

    # Integrated Champagne-Brass Nasal Bar & Crown Comb Channel (`hx = 0.0165`)
    def nasal_ring(hx_out, hx_in, yf_face, yf_base, z_face, z_base):
        return [
            ( 0.000,   yf_face + 0.003, z_face),
            (-hx_in,   yf_face,         z_face),
            (-hx_out,  yf_base,         z_base),
            ( 0.000,   yf_base,         z_base),
            ( hx_out,  yf_base,         z_base),
            ( hx_in,   yf_face,         z_face),
        ]

    nb0 = nasal_ring(0.002, 0.001, 0.250, 0.232, 1.840, 1.844) # Sharp diamond spear-tip between eyes
    nb1 = nasal_ring(0.017, 0.013, 0.255, 0.236, 1.874, 1.874) # Lower V-brow bridge
    nb2 = nasal_ring(0.022, 0.017, 0.251, 0.232, 1.920, 1.918) # Stepped T-bridge boss at brow step
    nb3 = nasal_ring(0.016, 0.012, 0.238, 0.220, 1.958, 1.956) # Upper forehead spine
    nb4 = nasal_ring(0.020, 0.016, 0.184, 0.172, 2.022, 2.012) # Crown comb prow
    nb5 = nasal_ring(0.019, 0.015, -0.095, -0.095, 1.948, 1.936) # Rear crest rail tail

    n_cols_main = ["BRASS_BRIGHT", "BRASS_MAIN", "BRASS_SHADE", "BRASS_DARK", "BRASS_MAIN", "BRASS_BRIGHT"]
    n_cols_top  = ["BRASS_BRIGHT", "BRASS_EDGE", "BRASS_SHADE", "BRASS_DARK", "BRASS_EDGE", "BRASS_BRIGHT"]
    mb_shell.add_loft(
        [nb0, nb1, nb2, nb3, nb4, nb5],
        weights=w, mat="METAL",
        colors=[n_cols_main, n_cols_top, n_cols_main, n_cols_top, n_cols_top],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT"
    )

    # Flush-seated Framed Side Ear-Guards (`CANONICAL_HELMET_FOCUS_KEEP.png`)
    for sign in (-1.0, 1.0):
        x_eb = sign * 0.118
        if sign > 0:
            eb_corners = [
                (x_eb - 0.004, 0.096, 1.882),
                (x_eb + 0.002, 0.016, 1.878),
                (x_eb - 0.004, 0.020, 1.768),
                (x_eb - 0.010, 0.098, 1.764),
            ]
        else:
            eb_corners = [
                (x_eb - 0.002, 0.016, 1.878),
                (x_eb + 0.004, 0.096, 1.882),
                (x_eb + 0.010, 0.098, 1.764),
                (x_eb + 0.004, 0.020, 1.768),
            ]
        rs_prev.add_framed_rect_plate(
            mb_shell, eb_corners, normal_dir=(sign * 0.96, 0.18, -0.08),
            thickness=0.012, border_frac=0.30, weights=w,
            mat_border="METAL", col_border="STEEL_LIGHT" if sign > 0 else "STEEL_MAIN", col_border_edge="STEEL_BRIGHT",
            mat_inner="MATTE", col_inner="FACE_DARK", open_top=False
        )

    # 2. MEHelmetJawCanonical: Integrated Zygomatic Cheek Ridge, Mandible Taper & Chin-Bevor Rim
    mb_jaw = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    def cav_ring(z):
        return [
            ( 0.000,  0.194, z),
            (-0.028,  0.192, z),
            (-0.088,  0.168, z),
            (-0.096,  0.112, z),
            ( 0.000, -0.062, z),
            ( 0.096,  0.112, z),
            ( 0.088,  0.168, z),
            ( 0.028,  0.192, z),
        ]
    mb_jaw.add_loft([cav_ring(1.720), cav_ring(1.928)], weights=w, mat="MATTE", colors="FACE_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    mb_jaw.add_beveled_box(
        center=(0.000, 0.204, 1.792),
        half_extents=(0.0055, 0.007, 0.058),
        bevel=0.18, weights=w, mat="METAL",
        col_main="STEEL_DARK", col_edge="STEEL_FACET", col_dark="FACE_DARK",
    )

    def jaw_shell_ring(x_in, yf_in, x_step, yf_step, x_cheek, yf_cheek, x_temp, yf_temp, rx_side, yb_side, rx_back, yb_back, yb_c, z_in, z_cheek, z_temp, z_side, z_back):
        return [
            (-x_in,     yf_in,    z_in),
            (-x_step,   yf_step,  z_in),
            (-x_cheek,  yf_cheek, z_cheek),
            (-x_temp,   yf_temp,  z_temp),
            (-rx_side,  yb_side,  z_side),
            (-rx_back,  yb_back,  z_back),
            ( 0.000,    yb_c,     z_back),
            ( rx_back,  yb_back,  z_back),
            ( rx_side,  yb_side,  z_side),
            ( x_temp,   yf_temp,  z_temp),
            ( x_cheek,  yf_cheek, z_cheek),
            ( x_step,   yf_step,  z_in),
            ( x_in,     yf_in,    z_in),
        ]

    # Integrated 6-row loft with lower chin-bevor rim (`j_under -> j_bevor_hi -> j_bevor_in`) and cheekbone prominence (`j_zyg`)
    j_under    = jaw_shell_ring(0.025, 0.208, 0.038, 0.224, 0.070, 0.206, 0.075, 0.198, 0.098, 0.018, 0.090, -0.072, -0.108, 1.722, 1.734, 1.738, 1.748, 1.742)
    j_bevor_hi = jaw_shell_ring(0.027, 0.214, 0.041, 0.230, 0.076, 0.212, 0.080, 0.204, 0.103, 0.018, 0.094, -0.074, -0.110, 1.750, 1.762, 1.766, 1.774, 1.768)
    j_bevor_in = jaw_shell_ring(0.027, 0.210, 0.040, 0.226, 0.075, 0.208, 0.079, 0.200, 0.102, 0.018, 0.094, -0.074, -0.110, 1.754, 1.766, 1.770, 1.778, 1.772)
    j_zyg      = jaw_shell_ring(0.029, 0.212, 0.044, 0.228, 0.088, 0.214, 0.092, 0.204, 0.114, 0.018, 0.100, -0.076, -0.112, 1.812, 1.826, 1.842, 1.844, 1.834)
    j_top      = jaw_shell_ring(0.031, 0.206, 0.046, 0.222, 0.094, 0.208, 0.098, 0.200, 0.120, 0.018, 0.104, -0.078, -0.114, 1.846, 1.864, 1.900, 1.898, 1.886)
    j_sill     = jaw_shell_ring(0.031, 0.194, 0.044, 0.198, 0.090, 0.190, 0.094, 0.188, 0.114, 0.018, 0.098, -0.074, -0.110, 1.850, 1.868, 1.902, 1.900, 1.888)

    jaw_bevor_cols = ["STEEL_DARK", "STEEL_BRIGHT", "STEEL_LIGHT", "STEEL_DARK", "STEEL_FACET", "STEEL_DARK", "STEEL_DARK", "STEEL_FACET", "STEEL_DARK", "STEEL_LIGHT",  "STEEL_BRIGHT", "STEEL_DARK"]
    jaw_step_cols  = ["FACE_DARK",  "STEEL_DARK",   "STEEL_SHADE", "FACE_DARK",  "STEEL_DARK",  "FACE_DARK",  "FACE_DARK",  "STEEL_DARK",  "FACE_DARK",  "STEEL_SHADE",  "STEEL_DARK",   "FACE_DARK"]
    jaw_mid_cols   = ["STEEL_DARK", "STEEL_LIGHT",  "STEEL_MAIN",  "STEEL_DARK", "STEEL_FACET", "STEEL_DARK", "STEEL_DARK", "STEEL_FACET", "STEEL_DARK", "STEEL_MAIN",   "STEEL_LIGHT",  "STEEL_DARK"]
    jaw_high_cols  = ["STEEL_DARK", "STEEL_BRIGHT", "STEEL_LIGHT", "STEEL_DARK", "STEEL_FACET", "STEEL_DARK", "STEEL_DARK", "STEEL_FACET", "STEEL_DARK", "STEEL_LIGHT",  "STEEL_BRIGHT", "STEEL_DARK"]
    jaw_sill_cols  = ["FACE_DARK",  "STEEL_BRIGHT", "STEEL_EDGE",  "FACE_DARK",  "STEEL_SHADE", "FACE_DARK",  "FACE_DARK",  "STEEL_SHADE", "FACE_DARK",  "STEEL_EDGE",   "STEEL_BRIGHT", "FACE_DARK"]

    mb_jaw.add_loft(
        [j_under, j_bevor_hi, j_bevor_in, j_zyg, j_top, j_sill],
        weights=w, mat="METAL",
        colors=[jaw_bevor_cols, jaw_step_cols, jaw_mid_cols, jaw_high_cols, jaw_sill_cols],
        closed_ring=False,
    )

    # 3. MEVisorCanonical: Crisp Cyan L-Visor Bars (`MAVisorGlow`)
    mb_visor = MeshBuilder(["MAVisorGlow"])
    for sign in (-1.0, 1.0):
        eye_pts = [
            (sign * 0.0165, 0.224, 1.880),
            (sign * 0.0880, 0.208, 1.895),
            (sign * 0.0860, 0.208, 1.875),
            (sign * 0.0165, 0.224, 1.861),
        ]
        mb_visor.add_flat_beveled_plate(
            eye_pts, normal_dir=(sign * 0.18, 0.98, 0.0), thickness=0.007, bevel_inset=0.14, weights=w,
            mat="VISOR", col_face="WHITE", col_edge="WHITE", col_side="WHITE", col_back="WHITE"
        )
        vert_pts = [
            (sign * 0.0165, 0.224, 1.866),
            (sign * 0.0295, 0.220, 1.868),
            (sign * 0.0260, 0.212, 1.738),
            (sign * 0.0155, 0.215, 1.736),
        ]
        mb_visor.add_flat_beveled_plate(
            vert_pts, normal_dir=(sign * 0.12, 0.99, 0.0), thickness=0.007, bevel_inset=0.14, weights=w,
            mat="VISOR", col_face="WHITE", col_edge="WHITE", col_side="WHITE", col_back="WHITE"
        )

    # 4. MECrestCanonical: Bold, Proud 7-Section Radial-Fanned Spartan Crimson Plume Crest (`CANONICAL_HELMET_FOCUS_KEEP.png`)
    mb_crest = MeshBuilder(["MAKitMatte"])
    crest_sections = [
        # (y_bot, z_bot, y_top, z_top, hw_bot, hw_top)
        ( 0.158, 2.012,  0.182, 2.138, 0.026, 0.021), # Bold forward-swept prow
        ( 0.095, 2.016,  0.105, 2.144, 0.027, 0.022), # Front-upper crest peak
        ( 0.032, 2.012,  0.028, 2.132, 0.026, 0.021), # Mid-high crest
        (-0.028, 1.994, -0.046, 2.096, 0.024, 0.019), # Upper-rear sweep
        (-0.078, 1.956, -0.112, 2.036, 0.022, 0.018), # Mid-rear sweep
        (-0.112, 1.896, -0.156, 1.956, 0.020, 0.016), # Lower-rear sweep
        (-0.126, 1.806, -0.178, 1.854, 0.018, 0.014), # Nape tail
    ]
    for idx in range(len(crest_sections) - 1):
        yfb, zfb, yft, zft, hwb, hwt = crest_sections[idx]
        ybb, zbb, ybt, zbt, hwbb, hwbt = crest_sections[idx + 1]
        def c_ring(yf, zf, yb, zb, hw_f, hw_b, flute=0.0):
            ym, zm = 0.5 * (yf + yb), 0.5 * (zf + zb)
            hw_m = 0.5 * (hw_f + hw_b) - flute
            return [
                ( 0.000,       yf + 0.003, zf),
                (-hw_f,        yf,         zf),
                (-hw_m,        ym,         zm),
                (-hw_b,        yb,         zb),
                ( 0.000,       yb - 0.003, zb),
                ( hw_b,        yb,         zb),
                ( hw_m,        ym,         zm),
                ( hw_f,        yf,         zf),
            ]
        r_b = c_ring(yfb, zfb, ybb, zbb, hwb, hwbb, flute=0.002)
        r_m = c_ring(0.16*yfb+0.84*yft, 0.16*zfb+0.84*zft, 0.16*ybb+0.84*ybt, 0.16*zbb+0.84*zbt, hwt, hwbt, flute=0.003)
        r_t = c_ring(yft, zft, ybt, zbt, hwt*0.76, hwbt*0.76, flute=0.001)
        cols_side = ["CLOTH_BRIGHT", "CLOTH_MAIN", "CLOTH_SHADE", "CLOTH_MAIN", "CLOTH_LIGHT", "CLOTH_MAIN", "CLOTH_SHADE", "CLOTH_BRIGHT"]
        cols_top  = ["CLOTH_BRIGHT", "CLOTH_LIGHT","CLOTH_MAIN",  "CLOTH_LIGHT","CLOTH_BRIGHT","CLOTH_LIGHT","CLOTH_MAIN",  "CLOTH_BRIGHT"]
        mb_crest.add_loft([r_b, r_m, r_t], weights=w, mat="MATTE", colors=[cols_side, cols_top], closed_ring=True, cap_start=(idx==0), cap_end=(idx==len(crest_sections)-2), cap_color="CLOTH_BRIGHT")

    # Apply `transform_helmet_v29` ONCE to all 4 helmet datablocks so they stay 100% locked together!
    return (
        b29.transform_helmet_v29(mb_shell),
        b29.transform_helmet_v29(mb_jaw),
        b29.transform_helmet_v29(mb_visor),
        b29.transform_helmet_v29(mb_crest),
    )


def build_v31_pauldron_pair():
    """
    2. Cohesive Open-Arch 3-Tier Pauldrons & Rerebraces (`shoulder.png`):
       - Eliminates the interior-bridging `rm0..rm2` and `dl0..dl2` slabs that cut across the
         inside of the shoulder in v3.0!
       - Sculpts the Main Fortress Cop + 2 Nested Deltoid Lames (`Tier 2` and `Tier 3`) as true
         open C-arches with an 18 mm wall thickness (`outer shell + inner under-shadow wall`),
         framed by a wide champagne-brass perimeter border and front-corner pyramid stud.
       - Coaxially lofts 2 steel rerebrace bands and a lower champagne-brass bicep cuff around
         the dark charcoal upper-arm sleeve.
    """
    mb = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    w = "clavicle.L"

    def arch_shell_ring(x_bot, x_mid, x_top, wrap_x, yf_bot, yf_mid, yf_top, z_bot, z_mid, z_top, y_shift=0.0, wall_t=0.018):
        """
        10-vertex closed cross-section of a thin C-curved arch shell (wraps from front-bottom ->
        front-mid -> top-front -> top-back -> back-mid -> back-bottom, then steps inward by `wall_t`
        along the underside from back-bottom -> top -> front-bottom so the arch is completely
        hollow underneath for the upper arm!).
        """
        yb_bot, yb_mid, yb_top = yf_bot * 0.96, yf_mid * 0.96, yf_top * 0.96
        return [
            (x_bot + wrap_x,          yf_bot + y_shift,         z_bot),            # 0: Outer front-bottom edge
            (x_mid + wrap_x * 0.85,   yf_mid + y_shift,         z_mid),            # 1: Outer front mid-ridge
            (x_top,                   yf_top + y_shift * 0.6,   z_top),            # 2: Outer top-front peak
            (x_top,                  -yb_top + y_shift * 0.6,   z_top),            # 3: Outer top-back peak
            (x_mid + wrap_x * 0.85,  -yb_mid + y_shift,         z_mid),            # 4: Outer back mid-ridge
            (x_bot + wrap_x,         -yb_bot + y_shift,         z_bot + 0.008),    # 5: Outer back-bottom edge
            # Inner wall (steps inward by wall_t so it never bridges straight across +y to -y!)
            (x_bot + wrap_x + wall_t,-yb_bot*0.88 + y_shift,    z_bot - wall_t*0.6 + 0.008), # 6: Inner back-bottom lip
            (x_mid + wrap_x + wall_t,-yb_mid*0.84 + y_shift,    z_mid - wall_t),             # 7: Inner back-mid ceiling
            (x_top + wall_t * 0.8,    0.0 + y_shift * 0.6,      z_top - wall_t),             # 8: Inner top vault ceiling
            (x_mid + wrap_x + wall_t, yf_mid*0.84 + y_shift,    z_mid - wall_t),             # 9: Inner front-mid ceiling
            (x_bot + wrap_x + wall_t, yf_bot*0.88 + y_shift,    z_bot - wall_t*0.6),         # 10: Inner front-bottom lip
        ]

    # Tier 1: Main Fortress Pauldron Cop (with wide Champagne-Brass Collar & Skirt Rim)
    s0 = arch_shell_ring(-0.198, -0.166, -0.140, 0.008, 0.146, 0.170, 0.056, 1.568, 1.644, 1.734, y_shift= 0.006, wall_t=0.020)
    s1 = arch_shell_ring(-0.264, -0.242, -0.196, 0.014, 0.180, 0.190, 0.058, 1.518, 1.614, 1.720, y_shift= 0.010, wall_t=0.020)
    s2 = arch_shell_ring(-0.362, -0.376, -0.332, 0.018, 0.150, 0.166, 0.052, 1.454, 1.570, 1.674, y_shift= 0.000, wall_t=0.020)
    s3 = arch_shell_ring(-0.442, -0.448, -0.416, 0.020, 0.106, 0.118, 0.042, 1.482, 1.548, 1.592, y_shift=-0.006, wall_t=0.018)
    s4 = arch_shell_ring(-0.458, -0.462, -0.432, 0.022, 0.094, 0.104, 0.038, 1.492, 1.542, 1.580, y_shift=-0.008, wall_t=0.016)

    c_collar = ["BRASS_MAIN",  "BRASS_BRIGHT","BRASS_BRIGHT","BRASS_MAIN",  "BRASS_SHADE", "BRASS_DARK",  "FACE_DARK", "FACE_DARK", "FACE_DARK", "FACE_DARK", "BRASS_DARK"]
    c_steel1 = ["BRASS_MAIN",  "STEEL_LIGHT", "STEEL_BRIGHT","STEEL_LIGHT", "STEEL_FACET", "BRASS_SHADE", "FACE_DARK", "FACE_DARK", "FACE_DARK", "FACE_DARK", "BRASS_DARK"]
    c_steel2 = ["BRASS_BRIGHT","STEEL_MAIN",  "STEEL_LIGHT", "STEEL_MAIN",  "STEEL_DARK",  "BRASS_MAIN",  "FACE_DARK", "FACE_DARK", "FACE_DARK", "FACE_DARK", "BRASS_SHADE"]
    c_outer  = ["BRASS_BRIGHT","BRASS_BRIGHT","BRASS_MAIN",  "BRASS_BRIGHT","BRASS_MAIN",  "BRASS_SHADE", "FACE_DARK", "FACE_DARK", "FACE_DARK", "FACE_DARK", "BRASS_SHADE"]

    mb.add_loft(
        [s0, s1, s2, s3, s4],
        weights=w, mat="METAL",
        colors=[c_collar, c_steel1, c_steel2, c_outer],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="BRASS_BRIGHT",
    )

    # Flush-seated Champagne-Brass Corner Besagew Plate & Pyramid Stud (`shoulder.png`)
    pad_corners = [
        (-0.238, 0.192, 1.632),
        (-0.306, 0.198, 1.554),
        (-0.242, 0.198, 1.486),
        (-0.178, 0.186, 1.556),
    ]
    mb.add_flat_beveled_plate(
        pad_corners, normal_dir=(-0.34, 0.92, 0.16), thickness=0.012, bevel_inset=0.16,
        weights=w, mat="METAL", col_face="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_side="BRASS_SHADE",
    )
    mb.add_diamond_boss(
        center=(-0.242, 0.198, 1.554), normal=(-0.34, 0.92, 0.16), up_vec=(-0.12, 0.05, 0.99),
        radius_u=0.030, radius_v=0.030, height=0.022, weights=w, mat="METAL",
        col_main="BRASS_BRIGHT", col_edge="BRASS_MAIN", col_base="BRASS_SHADE",
    )

    # Tier 2 & Tier 3: Two Concentric Open C-Arch Overlapping Deltoid Lames stepping down under Tier 1 (`shoulder.png`)
    for tier_idx, (dz, dx_in, scale_y, col_f) in enumerate([(0.052, 0.016, 0.90, "STEEL_LIGHT"), (0.102, 0.030, 0.82, "STEEL_MAIN")]):
        d1 = arch_shell_ring(-0.258 + dx_in, -0.240 + dx_in, -0.202 + dx_in, 0.012, 0.162*scale_y, 0.172*scale_y, 0.052*scale_y, 1.512 - dz, 1.592 - dz, 1.668 - dz, y_shift=0.006, wall_t=0.016)
        d2 = arch_shell_ring(-0.348 + dx_in, -0.358 + dx_in, -0.318 + dx_in, 0.016, 0.138*scale_y, 0.150*scale_y, 0.046*scale_y, 1.448 - dz, 1.542 - dz, 1.618 - dz, y_shift=0.000, wall_t=0.016)
        d3 = arch_shell_ring(-0.418 + dx_in, -0.422 + dx_in, -0.392 + dx_in, 0.018, 0.098*scale_y, 0.108*scale_y, 0.038*scale_y, 1.466 - dz, 1.518 - dz, 1.558 - dz, y_shift=-0.004, wall_t=0.014)
        c_lame = ["BRASS_MAIN", col_f, "STEEL_BRIGHT", col_f, "STEEL_FACET", "BRASS_SHADE", "FACE_DARK", "FACE_DARK", "FACE_DARK", "FACE_DARK", "FACE_DARK"]
        c_rim  = ["BRASS_BRIGHT", "BRASS_MAIN", "BRASS_BRIGHT", "BRASS_MAIN", "BRASS_SHADE", "BRASS_DARK", "FACE_DARK", "FACE_DARK", "FACE_DARK", "FACE_DARK", "FACE_DARK"]
        mb.add_loft([d1, d2, d3], weights=w, mat="METAL", colors=[c_lame, c_rim], closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    # Apply the 34° descending shoulder contour transform (`b29`)
    piv_x, piv_z = -0.175, 1.665
    rad = math.radians(9.5)
    cs, ss = math.cos(rad), math.sin(rad)
    for i, (x, y, z) in enumerate(mb.verts):
        dx = (x - piv_x) * 0.84
        dz = (z - piv_z) * 0.88
        nx = piv_x + dx * cs - dz * ss + 0.018
        nz = piv_z + dx * ss + dz * cs - 0.018
        ny = y * 0.88 - 0.016
        mb.verts[i] = (float(nx), float(ny), float(nz))

    # Coaxial Cylindrical Upper-Arm Rerebrace Bands + Lower Champagne-Brass Bicep Cuff (`shoulder.png` bottom-right)
    ua_h, ua_t = (-0.255, -0.020, 1.545), (-0.345, 0.095, 1.255)
    ua_frame = BoneFrame(ua_h, ua_t, up_hint=(0.0, 1.0, 0.0))
    def r_ring(t, ru, rv):
        d = 0.74
        pts = [(0, rv), (ru*d, rv*d), (ru, 0), (ru*d, -rv*d), (0, -rv), (-ru*d, -rv*d), (-ru, 0), (-ru*d, rv*d)]
        return [ua_frame.pt(u, v, t - 0.09 * (u / max(ru, 1e-4))) for (u, v) in pts]

    for t0, t1, t2, r_a, r_b, rim_col in [
        (0.08, 0.36, 0.41, 0.096, 0.100, "STEEL_BRIGHT"),
        (0.40, 0.66, 0.72, 0.091, 0.094, "BRASS_BRIGHT"),
    ]:
        mb.add_loft(
            [r_ring(t0, r_a, r_a), r_ring(t1, r_b, r_b), r_ring(t2, r_b - 0.004, r_b - 0.004)],
            weights="upper_arm.L", mat="METAL",
            colors=[["STEEL_DARK", "UNDERSUIT_DARK", "UNDERSUIT_DARK", "STEEL_DARK", "STEEL_FACET", "STEEL_MAIN", "STEEL_LIGHT", "STEEL_FACET"], rim_col],
            closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK"
        )

    pr = MeshBuilder(["MAKitMetal", "MAKitMatte"])
    pr.mirror_from(mb)
    return mb, pr


def build_v31_breastplate_scarf_and_belt():
    """
    3 & 5. Cohesive Compound-Curved V-Keeled Gothic Cuirass, 2-Tier Gorget, Coaxial Rib/Waist
       Fauld Lames, War-Belt & Gusseted Pouches (`tabard.png` & `CANONICAL_SPELLBLADE_KEEP.png`):
       - Eliminates the split flat plackart patch and protruding rectangular flank plates from v3.0.
       - Builds the Milanese plackart-to-cuirass overlap step directly into the compound-curved
         V-keeled `plackart_row` loft (`pr0 -> pr1_plack -> pr2_step -> pr3_chest -> pr4_upper -> pr5_gorget`),
         framed by a continuous 14 mm champagne-brass V-border.
       - Uses 3 coaxially curved elliptical rib/waist fauld rings (`tr0..tr2`) with crisp 24°
         stepped top bevels over the dark charcoal undersuit core.
    """
    mb = MeshBuilder(["MAKitMatte", "MAKitMetal"])

    def core_ring(rx, yf, yb, z):
        return [
            ( 0.000,      yf,        z),
            (-rx * 0.72,  yf * 0.75, z),
            (-rx,         0.000,     z),
            (-rx * 0.72,  yb * 0.75, z),
            ( 0.000,      yb,        z),
            ( rx * 0.72,  yb * 0.75, z),
            ( rx,         0.000,     z),
            ( rx * 0.72,  yf * 0.75, z),
        ]

    c_rings = [
        core_ring(0.148, 0.128, -0.120, 0.950),
        core_ring(0.142, 0.142, -0.128, 1.170),
        core_ring(0.146, 0.154, -0.134, 1.300),
        core_ring(0.178, 0.172, -0.148, 1.520),
        core_ring(0.114, 0.148, -0.106, 1.800),
    ]
    mb.add_loft(c_rings, weights=["pelvis", "pelvis", "spine", "chest", "chest"], mat="MATTE", colors="UNDERSUIT_DARK", closed_ring=True, cap_start=True, cap_end=True, cap_color="UNDERSUIT_DARK")

    # 3 Coaxially Curved Overlapping Lateral Fauld & Rib Lames (`z = 1.265 .. 1.560`)
    def torso_ring(rx, yf_c, yf_s, yb_c, yb_s, z):
        return [
            ( 0.000,      yf_c,   z),
            (-rx * 0.86,  yf_s,   z),
            (-rx,        -0.012,  z),
            (-rx * 0.92,  yb_s,   z),
            ( 0.000,      yb_c,   z),
            ( rx * 0.92,  yb_s,   z),
            ( rx,        -0.012,  z),
            ( rx * 0.86,  yf_s,   z),
        ]

    for z_bot, z_top, rx_b, rx_t, yf_b, yf_t, yb_b, yb_t, w_tag in [
        (1.265, 1.365, 0.154, 0.170, 0.184, 0.196, -0.146, -0.154, "spine"),
        (1.358, 1.465, 0.168, 0.186, 0.194, 0.208, -0.152, -0.160, "chest"),
        (1.458, 1.560, 0.184, 0.198, 0.204, 0.214, -0.158, -0.166, "chest"),
    ]:
        tr0 = torso_ring(rx_b, yf_b, yf_b - 0.020, yb_b, yb_b + 0.014, z_bot)
        tr1 = torso_ring(rx_t, yf_t, yf_t - 0.016, yb_t, yb_t + 0.014, z_top - 0.010)
        tr2 = torso_ring(rx_t - 0.007, yf_t - 0.007, yf_t - 0.022, yb_t + 0.006, yb_t + 0.018, z_top)
        lame_c = ["STEEL_FACET", "STEEL_MAIN",  "FACE_DARK",   "STEEL_DARK",  "STEEL_DARK",  "FACE_DARK",   "STEEL_MAIN",  "STEEL_LIGHT"]
        top_c  = ["STEEL_LIGHT", "STEEL_BRIGHT","STEEL_SHADE", "STEEL_FACET", "STEEL_FACET", "STEEL_SHADE", "STEEL_BRIGHT","STEEL_BRIGHT"]
        mb.add_loft([tr0, tr1, tr2], weights=w_tag, mat="METAL", colors=[lame_c, top_c], closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    # Unified Compound-Curved V-Keeled Gothic Cuirass (`pr0..pr5`) with Integrated Plackart Overlap Step & 14 mm Brass Border
    def cuirass_row(x_gold_out, x_gold_in, y_side, y_keel, z):
        y_back = y_side - 0.028
        x_mid = 0.52 * x_gold_in
        y_mid = 0.45 * y_side + 0.55 * y_keel + 0.005 # Convex pectoral curvature!
        return [
            (-x_gold_out, y_back,           z),
            (-x_gold_out, y_side + 0.008,   z),
            (-x_gold_in,  y_side + 0.011,   z),
            (-x_gold_in,  y_side + 0.003,   z),
            (-x_mid,      y_mid,            z),
            ( 0.000,      y_keel,           z),
            ( x_mid,      y_mid,            z),
            ( x_gold_in,  y_side + 0.003,   z),
            ( x_gold_in,  y_side + 0.011,   z),
            ( x_gold_out, y_side + 0.008,   z),
            ( x_gold_out, y_back,           z),
        ]

    pr0_apex  = cuirass_row(0.019, 0.005, 0.198, 0.218, 1.270) # Crisp V-point above belt buckle
    pr1_plack = cuirass_row(0.106, 0.092, 0.216, 0.258, 1.390) # Overlapping lower abdominal plackart lip
    pr2_step  = cuirass_row(0.108, 0.094, 0.212, 0.251, 1.396) # 7 mm inward step onto upper breastplate
    pr3_chest = cuirass_row(0.138, 0.124, 0.220, 0.264, 1.472) # Convex mid-pectoral swell
    pr4_upper = cuirass_row(0.150, 0.136, 0.218, 0.256, 1.535) # Upper pectoral dome
    pr5_gorg  = cuirass_row(0.136, 0.122, 0.198, 0.226, 1.594) # Upper gorget transition under scarf

    c_plack = ["BRASS_SHADE", "BRASS_MAIN",  "BRASS_BRIGHT","STEEL_FACET", "STEEL_MAIN",  "STEEL_LIGHT", "STEEL_BRIGHT","BRASS_BRIGHT","BRASS_MAIN",  "BRASS_SHADE", "FACE_DARK"]
    c_step  = ["BRASS_MAIN",  "BRASS_BRIGHT","BRASS_BRIGHT","FACE_DARK",   "STEEL_DARK",  "STEEL_SHADE", "STEEL_DARK",  "BRASS_BRIGHT","BRASS_BRIGHT","BRASS_MAIN",  "FACE_DARK"]
    c_chest = ["BRASS_MAIN",  "BRASS_BRIGHT","BRASS_EDGE",  "STEEL_MAIN",  "STEEL_LIGHT", "STEEL_BRIGHT","STEEL_BRIGHT","BRASS_EDGE",  "BRASS_BRIGHT","BRASS_MAIN",  "FACE_DARK"]
    c_upper = ["BRASS_MAIN",  "BRASS_LIGHT", "BRASS_EDGE",  "STEEL_FACET", "STEEL_MAIN",  "STEEL_LIGHT", "STEEL_BRIGHT","BRASS_EDGE",  "BRASS_LIGHT", "BRASS_MAIN",  "FACE_DARK"]
    c_gorg  = ["BRASS_SHADE", "BRASS_MAIN",  "BRASS_DARK",  "FACE_DARK",   "STEEL_DARK",  "STEEL_FACET", "STEEL_DARK",  "BRASS_DARK",  "BRASS_MAIN",  "BRASS_SHADE", "FACE_DARK"]

    mb.add_loft(
        [pr0_apex, pr1_plack, pr2_step, pr3_chest, pr4_upper, pr5_gorg],
        weights=["spine", "spine", "chest", "chest", "chest", "chest"],
        mat="METAL",
        colors=[c_plack, c_step, c_chest, c_upper, c_gorg],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="STEEL_DARK",
    )

    # Articulated 2-Tier Steel & Brass Gorget Collar beneath the crimson V-scarf
    for z_lo, z_hi, rx_g, yf_g, col_top in [(1.558, 1.596, 0.130, 0.212, "BRASS_MAIN"), (1.592, 1.628, 0.116, 0.198, "STEEL_LIGHT")]:
        g_r0 = [(0.0, yf_g, z_lo), (-rx_g*0.75, yf_g*0.78, z_lo), (-rx_g, 0.0, z_lo), (0.0, -0.145, z_lo), (rx_g, 0.0, z_lo), (rx_g*0.75, yf_g*0.78, z_lo)]
        g_r1 = [(0.0, yf_g-0.006, z_hi), (-rx_g*0.72, yf_g*0.75, z_hi), (-rx_g*0.95, 0.0, z_hi), (0.0, -0.140, z_hi), (rx_g*0.95, 0.0, z_hi), (rx_g*0.72, yf_g*0.75, z_hi)]
        mb.add_loft([g_r0, g_r1], weights="chest", mat="METAL", colors=[["STEEL_DARK", "STEEL_FACET", "FACE_DARK", "FACE_DARK", "STEEL_FACET", "STEEL_MAIN"], col_top], closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK")

    # Compact 2-Fold V-Notched Crimson Neck Scarf + Rear Cape Collar
    def scarf_ring(rx, yf_v, yf_side, yb_v, yb_side, z_front_v, z_side, z_back):
        return [
            ( 0.000,      yf_v,     z_front_v),
            (-rx * 0.62,  yf_side,  z_side),
            (-rx,         0.010,    z_side + 0.010),
            (-rx * 0.82,  yb_side,  z_back + 0.006),
            ( 0.000,      yb_v,     z_back),
            ( rx * 0.82,  yb_side,  z_back + 0.006),
            ( rx,         0.010,    z_side + 0.010),
            ( rx * 0.62,  yf_side,  z_side),
        ]

    s0     = scarf_ring(0.142, 0.228, 0.194, -0.168, -0.152, 1.532, 1.604, 1.548)
    s1_out = scarf_ring(0.178, 0.240, 0.204, -0.184, -0.166, 1.592, 1.664, 1.614)
    s1_in  = scarf_ring(0.164, 0.222, 0.190, -0.170, -0.152, 1.602, 1.672, 1.622)
    s2_out = scarf_ring(0.182, 0.230, 0.196, -0.182, -0.164, 1.660, 1.744, 1.712)
    s3     = scarf_ring(0.140, 0.184, 0.168, -0.142, -0.128, 1.706, 1.768, 1.748)

    scarf_cols_bright = ["CLOTH_BRIGHT", "CLOTH_LIGHT", "CLOTH_MAIN", "CLOTH_LIGHT", "CLOTH_BRIGHT", "CLOTH_MAIN", "CLOTH_LIGHT", "CLOTH_BRIGHT"]
    scarf_cols_mid    = ["CLOTH_LIGHT",  "CLOTH_MAIN",  "CLOTH_SHADE","CLOTH_MAIN",  "CLOTH_LIGHT",  "CLOTH_SHADE","CLOTH_MAIN",  "CLOTH_LIGHT"]
    scarf_cols_crev   = ["CLOTH_DARK"] * 8

    mb.add_loft(
        [s0, s1_out, s1_in, s2_out, s3],
        weights="chest", mat="MATTE",
        colors=[scarf_cols_mid, scarf_cols_crev, scarf_cols_bright, scarf_cols_mid],
        closed_ring=True, cap_start=True, cap_end=True, cap_color="CLOTH_DARK"
    )

    collar_pts = [
        (-0.148, -0.162, 1.648),
        ( 0.148, -0.162, 1.648),
        ( 0.164, -0.174, 1.510),
        (-0.164, -0.174, 1.510),
    ]
    mb.add_flat_beveled_plate(
        collar_pts, normal_dir=(0.0, -0.98, 0.16), thickness=0.016, bevel_inset=0.14,
        weights="chest", mat="MATTE", col_face="CLOTH_MAIN", col_edge="CLOTH_BRIGHT", col_side="CLOTH_DARK"
    )

    # Stitched Saddle-Leather War-Belt, Chamfered Silver Buckle, Diamond Studs & Contoured Side Pouches
    def belt_ring(rx, yf, yb, z):
        return [
            ( 0.000,      yf,        z),
            (-rx * 0.78,  yf * 0.84, z),
            (-rx,        -0.010,     z),
            (-rx * 0.84,  yb * 0.88, z),
            ( 0.000,      yb,        z),
            ( rx * 0.84,  yb * 0.88, z),
            ( rx,        -0.010,     z),
            ( rx * 0.78,  yf * 0.84, z),
        ]
    b_r0 = belt_ring(0.164, 0.194, -0.154, 1.186)
    b_r1 = belt_ring(0.166, 0.198, -0.156, 1.266)
    b_r2 = belt_ring(0.156, 0.186, -0.148, 1.272)
    belt_cols = ["LEATHER_MAIN", "LEATHER_LIGHT", "LEATHER_SHADE", "LEATHER_DARK", "LEATHER_MAIN", "LEATHER_DARK", "LEATHER_SHADE", "LEATHER_LIGHT"]
    mb.add_loft([b_r0, b_r1, b_r2], weights="pelvis", mat="MATTE", colors=[belt_cols, "LEATHER_DARK"], closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_DARK")

    bk_corners = [(-0.044, 0.200, 1.274), (0.044, 0.200, 1.274), (0.044, 0.198, 1.178), (-0.044, 0.198, 1.178)]
    rs_prev.add_framed_rect_plate(
        mb, bk_corners, normal_dir=(0.0, 1.0, 0.04), thickness=0.016, border_frac=0.28, weights="pelvis",
        mat_border="METAL", col_border="STEEL_LIGHT", col_border_edge="STEEL_BRIGHT",
        mat_inner="MATTE", col_inner="LEATHER_DARK", open_top=False
    )
    mb.add_beveled_box(
        center=(0.010, 0.208, 1.226), half_extents=(0.018, 0.006, 0.007),
        bevel=0.18, weights="pelvis", mat="METAL", col_main="STEEL_BRIGHT", col_edge="STEEL_LIGHT", col_dark="STEEL_DARK"
    )

    for sign in (-1.0, 1.0):
        mb.add_diamond_boss(
            center=(sign * 0.098, 0.184, 1.226), normal=(sign * 0.42, 0.90, 0.0), up_vec=(0.0, 0.0, 1.0),
            radius_u=0.028, radius_v=0.032, height=0.018, weights="pelvis", mat="METAL",
            col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_base="BRASS_SHADE"
        )
        pouch_c = (sign * 0.166, -0.020, 1.195)
        mb.add_beveled_box(
            center=pouch_c, half_extents=(0.018, 0.042, 0.046),
            axes=((sign, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)),
            bevel=0.20, weights="pelvis", mat="MATTE", col_main="LEATHER_MAIN", col_edge="LEATHER_LIGHT", col_dark="LEATHER_DARK"
        )
        # Contoured top pouch flap
        mb.add_beveled_box(
            center=(sign * 0.168, -0.020, 1.236), half_extents=(0.020, 0.044, 0.010),
            axes=((sign, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)),
            bevel=0.22, weights="pelvis", mat="MATTE", col_main="LEATHER_LIGHT", col_edge="LEATHER_MAIN", col_dark="LEATHER_DARK"
        )
        mb.add_beveled_box(
            center=(sign * 0.184, -0.020, 1.214), half_extents=(0.006, 0.012, 0.014),
            bevel=0.18, weights="pelvis", mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
        )

    return mb


def build_v31_arm_and_gauntlet(is_right=False, closed_left_grip=False):
    """
    4. Coaxial 3-Piece Elbow Couter, Hinged Clamshell Vambrace with Leather Straps, Flared Cuff &
       Articulated 5-Digit Gauntlets (`CANONICAL_HAND_DETAIL_KEEP.png`):
       - All couter rings, vambrace straps, and wrist cuffs are coaxially lofted around `fa_frame`
         so there are zero sticking-out flat plates during elbow/wrist rotation!
    """
    mb = b29.build_v29_arm_and_gauntlet(is_right=is_right, closed_left_grip=closed_left_grip)
    suffix = ".R" if is_right else ".L"
    sign = 1.0 if is_right else -1.0
    out_u = -sign

    if not is_right:
        fa_h, fa_t = (-0.345,  0.095, 1.255), (-0.428,  0.455, 1.185)
    else:
        fa_h, fa_t = ( 0.385, -0.128, 1.335), ( 0.465,  0.005, 1.060)
    fa_frame = BoneFrame(fa_h, fa_t, up_hint=(0.0, 1.0, 0.0))
    fa_w = f"forearm{suffix}"
    ha_w = f"hand{suffix}"

    def strap_ring(t, r):
        d = 0.74
        pts = [(0, r), (r*d, r*d), (r, 0), (r*d, -r*d), (0, -r), (-r*d, -r*d), (-r, 0), (-r*d, r*d)]
        return [fa_frame.pt(u, v, t) for (u, v) in pts]

    # Coaxial upper and lower couter articulation lames (`t = -0.05..0.01` and `t = 0.16..0.22`)
    for t_lo, t_hi, r_c in [(-0.05, 0.00, 0.086), (0.16, 0.22, 0.088)]:
        mb.add_loft(
            [strap_ring(t_lo, r_c), strap_ring(t_hi, r_c + 0.003)],
            weights=fa_w, mat="METAL",
            colors=[["UNDERSUIT_DARK", "STEEL_DARK", "STEEL_MAIN", "STEEL_LIGHT", "STEEL_BRIGHT", "STEEL_LIGHT", "STEEL_MAIN", "UNDERSUIT_DARK"]],
            closed_ring=True, cap_start=True, cap_end=True, cap_color="FACE_DARK"
        )

    # Two Coaxial Wrap-Around Saddle-Leather Vambrace Straps with Brass Keepers (`t = 0.34` & `t = 0.64`)
    for t_s, r_s in [(0.34, 0.086), (0.64, 0.072)]:
        mb.add_loft(
            [strap_ring(t_s - 0.022, r_s), strap_ring(t_s + 0.022, r_s - 0.002)],
            weights=fa_w, mat="MATTE", colors="LEATHER_MAIN", closed_ring=True, cap_start=True, cap_end=True, cap_color="LEATHER_LIGHT"
        )
        mb.add_beveled_box(
            center=fa_frame.pt(out_u * (r_s * 0.72), r_s * 0.68, t_s),
            half_extents=(0.009, 0.007, 0.011),
            axes=(fa_frame.u, fa_frame.v, fa_frame.w),
            bevel=0.18, weights=fa_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
        )

    if is_right:
        wrist_pt = np.array(fa_t, dtype=np.float32)
        b_dir = np.array([0.54, 0.67, -0.508], dtype=np.float32)
        b_dir /= np.linalg.norm(b_dir)
        f_out = np.array([0.48, 0.76, 0.44], dtype=np.float32)
        f_out -= np.dot(f_out, b_dir) * b_dir
        f_out /= np.linalg.norm(f_out)
        f_perp = np.cross(b_dir, f_out)
        if f_perp[2] > 0:
            f_perp = -f_perp
        f_perp /= np.linalg.norm(f_perp)
        hand_root = wrist_pt + 0.024 * fa_frame.w - 0.010 * f_out

        for l_idx, (p_off, out_off, col_l) in enumerate([(0.008, 0.026, "STEEL_LIGHT"), (0.026, 0.028, "STEEL_MAIN"), (0.044, 0.030, "STEEL_LIGHT")]):
            mb.add_beveled_box(
                center=hand_root + p_off * f_perp + out_off * f_out,
                half_extents=(0.048 - 0.002 * l_idx, 0.008, 0.011),
                axes=(b_dir, f_out, f_perp),
                bevel=0.18, weights=ha_w, mat="METAL", col_main=col_l, col_edge="STEEL_BRIGHT", col_dark="FACE_DARK"
            )
        for s_off in (-0.036, -0.012, 0.012, 0.036):
            mb.add_diamond_boss(
                center=hand_root + s_off * b_dir + 0.062 * f_perp + 0.038 * f_out,
                normal=f_out, up_vec=f_perp,
                radius_u=0.013, radius_v=0.014, height=0.010,
                weights=ha_w, mat="METAL", col_main="BRASS_BRIGHT", col_edge="BRASS_MAIN", col_base="BRASS_SHADE"
            )
    return mb


def build_v31_legs_greaves_and_boots(is_right=False):
    """
    6. Cohesive 2-Lame Thigh Cuisses, 3-Tier Articulated Hip Tassets (with blended Pelvis/Thigh
       weights for mounted & sprint deformation), 3-Piece Knee Poleyns, Tapered Shin Greaves &
       4-Lame Sabatons (`boot.png` & `tabard.png`).
    """
    mb = b29.build_v29_legs_greaves_and_boots(is_right=is_right)
    suffix = ".R" if is_right else ".L"
    sign = 1.0 if is_right else -1.0
    yaw_deg = -7.5 if is_right else 7.5

    th_h = (sign * 0.168,  0.012, 1.060)
    th_t = (sign * 0.218,  0.042, 0.635)
    sh_h = (sign * 0.218,  0.042, 0.635)
    sh_t = (sign * 0.248, -0.010, 0.225)

    rad = math.radians(yaw_deg)
    up_out = (float(-math.sin(rad)), float(np.cos(rad)), 0.0)
    th_frame = BoneFrame(th_h, th_t, up_hint=up_out)
    sh_frame = BoneFrame(sh_h, sh_t, up_hint=up_out)
    th_w = f"thigh{suffix}"
    sh_w = f"shin{suffix}"
    ft_w = f"foot{suffix}"
    out_u = 1.0 if np.dot(sh_frame.u, np.array([sign, 0.0, 0.0])) > 0 else -1.0

    # 1. Contoured Outer-Front Thigh Cuisse Plate
    cuisse_grid = [
        [th_frame.pt(-0.074, 0.094, 0.22), th_frame.pt(0.0, 0.126, 0.20), th_frame.pt(0.082, 0.090, 0.22)],
        [th_frame.pt(-0.070, 0.090, 0.56), th_frame.pt(0.0, 0.122, 0.55), th_frame.pt(0.078, 0.086, 0.56)],
        [th_frame.pt(-0.064, 0.084, 0.84), th_frame.pt(0.0, 0.114, 0.84), th_frame.pt(0.072, 0.080, 0.84)],
    ]
    mb.add_faceted_shield_plate(
        cuisse_grid, outward_hint=th_frame.v, thickness=0.014, bevel_inset=0.16, weights=th_w,
        mat="METAL", col_faces=[["STEEL_FACET", "STEEL_MAIN"], ["STEEL_DARK", "STEEL_FACET"]],
        col_bevel="STEEL_LIGHT", col_side="FACE_DARK"
    )

    # 3rd Lower Hip Tasset Lame (`tabard.png`)
    tasset_3 = [
        (sign * 0.152, 0.172, 0.972),
        (sign * 0.214, 0.144, 0.972),
        (sign * 0.228, 0.132, 0.865),
        (sign * 0.166, 0.160, 0.865),
    ]
    rs_prev.add_framed_rect_plate(
        mb, tasset_3, normal_dir=(sign * 0.38, 0.91, 0.10), thickness=0.012, border_frac=0.22, weights=th_w,
        mat_border="METAL", col_border="BRASS_MAIN", col_border_edge="BRASS_BRIGHT",
        mat_inner="MATTE", col_inner="LEATHER_SHADE", open_top=True
    )

    # Blend weights of upper hip tasset vertices (`z > 1.02`) between `pelvis` and `thigh` so they hinge smoothly when mounted!
    for vi, (vx, vy, vz) in enumerate(mb.verts):
        if vz > 1.02 and th_w in mb.weights[vi]:
            alpha_p = float(np.clip((vz - 1.02) / 0.18, 0.0, 0.65))
            mb.weights[vi] = {"pelvis": alpha_p, th_w: 1.0 - alpha_p}

    # 2. Knee Poleyn Side-Wing Rondel + Sub-Poleyn Lame (`boot.png`)
    wing_k = [
        sh_frame.pt(out_u * 0.116,  0.042,  0.02),
        sh_frame.pt(out_u * 0.136, -0.020,  0.14),
        sh_frame.pt(out_u * 0.112,  0.032,  0.32),
        sh_frame.pt(out_u * 0.094,  0.082,  0.16),
    ]
    mb.add_flat_beveled_plate(
        wing_k, normal_dir=out_u * sh_frame.u + 0.25 * sh_frame.v, thickness=0.012, bevel_inset=0.18,
        weights=sh_w, mat="METAL", col_face="STEEL_MAIN", col_edge="STEEL_BRIGHT", col_side="FACE_DARK"
    )
    mb.add_beveled_box(
        center=sh_frame.pt(out_u * 0.124, 0.010, 0.15), half_extents=(0.007, 0.007, 0.007),
        axes=(sh_frame.u, sh_frame.v, sh_frame.w),
        bevel=0.20, weights=sh_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
    )

    sub_k_grid = [
        [sh_frame.pt(-0.096, 0.005, 0.35), sh_frame.pt(-0.060, 0.116, 0.37), sh_frame.pt(0.060, 0.116, 0.37), sh_frame.pt(0.096, 0.005, 0.35)],
        [sh_frame.pt(-0.090, 0.002, 0.45), sh_frame.pt(-0.054, 0.110, 0.48), sh_frame.pt(0.054, 0.110, 0.48), sh_frame.pt(0.090, 0.002, 0.45)],
    ]
    mb.add_faceted_shield_plate(
        sub_k_grid, outward_hint=sh_frame.v, thickness=0.016, bevel_inset=0.16, weights=sh_w,
        mat="METAL", col_faces=[["STEEL_FACET", "STEEL_MAIN", "STEEL_LIGHT"]], col_bevel="STEEL_BRIGHT", col_side="FACE_DARK"
    )

    # 3. Overlapping Dorsal Sabaton Lames, Heel Spur-Rest & Twin Brass Ankle Buckles (`boot.png`)
    cx, cy = sh_t[0], sh_t[1]
    for l_i, (y_f, y_b, z_l, w_l, col_s) in enumerate([
        (0.245, 0.195, 0.088, 0.076, "STEEL_LIGHT"),
        (0.205, 0.155, 0.104, 0.070, "STEEL_MAIN"),
        (0.165, 0.118, 0.122, 0.066, "STEEL_LIGHT"),
    ]):
        lame_pts = rs_prev.rot_z([
            (cx - w_l, cy + y_f, z_l - 0.008),
            (cx + w_l, cy + y_f, z_l - 0.008),
            (cx + w_l * 0.92, cy + y_b, z_l + 0.012),
            (cx - w_l * 0.92, cy + y_b, z_l + 0.012),
        ], yaw_deg, pivot=(cx, cy))
        mb.add_flat_beveled_plate(
            lame_pts, normal_dir=(0.0, 0.48, 0.88), thickness=0.008, bevel_inset=0.16,
            weights=ft_w, mat="METAL", col_face=col_s, col_edge="STEEL_BRIGHT", col_side="FACE_DARK"
        )

    for k_side in (-1.0, 1.0):
        bk_pt = rs_prev.rot_z([(cx + k_side * 0.094, cy + 0.018, 0.114)], yaw_deg, pivot=(cx, cy))[0]
        mb.add_beveled_box(
            center=bk_pt, half_extents=(0.009, 0.015, 0.017),
            weights=ft_w, mat="METAL", col_main="BRASS_MAIN", col_edge="BRASS_BRIGHT", col_dark="BRASS_SHADE"
        )
    spur_pt = rs_prev.rot_z([(cx, cy - 0.142, 0.068)], yaw_deg, pivot=(cx, cy))[0]
    mb.add_beveled_box(
        center=spur_pt, half_extents=(0.044, 0.012, 0.010),
        weights=ft_w, mat="METAL", col_main="STEEL_MAIN", col_edge="BRASS_MAIN", col_dark="FACE_DARK"
    )
    return mb


def build_v31_arm_only_without_left_hand():
    full_arm_l = build_v31_arm_and_gauntlet(is_right=False, closed_left_grip=False)
    mb_arm = MeshBuilder(["MAKitMatte", "MAKitMetal"])
    off = 0
    for pi, poly in enumerate(full_arm_l.polys):
        plen = len(poly)
        w0 = full_arm_l.weights[poly[0]]
        if "hand.L" not in w0 and "socket_sorcery" not in w0:
            mat_name = full_arm_l.mat_names[full_arm_l.mat_indices[pi]]
            new_vis = [mb_arm.add_vert(full_arm_l.verts[vi], full_arm_l.weights[vi]) for vi in poly]
            mb_arm.polys.append(new_vis)
            mb_arm.mat_indices.append(mb_arm._resolve_mat(mat_name))
            mb_arm.loop_colors.extend(full_arm_l.loop_colors[off:off+plen])
            mb_arm.loop_uvs.extend(full_arm_l.loop_uvs[off:off+plen])
        off += plen
    mb_arm.bake_loop_shading()
    return mb_arm


def calibrate_v31_vertex_color(poly_mat_id: int, raw_rgba, is_glow: bool, k: int, plen: int):
    """
    Calibrates vertex colors per material for `v3.1` so:
      - Mat 0 (`MA_Spellblade_Forged_Steel`, M=0.54, R=0.34): Shifts from dark brownish-gray
        (`R > B` in old PALETTE) to crisp cool-slate forged steel (`B > G > R`) matching
        `CANONICAL_SPELLBLADE_KEEP.png`, `CANONICAL_HELMET_FOCUS_KEEP.png`, `shoulder.png`, and `boot.png`!
      - Mat 1 (`MA_Spellblade_Champagne_Brass`, M=0.74, R=0.25): Warm luminous champagne-brass
        (`R > G > B`) with clear separation from steel.
      - Mat 2 (`MA_Spellblade_Saddle_Leather`, M=0.04, R=0.62): Rich warm saddle-leather brown.
      - Mat 3 (`MA_Spellblade_Dark_Undersuit`, M=0.02, R=0.90): Deep matte charcoal-slate core.
      - Mat 4 (`MA_Spellblade_Crimson_Cloth`, M=0.03, R=0.80): Rich heraldic crimson cloth.
      - Mat 5 (`MA_Spellblade_Arcane_Cyan_Emissive`): Dual-tone glowing arcane cyan.
    """
    if is_glow or poly_mat_id == 5:
        is_core = (k < plen - 2) if plen == 4 else True
        return [0.22, 0.96, 1.00, 1.0] if is_core else [0.80, 0.99, 1.00, 1.0]

    r = float(np.clip(raw_rgba[0] ** (1.0 / 1.85), 0.0, 1.0))
    g = float(np.clip(raw_rgba[1] ** (1.0 / 1.85), 0.0, 1.0))
    b = float(np.clip(raw_rgba[2] ** (1.0 / 1.85), 0.0, 1.0))

    if poly_mat_id == 0:
        # Cool-slate forged steel: lift luminance and give cool blue-slate tint (B > G > R)
        lum = 0.30 * r + 0.45 * g + 0.25 * b
        sr = float(np.clip(0.11 + 1.02 * lum, 0.08, 0.84))
        sg = float(np.clip(0.13 + 1.10 * lum, 0.10, 0.88))
        sb = float(np.clip(0.16 + 1.24 * lum, 0.13, 0.95))
        return [sr, sg, sb, 1.0]
    elif poly_mat_id == 1:
        # Luminous champagne brass
        br = float(np.clip(r * 1.18 + 0.06, 0.18, 0.98))
        bg = float(np.clip(g * 1.15 + 0.04, 0.14, 0.86))
        bb = float(np.clip(b * 0.95 + 0.02, 0.08, 0.58))
        return [br, bg, bb, 1.0]
    elif poly_mat_id == 2:
        # Warm saddle leather
        return [float(np.clip(r * 1.12, 0.05, 0.72)), float(np.clip(g * 1.06, 0.03, 0.48)), float(np.clip(b * 1.02, 0.02, 0.34)), 1.0]
    elif poly_mat_id == 3:
        # Deep matte charcoal undersuit (slight cool charcoal tint)
        lum = 0.33 * (r + g + b)
        return [float(np.clip(lum * 0.85, 0.02, 0.22)), float(np.clip(lum * 0.90, 0.02, 0.24)), float(np.clip(lum * 1.05, 0.03, 0.28)), 1.0]
    elif poly_mat_id == 4:
        # Rich heraldic crimson cloth
        return [float(np.clip(r * 1.14 + 0.03, 0.12, 0.86)), float(np.clip(g * 0.96, 0.02, 0.26)), float(np.clip(b * 0.98, 0.03, 0.28)), 1.0]
    return [r, g, b, 1.0]


def compile_meshbuilder_to_v31_multimat_arrays(mb: MeshBuilder, default_joint_idx: int = 3):
    verts_w = exp28.b_to_gltf_pos(np.array(mb.verts, dtype=np.float32))
    pos_list, nrm_list, vc_list, uv_list, j0_list, w0_list, tri_list, tmat_list = [], [], [], [], [], [], [], []

    v_j0 = np.zeros((len(mb.verts), 4), dtype=np.uint16)
    v_w0 = np.zeros((len(mb.verts), 4), dtype=np.float32)
    for vi, wdict in enumerate(mb.weights):
        items = sorted(
            [(exp28.JOINT_INDEX_MAP.get(k, default_joint_idx), float(val)) for k, val in wdict.items() if float(val) > 1e-5],
            key=lambda x: -x[1]
        )[:4]
        if not items:
            items = [(default_joint_idx, 1.0)]
        tot = sum(x[1] for x in items)
        for c, (j_idx, w_val) in enumerate(items):
            v_j0[vi, c] = int(j_idx)
            v_w0[vi, c] = float(w_val / max(tot, 1e-6))

    l_off = 0
    v_cur = 0
    for pi, poly in enumerate(mb.polys):
        plen = len(poly)
        if plen < 3:
            l_off += plen
            continue
        pts = verts_w[poly]
        fn = np.cross(pts[1] - pts[0], pts[2] - pts[0])
        fn_len = float(np.linalg.norm(fn))
        fn = (fn / fn_len).astype(np.float32) if fn_len >= 1e-9 else np.array([0.0, 1.0, 0.0], dtype=np.float32)

        mat_name = mb.mat_names[mb.mat_indices[pi]] if pi < len(mb.mat_indices) else "MAKitMetal"
        is_glow = mat_name in ("MAVisorGlow", "MASorceryAccent")
        poly_mat_id = b29.classify_poly_material_v29(mat_name, mb.loop_colors[l_off])

        for k, vi in enumerate(poly):
            pos_list.append(verts_w[vi])
            nrm_list.append(fn)
            rgba = calibrate_v31_vertex_color(poly_mat_id, mb.loop_colors[l_off + k], is_glow, k, plen)
            vc_list.append(rgba)
            uv_list.append(mb.loop_uvs[l_off + k])
            j0_list.append(v_j0[vi])
            w0_list.append(v_w0[vi])

        for t_i in range(1, plen - 1):
            tri_list.append([v_cur, v_cur + t_i, v_cur + t_i + 1])
            tmat_list.append(poly_mat_id)

        v_cur += plen
        l_off += plen

    return (
        np.array(pos_list, dtype=np.float32),
        np.array(nrm_list, dtype=np.float32),
        np.array(vc_list,  dtype=np.float32),
        np.array(uv_list,  dtype=np.float32),
        np.array(j0_list,  dtype=np.uint16),
        np.array(w0_list,  dtype=np.float32),
        np.array(tri_list, dtype=np.uint32),
        np.array(tmat_list, dtype=np.int32),
    )


def export_spellblade_v31():
    tp_src = C_PREV_WORK / "Spellblade-production-third-person.blend"
    bf_tp = BlendFile(str(tp_src))
    rs_prev.upgrade_banner_texture(bf_tp)

    mb_shell, mb_jaw, mb_visor, mb_crest = build_v31_helmet_parts()
    mb_pl, mb_pr = build_v31_pauldron_pair()
    mb_bp = build_v31_breastplate_scarf_and_belt()
    mb_arm_l = build_v31_arm_and_gauntlet(is_right=False, closed_left_grip=False)
    mb_arm_r = build_v31_arm_and_gauntlet(is_right=True,  closed_left_grip=False)
    mb_sorc = rs_prev.build_sorcery_cluster(first_person=False)
    mb_sword = b29.build_v29_hero_broadsword(first_person=False)
    for i in range(len(mb_sword.weights)):
        mb_sword.weights[i] = {"socket_sword": 1.0}
    leg_l = build_v31_legs_greaves_and_boots(is_right=False)
    leg_r = build_v31_legs_greaves_and_boots(is_right=True)
    mb_grv_l, mb_bt_l = exp28.split_greave_and_boot(leg_l, is_right=False)
    mb_grv_r, mb_bt_r = exp28.split_greave_and_boot(leg_r, is_right=True)
    mb_tab_f = u28.build_v28_sculpted_3d_tabard(is_front=True)
    mb_tab_b = u28.build_v28_sculpted_3d_tabard(is_front=False)
    for i, (x, y, z) in enumerate(mb_tab_f.verts):
        mb_tab_f.verts[i] = (float(x * 0.92), float(y - 0.018), float(z))
    for i, (x, y, z) in enumerate(mb_tab_b.verts):
        mb_tab_b.verts[i] = (float(x * 0.92), float(y + 0.016), float(z))

    all_tp = [
        ("MEHelmetShellCanonical", mb_shell),
        ("MEHelmetJawCanonical",   mb_jaw),
        ("MEVisorCanonical",       mb_visor),
        ("MECrestCanonical",       mb_crest),
        ("MEPauldron.L",           mb_pl),
        ("MEPauldron.R",           mb_pr),
        ("MEBreastplate",          mb_bp),
        ("MEGauntlet.L.001",       mb_arm_l),
        ("MEGauntlet.R.001",       mb_arm_r),
        ("MEPalmRune.001",         mb_sorc),
        ("MEHeroSword",            mb_sword),
        ("MEGreave.L",             mb_grv_l),
        ("MEBoot.L",               mb_bt_l),
        ("MEGreave.R",             mb_grv_r),
        ("MEBoot.R",               mb_bt_r),
        ("METabardFront",          mb_tab_f),
        ("METabardBack",           mb_tab_b),
    ]
    for name, mb in all_tp:
        mb.bake_loop_shading()
        bf_tp.replace_mesh(name, mb)
    bf_tp.set_armature_rest_pose_in_pose_channels()

    raw_v31_blend = WORK_DIR / "Spellblade-v31-preview.blend"
    bf_tp.save(str(raw_v31_blend))
    out_v31_blend = OUT_DIR / "spellblade-v31-ingame-review-candidate.blend"
    zstd_compress_blend(raw_v31_blend.read_bytes(), out_v31_blend)
    sha_v31_blend = hashlib.sha256(out_v31_blend.read_bytes()).hexdigest()
    print(f"[OK] Saved {out_v31_blend.name}: {out_v31_blend.stat().st_size:,} bytes, SHA256={sha_v31_blend}")

    # Export `spellblade-v31-ingame-review-candidate.glb` with calibrated 6-material PBR response
    b29.build_v29_arm_only_without_left_hand = build_v31_arm_only_without_left_hand
    orig_compile = b29.compile_meshbuilder_to_multimat_arrays
    b29.compile_meshbuilder_to_multimat_arrays = compile_meshbuilder_to_v31_multimat_arrays

    bf_glb_tab = BlendFile(str(tp_src))
    rs_prev.upgrade_banner_texture(bf_glb_tab)
    rs_prev.polish_original_tabards(bf_glb_tab)
    glb_tab_path = WORK_DIR / "Spellblade-v31-glb-tabard.blend"
    bf_glb_tab.save(str(glb_tab_path))

    tmp_v31_glb = WORK_DIR / "spellblade-v31-ingame-review-candidate.glb"
    rep_no_tab = {k: v for k, v in all_tp if k not in ("METabardFront", "METabardBack")}
    b29.export_spellblade_v29_multimat_glb(glb_tab_path, rep_no_tab, tmp_v31_glb)
    b29.compile_meshbuilder_to_multimat_arrays = orig_compile

    # Update the glTF material metallic/roughness factors in tmp_v31_glb to the calibrated stylized-PBR response:
    # Mat 0 Forged Steel: M=0.54, R=0.34 | Mat 1 Champagne Brass: M=0.74, R=0.25 | Mat 2 Saddle Leather: M=0.04, R=0.62
    # Mat 3 Dark Undersuit: M=0.02, R=0.90 | Mat 4 Crimson Cloth: M=0.03, R=0.80 | Mat 5 Arcane Cyan Emissive: M=0.12, R=0.14
    raw = tmp_v31_glb.read_bytes()
    j_len = struct.unpack_from("<I", raw, 12)[0]
    g_json = json.loads(raw[20:20+j_len].decode("utf-8"))
    b_chunk = raw[20+j_len+8:]

    g_json["materials"][0]["pbrMetallicRoughness"]["metallicFactor"] = 0.54
    g_json["materials"][0]["pbrMetallicRoughness"]["roughnessFactor"] = 0.34
    g_json["materials"][1]["pbrMetallicRoughness"]["metallicFactor"] = 0.74
    g_json["materials"][1]["pbrMetallicRoughness"]["roughnessFactor"] = 0.25
    g_json["materials"][2]["pbrMetallicRoughness"]["metallicFactor"] = 0.04
    g_json["materials"][2]["pbrMetallicRoughness"]["roughnessFactor"] = 0.62
    g_json["materials"][3]["pbrMetallicRoughness"]["metallicFactor"] = 0.02
    g_json["materials"][3]["pbrMetallicRoughness"]["roughnessFactor"] = 0.90
    g_json["materials"][4]["pbrMetallicRoughness"]["metallicFactor"] = 0.03
    g_json["materials"][4]["pbrMetallicRoughness"]["roughnessFactor"] = 0.80
    g_json["extras"]["version"] = "3.1.0-ingame-review-candidate"
    g_json["extras"]["materialBreakdown"]["0_MA_Spellblade_Forged_Steel"] = {"metallicFactor": 0.54, "roughnessFactor": 0.34, "chromaticity": "Cool-Slate Forged Steel (B > G > R)"}
    g_json["extras"]["materialBreakdown"]["1_MA_Spellblade_Champagne_Brass"] = {"metallicFactor": 0.74, "roughnessFactor": 0.25, "chromaticity": "Warm Champagne Gold (R > G > B)"}

    j_bytes = json.dumps(g_json, separators=(",", ":")).encode("utf-8")
    while len(j_bytes) % 4 != 0:
        j_bytes += b" "
    tot_len = 12 + 8 + len(j_bytes) + 8 + len(b_chunk)
    out_bytes = struct.pack("<4sII", b"glTF", 2, tot_len) + struct.pack("<I4s", len(j_bytes), b"JSON") + j_bytes + struct.pack("<I4s", len(b_chunk), b"BIN\x00") + b_chunk
    tmp_v31_glb.write_bytes(out_bytes)
    out_v31_glb = OUT_DIR / "spellblade-v31-ingame-review-candidate.glb"
    out_v31_glb.write_bytes(out_bytes)

    ev31 = StandardGltfEvaluator(str(out_v31_glb))
    P0, _, T0, _, _, _, _ = ev31.evaluate_scene_meshes(None, 0.0)
    sha_v31_glb = hashlib.sha256(out_v31_glb.read_bytes()).hexdigest()
    print(f"[OK] Saved {out_v31_glb.name}: {out_v31_glb.stat().st_size:,} bytes, V={len(P0)}, T={len(T0)}, Mats={len(ev31.gltf['materials'])}, Clips={len(ev31.gltf['animations'])}, SHA256={sha_v31_glb}")


# ==============================================================================
# PART 2: FIGHT-AND-FLIGHT 19.5° PRE-STEERING SIMULATION DASH TRIM ALIGNMENT
# ==============================================================================

def build_faf_v30_sim19p5_dash():
    """
    Produces `fight-and-flight-v30-sim19p5-dash.glb` and `fight-and-flight-v30-sim19p5-dash.blend`
    (while keeping `fight-and-flight-v29-narrowed-dash.glb` untouched for rollback):
      - Updates standalone preview clips (`Clips 19, 47, 48`) so `Node 1 (Main_Apparatus_Chassis)`
        uses Castleward's authoritative `19.5°` offensive Dash trim before steering (instead of
        `24.0°` chassis + `14.0°` shaft = `38.0°`), and `Node 8 (Rotor_Shaft_And_Bearing)` uses `0.0°`
        unconditional local pitch override (`19.5°` world thrust vector before steering).
      - Preserves the 5 narrowed runtime Dash clips (`Clips 49..53`, `24` and `12` channels) which
        exclude `Node 1` and `Node 8/9` entirely so the runtime simulation remains 100% authoritative!
    """
    from build_faf_v29_narrowed_dash_and_blend import load_glb, save_glb, quat_from_euler_xyz, ensure_quat_continuity, _smoothstep, append_accessor
    src_glb = OUT_DIR / "fight-and-flight-v29-narrowed-dash.glb"
    gltf, bin_data = load_glb(src_glb)

    # Recalibrate Node 1 (Chassis) and Node 8 (Rotor Shaft) in standalone preview Clips 19, 47, 48 to 19.5 deg pre-steering Dash trim!
    for clip_name, n_keys, dur_s, mode in [
        ("Posture_12_Offensive_Dash_Entry_Hold_Recovery", 55, 1.80, "full_180"),
        ("Dash_01_Sustained_Attack_Flight_Loop", 25, 0.80, "loop_080"),
        ("Dash_02_Release_Flare_Brake_And_Recovery", 25, 0.70, "rel_070"),
    ]:
        anim = next(a for a in gltf["animations"] if a["name"] == clip_name)
        times = [round(dur_s * i / float(n_keys - 1), 5) for i in range(n_keys)]
        n1_T, n1_R = [], []
        n8_T, n8_R = [], []
        for t_sec in times:
            if mode == "full_180":
                if t_sec <= 0.38:
                    w = t_sec / 0.38
                    dash_w = _smoothstep(0.0, 1.0, w) + 0.08 * math.sin(w * math.pi)
                    flare = 0.0
                elif t_sec <= 1.15:
                    dash_w = 1.0
                    flare = 0.0
                else:
                    w = (t_sec - 1.15) / 0.65
                    dash_w = 1.0 - _smoothstep(0.0, 1.0, w)
                    flare = math.sin(w * math.pi)
                u_ph = t_sec / 0.80
            elif mode == "loop_080":
                dash_w = 1.0
                flare = 0.0
                u_ph = t_sec / 0.80
            else:
                u = t_sec / 0.70
                dash_w = 1.0 - _smoothstep(0.0, 0.75, u)
                flare = math.sin(min(1.0, u / 0.85) * math.pi)
                u_ph = u
            s_osc = math.sin(2.0 * math.pi * 2.0 * u_ph) * dash_w
            c_osc = math.cos(2.0 * math.pi * 2.0 * u_ph) * dash_w

            # Authoritative 19.5 deg pre-steering Dash trim on Node 1 (-8.5 deg flare on release)
            n1_T.append([0.0, round(0.028 * dash_w - 0.036 * flare + 0.008 * s_osc, 4), 0.0])
            n1_R.append(quat_from_euler_xyz(19.5 * dash_w - 8.5 * flare + 0.9 * s_osc, 0.0, 1.2 * c_osc))

            # Node 8 (Rotor Shaft): 0.0 deg unconditional pitch override before steering (only micro 0.6 deg thrust oscillation)
            n8_T.append([0.0, 1.985, -0.025])
            n8_R.append(quat_from_euler_xyz(0.6 * s_osc - 3.5 * flare, 0.0, 0.0))

        n1_R = ensure_quat_continuity(n1_R)
        n8_R = ensure_quat_continuity(n8_R)
        acc_n1_T = append_accessor(gltf, bin_data, np.array(n1_T, dtype=np.float32), "VEC3")
        acc_n1_R = append_accessor(gltf, bin_data, np.array(n1_R, dtype=np.float32), "VEC4")
        acc_n8_T = append_accessor(gltf, bin_data, np.array(n8_T, dtype=np.float32), "VEC3")
        acc_n8_R = append_accessor(gltf, bin_data, np.array(n8_R, dtype=np.float32), "VEC4")

        for ch in anim["channels"]:
            nid = ch["target"]["node"]
            pth = ch["target"]["path"]
            s_idx = ch["sampler"]
            if nid == 1 and pth == "translation":
                anim["samplers"][s_idx]["output"] = acc_n1_T
            elif nid == 1 and pth == "rotation":
                anim["samplers"][s_idx]["output"] = acc_n1_R
            elif nid == 8 and pth == "translation":
                anim["samplers"][s_idx]["output"] = acc_n8_T
            elif nid == 8 and pth == "rotation":
                anim["samplers"][s_idx]["output"] = acc_n8_R

    # Update animationLayerContract metadata to explicitly state the ~19.5 deg pre-steering simulation trim
    contract = gltf["extras"]["animationLayerContract"]
    contract["schemaVersion"] = "Castleward-FAF-v3.0-Sim19p5-Narrowed-Dash-Composition-Contract"
    contract["authoritativeSimulationDashTrimRule"] = (
        "Castleward's authoritative simulation offensive Dash trim is ~19.5 deg forward pitch before dynamic steering "
        "(NOT an unconditional 24 deg chassis pitch + 14 deg shaft tilt = 38 deg). Runtime simulation MUST remain 100% "
        "authoritative over Node 1 (Main_Apparatus_Chassis) and Node 8/9 (Rotor Shaft & Hub). Narrowed production Dash "
        "clips (Clips 49..53) contain ZERO channels on Nodes 0, 1, 8, 9, 5..7, 10..11, 61..64 so they compose seamlessly "
        "under whatever pitch/steering trim the simulation commands."
    )
    contract["explicitRuntimeTrackMasks"]["Layer_0_Authoritative_Sim_Pitch_And_Rotor_Spin"]["notes"] = (
        "Simulation owns world position/velocity, authoritative Dash pre-steering trim (~19.5 deg on Node 1 + live steering "
        "modulation, 0.0 deg unconditional shaft tilt override on Node 8), and rotor angular velocity (Node 9 & gears 5..7)."
    )

    tmp_glb = WORK_DIR / "fight-and-flight-v30-sim19p5-dash.glb"
    save_glb(tmp_glb, gltf, bin_data)
    out_glb = OUT_DIR / "fight-and-flight-v30-sim19p5-dash.glb"
    out_glb.write_bytes(tmp_glb.read_bytes())

    raw_blend_src = WORK_DIR / "fight-and-flight-v27-review-uncompressed.blend"
    raw_bytes = bytearray(raw_blend_src.read_bytes())
    endb_pos = raw_bytes.rfind(b"ENDB")
    glb_sha = hashlib.sha256(tmp_glb.read_bytes()).hexdigest()
    contract_payload = json.dumps({
        "blendRevision": "fight-and-flight-v30-sim19p5-dash.blend",
        "pairedGlb": "fight-and-flight-v30-sim19p5-dash.glb",
        "pairedGlbSha256": glb_sha,
        "animationCount": len(gltf["animations"]),
        "authoritativeSimDashTrimDeg": 19.5,
        "animationLayerContract": contract
    }, indent=2).encode("utf-8")
    while len(contract_payload) % 8 != 0:
        contract_payload += b"\x00"
    bhead = struct.pack("<4siQii", b"REND", len(contract_payload), 0x7F00990055667788, 0, 1)
    updated_raw = bytes(raw_bytes[:endb_pos] + bhead + contract_payload + raw_bytes[endb_pos:])

    tmp_blend = WORK_DIR / "fight-and-flight-v30-sim19p5-dash.blend"
    zstd_compress_blend(updated_raw, tmp_blend)
    out_blend = OUT_DIR / "fight-and-flight-v30-sim19p5-dash.blend"
    out_blend.write_bytes(tmp_blend.read_bytes())
    blend_sha = hashlib.sha256(tmp_blend.read_bytes()).hexdigest()
    print(f"[OK] Built {out_glb.name}: {out_glb.stat().st_size:,} B, SHA-256={glb_sha}, clips={len(gltf['animations'])}")
    print(f"[OK] Built {out_blend.name}: {out_blend.stat().st_size:,} B, SHA-256={blend_sha}")


if __name__ == "__main__":
    export_spellblade_v31()
    build_faf_v30_sim19p5_dash()
